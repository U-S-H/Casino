CREATE TABLE "casino_bets" (
	"id" text PRIMARY KEY,
	"round_id" text NOT NULL,
	"game" text NOT NULL,
	"user_id" text NOT NULL,
	"choice" text NOT NULL,
	"stake" bigint NOT NULL,
	"terms" jsonb NOT NULL,
	"auto_x100" integer,
	"status" text DEFAULT 'active' NOT NULL,
	"cashout_x100" integer,
	"payout" bigint DEFAULT 0 NOT NULL,
	"fee" bigint DEFAULT 0 NOT NULL,
	"paid" jsonb NOT NULL,
	"client_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"settled_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "casino_disputes" (
	"id" serial PRIMARY KEY,
	"bet_id" text NOT NULL,
	"round_id" text NOT NULL,
	"game" text NOT NULL,
	"user_id" text NOT NULL,
	"reason" text NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"resolution" text,
	"resolved_by" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "casino_rounds" (
	"id" text PRIMARY KEY,
	"game" text NOT NULL,
	"round_no" integer NOT NULL,
	"status" text DEFAULT 'betting' NOT NULL,
	"server_seed" text NOT NULL,
	"seed_hash" text NOT NULL,
	"params" jsonb NOT NULL,
	"opens_at" timestamp with time zone NOT NULL,
	"closes_at" timestamp with time zone NOT NULL,
	"result_at" timestamp with time zone NOT NULL,
	"ends_at" timestamp with time zone NOT NULL,
	"result" jsonb,
	"bet_count" integer DEFAULT 0 NOT NULL,
	"total_stake" bigint DEFAULT 0 NOT NULL,
	"total_payout" bigint DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"settled_at" timestamp with time zone
);
--> statement-breakpoint
CREATE UNIQUE INDEX "casino_bets_round_user_choice_uq" ON "casino_bets" ("round_id","user_id","choice") WHERE status <> 'cancelled';--> statement-breakpoint
CREATE UNIQUE INDEX "casino_bets_user_key_uq" ON "casino_bets" ("user_id","client_key");--> statement-breakpoint
CREATE INDEX "casino_bets_round_idx" ON "casino_bets" ("round_id","status");--> statement-breakpoint
CREATE INDEX "casino_bets_user_idx" ON "casino_bets" ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "casino_bets_game_idx" ON "casino_bets" ("game","created_at");--> statement-breakpoint
CREATE INDEX "casino_disputes_status_idx" ON "casino_disputes" ("game","status","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "casino_disputes_bet_user_uq" ON "casino_disputes" ("bet_id","user_id");--> statement-breakpoint
CREATE UNIQUE INDEX "casino_rounds_game_no_uq" ON "casino_rounds" ("game","round_no");--> statement-breakpoint
CREATE INDEX "casino_rounds_due_idx" ON "casino_rounds" ("game","status","result_at");--> statement-breakpoint
CREATE INDEX "casino_rounds_created_idx" ON "casino_rounds" ("game","created_at");--> statement-breakpoint
CREATE OR REPLACE FUNCTION casino_rounds_guard() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'casino rounds cannot be deleted';
  END IF;
  IF NEW.id <> OLD.id OR NEW.game <> OLD.game OR NEW.round_no <> OLD.round_no
     OR NEW.server_seed <> OLD.server_seed OR NEW.seed_hash <> OLD.seed_hash OR NEW.params <> OLD.params
     OR NEW.opens_at <> OLD.opens_at OR NEW.closes_at <> OLD.closes_at OR NEW.result_at <> OLD.result_at OR NEW.ends_at <> OLD.ends_at THEN
    RAISE EXCEPTION 'casino round commitments are immutable';
  END IF;
  IF OLD.status = 'settled' THEN
    RAISE EXCEPTION 'settled casino rounds are immutable';
  END IF;
  RETURN NEW;
END
$$ LANGUAGE plpgsql;
--> statement-breakpoint
CREATE TRIGGER casino_rounds_guard BEFORE UPDATE OR DELETE ON casino_rounds FOR EACH ROW EXECUTE FUNCTION casino_rounds_guard();
--> statement-breakpoint
CREATE OR REPLACE FUNCTION casino_bets_guard() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'casino bets cannot be deleted';
  END IF;
  IF NEW.id <> OLD.id OR NEW.round_id <> OLD.round_id OR NEW.game <> OLD.game OR NEW.user_id <> OLD.user_id
     OR NEW.choice <> OLD.choice OR NEW.stake <> OLD.stake OR NEW.terms <> OLD.terms OR NEW.paid <> OLD.paid
     OR NEW.client_key <> OLD.client_key OR NEW.auto_x100 IS DISTINCT FROM OLD.auto_x100 THEN
    RAISE EXCEPTION 'casino bet terms are immutable';
  END IF;
  IF OLD.status <> 'active' THEN
    RAISE EXCEPTION 'settled casino bets are immutable';
  END IF;
  RETURN NEW;
END
$$ LANGUAGE plpgsql;
--> statement-breakpoint
CREATE TRIGGER casino_bets_guard BEFORE UPDATE OR DELETE ON casino_bets FOR EACH ROW EXECUTE FUNCTION casino_bets_guard();
