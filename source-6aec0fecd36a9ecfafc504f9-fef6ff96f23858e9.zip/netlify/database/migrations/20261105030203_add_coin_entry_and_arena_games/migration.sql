CREATE TABLE "match_reports" (
	"id" serial PRIMARY KEY,
	"room_id" text NOT NULL,
	"user_id" text NOT NULL,
	"reason" text NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"resolution" text,
	"resolved_by" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone
);
--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "game" text DEFAULT 'ludo' NOT NULL;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "entry_fee" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "fee_percent" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "stake_status" text DEFAULT 'none' NOT NULL;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "result" jsonb;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "cancel_reason" text;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "disputed" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "started_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "game_rooms" ADD COLUMN "ended_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "games" ADD COLUMN "game" text DEFAULT 'ludo' NOT NULL;--> statement-breakpoint
ALTER TABLE "games" ADD COLUMN "entry_fee" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "games" ADD COLUMN "prize_pool" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "games" ADD COLUMN "platform_fee" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "games" ADD COLUMN "reason" text;--> statement-breakpoint
CREATE INDEX "rooms_game_idx" ON "game_rooms" ("game","status","entry_fee");--> statement-breakpoint
CREATE INDEX "rooms_stake_idx" ON "game_rooms" ("stake_status","updated_at");--> statement-breakpoint
CREATE INDEX "match_reports_status_idx" ON "match_reports" ("status","created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "match_reports_room_user_uq" ON "match_reports" ("room_id","user_id");