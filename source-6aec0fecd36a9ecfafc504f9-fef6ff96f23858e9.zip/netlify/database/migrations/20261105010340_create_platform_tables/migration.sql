CREATE TABLE "admins" (
	"user_id" text PRIMARY KEY,
	"email" text NOT NULL,
	"granted_by" text NOT NULL,
	"granted_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY,
	"actor_id" text NOT NULL,
	"actor_email" text NOT NULL,
	"action" text NOT NULL,
	"target_type" text,
	"target_id" text,
	"details" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "deposits" (
	"id" text PRIMARY KEY,
	"user_id" text NOT NULL,
	"package_id" text NOT NULL,
	"package_name" text NOT NULL,
	"coins" integer NOT NULL,
	"bonus_coins" integer DEFAULT 0 NOT NULL,
	"amount_pkr" integer NOT NULL,
	"method" text NOT NULL,
	"pay_to_account" text NOT NULL,
	"sender_account" text,
	"tid" text NOT NULL,
	"tid_normalized" text NOT NULL,
	"screenshot_key" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"flags" jsonb DEFAULT '[]' NOT NULL,
	"admin_note" text,
	"reviewed_by" text,
	"reviewed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "friendships" (
	"requester_id" text,
	"addressee_id" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "friendships_pkey" PRIMARY KEY("requester_id","addressee_id")
);
--> statement-breakpoint
CREATE TABLE "game_players" (
	"game_id" text,
	"user_id" text,
	"won" boolean NOT NULL,
	"rating_delta" integer DEFAULT 0 NOT NULL,
	"ended_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "game_players_pkey" PRIMARY KEY("game_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "game_rooms" (
	"id" text PRIMARY KEY,
	"code" text NOT NULL UNIQUE,
	"mode" text NOT NULL,
	"is_private" boolean DEFAULT false NOT NULL,
	"password_hash" text,
	"host_id" text NOT NULL,
	"status" text DEFAULT 'waiting' NOT NULL,
	"seats" jsonb NOT NULL,
	"state" jsonb,
	"version" integer DEFAULT 0 NOT NULL,
	"turn_deadline" timestamp with time zone,
	"tournament_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "games" (
	"id" text PRIMARY KEY,
	"room_id" text NOT NULL,
	"mode" text NOT NULL,
	"players" jsonb NOT NULL,
	"winner_team" integer,
	"tournament_id" text,
	"turns" integer DEFAULT 0 NOT NULL,
	"started_at" timestamp with time zone NOT NULL,
	"ended_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "login_history" (
	"id" serial PRIMARY KEY,
	"user_id" text NOT NULL,
	"user_agent" text,
	"ip_hash" text,
	"country" text,
	"city" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY,
	"user_id" text,
	"audience" text DEFAULT 'user' NOT NULL,
	"kind" text NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"link" text,
	"read_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rate_limits" (
	"key" text PRIMARY KEY,
	"window_start" timestamp with time zone NOT NULL,
	"count" integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "referrals" (
	"id" serial PRIMARY KEY,
	"referrer_id" text NOT NULL,
	"referred_id" text NOT NULL UNIQUE,
	"code" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"reward" integer DEFAULT 0 NOT NULL,
	"flags" jsonb DEFAULT '[]' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "room_messages" (
	"id" serial PRIMARY KEY,
	"room_id" text NOT NULL,
	"user_id" text NOT NULL,
	"name" text NOT NULL,
	"text" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "settings" (
	"key" text PRIMARY KEY,
	"value" jsonb NOT NULL,
	"updated_by" text,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "support_tickets" (
	"id" text PRIMARY KEY,
	"user_id" text NOT NULL,
	"subject" text NOT NULL,
	"message" text NOT NULL,
	"category" text DEFAULT 'general' NOT NULL,
	"priority" text DEFAULT 'medium' NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"admin_reply" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tournament_entries" (
	"tournament_id" text,
	"user_id" text,
	"points" integer DEFAULT 0 NOT NULL,
	"wins" integer DEFAULT 0 NOT NULL,
	"games" integer DEFAULT 0 NOT NULL,
	"rank" integer,
	"prize" integer DEFAULT 0 NOT NULL,
	"joined_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "tournament_entries_pkey" PRIMARY KEY("tournament_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "tournaments" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"kind" text NOT NULL,
	"mode" text NOT NULL,
	"entry_fee" integer DEFAULT 0 NOT NULL,
	"prize_coins" integer DEFAULT 0 NOT NULL,
	"capacity" integer DEFAULT 64 NOT NULL,
	"invite_code" text,
	"starts_at" timestamp with time zone NOT NULL,
	"ends_at" timestamp with time zone NOT NULL,
	"status" text DEFAULT 'upcoming' NOT NULL,
	"created_by" text NOT NULL,
	"settled_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "transactions" (
	"id" text PRIMARY KEY,
	"user_id" text NOT NULL,
	"type" text NOT NULL,
	"bucket" text NOT NULL,
	"amount" bigint NOT NULL,
	"balance_after" bigint NOT NULL,
	"label" text NOT NULL,
	"status" text DEFAULT 'completed' NOT NULL,
	"ref_type" text,
	"ref_id" text,
	"idempotency_key" text NOT NULL UNIQUE,
	"created_by" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" text PRIMARY KEY,
	"public_id" text NOT NULL UNIQUE,
	"email" text NOT NULL,
	"display_name" text NOT NULL,
	"avatar_key" text,
	"referral_code" text NOT NULL UNIQUE,
	"referred_by" text,
	"status" text DEFAULT 'active' NOT NULL,
	"status_reason" text,
	"suspended_until" timestamp with time zone,
	"age_confirmed" boolean DEFAULT false NOT NULL,
	"date_of_birth" text,
	"kyc_status" text DEFAULT 'not_started' NOT NULL,
	"kyc_name" text,
	"kyc_doc_number" text,
	"kyc_doc_key" text,
	"self_excluded_until" timestamp with time zone,
	"daily_deposit_limit_pkr" integer,
	"rating" integer DEFAULT 1200 NOT NULL,
	"games_played" integer DEFAULT 0 NOT NULL,
	"games_won" integer DEFAULT 0 NOT NULL,
	"captures" integer DEFAULT 0 NOT NULL,
	"daily_streak" integer DEFAULT 0 NOT NULL,
	"last_daily_claim" text,
	"password_changed_at" timestamp with time zone,
	"notifications_seen_at" timestamp with time zone,
	"signup_ip_hash" text,
	"country" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wallets" (
	"user_id" text PRIMARY KEY,
	"purchased" bigint DEFAULT 0 NOT NULL,
	"bonus" bigint DEFAULT 0 NOT NULL,
	"winnings" bigint DEFAULT 0 NOT NULL,
	"reserved" bigint DEFAULT 0 NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "withdrawals" (
	"id" text PRIMARY KEY,
	"user_id" text NOT NULL,
	"method" text NOT NULL,
	"account_holder" text NOT NULL,
	"account_number" text NOT NULL,
	"coins" integer NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"payment_reference" text,
	"admin_note" text,
	"idempotency_key" text NOT NULL UNIQUE,
	"reviewed_by" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "audit_created_idx" ON "audit_logs" ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "deposits_method_tid_uq" ON "deposits" ("method","tid_normalized");--> statement-breakpoint
CREATE INDEX "deposits_status_idx" ON "deposits" ("status","created_at");--> statement-breakpoint
CREATE INDEX "deposits_user_idx" ON "deposits" ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "friend_addressee_idx" ON "friendships" ("addressee_id");--> statement-breakpoint
CREATE INDEX "game_players_user_idx" ON "game_players" ("user_id","ended_at");--> statement-breakpoint
CREATE INDEX "rooms_status_idx" ON "game_rooms" ("status","mode","is_private");--> statement-breakpoint
CREATE INDEX "games_ended_idx" ON "games" ("ended_at");--> statement-breakpoint
CREATE INDEX "login_history_user_idx" ON "login_history" ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "notifications_user_idx" ON "notifications" ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "notifications_aud_idx" ON "notifications" ("audience","created_at");--> statement-breakpoint
CREATE INDEX "referrals_referrer_idx" ON "referrals" ("referrer_id");--> statement-breakpoint
CREATE INDEX "room_messages_room_idx" ON "room_messages" ("room_id","id");--> statement-breakpoint
CREATE INDEX "tickets_status_idx" ON "support_tickets" ("status","created_at");--> statement-breakpoint
CREATE INDEX "tickets_user_idx" ON "support_tickets" ("user_id");--> statement-breakpoint
CREATE INDEX "entries_user_idx" ON "tournament_entries" ("user_id");--> statement-breakpoint
CREATE INDEX "tournaments_status_idx" ON "tournaments" ("status","starts_at");--> statement-breakpoint
CREATE INDEX "transactions_user_idx" ON "transactions" ("user_id","created_at");--> statement-breakpoint
CREATE INDEX "users_rating_idx" ON "users" ("rating");--> statement-breakpoint
CREATE INDEX "users_created_idx" ON "users" ("created_at");--> statement-breakpoint
CREATE INDEX "withdrawals_status_idx" ON "withdrawals" ("status","created_at");--> statement-breakpoint
CREATE INDEX "withdrawals_user_idx" ON "withdrawals" ("user_id");