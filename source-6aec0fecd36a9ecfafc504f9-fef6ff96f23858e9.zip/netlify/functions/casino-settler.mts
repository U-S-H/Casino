import type { Config } from '@netlify/functions'

import { settleDue } from '../../src/server/lib/casino.js'

/**
 * Every minute: settles Dragon Tiger and Aviator rounds whose result time has
 * passed, even when no player is online to trigger it (e.g. everyone closed the
 * tab mid-round). Settlement is idempotent, so overlapping with player polls is safe.
 */
export default async () => {
  for (let i = 0; i < 4; i++) {
    const n = (await settleDue('dragon_tiger')) + (await settleDue('aviator'))
    if (n < 5) break
  }
}

export const config: Config = { schedule: '* * * * *' }
