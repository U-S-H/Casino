import type { Config } from '@netlify/functions'

import { ensureRecurringTournaments, settleDueTournaments } from '../../src/server/lib/tournaments.js'

/** Every 15 minutes: settle finished tournaments (automatic results) and schedule new daily/weekly ones. */
export default async () => {
  await settleDueTournaments()
  await ensureRecurringTournaments()
}

export const config: Config = { schedule: '*/15 * * * *' }
