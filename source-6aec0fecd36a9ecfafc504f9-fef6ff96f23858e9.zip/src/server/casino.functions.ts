import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, inArray, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { casinoBets, casinoDisputes, casinoRounds, users, wallets } from '../../db/schema.js'
import { betError, CASINO_INFO, type CasinoKey } from '../lib/games/casino.js'
import { notifyAdmins } from './lib/audit.js'
import { requireViewer, type Viewer } from './lib/auth.js'
import { betsOf, cancelBet, cashOut, getCasinoConfig, placeBet, publicBet, publicRound, recentRounds, tick } from './lib/casino.js'
import { rateLimit } from './lib/ratelimit.js'
import { getSettings } from './lib/settings.js'
import { isUniqueViolation, UserError } from './lib/util.js'

/**
 * Dragon Tiger and Aviator server functions. Every handler checks the
 * signed-in player on the server; the browser only ever sends intents
 * (round, side/slot, amount, optional auto target) — never results or payouts.
 */

const gameEnum = z.enum(['dragon_tiger', 'aviator'])

async function balanceOf(userId: string) {
  const [w] = await db.select().from(wallets).where(eq(wallets.userId, userId))
  return w ? w.bonus + w.purchased + w.winnings : 0
}

async function assertCanBet(v: Viewer, game: CasinoKey) {
  const s = await getSettings()
  if (s.maintenance.enabled && !v.isAdmin) throw new UserError('The arena is in maintenance mode. Please try again soon.')
  if (v.profile.selfExcludedUntil && v.profile.selfExcludedUntil > new Date()) throw new UserError('Play is paused while your self-exclusion is active.')
  const cfg = await getCasinoConfig()
  const gc = cfg[game]
  if (!gc.enabled) throw new UserError(`${CASINO_INFO[game].name} is currently unavailable.`)
  if (gc.paused) throw new UserError(gc.pauseMessage || `${CASINO_INFO[game].name} is paused for maintenance.`)
  return cfg
}

const mask = (name: string) => (name.length <= 2 ? `${name[0] ?? '*'}*` : `${name.slice(0, 2)}${'*'.repeat(Math.min(4, name.length - 2))}`)

/** Public game configuration for lobby cards (enabled/paused, limits). */
export const getCasinoLobby = createServerFn({ method: 'GET' }).handler(async () => {
  await requireViewer()
  return getCasinoConfig()
})

/**
 * Live state for one game. Polling this also advances the game (settles due
 * rounds, opens the next one, pays due Aviator auto cash-outs).
 */
export const getCasinoState = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const { cfg, round } = await tick(data.game)
    const now = Date.now()
    const history = await recentRounds(data.game, 40)
    const ids = [...(round ? [round.id] : []), ...history.slice(0, 15).map((r) => r.id)]
    const mine = await betsOf(v.profile.id, ids)

    // Everyone's bets in the current round (names masked) — the "live bets" list.
    let live: { name: string; choice: string; stake: number; status: string; cashoutX100: number | null; payout: number; me: boolean }[] = []
    let totals = { dragon: 0, tiger: 0, tie: 0, players: 0 }
    if (round) {
      const rows = await db
        .select({ userId: casinoBets.userId, name: users.displayName, choice: casinoBets.choice, stake: casinoBets.stake, status: casinoBets.status, cashoutX100: casinoBets.cashoutX100, payout: casinoBets.payout })
        .from(casinoBets)
        .leftJoin(users, eq(users.id, casinoBets.userId))
        .where(and(eq(casinoBets.roundId, round.id), sql`${casinoBets.status} <> 'cancelled'`))
        .orderBy(desc(casinoBets.stake))
        .limit(60)
      live = rows.map((r) => ({ name: r.userId === v.profile.id ? 'You' : mask(r.name ?? 'Player'), choice: r.choice, stake: r.stake, status: r.status, cashoutX100: r.cashoutX100, payout: r.payout, me: r.userId === v.profile.id }))
      totals = {
        dragon: rows.filter((r) => r.choice === 'dragon').reduce((s, r) => s + r.stake, 0),
        tiger: rows.filter((r) => r.choice === 'tiger').reduce((s, r) => s + r.stake, 0),
        tie: rows.filter((r) => r.choice === 'tie').reduce((s, r) => s + r.stake, 0),
        players: new Set(rows.map((r) => r.userId)).size,
      }
    }
    return {
      config: cfg[data.game],
      serverNow: now,
      round: round ? publicRound(round, now) : null,
      history: history.map((r) => publicRound(r, now)),
      myBets: mine.filter((b) => b.status !== 'cancelled').map(publicBet).sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)),
      live,
      totals,
      balance: await balanceOf(v.profile.id),
    }
  })
export type CasinoState = Awaited<ReturnType<typeof getCasinoState>>

export const placeCasinoBet = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      game: gameEnum,
      roundId: z.string().min(3).max(20),
      choice: z.enum(['dragon', 'tiger', 'tie', '1', '2']),
      amount: z.number().int().min(1).max(10_000_000),
      autoX100: z.number().int().min(101).max(1_000_000).nullable().optional(),
      clientKey: z.string().min(8).max(64),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`casino-bet:${v.profile.id}`, 20, 10)
    const cfg = await assertCanBet(v, data.game)
    const err = betError(cfg[data.game], data.amount)
    if (err) throw new UserError(err)
    const r = await placeBet(v.profile.id, cfg, data)
    return { bet: publicBet(r.bet), duplicate: r.duplicate, balance: await balanceOf(v.profile.id) }
  })

export const cancelCasinoBet = createServerFn({ method: 'POST' })
  .validator(z.object({ betId: z.string().min(3).max(20) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`casino-bet:${v.profile.id}`, 20, 10)
    const b = await cancelBet(v.profile.id, data.betId)
    return { bet: publicBet(b), balance: await balanceOf(v.profile.id) }
  })

export const cashOutCasinoBet = createServerFn({ method: 'POST' })
  .validator(z.object({ betId: z.string().min(3).max(20) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`casino-cash:${v.profile.id}`, 20, 10)
    const r = await cashOut(v.profile.id, data.betId)
    return { bet: publicBet(r.bet), duplicate: r.duplicate, balance: await balanceOf(v.profile.id) }
  })

/** A settled round with its revealed seed, for the provably-fair verifier. */
export const getCasinoRound = createServerFn({ method: 'GET' })
  .validator(z.object({ id: z.string().trim().toUpperCase().pipe(z.string().regex(/^(DT|AV)-\d{1,9}$/)) }))
  .handler(async ({ data }) => {
    await requireViewer()
    const [r] = await db.select().from(casinoRounds).where(eq(casinoRounds.id, data.id))
    if (!r) throw new UserError('Round not found.')
    return publicRound(r)
  })

/** The player's own bet history for one game. */
export const myCasinoBets = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const rows = await db
      .select()
      .from(casinoBets)
      .where(and(eq(casinoBets.userId, v.profile.id), eq(casinoBets.game, data.game)))
      .orderBy(desc(casinoBets.createdAt))
      .limit(50)
    const disputes = rows.length
      ? await db.select({ betId: casinoDisputes.betId, status: casinoDisputes.status, resolution: casinoDisputes.resolution }).from(casinoDisputes).where(inArray(casinoDisputes.betId, rows.map((r) => r.id)))
      : []
    return rows.map((b) => ({ ...publicBet(b), dispute: disputes.find((d) => d.betId === b.id) ?? null }))
  })

export const reportCasinoBet = createServerFn({ method: 'POST' })
  .validator(z.object({ betId: z.string().min(3).max(20), reason: z.string().trim().min(10).max(500) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`casino-report:${v.profile.id}`, 5, 3600)
    const [bet] = await db.select().from(casinoBets).where(and(eq(casinoBets.id, data.betId), eq(casinoBets.userId, v.profile.id)))
    if (!bet) throw new UserError('Bet not found.')
    try {
      await db.insert(casinoDisputes).values({ betId: bet.id, roundId: bet.roundId, game: bet.game, userId: v.profile.id, reason: data.reason })
    } catch (e) {
      if (isUniqueViolation(e)) throw new UserError('You already reported this bet. Our team will review it.')
      throw e
    }
    const name = CASINO_INFO[bet.game as CasinoKey].name
    await notifyAdmins({ kind: 'dispute', title: `${name} dispute`, body: `${v.profile.displayName} reported bet ${bet.id} (round ${bet.roundId}).`, link: `/admin?section=${bet.game === 'aviator' ? 'aviator' : 'dragon-tiger'}` })
    return { ok: true }
  })
