// @vitest-environment node
/**
 * Withdrawal (cash-out) integration tests against a real Postgres.
 * Run with: LKA_IT_DB=postgres://… npx vitest run src/server/withdrawals.integration.test.ts
 */
import { beforeAll, describe, expect, it } from 'vitest'

const url = process.env.LKA_IT_DB
if (url) {
  process.env.NETLIFY_DB_URL = url
  process.env.NETLIFY_DB_DRIVER = 'server'
}

describe.skipIf(!url)('withdrawals', () => {
  let db: typeof import('../../db/index.js')['db']
  let s: typeof import('../../db/schema.js')
  let ledger: typeof import('./lib/ledger.js')
  let wd: typeof import('./lib/withdrawals.js')
  let util: typeof import('./lib/util.js')
  let orm: typeof import('drizzle-orm')
  const run = Date.now()
  const U = (n: string) => `wd-${n}-${run}`
  const admin = { id: 'wd-admin', email: 'admin@x.test' }

  async function user(n: string, coins: { bonus?: number; purchased?: number; winnings?: number }) {
    const id = U(n)
    await db.insert(s.users).values({ id, publicId: `LKA-${util.randomCode(6)}`, email: `${id}@x.test`, displayName: n, referralCode: util.randomCode(8), kycStatus: 'verified' })
    for (const [bucket, amount] of Object.entries(coins))
      if (amount) await db.transaction((tx) => ledger.postLedger(tx, { userId: id, bucket: bucket as 'bonus', amount, type: 'promo', label: 'seed', idempotencyKey: `seed:${id}:${bucket}` }))
    return id
  }
  const wallet = async (id: string) => (await db.select().from(s.wallets).where(orm.eq(s.wallets.userId, id)))[0]!
  const req = (userId: string, coins: number, key = crypto.randomUUID()) =>
    wd.createWithdrawal({ userId, displayName: 'P', method: 'jazzcash', accountHolder: 'Test Player', accountNumber: '03001234567', coins, idempotencyKey: key, coinsPerPkr: 5 })
  const set = (id: string, status: 'approved' | 'processing' | 'paid' | 'rejected', reference = '', note = '') => wd.updateWithdrawal({ id, status, reference, note, admin })
  const row = async (id: string) => (await db.select().from(s.withdrawals).where(orm.eq(s.withdrawals.id, id)))[0]!
  const txs = async (userId: string) => db.select().from(s.transactions).where(orm.and(orm.eq(s.transactions.userId, userId), orm.eq(s.transactions.type, 'withdrawal')))

  beforeAll(async () => {
    ;[{ db }, s, ledger, wd, util, orm] = await Promise.all([
      import('../../db/index.js'),
      import('../../db/schema.js'),
      import('./lib/ledger.js'),
      import('./lib/withdrawals.js'),
      import('./lib/util.js'),
      import('drizzle-orm'),
    ])
  })

  it('reserves winnings, goes pending → approved → processing → paid and finalises once', async () => {
    const a = await user('pay', { winnings: 5000, bonus: 700, purchased: 300 })
    const { id } = await req(a, 2000)
    let w = await wallet(a)
    expect([w.winnings, w.reserved, w.bonus, w.purchased]).toEqual([3000, 2000, 700, 300])
    expect((await row(id)).amountPkr).toBe(400)
    expect((await txs(a))[0]!.status).toBe('pending')

    await expect(set(id, 'paid', 'REF1')).rejects.toThrow(/cannot move/) // must be approved first
    await set(id, 'approved')
    await set(id, 'processing')
    await expect(set(id, 'paid')).rejects.toThrow(/reference/)
    await set(id, 'paid', `JC-${run}`)
    w = await wallet(a)
    expect([w.winnings, w.reserved]).toEqual([3000, 0])
    const t = await txs(a)
    expect(t).toHaveLength(1)
    expect(t[0]!.status).toBe('completed')
    expect(t[0]!.amount).toBe(-2000)

    // Paying or rejecting again does nothing.
    await expect(set(id, 'paid', `JC-${run}-b`)).rejects.toThrow(/cannot move/)
    await expect(set(id, 'rejected', '', 'late')).rejects.toThrow(/cannot move/)
    w = await wallet(a)
    expect([w.winnings, w.reserved]).toEqual([3000, 0])
    expect((await row(id)).status).toBe('paid')
  })

  it('rejecting returns the reserved coins exactly once', async () => {
    const a = await user('rej', { winnings: 1500 })
    const { id } = await req(a, 1500)
    expect((await wallet(a)).winnings).toBe(0)
    await expect(set(id, 'rejected')).rejects.toThrow(/reason/)
    await set(id, 'rejected', '', 'Name does not match CNIC')
    let w = await wallet(a)
    expect([w.winnings, w.reserved]).toEqual([1500, 0])
    await expect(set(id, 'rejected', '', 'again')).rejects.toThrow(/cannot move/)
    w = await wallet(a)
    expect(w.winnings).toBe(1500)
    const t = await txs(a)
    expect(t.map((x) => [x.amount, x.status]).sort()).toEqual([
      [-1500, 'refunded'],
      [1500, 'completed'],
    ].sort())
    expect((await row(id)).adminNote).toBe('Name does not match CNIC')
  })

  it('blocks over-balance, non-winnings coins, duplicate submits and a second open request', async () => {
    const a = await user('dup', { winnings: 3000, bonus: 10000 })
    await expect(req(a, 3001)).rejects.toThrow(/Insufficient/)
    const key = crypto.randomUUID()
    const [r1, r2] = await Promise.allSettled([req(a, 1000, key), req(a, 1000, key)])
    const ok = [r1, r2].filter((r) => r.status === 'fulfilled') as PromiseFulfilledResult<{ id: string }>[]
    expect(ok).toHaveLength(2)
    expect(new Set(ok.map((r) => r.value.id)).size).toBe(1)
    expect((await req(a, 1000, key)).duplicate).toBe(true)
    await expect(req(a, 1000)).rejects.toThrow(/already have an open/)
    const w = await wallet(a)
    expect([w.winnings, w.reserved, w.bonus]).toEqual([2000, 1000, 10000])
    expect(await txs(a)).toHaveLength(1)
  })

  it('serialises concurrent requests so the balance never goes negative', async () => {
    const a = await user('race', { winnings: 1000 })
    const res = await Promise.allSettled([req(a, 1000), req(a, 1000), req(a, 1000)])
    expect(res.filter((r) => r.status === 'fulfilled')).toHaveLength(1)
    const w = await wallet(a)
    expect([w.winnings, w.reserved]).toEqual([0, 1000])
  })

  it('rejects a payment reference already used for another payout', async () => {
    const a = await user('ref1', { winnings: 1000 })
    const b = await user('ref2', { winnings: 1000 })
    const x = await req(a, 1000)
    const y = await req(b, 1000)
    await set(x.id, 'approved')
    await set(y.id, 'approved')
    await set(x.id, 'paid', `SAME-${run}`)
    await expect(set(y.id, 'paid', `SAME-${run}`)).rejects.toThrow(/already used/)
    const w = await wallet(b)
    expect([w.winnings, w.reserved]).toEqual([0, 1000])
    expect((await row(y.id)).status).toBe('approved')
  })
})
