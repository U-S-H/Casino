import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { tournamentEntries, tournaments, users } from '../../db/schema.js'
import { requireViewer } from './lib/auth.js'
import { rateLimit } from './lib/ratelimit.js'
import { ensureRecurringTournaments, settleDueTournaments } from './lib/tournaments.js'
import { isUniqueViolation, newId, randomCode, UserError } from './lib/util.js'

export const listTournaments = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  await settleDueTournaments()
  await ensureRecurringTournaments()
  const rows = await db
    .select({
      t: tournaments,
      players: sql<number>`(select count(*)::int from tournament_entries e where e.tournament_id = ${tournaments.id})`,
      joined: sql<boolean>`exists(select 1 from tournament_entries e where e.tournament_id = ${tournaments.id} and e.user_id = ${v.profile.id})`,
    })
    .from(tournaments)
    .where(
      and(
        sql`${tournaments.status} in ('upcoming','live')`,
        sql`(${tournaments.kind} <> 'private' or ${tournaments.createdBy} = ${v.profile.id} or exists(select 1 from tournament_entries e where e.tournament_id = ${tournaments.id} and e.user_id = ${v.profile.id}))`,
      ),
    )
    .orderBy(tournaments.endsAt)
  return rows.map(({ t, players, joined }) => ({
    id: t.id,
    name: t.name,
    kind: t.kind,
    mode: t.mode,
    prizeCoins: t.prizeCoins,
    capacity: t.capacity,
    startsAt: t.startsAt,
    endsAt: t.endsAt,
    status: t.status,
    inviteCode: t.createdBy === v.profile.id ? t.inviteCode : null,
    players,
    joined,
  }))
})

export const joinTournament = createServerFn({ method: 'POST' })
  .validator(z.union([z.object({ id: z.string() }), z.object({ inviteCode: z.string().trim().min(4).max(12) })]))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`tjoin:${v.profile.id}`, 30, 600)
    const [t] = await db
      .select()
      .from(tournaments)
      .where('id' in data ? and(eq(tournaments.id, data.id), sql`kind <> 'private'`) : eq(tournaments.inviteCode, data.inviteCode.toUpperCase()))
    if (!t || t.status === 'finished' || t.status === 'cancelled') throw new UserError('Tournament not found or already finished.')
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(tournamentEntries).where(eq(tournamentEntries.tournamentId, t.id))
    if (n >= t.capacity) throw new UserError('This tournament is full.')
    await db.insert(tournamentEntries).values({ tournamentId: t.id, userId: v.profile.id }).onConflictDoNothing()
    return { id: t.id, name: t.name }
  })

export const createPrivateTournament = createServerFn({ method: 'POST' })
  .validator(z.object({ name: z.string().trim().min(3).max(40), mode: z.enum(['1v1', '2v2', '4p']), hours: z.number().int().min(1).max(168) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`tcreate:${v.profile.id}`, 3, 86400)
    for (let i = 0; i < 5; i++) {
      try {
        const id = newId('TN', 6)
        const inviteCode = randomCode(6)
        const now = new Date()
        await db.insert(tournaments).values({
          id,
          name: data.name,
          kind: 'private',
          mode: data.mode,
          prizeCoins: 0,
          capacity: 32,
          inviteCode,
          startsAt: now,
          endsAt: new Date(now.getTime() + data.hours * 3600_000),
          status: 'live',
          createdBy: v.profile.id,
        })
        await db.insert(tournamentEntries).values({ tournamentId: id, userId: v.profile.id })
        return { id, inviteCode }
      } catch (e) {
        if (!isUniqueViolation(e)) throw e
      }
    }
    throw new Error('Could not create tournament')
  })

export const getStandings = createServerFn({ method: 'GET' })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const [t] = await db.select().from(tournaments).where(eq(tournaments.id, data.id))
    if (!t) throw new UserError('Tournament not found.')
    const rows = await db
      .select({ userId: tournamentEntries.userId, name: users.displayName, points: tournamentEntries.points, wins: tournamentEntries.wins, games: tournamentEntries.games, rank: tournamentEntries.rank, prize: tournamentEntries.prize })
      .from(tournamentEntries)
      .innerJoin(users, eq(users.id, tournamentEntries.userId))
      .where(eq(tournamentEntries.tournamentId, t.id))
      .orderBy(desc(tournamentEntries.points), desc(tournamentEntries.wins), tournamentEntries.joinedAt)
      .limit(100)
    return { name: t.name, status: t.status, rows: rows.map((r, i) => ({ ...r, rank: r.rank ?? i + 1, me: r.userId === v.profile.id })) }
  })

export const myTournamentHistory = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  return db
    .select({ id: tournaments.id, name: tournaments.name, mode: tournaments.mode, status: tournaments.status, endsAt: tournaments.endsAt, points: tournamentEntries.points, wins: tournamentEntries.wins, games: tournamentEntries.games, rank: tournamentEntries.rank, prize: tournamentEntries.prize })
    .from(tournamentEntries)
    .innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
    .where(eq(tournamentEntries.userId, v.profile.id))
    .orderBy(desc(tournaments.endsAt))
    .limit(30)
})
