import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { deposits, transactions, users, withdrawals } from '../../db/schema.js'
import { requireViewer } from './lib/auth.js'
import { notify, notifyAdmins } from './lib/audit.js'
import { putScreenshot, readImage } from './lib/files.js'
import { postLedger } from './lib/ledger.js'
import { rateLimit } from './lib/ratelimit.js'
import { clientGeo } from './lib/request.js'
import { CASHOUT_ENABLED, getSettings } from './lib/settings.js'
import { createWithdrawal } from './lib/withdrawals.js'
import { isUniqueViolation, newId, normalizeTid, todayUtc, UserError } from './lib/util.js'

export const listTransactions = createServerFn({ method: 'GET' })
  .validator(z.object({ limit: z.number().int().min(1).max(200).default(50) }).optional())
  .handler(async ({ data }) => {
    const v = await requireViewer()
    return db
      .select({
        id: transactions.id,
        type: transactions.type,
        bucket: transactions.bucket,
        amount: transactions.amount,
        balanceAfter: transactions.balanceAfter,
        label: transactions.label,
        status: transactions.status,
        createdAt: transactions.createdAt,
      })
      .from(transactions)
      .where(eq(transactions.userId, v.profile.id))
      .orderBy(desc(transactions.createdAt))
      .limit(data?.limit ?? 50)
  })

export const claimDailyReward = createServerFn({ method: 'POST' }).handler(async () => {
  const v = await requireViewer()
  await rateLimit(`daily:${v.profile.id}`, 10, 60)
  const s = await getSettings()
  const today = todayUtc()
  const yesterday = new Date(Date.now() - 864e5).toISOString().slice(0, 10)
  return db.transaction(async (tx) => {
    const streak = v.profile.lastDailyClaim === yesterday ? (v.profile.dailyStreak % s.dailyRewards.length) + 1 : 1
    // Conditional update makes a second claim on the same day a no-op.
    const [u] = await tx
      .update(users)
      .set({ lastDailyClaim: today, dailyStreak: streak })
      .where(and(eq(users.id, v.profile.id), sql`coalesce(${users.lastDailyClaim}, '') <> ${today}`))
      .returning()
    if (!u) throw new UserError('You already claimed today’s reward. Come back tomorrow!')
    const amount = s.dailyRewards[streak - 1] ?? s.dailyRewards[0] ?? 50
    await postLedger(tx, {
      userId: v.profile.id,
      bucket: 'bonus',
      amount,
      type: 'daily_reward',
      label: `Daily reward · Day ${streak}`,
      idempotencyKey: `daily:${v.profile.id}:${today}`,
    })
    await notify(v.profile.id, { kind: 'reward', title: 'Daily reward claimed', body: `+${amount} bonus coins (day ${streak} streak).`, link: '/app/wallet' }, tx)
    return { amount, streak }
  })
})

const methodEnum = z.enum(['easypaisa', 'jazzcash', 'sadapay'])

export const createDeposit = createServerFn({ method: 'POST' })
  .validator((d: unknown) => {
    if (!(d instanceof FormData)) throw new Error('Expected form data')
    return d
  })
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const p = v.profile
    await rateLimit(`deposit:${p.id}`, 6, 3600)
    const s = await getSettings()
    if (s.maintenance.enabled) throw new UserError('Deposits are paused during maintenance.')
    if (!p.ageConfirmed) throw new UserError('Confirm your date of birth (18+) in your profile before depositing.')
    if (p.selfExcludedUntil && p.selfExcludedUntil > new Date())
      throw new UserError('Deposits are paused while your self-exclusion is active.')
    const { country } = clientGeo()
    if (country && s.blockedCountries.includes(country)) throw new UserError('Deposits are not available in your region.')

    const packageId = z.string().parse(data.get('packageId'))
    const method = methodEnum.parse(data.get('method'))
    const tid = z
      .string()
      .trim()
      .min(6, 'Transaction ID looks too short')
      .max(40)
      .regex(/^[A-Za-z0-9 -]+$/, 'Transaction ID can only contain letters and numbers')
      .parse(data.get('tid'))
    const sender = z.string().trim().regex(/^03\d{9}$/, 'Sender number must look like 03XXXXXXXXX').parse(data.get('sender'))
    const pkg = s.coinPackages.find((x) => x.id === packageId && x.active)
    if (!pkg) throw new UserError('That coin package is no longer available.')
    const pm = s.paymentMethods.find((m) => m.id === method && m.enabled)
    if (!pm) throw new UserError('That payment method is currently unavailable.')
    if (pkg.price < s.limits.depositMinPkr || pkg.price > s.limits.depositMaxPkr) throw new UserError('This package is outside the deposit limits.')

    const [{ total, count }] = await db
      .select({ total: sql<number>`coalesce(sum(amount_pkr),0)::int`, count: sql<number>`count(*)::int` })
      .from(deposits)
      .where(and(eq(deposits.userId, p.id), sql`created_at > now() - interval '1 day'`, sql`status <> 'rejected'`))
    if (count >= s.limits.depositsPerDay) throw new UserError('Daily deposit request limit reached. Try again tomorrow.')
    if (total + pkg.price > s.limits.depositDailyMaxPkr) throw new UserError('This deposit would exceed the daily deposit limit.')
    if (p.dailyDepositLimitPkr && total + pkg.price > p.dailyDepositLimitPkr)
      throw new UserError('This deposit would exceed your personal daily deposit limit.')

    const shot = await readImage(data.get('screenshot'), 5 * 1024 * 1024)
    const id = newId('DR', 6)
    const tidNormalized = normalizeTid(tid)
    const flags: string[] = []
    if (Date.now() - p.createdAt.getTime() < 864e5) flags.push('New account')
    if (pkg.price >= 1900) flags.push('High value')

    // Insert first so the unique (method, TID) index rejects duplicates before we store anything.
    try {
      await db.insert(deposits).values({
        id,
        userId: p.id,
        packageId: pkg.id,
        packageName: pkg.name,
        coins: pkg.coins,
        bonusCoins: pkg.bonus,
        amountPkr: pkg.price,
        method,
        payToAccount: pm.account,
        senderAccount: sender,
        tid,
        tidNormalized,
        flags,
      })
    } catch (e) {
      if (isUniqueViolation(e)) throw new UserError('This Transaction ID has already been submitted. Each payment can only be used once.')
      throw e
    }
    try {
      const key = await putScreenshot(id, shot)
      await db.update(deposits).set({ screenshotKey: key }).where(eq(deposits.id, id))
    } catch (e) {
      await db.delete(deposits).where(eq(deposits.id, id))
      throw e
    }
    await notify(p.id, {
      kind: 'deposit',
      title: 'Deposit submitted',
      body: `${pkg.name} pack via ${pm.name} (TID ${tid}) is pending verification.`,
      link: '/app/wallet',
    })
    await notifyAdmins({
      kind: 'deposit',
      title: 'New deposit request',
      body: `${p.displayName} · ${pkg.name} · Rs ${pkg.price} via ${pm.name} · TID ${tid}`,
      link: '/admin?section=deposits',
    })
    return { id }
  })

export const listMyDeposits = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  return db
    .select({
      id: deposits.id,
      packageName: deposits.packageName,
      coins: deposits.coins,
      bonusCoins: deposits.bonusCoins,
      amountPkr: deposits.amountPkr,
      method: deposits.method,
      tid: deposits.tid,
      status: deposits.status,
      adminNote: deposits.adminNote,
      createdAt: deposits.createdAt,
      reviewedAt: deposits.reviewedAt,
    })
    .from(deposits)
    .where(eq(deposits.userId, v.profile.id))
    .orderBy(desc(deposits.createdAt))
    .limit(50)
})

export const requestWithdrawal = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      method: methodEnum,
      accountHolder: z.string().trim().min(3).max(60),
      accountNumber: z.string().trim().regex(/^03\d{9}$/, 'Account number must look like 03XXXXXXXXX'),
      coins: z.number().int().positive(),
      idempotencyKey: z.string().uuid(),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireViewer()
    // Code-level switch — no database setting can bypass this.
    if (!CASHOUT_ENABLED) throw new UserError('Withdrawals are not available right now.')
    const s = await getSettings()
    if (v.profile.kycStatus !== 'verified') throw new UserError('Complete KYC verification (Profile → KYC) before requesting a withdrawal.')
    if (data.coins < s.limits.withdrawMinCoins || data.coins > s.limits.withdrawMaxCoins)
      throw new UserError(`Withdrawals must be between ${s.limits.withdrawMinCoins.toLocaleString()} and ${s.limits.withdrawMaxCoins.toLocaleString()} coins.`)
    await rateLimit(`withdraw:${v.profile.id}`, 5, 86400)
    return createWithdrawal({
      userId: v.profile.id,
      displayName: v.profile.displayName,
      method: data.method,
      accountHolder: data.accountHolder,
      accountNumber: data.accountNumber,
      coins: data.coins,
      idempotencyKey: data.idempotencyKey,
      coinsPerPkr: s.limits.withdrawCoinsPerPkr,
    })
  })

export const listMyWithdrawals = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  return db
    .select({
      id: withdrawals.id,
      method: withdrawals.method,
      accountNumber: withdrawals.accountNumber,
      accountHolder: withdrawals.accountHolder,
      coins: withdrawals.coins,
      amountPkr: withdrawals.amountPkr,
      status: withdrawals.status,
      paymentReference: withdrawals.paymentReference,
      adminNote: withdrawals.adminNote,
      createdAt: withdrawals.createdAt,
      updatedAt: withdrawals.updatedAt,
    })
    .from(withdrawals)
    .where(eq(withdrawals.userId, v.profile.id))
    .orderBy(desc(withdrawals.createdAt))
    .limit(50)
})
