import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { loginHistory, users, wallets } from '../../db/schema.js'
import { assertActive, getViewer, requireViewer, type Profile } from './lib/auth.js'
import { audit } from './lib/audit.js'
import { rateLimit } from './lib/ratelimit.js'
import { clientGeo, clientIp, userAgent } from './lib/request.js'
import { getSettings, publicSettings } from './lib/settings.js'
import { hashIp } from './lib/util.js'
import { putAvatar, putKycDoc, readImage } from './lib/files.js'

export function toMe(p: Profile, isAdmin: boolean) {
  return {
    id: p.id,
    publicId: p.publicId,
    email: p.email,
    displayName: p.displayName,
    avatarUrl: p.avatarKey ? `/api/avatar/${p.id}?v=${encodeURIComponent(p.avatarKey.split('/').pop() ?? '')}` : null,
    referralCode: p.referralCode,
    status: p.status,
    statusReason: p.statusReason,
    suspendedUntil: p.suspendedUntil,
    ageConfirmed: p.ageConfirmed,
    dateOfBirth: p.dateOfBirth,
    kycStatus: p.kycStatus,
    selfExcludedUntil: p.selfExcludedUntil,
    dailyDepositLimitPkr: p.dailyDepositLimitPkr,
    rating: p.rating,
    gamesPlayed: p.gamesPlayed,
    gamesWon: p.gamesWon,
    dailyStreak: p.dailyStreak,
    lastDailyClaim: p.lastDailyClaim,
    passwordChangedAt: p.passwordChangedAt,
    createdAt: p.createdAt,
    isAdmin,
  }
}
export type Me = ReturnType<typeof toMe>

async function walletOf(userId: string) {
  const [w] = await db.select().from(wallets).where(eq(wallets.userId, userId))
  const purchased = w?.purchased ?? 0
  const bonus = w?.bonus ?? 0
  const winnings = w?.winnings ?? 0
  return { purchased, bonus, winnings, reserved: w?.reserved ?? 0, available: purchased + bonus + winnings }
}
export type WalletSummary = Awaited<ReturnType<typeof walletOf>>

/** Everything the app shell needs in one round-trip. Returns `me: null` for guests. */
export const getSession = createServerFn({ method: 'GET' }).handler(async () => {
  const s = await getSettings()
  const v = await getViewer()
  if (!v) return { me: null, wallet: null, settings: publicSettings(s) }
  await db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, v.profile.id))
  return { me: toMe(v.profile, v.isAdmin), wallet: await walletOf(v.profile.id), settings: publicSettings(s) }
})

export const getWallet = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  return walletOf(v.profile.id)
})

/** Called once per browser session after sign-in to build the login history. */
export const recordLogin = createServerFn({ method: 'POST' }).handler(async () => {
  const v = await getViewer()
  if (!v) return { ok: false }
  await rateLimit(`login:${v.profile.id}`, 20, 3600)
  const geo = clientGeo()
  await db.insert(loginHistory).values({
    userId: v.profile.id,
    userAgent: userAgent(),
    ipHash: hashIp(clientIp()),
    country: geo.country,
    city: geo.city,
  })
  if (geo.country && !v.profile.country) await db.update(users).set({ country: geo.country }).where(eq(users.id, v.profile.id))
  return { ok: true }
})

export const getLoginHistory = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  return db
    .select({ id: loginHistory.id, userAgent: loginHistory.userAgent, country: loginHistory.country, city: loginHistory.city, createdAt: loginHistory.createdAt })
    .from(loginHistory)
    .where(eq(loginHistory.userId, v.profile.id))
    .orderBy(desc(loginHistory.createdAt))
    .limit(15)
})

export const updateProfile = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      displayName: z.string().trim().min(3).max(24).regex(/^[\p{L}\p{N} ._-]+$/u, 'Letters, numbers, spaces, dots, dashes only'),
      dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const patch: Partial<Profile> = { displayName: data.displayName }
    if (data.dateOfBirth) {
      const dob = new Date(data.dateOfBirth)
      const age = (Date.now() - dob.getTime()) / (365.25 * 864e5)
      if (!(age >= 18 && age < 120)) throw new Error('You must be 18 or older to use Ludo King Arena.')
      patch.dateOfBirth = data.dateOfBirth
      patch.ageConfirmed = true
    }
    await db.update(users).set(patch).where(eq(users.id, v.profile.id))
    return { ok: true }
  })

export const markPasswordChanged = createServerFn({ method: 'POST' }).handler(async () => {
  const v = await requireViewer()
  await db.update(users).set({ passwordChangedAt: new Date() }).where(eq(users.id, v.profile.id))
  if (v.isAdmin) await audit({ id: v.profile.id, email: v.profile.email }, 'Changed own password')
  return { ok: true }
})

export const setResponsibleGaming = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      dailyDepositLimitPkr: z.number().int().min(0).max(1_000_000).nullable(),
      selfExcludeDays: z.number().int().min(0).max(365).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const patch: Partial<Profile> = { dailyDepositLimitPkr: data.dailyDepositLimitPkr || null }
    // Self-exclusion can only be extended, never shortened.
    if (data.selfExcludeDays) {
      const until = new Date(Date.now() + data.selfExcludeDays * 864e5)
      if (!v.profile.selfExcludedUntil || v.profile.selfExcludedUntil < until) patch.selfExcludedUntil = until
    }
    await db.update(users).set(patch).where(eq(users.id, v.profile.id))
    return { ok: true }
  })

export const uploadAvatar = createServerFn({ method: 'POST' })
  .validator((d: unknown) => {
    if (!(d instanceof FormData)) throw new Error('Expected form data')
    return d
  })
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`avatar:${v.profile.id}`, 10, 3600)
    const file = await readImage(data.get('file'), 2 * 1024 * 1024)
    const key = await putAvatar(v.profile.id, file)
    await db.update(users).set({ avatarKey: key }).where(eq(users.id, v.profile.id))
    return { ok: true }
  })

export const submitKyc = createServerFn({ method: 'POST' })
  .validator((d: unknown) => {
    if (!(d instanceof FormData)) throw new Error('Expected form data')
    return d
  })
  .handler(async ({ data }) => {
    const v = await requireViewer()
    assertActive(v.profile)
    await rateLimit(`kyc:${v.profile.id}`, 5, 86400)
    if (v.profile.kycStatus === 'verified' || v.profile.kycStatus === 'pending') throw new Error('Your KYC is already submitted.')
    const name = z.string().trim().min(3).max(60).parse(data.get('fullName'))
    const doc = z.string().trim().regex(/^\d{5}-?\d{7}-?\d$/, 'Enter a valid 13-digit CNIC').parse(data.get('cnic'))
    const file = await readImage(data.get('file'), 5 * 1024 * 1024)
    const key = await putKycDoc(v.profile.id, file)
    await db
      .update(users)
      .set({ kycStatus: 'pending', kycName: name, kycDocNumber: doc.replace(/-/g, ''), kycDocKey: key })
      .where(and(eq(users.id, v.profile.id), sql`kyc_status in ('not_started','rejected')`))
    return { ok: true }
  })
