import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, inArray, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { gameRooms, matchReports, transactions, users, wallets } from '../../db/schema.js'
import { GAME_KEYS, mergeArena, type ArenaConfig } from '../lib/games/catalog.js'
import { finishArena, isArena, type ArenaRoomState } from './lib/arena.js'
import { audit } from './lib/audit.js'
import { requireAdmin, type Viewer } from './lib/auth.js'
import { ludoRanking, type RoomState } from './lib/rooms.js'
import { getArenaConfig, refundRoom, saveArenaConfig, settleRoom, stakeView } from './lib/stakes.js'
import { UserError } from './lib/util.js'

/** Admin console: game settings, match monitoring and coin-entry history. Every handler re-checks the admin role. */

const actor = (v: Viewer) => ({ id: v.profile.id, email: v.profile.email })

export const adminGetArena = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  return getArenaConfig()
})

const matchTypeSchema = z.object({
  id: z.string(),
  label: z.string().trim().min(2).max(24),
  sub: z.string().trim().max(60),
  players: z.number().int(),
  turnSeconds: z.number().int().min(10).max(600).optional(),
  enabled: z.boolean(),
})
const gameSchema = z
  .object({
    enabled: z.boolean(),
    entryEnabled: z.boolean(),
    customAmounts: z.boolean(),
    minEntry: z.number().int().min(1).max(1_000_000),
    maxEntry: z.number().int().min(1).max(1_000_000),
    presets: z.array(z.number().int().min(1).max(1_000_000)).min(1).max(10),
    feePercent: z.number().int().min(0).max(50),
    prizeSplit: z.array(z.number().int().min(0).max(100)).min(1).max(4),
    matchTypes: z.array(matchTypeSchema).min(1).max(6),
  })
  .refine((g) => g.minEntry <= g.maxEntry, 'Minimum entry must not be above the maximum.')
  .refine((g) => g.prizeSplit.reduce((a, b) => a + b, 0) === 100, 'Prize distribution must add up to 100%.')
  .refine((g) => g.prizeSplit[0]! >= Math.max(...g.prizeSplit), 'First place must get the largest share.')
  .refine((g) => g.matchTypes.some((m) => m.enabled), 'Keep at least one match type enabled.')

export const adminSaveArena = createServerFn({ method: 'POST' })
  .validator(z.object({ ludo: gameSchema, pool: gameSchema, carrom: gameSchema, chess: gameSchema }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const before = await getArenaConfig()
    const next = mergeArena(data)
    for (const k of GAME_KEYS) next[k].presets = [...new Set(next[k].presets.filter((p) => p >= next[k].minEntry && p <= next[k].maxEntry))].sort((a, b) => a - b)
    await saveArenaConfig(next, v.profile.id)
    const changed = GAME_KEYS.filter((k) => JSON.stringify(before[k]) !== JSON.stringify(next[k]))
    await audit(actor(v), 'Updated game & coin-entry settings', { type: 'settings', id: 'arena' }, {
      changed,
      fees: Object.fromEntries(GAME_KEYS.map((k) => [k, next[k].feePercent])),
      limits: Object.fromEntries(GAME_KEYS.map((k) => [k, [next[k].minEntry, next[k].maxEntry]])),
    })
    return next satisfies ArenaConfig
  })

const filterEnum = z.enum(['active', 'completed', 'cancelled', 'problems', 'all'])

export const adminMatches = createServerFn({ method: 'GET' })
  .validator(z.object({ filter: filterEnum.default('active'), game: z.enum(['all', 'ludo', 'pool', 'carrom', 'chess']).default('all') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const where = [
      data.game !== 'all' ? eq(gameRooms.game, data.game) : undefined,
      data.filter === 'active'
        ? sql`${gameRooms.status} in ('waiting','playing')`
        : data.filter === 'completed'
          ? eq(gameRooms.status, 'finished')
          : data.filter === 'cancelled'
            ? sql`${gameRooms.status} in ('cancelled','abandoned')`
            : data.filter === 'problems'
              ? sql`(${gameRooms.disputed} = true or (${gameRooms.stakeStatus} = 'charged' and ${gameRooms.status} <> 'playing') or (${gameRooms.stakeStatus} = 'charged' and ${gameRooms.updatedAt} < now() - interval '2 hours'))`
              : undefined,
    ]
    const rooms = await db
      .select()
      .from(gameRooms)
      .where(and(...where))
      .orderBy(desc(gameRooms.updatedAt))
      .limit(150)
    const reports = rooms.length
      ? await db.select().from(matchReports).where(inArray(matchReports.roomId, rooms.map((r) => r.id))).orderBy(desc(matchReports.createdAt))
      : []
    const stats = await db.execute<Record<string, number>>(sql`
      select
        count(*) filter (where status in ('waiting','playing'))::int as "active",
        count(*) filter (where status = 'finished')::int as "completed",
        count(*) filter (where status in ('cancelled','abandoned'))::int as "cancelled",
        count(*) filter (where disputed or (stake_status = 'charged' and status <> 'playing'))::int as "problems",
        coalesce(sum(entry_fee * jsonb_array_length(seats)) filter (where stake_status = 'paid'), 0)::bigint as "volume",
        coalesce(sum((result->>'fee')::int) filter (where stake_status = 'paid'), 0)::bigint as "fees"
      from game_rooms where entry_fee > 0 or status in ('waiting','playing','finished','cancelled','abandoned')`)
    const st = (((stats as unknown as { rows?: unknown[] }).rows ?? stats) as Record<string, number | string>[])[0] ?? {}
    return {
      stats: Object.fromEntries(Object.entries(st).map(([k, v]) => [k, Number(v)])) as Record<string, number>,
      rooms: rooms.map((r) => {
        const outcome = r.game === 'ludo' ? null : ((r.state as unknown as ArenaRoomState | null)?.outcome ?? null)
        return {
          id: r.id,
          code: r.code,
          game: r.game,
          mode: r.mode,
          status: r.status,
          isPrivate: r.isPrivate,
          seats: r.seats.map((s) => ({ name: s.name || 'Open seat', userId: s.owner ?? s.userId, forfeited: !!s.forfeited, paid: s.paid ? s.paid.bonus + s.paid.purchased + s.paid.winnings : 0 })),
          stake: stakeView(r),
          outcome,
          disputed: r.disputed,
          cancelReason: r.cancelReason,
          createdAt: r.createdAt,
          startedAt: r.startedAt,
          endedAt: r.endedAt,
          updatedAt: r.updatedAt,
          reports: reports.filter((x) => x.roomId === r.id).map((x) => ({ id: x.id, userId: x.userId, reason: x.reason, status: x.status, resolution: x.resolution, createdAt: x.createdAt })),
        }
      }),
    }
  })

/** Cancels / voids a match. Before the start nothing was deducted; after the start every entry is refunded to its original bucket. */
export const adminVoidMatch = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string(), reason: z.string().trim().min(3).max(200) }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [room] = await db.select().from(gameRooms).where(eq(gameRooms.id, data.id))
    if (!room) throw new UserError('Room not found.')
    if (room.stakeStatus === 'paid') throw new UserError('This match was already paid out. Use a manual wallet adjustment if a correction is needed.')
    if (room.stakeStatus === 'none') {
      await db.update(gameRooms).set({ status: 'cancelled', cancelReason: data.reason, endedAt: new Date(), updatedAt: new Date(), version: room.version + 1 }).where(eq(gameRooms.id, room.id))
      await audit(actor(v), 'Cancelled free match', { type: 'room', id: room.id }, { reason: data.reason })
    } else {
      await refundRoom(room.id, `Cancelled by an admin: ${data.reason}`, actor(v))
    }
    return { ok: true }
  })

/** Re-runs the server-verified settlement for a finished match whose payout was interrupted. Idempotent. */
export const adminRetrySettlement = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [room] = await db.select().from(gameRooms).where(eq(gameRooms.id, data.id))
    if (!room) throw new UserError('Room not found.')
    if (room.status !== 'finished' || room.stakeStatus !== 'charged') throw new UserError('Only finished matches awaiting payout can be settled.')
    if (isArena(room.game)) await finishArena(room)
    else await settleRoom(room.id, ludoRanking((room.state as unknown as RoomState).game), 'Won the Ludo race')
    await audit(actor(v), 'Retried match settlement', { type: 'room', id: room.id })
    return { ok: true }
  })

export const adminResolveReport = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string(), status: z.enum(['resolved', 'dismissed']), resolution: z.string().trim().max(300).default('') }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    await db
      .update(matchReports)
      .set({ status: data.status, resolution: data.resolution || null, resolvedBy: v.profile.id, resolvedAt: new Date() })
      .where(and(eq(matchReports.roomId, data.roomId), eq(matchReports.status, 'open')))
    await db.update(gameRooms).set({ disputed: false }).where(eq(gameRooms.id, data.roomId))
    await audit(actor(v), `Marked match dispute ${data.status}`, { type: 'room', id: data.roomId }, { resolution: data.resolution })
    return { ok: true }
  })

/** Coin deduction / reward / refund ledger rows for game entries, plus wallet balances of the players involved. */
export const adminCoinHistory = createServerFn({ method: 'GET' })
  .validator(z.object({ type: z.enum(['all', 'game_entry', 'game_win', 'game_refund']).default('all'), q: z.string().trim().max(60).default('') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const rows = await db
      .select({ t: transactions, name: users.displayName, publicId: users.publicId })
      .from(transactions)
      .leftJoin(users, eq(users.id, transactions.userId))
      .where(
        and(
          data.type === 'all' ? inArray(transactions.type, ['game_entry', 'game_win', 'game_refund']) : eq(transactions.type, data.type),
          data.q ? sql`(${users.publicId} ilike ${'%' + data.q + '%'} or ${users.displayName} ilike ${'%' + data.q + '%'} or ${transactions.refId} ilike ${'%' + data.q + '%'})` : undefined,
        ),
      )
      .orderBy(desc(transactions.createdAt))
      .limit(200)
    const ids = [...new Set(rows.map((r) => r.t.userId))]
    const bal = ids.length ? await db.select().from(wallets).where(inArray(wallets.userId, ids)) : []
    const totals = await db.execute<Record<string, number>>(sql`
      select coalesce(-sum(amount) filter (where type = 'game_entry'), 0)::bigint as "entries",
             coalesce(sum(amount) filter (where type = 'game_win'), 0)::bigint as "rewards",
             coalesce(sum(amount) filter (where type = 'game_refund'), 0)::bigint as "refunds"
      from transactions where type in ('game_entry','game_win','game_refund')`)
    const tt = (((totals as unknown as { rows?: unknown[] }).rows ?? totals) as Record<string, number | string>[])[0] ?? {}
    return {
      totals: { entries: Number(tt.entries ?? 0), rewards: Number(tt.rewards ?? 0), refunds: Number(tt.refunds ?? 0) },
      rows: rows.map((r) => {
        const w = bal.find((b) => b.userId === r.t.userId)
        return {
          ...r.t,
          name: r.name ?? '—',
          publicId: r.publicId ?? '',
          balance: w ? w.purchased + w.bonus + w.winnings : 0,
        }
      }),
    }
  })
