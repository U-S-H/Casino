// @vitest-environment node
/**
 * Coin-entry + arena integration tests against a real Postgres.
 * Run with: LKA_IT_DB=postgres://… npx vitest run src/server/stakes.integration.test.ts
 */
import { beforeAll, describe, expect, it } from 'vitest'

const url = process.env.LKA_IT_DB
if (url) {
  process.env.NETLIFY_DB_URL = url
  process.env.NETLIFY_DB_DRIVER = 'server'
}

describe.skipIf(!url)('coin entry & arena games', () => {
  let db: typeof import('../../db/index.js')['db']
  let s: typeof import('../../db/schema.js')
  let ledger: typeof import('./lib/ledger.js')
  let stakes: typeof import('./lib/stakes.js')
  let rooms: typeof import('./lib/rooms.js')
  let arena: typeof import('./lib/arena.js')
  let util: typeof import('./lib/util.js')
  let orm: typeof import('drizzle-orm')
  const run = Date.now()
  const U = (n: string) => `st-${n}-${run}`

  async function user(n: string, coins: { bonus?: number; purchased?: number; winnings?: number }) {
    const id = U(n)
    await db.insert(s.users).values({ id, publicId: `LKA-${util.randomCode(6)}`, email: `${id}@x.test`, displayName: n, referralCode: util.randomCode(8) })
    for (const [bucket, amount] of Object.entries(coins))
      if (amount) await db.transaction((tx) => ledger.postLedger(tx, { userId: id, bucket: bucket as 'bonus', amount, type: 'promo', label: 'seed', idempotencyKey: `seed:${id}:${bucket}` }))
    return id
  }
  const wallet = async (id: string) => {
    const [w] = await db.select().from(s.wallets).where(orm.eq(s.wallets.userId, id))
    return { ...w!, total: w!.bonus + w!.purchased + w!.winnings }
  }
  const txs = (id: string, type: string) => db.select().from(s.transactions).where(orm.and(orm.eq(s.transactions.userId, id), orm.eq(s.transactions.type, type)))

  async function room(game: string, mode: string, entry: number, seats: [string, string][], feePercent = 10) {
    const [r] = await db
      .insert(s.gameRooms)
      .values({
        id: `RM-${util.randomCode(10)}`,
        code: String(100000 + Math.floor(Math.random() * 899999)),
        game,
        mode,
        isPrivate: true,
        hostId: seats[0]![0],
        seats: seats.map(([id, name]) => ({ userId: id, name, isBot: false, missed: 0, confirmed: true })),
        entryFee: entry,
        feePercent,
        stakeStatus: entry > 0 ? 'pending' : 'none',
      })
      .returning()
    return r!
  }

  beforeAll(async () => {
    ;[{ db }, s, ledger, stakes, rooms, arena, util, orm] = await Promise.all([
      import('../../db/index.js'),
      import('../../db/schema.js'),
      import('./lib/ledger.js'),
      import('./lib/stakes.js'),
      import('./lib/rooms.js'),
      import('./lib/arena.js'),
      import('./lib/util.js'),
      import('drizzle-orm'),
    ])
  })

  it('chess: entry deducted once at start, winner paid pool minus fee once', async () => {
    const a = await user('chessA', { bonus: 300, purchased: 900 })
    const b = await user('chessB', { purchased: 1500 })
    let r = await room('chess', 'rapid', 1000, [
      [a, 'A'],
      [b, 'B'],
    ])
    // Nothing deducted before the start.
    expect((await wallet(a)).total).toBe(1200)
    r = (await arena.startArena(r))!
    expect(r.status).toBe('playing')
    expect(r.stakeStatus).toBe('charged')
    // Starting again is impossible (status/version guard) and doesn't double charge.
    expect(await stakes.chargeAndStart(r, { status: 'playing' }).catch(() => null)).toBeNull()
    expect((await wallet(a)).total).toBe(200)
    expect((await wallet(a)).bonus).toBe(0) // bonus spent first
    expect((await wallet(b)).total).toBe(500)
    expect(await txs(a, 'game_entry')).toHaveLength(2) // bonus 300 + purchased 700
    // Wrong turn & non-player are rejected.
    await expect(arena.arenaAction(r, b, { type: 'move', from: 'e7', to: 'e5' })).rejects.toThrow()
    await expect(arena.arenaAction(r, U('nobody'), { type: 'move', from: 'e2', to: 'e4' })).rejects.toThrow(/not a player/)
    await expect(arena.arenaAction(r, a, { type: 'move', from: 'e2', to: 'e5' })).rejects.toThrow()
    // Fool's mate: Black (B) wins.
    for (const [who, from, to] of [
      [a, 'f2', 'f3'],
      [b, 'e7', 'e5'],
      [a, 'g2', 'g4'],
      [b, 'd8', 'h4'],
    ] as const)
      r = await arena.arenaAction(r, who, { type: 'move', from, to })
    expect(r.status).toBe('finished')
    const [after] = await db.select().from(s.gameRooms).where(orm.eq(s.gameRooms.id, r.id))
    expect(after!.stakeStatus).toBe('paid')
    expect(after!.result!.prizes[b]).toBe(1800)
    expect(after!.result!.fee).toBe(200)
    expect((await wallet(b)).total).toBe(500 + 1800)
    expect((await wallet(b)).winnings).toBe(1800)
    expect((await wallet(a)).total).toBe(200) // loser gets nothing back
    // Re-running settlement is a no-op.
    await arena.finishArena(after!)
    await stakes.settleRoom(r.id, [[1], [0]], 'again')
    expect((await wallet(b)).total).toBe(2300)
    expect(await txs(b, 'game_win')).toHaveLength(1)
    const hist = await db.select().from(s.games).where(orm.eq(s.games.roomId, r.id))
    expect(hist).toHaveLength(1)
    expect(hist[0]!.game).toBe('chess')
  })

  it('refuses to start when a player can no longer afford the entry and deducts nothing', async () => {
    const a = await user('poorA', { purchased: 5000 })
    const b = await user('poorB', { purchased: 100 })
    const r = await room('pool', 'classic', 500, [
      [a, 'A'],
      [b, 'B'],
    ])
    await expect(arena.startArena(r)).rejects.toThrow(/enough coins/)
    expect((await wallet(a)).total).toBe(5000)
    expect((await wallet(b)).total).toBe(100)
    const [after] = await db.select().from(s.gameRooms).where(orm.eq(s.gameRooms.id, r.id))
    expect(after!.status).toBe('waiting')
    expect(after!.stakeStatus).toBe('pending')
    expect(after!.seats.some((x) => x.userId === b)).toBe(false)
    await expect(stakes.assertCanAfford(b, 500)).rejects.toThrow(/need 500/)
  })

  it('cancel before start deducts nothing; void after start refunds exact buckets once', async () => {
    const a = await user('cxA', { bonus: 200, winnings: 800 })
    const b = await user('cxB', { purchased: 1000 })
    const pending = await room('carrom', 'classic', 1000, [
      [a, 'A'],
      [b, 'B'],
    ])
    const c = await stakes.refundRoom(pending.id, 'test cancel')
    expect(c.status).toBe('cancelled')
    expect(c.stakeStatus).toBe('cancelled')
    expect((await wallet(a)).total).toBe(1000)

    let r = await room('carrom', 'classic', 1000, [
      [a, 'A'],
      [b, 'B'],
    ])
    r = (await arena.startArena(r))!
    expect((await wallet(a)).total).toBe(0)
    await stakes.refundRoom(r.id, 'void test', { id: 'admin', email: 'admin@x.test' })
    const wa = await wallet(a)
    expect(wa.bonus).toBe(200)
    expect(wa.winnings).toBe(800)
    expect((await wallet(b)).purchased).toBe(1000)
    await expect(stakes.refundRoom(r.id, 'again')).rejects.toThrow(/already refunded/)
    expect((await wallet(a)).total).toBe(1000)
  })

  it('forfeit by leaving pays the opponent; three timeouts forfeit too', async () => {
    const a = await user('ffA', { purchased: 2000 })
    const b = await user('ffB', { purchased: 2000 })
    let r = (await arena.startArena(await room('pool', 'classic', 200, [[a, 'A'], [b, 'B']], 0)))!
    await arena.arenaForfeit(r, a)
    let [x] = await db.select().from(s.gameRooms).where(orm.eq(s.gameRooms.id, r.id))
    expect(x!.stakeStatus).toBe('paid')
    expect((await wallet(b)).total).toBe(2200) // 0% fee
    expect((await wallet(a)).total).toBe(1800)

    r = (await arena.startArena(await room('chess', 'blitz', 200, [[a, 'A'], [b, 'B']])))!
    for (let i = 0; i < 3; i++) {
      await db.update(s.gameRooms).set({ turnDeadline: new Date(Date.now() - 1000) }).where(orm.eq(s.gameRooms.id, r.id))
      ;[x] = await db.select().from(s.gameRooms).where(orm.eq(s.gameRooms.id, r.id))
      r = await arena.arenaTick(x!)
    }
    expect(r.status).toBe('finished')
    // White (A) never moved on any of their turns… but chess timeout ends the game at the first timeout.
    const out = (r.state as unknown as import('./lib/arena.js').ArenaRoomState).outcome!
    expect(out.winner).toBe(1)
  })

  it('chess draw returns entries without a fee', async () => {
    const a = await user('drA', { purchased: 1000 })
    const b = await user('drB', { bonus: 1000 })
    let r = (await arena.startArena(await room('chess', 'rapid', 1000, [[a, 'A'], [b, 'B']])))!
    r = await arena.arenaAction(r, a, { type: 'offerDraw' })
    r = await arena.arenaAction(r, b, { type: 'acceptDraw' })
    expect(r.status).toBe('finished')
    expect((await wallet(a)).purchased).toBe(1000)
    expect((await wallet(b)).bonus).toBe(1000)
  })

  it('pool and carrom: server runs real shots and the game advances', async () => {
    const a = await user('phA', { purchased: 1000 })
    const b = await user('phB', { purchased: 1000 })
    let p = (await arena.startArena(await room('pool', 'classic', 0, [[a, 'A'], [b, 'B']])))!
    expect(p.stakeStatus).toBe('none')
    const before = JSON.stringify((p.state as unknown as import('./lib/arena.js').ArenaRoomState).g)
    p = await arena.arenaAction(p, a, { type: 'shot', dx: 1, dy: 0.01, power: 1, cueX: 200, cueY: 250 })
    const g = (p.state as unknown as import('./lib/arena.js').ArenaRoomState).g as { n: number; lastShot: unknown }
    expect(JSON.stringify(g)).not.toBe(before)
    expect(g.lastShot).toBeTruthy()

    let c = (await arena.startArena(await room('carrom', 'classic', 0, [[a, 'A'], [b, 'B']])))!
    await expect(arena.arenaAction(c, a, { type: 'strike', x: 0.5, dx: 0, dy: 1, power: 1 })).rejects.toThrow() // backwards
    c = await arena.arenaAction(c, a, { type: 'strike', x: 0.5, dx: 0, dy: -1, power: 1 })
    const cg = (c.state as unknown as import('./lib/arena.js').ArenaRoomState).g as { lastStrike: unknown; n: number }
    expect(cg.lastStrike).toBeTruthy()
  })

  it('ludo 1v1 coin match: charged once, verified winner paid, leaving forfeits', async () => {
    const a = await user('ldA', { purchased: 1000 })
    const b = await user('ldB', { purchased: 1000 })
    let r = (await rooms.startRoom(await room('ludo', '1v1', 500, [[a, 'A'], [b, 'B']]), true))!
    expect(r.stakeStatus).toBe('charged')
    expect(r.seats.every((x) => !x.isBot)).toBe(true)
    expect((await wallet(a)).total).toBe(500)
    // Play a few real turns, then B leaves → A wins immediately.
    for (let i = 0; i < 6; i++) {
      const st = r.state as unknown as import('./lib/rooms.js').RoomState
      const me = r.seats[st.game.turn]!.userId!
      const { movableTokens } = await import('../lib/ludo.js')
      r = st.game.dice === null ? await rooms.playerAction(r, me, { type: 'roll' }) : await rooms.playerAction(r, me, { type: 'move', token: movableTokens(st.game.players[st.game.turn]!, st.game.dice)[0]! })
    }
    const st = r.state as unknown as import('./lib/rooms.js').RoomState
    const seats = r.seats.map((x, j) => (j === 1 ? { ...x, userId: null, isBot: true, forfeited: true, owner: b } : x))
    const ended = rooms.lastSideStanding(r, st, seats)!
    expect(ended.finished).toBe(true)
    await rooms.commit(r, ended)
    const [x] = await db.select().from(s.gameRooms).where(orm.eq(s.gameRooms.id, r.id))
    expect(x!.status).toBe('finished')
    expect(x!.stakeStatus).toBe('paid')
    expect((await wallet(a)).total).toBe(500 + 900)
    expect((await wallet(b)).total).toBe(500)
  })

  it('ludo 4-player prize split follows ranking and pays the full net prize', async () => {
    const { splitPrize, prizeMath } = await import('../lib/games/catalog.js')
    const m = prizeMath(1000, 4, 10)
    expect(m).toEqual({ pool: 4000, fee: 400, prize: 3600 })
    expect(splitPrize(3600, [70, 30], 4)).toEqual([2520, 1080])
    expect(splitPrize(3600, [100], 4)).toEqual([3600])
    expect(splitPrize(1001, [50, 30, 20], 3).reduce((a, b) => a + b, 0)).toBe(1001)
  })
})
