import { createServerFn } from '@tanstack/react-start'
import { sql } from 'drizzle-orm'

import { db } from '../../db/index.js'
import { tournaments, users } from '../../db/schema.js'

/** Public, non-personal stats for the landing page. */
export const getLandingData = createServerFn({ method: 'GET' }).handler(async () => {
  try {
    const [{ online }] = await db.select({ online: sql<number>`count(*)::int` }).from(users).where(sql`last_seen_at > now() - interval '10 minutes'`)
    const list = await db
      .select({
        id: tournaments.id,
        name: tournaments.name,
        mode: tournaments.mode,
        prizeCoins: tournaments.prizeCoins,
        capacity: tournaments.capacity,
        status: tournaments.status,
        endsAt: tournaments.endsAt,
        players: sql<number>`(select count(*)::int from tournament_entries e where e.tournament_id = ${tournaments.id})`,
      })
      .from(tournaments)
      .where(sql`${tournaments.kind} <> 'private' and ${tournaments.status} in ('upcoming','live') and ${tournaments.endsAt} > now()`)
      .orderBy(tournaments.endsAt)
      .limit(4)
    return { online, tournaments: list }
  } catch {
    return { online: 0, tournaments: [] }
  }
})
