import { createServerFn } from '@tanstack/react-start'
import { admin as identityAdmin } from '@netlify/identity'
import { and, desc, eq, ilike, or, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import {
  admins,
  auditLogs,
  deposits,
  gamePlayers,
  gameRooms,
  games,
  loginHistory,
  referrals,
  supportTickets,
  tournamentEntries,
  tournaments,
  transactions,
  users,
  wallets,
  withdrawals,
} from '../../db/schema.js'
import { requireAdmin, type Viewer } from './lib/auth.js'
import { audit, broadcast, notify } from './lib/audit.js'
import { postLedger } from './lib/ledger.js'
import { qualifyReferral } from './lib/rooms.js'
import { getSettings, saveSettings, type SiteSettings } from './lib/settings.js'
import { refundRoom } from './lib/stakes.js'
import { settleDueTournaments } from './lib/tournaments.js'
import { updateWithdrawal } from './lib/withdrawals.js'
import { newId, randomCode, UserError } from './lib/util.js'

const actor = (v: Viewer) => ({ id: v.profile.id, email: v.profile.email })
const count = sql<number>`count(*)::int`

/* ---------------- Overview ---------------- */

export const adminOverview = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  const one = async (q: Promise<{ n: number }[]>) => (await q)[0]?.n ?? 0
  const [totalUsers, activeUsers, newUsers, totalGames, gamesToday, pendingDeposits, pendingWithdrawals, openTickets, liveRooms, referralsTotal, referralsRewarded, flaggedReferrals, pendingKyc] =
    await Promise.all([
      one(db.select({ n: count }).from(users)),
      one(db.select({ n: count }).from(users).where(sql`last_seen_at > now() - interval '1 day'`)),
      one(db.select({ n: count }).from(users).where(sql`created_at > now() - interval '7 days'`)),
      one(db.select({ n: count }).from(games)),
      one(db.select({ n: count }).from(games).where(sql`ended_at > now() - interval '1 day'`)),
      one(db.select({ n: count }).from(deposits).where(sql`status in ('pending','under_review')`)),
      one(db.select({ n: count }).from(withdrawals).where(sql`status in ('pending','approved','processing')`)),
      one(db.select({ n: count }).from(supportTickets).where(eq(supportTickets.status, 'open'))),
      one(db.select({ n: count }).from(gameRooms).where(eq(gameRooms.status, 'playing'))),
      one(db.select({ n: count }).from(referrals)),
      one(db.select({ n: count }).from(referrals).where(eq(referrals.status, 'rewarded'))),
      one(db.select({ n: count }).from(referrals).where(eq(referrals.status, 'flagged'))),
      one(db.select({ n: count }).from(users).where(eq(users.kycStatus, 'pending'))),
    ])
  const [money] = await db
    .select({
      approvedPkr: sql<number>`coalesce(sum(amount_pkr) filter (where status = 'approved'),0)::int`,
      approvedPkr30: sql<number>`coalesce(sum(amount_pkr) filter (where status = 'approved' and reviewed_at > now() - interval '30 days'),0)::int`,
      approvedCount: sql<number>`count(*) filter (where status = 'approved')::int`,
      rejectedCount: sql<number>`count(*) filter (where status = 'rejected')::int`,
    })
    .from(deposits)
  const daily = await db.execute<{ day: string; games: number; signups: number }>(sql`
    with d as (select generate_series(current_date - 6, current_date, interval '1 day')::date as day)
    select to_char(d.day, 'Dy') as day,
      (select count(*)::int from games g where g.ended_at::date = d.day) as games,
      (select count(*)::int from users u where u.created_at::date = d.day) as signups
    from d order by d.day`)
  const rows = ((daily as unknown as { rows?: unknown[] }).rows ?? daily) as { day: string; games: number; signups: number }[]
  return {
    totalUsers,
    activeUsers,
    newUsers,
    totalGames,
    gamesToday,
    pendingDeposits,
    pendingWithdrawals,
    openTickets,
    liveRooms,
    referralsTotal,
    referralsRewarded,
    flaggedReferrals,
    pendingKyc,
    money: money!,
    weekly: rows.map((r) => ({ day: r.day, games: Number(r.games), signups: Number(r.signups) })),
  }
})

/* ---------------- Users ---------------- */

export const adminListUsers = createServerFn({ method: 'GET' })
  .validator(z.object({ q: z.string().trim().max(80).default(''), status: z.string().default('all') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const q = data.q.replace(/[%_]/g, '')
    const where = and(
      q ? or(ilike(users.displayName, `%${q}%`), ilike(users.email, `%${q}%`), eq(users.publicId, q.toUpperCase()), eq(users.referralCode, q.toUpperCase())) : undefined,
      data.status === 'all' ? undefined : data.status === 'kyc' ? eq(users.kycStatus, 'pending') : eq(users.status, data.status),
    )
    return db
      .select({
        id: users.id,
        publicId: users.publicId,
        name: users.displayName,
        email: users.email,
        status: users.status,
        kycStatus: users.kycStatus,
        gamesPlayed: users.gamesPlayed,
        rating: users.rating,
        createdAt: users.createdAt,
        lastSeenAt: users.lastSeenAt,
        purchased: wallets.purchased,
        bonus: wallets.bonus,
        winnings: wallets.winnings,
        reserved: wallets.reserved,
      })
      .from(users)
      .leftJoin(wallets, eq(wallets.userId, users.id))
      .where(where)
      .orderBy(desc(users.createdAt))
      .limit(100)
  })

export const adminUserDetail = createServerFn({ method: 'GET' })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const [u] = await db.select().from(users).where(eq(users.id, data.id))
    if (!u) throw new UserError('User not found.')
    const [w] = await db.select().from(wallets).where(eq(wallets.userId, u.id))
    const [isAdmin] = await db.select().from(admins).where(eq(admins.userId, u.id))
    const [txs, deps, wds, gms, refs, logins] = await Promise.all([
      db.select().from(transactions).where(eq(transactions.userId, u.id)).orderBy(desc(transactions.createdAt)).limit(50),
      db.select().from(deposits).where(eq(deposits.userId, u.id)).orderBy(desc(deposits.createdAt)).limit(30),
      db.select().from(withdrawals).where(eq(withdrawals.userId, u.id)).orderBy(desc(withdrawals.createdAt)).limit(30),
      db
        .select({ id: games.id, mode: games.mode, won: gamePlayers.won, ratingDelta: gamePlayers.ratingDelta, endedAt: games.endedAt, players: games.players })
        .from(gamePlayers)
        .innerJoin(games, eq(games.id, gamePlayers.gameId))
        .where(eq(gamePlayers.userId, u.id))
        .orderBy(desc(games.endedAt))
        .limit(30),
      db
        .select({ id: referrals.id, status: referrals.status, flags: referrals.flags, createdAt: referrals.createdAt, name: users.displayName })
        .from(referrals)
        .innerJoin(users, eq(users.id, referrals.referredId))
        .where(eq(referrals.referrerId, u.id))
        .orderBy(desc(referrals.createdAt))
        .limit(50),
      db.select().from(loginHistory).where(eq(loginHistory.userId, u.id)).orderBy(desc(loginHistory.createdAt)).limit(20),
    ])
    const { signupIpHash: _ip, kycDocKey, ...safe } = u
    void _ip
    return { user: { ...safe, hasKycDoc: !!kycDocKey, isAdmin: !!isAdmin }, wallet: w ?? null, transactions: txs, deposits: deps, withdrawals: wds, games: gms, referrals: refs, logins }
  })

export const adminSetUserStatus = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string(), status: z.enum(['active', 'blocked', 'suspended']), reason: z.string().trim().max(300).default(''), days: z.number().int().min(1).max(365).optional() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    if (data.id === v.profile.id) throw new UserError('You cannot change your own account status.')
    const [u] = await db
      .update(users)
      .set({
        status: data.status,
        statusReason: data.reason || null,
        suspendedUntil: data.status === 'suspended' ? new Date(Date.now() + (data.days ?? 7) * 864e5) : null,
      })
      .where(eq(users.id, data.id))
      .returning()
    if (!u) throw new UserError('User not found.')
    await audit(actor(v), `Set user status to ${data.status}`, { type: 'user', id: u.publicId }, { reason: data.reason, days: data.days })
    await notify(u.id, {
      kind: 'account',
      title: data.status === 'active' ? 'Account restored' : `Account ${data.status}`,
      body: data.reason || (data.status === 'active' ? 'Your account is active again.' : 'Contact support for details.'),
    })
    return { ok: true }
  })

export const adminReviewKyc = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string(), approve: z.boolean(), note: z.string().max(300).default('') }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [u] = await db
      .update(users)
      .set({ kycStatus: data.approve ? 'verified' : 'rejected' })
      .where(and(eq(users.id, data.id), eq(users.kycStatus, 'pending')))
      .returning()
    if (!u) throw new UserError('No pending KYC for this user.')
    await audit(actor(v), data.approve ? 'Approved KYC' : 'Rejected KYC', { type: 'user', id: u.publicId }, { note: data.note })
    await notify(u.id, { kind: 'account', title: data.approve ? 'KYC verified' : 'KYC rejected', body: data.note || (data.approve ? 'Your identity is verified.' : 'Please resubmit clearer documents.') })
    return { ok: true }
  })

export const adminGrantAdmin = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string(), grant: z.boolean() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    if (data.id === v.profile.id && !data.grant) throw new UserError('You cannot remove your own admin role.')
    const [u] = await db.select().from(users).where(eq(users.id, data.id))
    if (!u) throw new UserError('User not found.')
    if (data.grant) await db.insert(admins).values({ userId: u.id, email: u.email, grantedBy: v.profile.id }).onConflictDoNothing()
    else await db.delete(admins).where(eq(admins.userId, u.id))
    try {
      const iu = await identityAdmin.getUser(u.id)
      const roles = new Set(iu.roles ?? [])
      if (data.grant) roles.add('admin')
      else roles.delete('admin')
      await identityAdmin.updateUser(u.id, { app_metadata: { ...(iu.appMetadata ?? {}), roles: [...roles] } })
    } catch {
      /* Identity role mirror is best-effort */
    }
    await audit(actor(v), data.grant ? 'Granted admin role' : 'Revoked admin role', { type: 'user', id: u.publicId })
    return { ok: true }
  })

/* ---------------- Deposits ---------------- */

export const adminListDeposits = createServerFn({ method: 'GET' })
  .validator(z.object({ status: z.string().default('open'), q: z.string().trim().max(60).default('') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const q = data.q.replace(/[%_]/g, '')
    const rows = await db
      .select({ d: deposits, name: users.displayName, publicId: users.publicId, email: users.email, userCreatedAt: users.createdAt })
      .from(deposits)
      .innerJoin(users, eq(users.id, deposits.userId))
      .where(
        and(
          data.status === 'open' ? sql`${deposits.status} in ('pending','under_review')` : data.status === 'all' ? undefined : eq(deposits.status, data.status),
          q ? or(ilike(deposits.tid, `%${q}%`), eq(deposits.id, q.toUpperCase()), eq(users.publicId, q.toUpperCase()), ilike(users.displayName, `%${q}%`)) : undefined,
        ),
      )
      .orderBy(desc(deposits.createdAt))
      .limit(100)
    return rows.map((r) => ({ ...r.d, name: r.name, publicId: r.publicId, email: r.email, hasScreenshot: !!r.d.screenshotKey }))
  })

export const adminReviewDeposit = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      id: z.string(),
      action: z.enum(['under_review', 'approve', 'reject']),
      note: z.string().trim().max(500).default(''),
      tidVerified: z.boolean().default(false),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    if (data.action === 'approve' && !data.tidVerified)
      throw new UserError('Confirm you verified the TID and amount in the provider statement before approving.')
    if (data.action === 'reject' && !data.note) throw new UserError('Add a note explaining the rejection.')
    return db.transaction(async (tx) => {
      const allowedFrom = data.action === 'under_review' ? ['pending'] : ['pending', 'under_review']
      const status = data.action === 'approve' ? 'approved' : data.action === 'reject' ? 'rejected' : 'under_review'
      const [d] = await tx
        .update(deposits)
        .set({ status, adminNote: data.note || null, reviewedBy: v.profile.id, reviewedAt: new Date() })
        .where(and(eq(deposits.id, data.id), sql`${deposits.status} in (${sql.join(allowedFrom.map((s) => sql`${s}`), sql`, `)})`))
        .returning()
      if (!d) throw new UserError('This deposit was already processed.')
      if (status === 'approved') {
        await postLedger(tx, {
          userId: d.userId,
          bucket: 'purchased',
          amount: d.coins,
          type: 'deposit',
          label: `${d.packageName} pack via ${d.method}`,
          idempotencyKey: `deposit:${d.id}:coins`,
          refType: 'deposit',
          refId: d.id,
          createdBy: v.profile.id,
        })
        if (d.bonusCoins > 0)
          await postLedger(tx, {
            userId: d.userId,
            bucket: 'bonus',
            amount: d.bonusCoins,
            type: 'deposit',
            label: `${d.packageName} pack bonus`,
            idempotencyKey: `deposit:${d.id}:bonus`,
            refType: 'deposit',
            refId: d.id,
            createdBy: v.profile.id,
          })
      }
      await audit(actor(v), `Deposit ${status.replace('_', ' ')}`, { type: 'deposit', id: d.id }, { tid: d.tid, amountPkr: d.amountPkr, note: data.note }, tx)
      const title = status === 'approved' ? 'Deposit approved' : status === 'rejected' ? 'Deposit rejected' : 'Deposit under review'
      const body =
        status === 'approved'
          ? `${(d.coins + d.bonusCoins).toLocaleString()} coins were added to your wallet (TID ${d.tid}).`
          : status === 'rejected'
            ? `TID ${d.tid}: ${data.note}`
            : `We are verifying TID ${d.tid} with ${d.method}.`
      await notify(d.userId, { kind: 'deposit', title, body, link: '/app/wallet' }, tx)
      return { ok: true }
    })
  })

/* ---------------- Withdrawals ---------------- */

export const adminListWithdrawals = createServerFn({ method: 'GET' })
  .validator(z.object({ status: z.string().default('open') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const rows = await db
      .select({ w: withdrawals, name: users.displayName, publicId: users.publicId, kycStatus: users.kycStatus })
      .from(withdrawals)
      .innerJoin(users, eq(users.id, withdrawals.userId))
      .where(data.status === 'open' ? sql`${withdrawals.status} in ('pending','approved','processing')` : data.status === 'all' ? undefined : eq(withdrawals.status, data.status))
      .orderBy(desc(withdrawals.createdAt))
      .limit(100)
    return rows.map((r) => ({ ...r.w, name: r.name, publicId: r.publicId, kycStatus: r.kycStatus }))
  })

export const adminUpdateWithdrawal = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string(), status: z.enum(['approved', 'processing', 'paid', 'rejected']), reference: z.string().trim().max(60).default(''), note: z.string().trim().max(500).default('') }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    return updateWithdrawal({ ...data, admin: actor(v) })
  })

/* ---------------- Wallets ---------------- */

export const adminAdjustWallet = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      userId: z.string(),
      bucket: z.enum(['purchased', 'bonus']),
      amount: z.number().int().min(-1_000_000).max(1_000_000).refine((n) => n !== 0),
      reason: z.string().trim().min(5).max(300),
      kind: z.enum(['promo', 'adjustment']),
      idempotencyKey: z.string().uuid(),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    if (data.kind === 'promo' && (data.bucket !== 'bonus' || data.amount < 0)) throw new UserError('Promotional rewards must be positive bonus coins.')
    return db.transaction(async (tx) => {
      const r = await postLedger(tx, {
        userId: data.userId,
        bucket: data.bucket,
        amount: data.amount,
        type: data.kind,
        label: data.kind === 'promo' ? `Promo: ${data.reason}` : `Correction: ${data.reason}`,
        idempotencyKey: `admin:${data.idempotencyKey}`,
        createdBy: v.profile.id,
      })
      if (r.duplicate) return { ok: true, duplicate: true }
      await audit(actor(v), data.kind === 'promo' ? 'Issued promotional bonus' : 'Wallet correction', { type: 'user', id: data.userId }, { bucket: data.bucket, amount: data.amount, reason: data.reason, tx: r.id }, tx)
      await notify(data.userId, { kind: 'wallet', title: data.kind === 'promo' ? 'You received bonus coins' : 'Wallet adjusted', body: `${data.amount > 0 ? '+' : ''}${data.amount} coins · ${data.reason}`, link: '/app/wallet' }, tx)
      return { ok: true, duplicate: false }
    })
  })

export const adminBulkPromo = createServerFn({ method: 'POST' })
  .validator(z.object({ amount: z.number().int().min(1).max(10_000), reason: z.string().trim().min(5).max(200), activeDays: z.number().int().min(1).max(90), idempotencyKey: z.string().uuid() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const targets = await db.select({ id: users.id }).from(users).where(and(eq(users.status, 'active'), sql`last_seen_at > now() - make_interval(days => ${data.activeDays})`)).limit(5000)
    let credited = 0
    for (const t of targets) {
      await db.transaction(async (tx) => {
        const r = await postLedger(tx, { userId: t.id, bucket: 'bonus', amount: data.amount, type: 'promo', label: `Promo: ${data.reason}`, idempotencyKey: `bulk:${data.idempotencyKey}:${t.id}`, createdBy: v.profile.id })
        if (!r.duplicate) {
          credited++
          await notify(t.id, { kind: 'wallet', title: 'Promotional bonus', body: `+${data.amount} bonus coins · ${data.reason}`, link: '/app/wallet' }, tx)
        }
      })
    }
    await audit(actor(v), 'Issued bulk promotional bonus', { type: 'promo', id: data.idempotencyKey }, { amount: data.amount, credited, reason: data.reason })
    return { credited }
  })

export const adminListTransactions = createServerFn({ method: 'GET' })
  .validator(z.object({ type: z.string().default('all'), q: z.string().trim().max(60).default('') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const q = data.q.replace(/[%_]/g, '')
    return db
      .select({ t: transactions, name: users.displayName, publicId: users.publicId })
      .from(transactions)
      .innerJoin(users, eq(users.id, transactions.userId))
      .where(and(data.type === 'all' ? undefined : eq(transactions.type, data.type), q ? or(eq(transactions.id, q.toUpperCase()), eq(users.publicId, q.toUpperCase()), ilike(users.displayName, `%${q}%`)) : undefined))
      .orderBy(desc(transactions.createdAt))
      .limit(200)
      .then((rows) => rows.map((r) => ({ ...r.t, name: r.name, publicId: r.publicId })))
  })

export const adminAuditLog = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  const rows = await db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(200)
  return rows.map((r) => ({ ...r, details: r.details ? JSON.stringify(r.details) : null }))
})

/* ---------------- Referrals ---------------- */

export const adminListReferrals = createServerFn({ method: 'GET' })
  .validator(z.object({ status: z.string().default('all') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const referred = sql`referred`
    void referred
    const rows = await db.execute<Record<string, unknown>>(sql`
      select r.id, r.status, r.reward, r.flags, r.created_at as "createdAt", r.code,
        a.display_name as "referrer", a.public_id as "referrerId",
        b.display_name as "referred", b.public_id as "referredId", b.id as "referredUserId", b.games_played as "games"
      from referrals r join users a on a.id = r.referrer_id join users b on b.id = r.referred_id
      ${data.status === 'all' ? sql`` : sql`where r.status = ${data.status}`}
      order by r.created_at desc limit 200`)
    const list = ((rows as unknown as { rows?: unknown[] }).rows ?? rows) as {
      id: number
      status: string
      reward: number
      flags: string[]
      createdAt: string
      code: string
      referrer: string
      referrerId: string
      referred: string
      referredId: string
      referredUserId: string
      games: number
    }[]
    const [earn] = await db.select({ total: sql<number>`coalesce(sum(amount),0)::int` }).from(transactions).where(eq(transactions.type, 'referral'))
    return { rows: list, totalPaid: earn?.total ?? 0 }
  })

export const adminResolveReferral = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.number().int(), action: z.enum(['approve', 'reject']) }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [r] = await db.select().from(referrals).where(eq(referrals.id, data.id))
    if (!r) throw new UserError('Referral not found.')
    if (data.action === 'reject') {
      const [x] = await db.update(referrals).set({ status: 'rejected', resolvedAt: new Date() }).where(and(eq(referrals.id, r.id), sql`status in ('pending','flagged')`)).returning()
      if (!x) throw new UserError('Referral already resolved.')
      await audit(actor(v), 'Rejected referral as fraudulent', { type: 'referral', id: String(r.id) })
      return { ok: true }
    }
    const s = await getSettings()
    await qualifyReferral(r.referredId, s.referral.referrerReward, s.referral.refereeReward, actor(v))
    return { ok: true }
  })

/* ---------------- Games & tournaments ---------------- */

export const adminGames = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  const rooms = await db.select().from(gameRooms).where(sql`${gameRooms.status} in ('waiting','playing')`).orderBy(desc(gameRooms.updatedAt)).limit(100)
  const history = await db.select().from(games).orderBy(desc(games.endedAt)).limit(100)
  // Simple anti-cheat signals: improbable win streaks and very fast games.
  const suspicious = await db.execute<Record<string, unknown>>(sql`
    select u.public_id as "publicId", u.display_name as "name", u.games_played as "played", u.games_won as "won",
      round(100.0 * u.games_won / nullif(u.games_played,0)) as "winRate"
    from users u where u.games_played >= 10 and u.games_won::float / u.games_played > 0.8 order by u.games_won desc limit 20`)
  const flagged = ((suspicious as unknown as { rows?: unknown[] }).rows ?? suspicious) as { publicId: string; name: string; played: number; won: number; winRate: number }[]
  return {
    rooms: rooms.map((r) => ({ id: r.id, code: r.code, mode: r.game === 'ludo' ? r.mode : `${r.game} ${r.mode}`, status: r.status, isPrivate: r.isPrivate, seats: r.seats.map((s) => s.name || '—'), updatedAt: r.updatedAt })),
    history,
    flagged,
  }
})

export const adminCloseRoom = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [room] = await db.select().from(gameRooms).where(eq(gameRooms.id, data.id))
    if (room && room.stakeStatus !== 'none' && room.stakeStatus !== 'paid') {
      // Coin-entry room: cancel and refund any charged entries.
      await refundRoom(room.id, 'Closed by an admin.', actor(v))
      return { ok: true }
    }
    await db.update(gameRooms).set({ status: 'abandoned', updatedAt: new Date() }).where(eq(gameRooms.id, data.id))
    await audit(actor(v), 'Closed game room', { type: 'room', id: data.id })
    return { ok: true }
  })

export const adminTournaments = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  await settleDueTournaments()
  return db
    .select({ t: tournaments, players: sql<number>`(select count(*)::int from tournament_entries e where e.tournament_id = ${tournaments.id})` })
    .from(tournaments)
    .orderBy(desc(tournaments.startsAt))
    .limit(100)
    .then((rows) => rows.map((r) => ({ ...r.t, players: r.players })))
})

export const adminCreateTournament = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      name: z.string().trim().min(3).max(60),
      kind: z.enum(['daily', 'weekly', 'private']),
      mode: z.enum(['1v1', '2v2', '4p']),
      prizeCoins: z.number().int().min(0).max(1_000_000),
      capacity: z.number().int().min(2).max(10_000),
      startsAt: z.string(),
      hours: z.number().int().min(1).max(24 * 30),
      announce: z.boolean().default(true),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const start = new Date(data.startsAt)
    if (Number.isNaN(start.getTime())) throw new UserError('Invalid start time.')
    const id = newId('TN', 6)
    await db.insert(tournaments).values({
      id,
      name: data.name,
      kind: data.kind,
      mode: data.mode,
      prizeCoins: data.prizeCoins,
      capacity: data.capacity,
      startsAt: start,
      endsAt: new Date(start.getTime() + data.hours * 3600_000),
      status: start <= new Date() ? 'live' : 'upcoming',
      inviteCode: data.kind === 'private' ? randomCode(6) : null,
      createdBy: v.profile.id,
    })
    await audit(actor(v), 'Created tournament', { type: 'tournament', id }, data)
    if (data.announce && data.kind !== 'private')
      await broadcast({ kind: 'tournament', title: `New tournament: ${data.name}`, body: `Free ${data.mode} tournament · ${data.prizeCoins} bonus-coin prize pool.`, link: '/app/tournaments' })
    return { id }
  })

export const adminCancelTournament = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    await db.update(tournaments).set({ status: 'cancelled' }).where(and(eq(tournaments.id, data.id), sql`settled_at is null`))
    await audit(actor(v), 'Cancelled tournament', { type: 'tournament', id: data.id })
    return { ok: true }
  })

export const adminEndTournament = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    await db.update(tournaments).set({ endsAt: new Date() }).where(and(eq(tournaments.id, data.id), sql`settled_at is null`))
    await settleDueTournaments()
    await audit(actor(v), 'Ended and settled tournament', { type: 'tournament', id: data.id })
    const n = await db.select({ n: count }).from(tournamentEntries).where(eq(tournamentEntries.tournamentId, data.id))
    return { ok: true, entries: n[0]?.n ?? 0 }
  })

/* ---------------- Settings, support, notifications ---------------- */

export const adminGetSettings = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  return getSettings()
})

const settingsSchema = z.object({
  siteName: z.string().trim().min(2).max(40),
  logoUrl: z.string().trim().max(300),
  paymentMethods: z.array(z.object({ id: z.enum(['easypaisa', 'jazzcash', 'sadapay']), name: z.string().min(2).max(30), account: z.string().regex(/^03\d{9}$/), accountTitle: z.string().max(60), enabled: z.boolean() })).length(3),
  coinPackages: z.array(z.object({ id: z.string().min(2).max(30), name: z.string().min(2).max(30), coins: z.number().int().min(1), bonus: z.number().int().min(0), price: z.number().int().min(1), tag: z.string().max(20).nullable(), active: z.boolean() })).min(1).max(12),
  referral: z.object({ enabled: z.boolean(), referrerReward: z.number().int().min(0).max(100000), refereeReward: z.number().int().min(0).max(100000), qualifyGames: z.number().int().min(0).max(100), dailyCapPerReferrer: z.number().int().min(1).max(1000), campaignName: z.string().max(60) }),
  welcomeBonus: z.number().int().min(0).max(100000),
  dailyRewards: z.array(z.number().int().min(0).max(100000)).length(7),
  limits: z.object({ depositMinPkr: z.number().int().min(1), depositMaxPkr: z.number().int().min(1), depositDailyMaxPkr: z.number().int().min(1), depositsPerDay: z.number().int().min(1).max(100), withdrawMinCoins: z.number().int().min(1), withdrawMaxCoins: z.number().int().min(1), withdrawCoinsPerPkr: z.number().min(0.01).max(10000).default(5) }),
  maintenance: z.object({ enabled: z.boolean(), message: z.string().max(300) }),
  banners: z.array(z.object({ id: z.string(), title: z.string().max(80), body: z.string().max(300), active: z.boolean() })).max(10),
  support: z.object({ email: z.string().max(120), whatsapp: z.string().max(30), hours: z.string().max(60) }),
  blockedCountries: z.array(z.string().length(2)).max(250),
  game: z.object({ turnSeconds: z.number().int().min(10).max(120), botFillSeconds: z.number().int().min(5).max(600) }),
})

export const adminSaveSettings = createServerFn({ method: 'POST' })
  .validator(settingsSchema)
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const before = await getSettings()
    await saveSettings(data as SiteSettings, v.profile.id)
    const changed = (Object.keys(data) as (keyof SiteSettings)[]).filter((k) => JSON.stringify(before[k]) !== JSON.stringify(data[k]))
    await audit(actor(v), 'Updated site settings', { type: 'settings', id: 'site' }, { changed })
    return { ok: true, changed }
  })

export const adminListTickets = createServerFn({ method: 'GET' })
  .validator(z.object({ status: z.string().default('open') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    return db
      .select({ t: supportTickets, name: users.displayName, publicId: users.publicId, email: users.email })
      .from(supportTickets)
      .innerJoin(users, eq(users.id, supportTickets.userId))
      .where(data.status === 'all' ? undefined : eq(supportTickets.status, data.status))
      .orderBy(desc(supportTickets.createdAt))
      .limit(100)
      .then((rows) => rows.map((r) => ({ ...r.t, name: r.name, publicId: r.publicId, email: r.email })))
  })

export const adminReplyTicket = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.string(), reply: z.string().trim().max(2000).default(''), close: z.boolean().default(false) }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [t] = await db
      .update(supportTickets)
      .set({ adminReply: data.reply || undefined, status: data.close ? 'closed' : 'answered', updatedAt: new Date() })
      .where(eq(supportTickets.id, data.id))
      .returning()
    if (!t) throw new UserError('Ticket not found.')
    await audit(actor(v), data.close ? 'Closed support ticket' : 'Replied to support ticket', { type: 'ticket', id: t.id })
    await notify(t.userId, { kind: 'support', title: `Support: ${t.subject}`, body: data.reply || 'Your ticket was closed.', link: '/app/profile' })
    return { ok: true }
  })

export const adminBroadcast = createServerFn({ method: 'POST' })
  .validator(z.object({ title: z.string().trim().min(3).max(80), body: z.string().trim().min(3).max(300), link: z.string().max(120).optional() }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    await broadcast({ kind: 'promo', title: data.title, body: data.body, link: data.link })
    await audit(actor(v), 'Sent broadcast notification', undefined, data)
    return { ok: true }
  })
