import { createHash, randomBytes, randomInt } from 'node:crypto'

const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

export function randomCode(len: number) {
  let s = ''
  for (let i = 0; i < len; i++) s += ALPHA[randomInt(ALPHA.length)]
  return s
}

export const newId = (prefix: string, len = 8) => `${prefix}-${randomCode(len)}`
export const roomCode = () => String(randomInt(100000, 1000000))
export const secureDie = () => randomInt(1, 7)

export function sha256(v: string) {
  return createHash('sha256').update(v).digest('hex')
}

/** One-way hash for IPs so fraud checks can compare without storing raw addresses. */
export function hashIp(ip: string | undefined | null) {
  if (!ip) return null
  return sha256(`lka-ip:${process.env.SITE_ID ?? 'local'}:${ip}`).slice(0, 32)
}

export function hashPassword(pw: string) {
  const salt = randomBytes(8).toString('hex')
  return `${salt}:${sha256(`${salt}:${pw}`)}`
}
export function checkPassword(pw: string, stored: string | null) {
  if (!stored) return true
  const [salt, h] = stored.split(':')
  return sha256(`${salt}:${pw}`) === h
}

/** TIDs are compared case/space-insensitively so "ab 12" and "AB12" collide. */
export const normalizeTid = (tid: string) => tid.replace(/[\s-]/g, '').toUpperCase()

export const todayUtc = () => new Date().toISOString().slice(0, 10)

export class UserError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'UserError'
  }
}

export function isUniqueViolation(e: unknown) {
  const err = e as { code?: string; cause?: { code?: string } }
  return err?.code === '23505' || err?.cause?.code === '23505'
}

export const initials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join('') || '?'
