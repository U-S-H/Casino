import { getStore } from '@netlify/blobs'

import { UserError } from './util.js'

const TYPES: Record<string, string> = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
}

export interface UploadedImage {
  bytes: ArrayBuffer
  type: string
  ext: string
}

/** Validates an uploaded image by declared type, magic bytes and size. */
export async function readImage(v: FormDataEntryValue | null, maxBytes: number): Promise<UploadedImage> {
  if (!v || typeof v === 'string') throw new UserError('Please attach an image.')
  const ext = TYPES[v.type]
  if (!ext) throw new UserError('Only PNG, JPG or WEBP images are allowed.')
  if (v.size === 0 || v.size > maxBytes) throw new UserError(`Image must be smaller than ${Math.round(maxBytes / 1024 / 1024)} MB.`)
  const bytes = await v.arrayBuffer()
  const h = new Uint8Array(bytes.slice(0, 12))
  const png = h[0] === 0x89 && h[1] === 0x50 && h[2] === 0x4e && h[3] === 0x47
  const jpg = h[0] === 0xff && h[1] === 0xd8 && h[2] === 0xff
  const webp = h[0] === 0x52 && h[1] === 0x49 && h[2] === 0x46 && h[3] === 0x46 && h[8] === 0x57 && h[9] === 0x45
  if (!png && !jpg && !webp) throw new UserError('That file does not look like a real image.')
  return { bytes, type: v.type, ext }
}

const store = (name: string) => getStore({ name, consistency: 'strong' })

export async function putAvatar(userId: string, f: UploadedImage) {
  const key = `${userId}/${Date.now()}.${f.ext}`
  await store('avatars').set(key, f.bytes, { metadata: { type: f.type } })
  return key
}
export async function putScreenshot(depositId: string, f: UploadedImage) {
  const key = `${depositId}.${f.ext}`
  await store('deposit-screenshots').set(key, f.bytes, { metadata: { type: f.type } })
  return key
}
export async function putKycDoc(userId: string, f: UploadedImage) {
  const key = `${userId}/${Date.now()}.${f.ext}`
  await store('kyc-documents').set(key, f.bytes, { metadata: { type: f.type } })
  return key
}

export async function readBlob(storeName: 'avatars' | 'deposit-screenshots' | 'kyc-documents', key: string) {
  const r = await store(storeName).getWithMetadata(key, { type: 'arrayBuffer' })
  if (!r) return null
  return { bytes: r.data, type: String((r.metadata as { type?: string }).type ?? 'application/octet-stream') }
}
