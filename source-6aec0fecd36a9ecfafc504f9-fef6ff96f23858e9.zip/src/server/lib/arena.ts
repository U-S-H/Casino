import { randomInt } from 'node:crypto'
import { and, eq, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { gamePlayers, gameRooms, games, users, type SeatInfo } from '../../../db/schema.js'
import { carromEngine } from '../../lib/games/carrom.js'
import { chessEngine } from '../../lib/games/chess.js'
import { poolEngine } from '../../lib/games/pool.js'
import { GameRuleError, type ArenaEngine, type ArenaGameId, type StepResult } from '../../lib/games/types.js'
import { notify } from './audit.js'
import { getSettings } from './settings.js'
import { chargeAndStart, getArenaConfig, refundRoom, settleRoom, type Room } from './stakes.js'
import { UserError } from './util.js'
import { qualifyReferral } from './rooms.js'

/**
 * Server-authoritative engine for the two-player arena games. The browser only
 * sends intents (a chess move, a cue direction + power, a striker position +
 * direction + power); the pure engines in src/lib/games run the rules and the
 * physics here, and only the server decides the winner and the payout.
 */

export const ENGINES: Record<ArenaGameId, ArenaEngine> = {
  pool: poolEngine as unknown as ArenaEngine,
  carrom: carromEngine as unknown as ArenaEngine,
  chess: chessEngine as unknown as ArenaEngine,
}
export const isArena = (g: string): g is ArenaGameId => g === 'pool' || g === 'carrom' || g === 'chess'

/** Shot animations need a moment to replay before the next turn clock starts. */
const ANIM_GRACE_MS: Record<ArenaGameId, number> = { pool: 7000, carrom: 6000, chess: 0 }
const MAX_MISSED = 3

export interface ArenaRoomState {
  g: unknown
  turnSeconds: number
  turns: number
  startedAt: string
  outcome: { winner: number | null; reason: string } | null
}

const cryptoRand = () => randomInt(0, 2 ** 32) / 2 ** 32

async function turnSecondsFor(room: Room) {
  const cfg = await getArenaConfig()
  const eng = ENGINES[room.game as ArenaGameId]
  return cfg[room.game as ArenaGameId]?.matchTypes.find((m) => m.id === room.mode)?.turnSeconds ?? eng.turnSeconds
}

export async function startArena(room: Room) {
  if (room.seats.some((s) => !s.userId)) throw new UserError('Waiting for an opponent.')
  const eng = ENGINES[room.game as ArenaGameId]
  const turnSeconds = await turnSecondsFor(room)
  const st: ArenaRoomState = {
    g: eng.init([room.seats[0]!.name, room.seats[1]!.name], cryptoRand),
    turnSeconds,
    turns: 0,
    startedAt: new Date().toISOString(),
    outcome: null,
  }
  return chargeAndStart(room, {
    status: 'playing',
    state: st as unknown as Record<string, unknown>,
    seats: room.seats.map((s) => ({ ...s, owner: s.userId ?? undefined, missed: 0 })),
    turnDeadline: new Date(Date.now() + turnSeconds * 1000),
  })
}

async function commit(room: Room, st: ArenaRoomState, res: StepResult<unknown>, seats: SeatInfo[], graceMs: number) {
  const next: ArenaRoomState = {
    ...st,
    g: res.state,
    turns: st.turns + 1,
    outcome: res.done ? { winner: res.winner, reason: res.reason ?? (res.winner === null ? 'Draw' : 'Won') } : null,
  }
  const [saved] = await db
    .update(gameRooms)
    .set({
      state: next as unknown as Record<string, unknown>,
      seats,
      status: res.done ? 'finished' : 'playing',
      turnDeadline: res.done ? null : new Date(Date.now() + graceMs + st.turnSeconds * 1000),
      ...(res.done ? { endedAt: new Date() } : {}),
      version: room.version + 1,
      updatedAt: new Date(),
    })
    .where(and(eq(gameRooms.id, room.id), eq(gameRooms.version, room.version), eq(gameRooms.status, 'playing')))
    .returning()
  if (saved && res.done) await finishArena(saved)
  return saved ?? null
}

/** Validates and applies one player action. Throws a UserError for anything illegal. */
export async function arenaAction(room: Room, userId: string, raw: unknown) {
  if (room.status !== 'playing') throw new UserError('This game is not in progress.')
  const seat = room.seats.findIndex((s) => s.userId === userId)
  if (seat < 0) throw new UserError('You are not a player in this match.')
  const game = room.game as ArenaGameId
  const eng = ENGINES[game]
  const st = room.state as unknown as ArenaRoomState
  let res: StepResult<unknown>
  try {
    res = eng.apply(st.g, seat, eng.parseAction(raw))
  } catch (e) {
    if (e instanceof GameRuleError) throw new UserError(e.message)
    throw e
  }
  const seats = room.seats.map((s, i) => (i === seat ? { ...s, missed: 0 } : s))
  const kind = (raw as { type?: string } | null)?.type
  const grace = kind === 'shot' || kind === 'strike' ? ANIM_GRACE_MS[game] : 0
  const saved = await commit(room, st, res, seats, grace)
  if (!saved) throw new UserError('The game moved on — try again.')
  return saved
}

/** Called on every poll: applies turn timeouts and repairs interrupted settlements. */
export async function arenaTick(room: Room): Promise<Room> {
  if (room.status === 'waiting') {
    const age = Date.now() - room.createdAt.getTime()
    const limit = (room.isPrivate ? 60 : 10) * 60_000
    if (age > limit) return (await refundRoom(room.id, 'No opponent joined in time.').catch(() => null)) ?? room
    return room
  }
  if (room.status === 'finished' && room.stakeStatus === 'charged' && Date.now() - room.updatedAt.getTime() > 5000) {
    await finishArena(room).catch(() => undefined)
    return loadArena(room.id)
  }
  if (room.status !== 'playing' || !room.turnDeadline || room.turnDeadline.getTime() > Date.now()) return room
  const st = room.state as unknown as ArenaRoomState
  const eng = ENGINES[room.game as ArenaGameId]
  const seat = eng.current(st.g)
  const missed = (room.seats[seat]?.missed ?? 0) + 1
  const seats = room.seats.map((s, i) => (i === seat ? { ...s, missed } : s))
  let res: StepResult<unknown>
  if (missed >= MAX_MISSED) {
    seats[seat] = { ...seats[seat]!, forfeited: true }
    res = { state: st.g, done: true, winner: 1 - seat, reason: `${room.seats[seat]!.name} missed ${MAX_MISSED} turns in a row` }
  } else {
    res = eng.timeout(st.g, seat)
  }
  return (await commit(room, st, res, seats, 0)) ?? (await loadArena(room.id))
}

/** Leaving a live match is a forfeit: the opponent is the verified winner. */
export async function arenaForfeit(room: Room, userId: string) {
  const seat = room.seats.findIndex((s) => s.userId === userId)
  if (seat < 0 || room.status !== 'playing') return room
  const st = room.state as unknown as ArenaRoomState
  const seats = room.seats.map((s, i) => (i === seat ? { ...s, forfeited: true } : s))
  return commit(room, st, { state: st.g, done: true, winner: 1 - seat, reason: `${room.seats[seat]!.name} left the match` }, seats, 0)
}

async function loadArena(id: string) {
  const [r] = await db.select().from(gameRooms).where(eq(gameRooms.id, id))
  if (!r) throw new UserError('Room not found.')
  return r
}

/** Records history/stats once (unique gameId per room) and pays the verified result. Safe to call repeatedly. */
export async function finishArena(room: Room) {
  const st = room.state as unknown as ArenaRoomState
  const out = st.outcome
  if (!out) return
  const draw = out.winner === null
  const gameId = `GM-${room.id}`
  const players = room.seats.map((s, i) => ({
    userId: s.owner ?? s.userId,
    name: s.name,
    color: i === 0 ? 'seat-1' : 'seat-2',
    team: i,
    won: !draw && out.winner === i,
    finished: 0,
  }))
  const inserted = await db
    .insert(games)
    .values({
      id: gameId,
      roomId: room.id,
      game: room.game,
      mode: room.mode,
      entryFee: room.entryFee,
      prizePool: room.entryFee * room.seats.length,
      platformFee: draw ? 0 : Math.floor((room.entryFee * room.seats.length * room.feePercent) / 100),
      reason: out.reason,
      players,
      winnerTeam: out.winner,
      turns: st.turns,
      startedAt: new Date(st.startedAt),
    })
    .onConflictDoNothing()
    .returning()

  if (inserted.length) {
    const s = await getSettings()
    for (const p of players) {
      if (!p.userId) continue
      await db.insert(gamePlayers).values({ gameId, userId: p.userId, won: p.won, ratingDelta: 0 }).onConflictDoNothing()
      const [u] = await db
        .update(users)
        .set({ gamesPlayed: sql`${users.gamesPlayed} + 1`, gamesWon: p.won ? sql`${users.gamesWon} + 1` : users.gamesWon })
        .where(eq(users.id, p.userId))
        .returning()
      if (room.entryFee === 0)
        await notify(p.userId, {
          kind: 'game',
          title: draw ? 'Match drawn' : p.won ? 'Victory!' : 'Match finished',
          body: `${ENGINES[room.game as ArenaGameId].name} #${room.code}: ${out.reason}.`,
          link: `/app/arena/${room.game}`,
        })
      if (u && u.referredBy && u.gamesPlayed >= s.referral.qualifyGames && s.referral.enabled)
        await qualifyReferral(u.id, s.referral.referrerReward, s.referral.refereeReward)
    }
  }
  if (room.entryFee > 0)
    await settleRoom(room.id, draw ? [] : [[out.winner!], [1 - out.winner!]], out.reason, { draw })
}
