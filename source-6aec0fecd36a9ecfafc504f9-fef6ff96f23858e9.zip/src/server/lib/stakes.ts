import { and, eq, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { gameRooms, settings, wallets, type SeatInfo } from '../../../db/schema.js'
import { mergeArena, prizeMath, splitPrize, type ArenaConfig, type GameKey } from '../../lib/games/catalog.js'
import { audit, notify } from './audit.js'
import type { Tx } from './db-types.js'
import { postLedger } from './ledger.js'
import { UserError } from './util.js'

/**
 * Shared virtual-coin entry system for every game (Ludo, 8 Ball Pool, Carrom,
 * Chess). Prizes land in the winnings bucket, which players may request to withdraw (see lib/withdrawals.ts).
 *
 * Lifecycle of a coin-entry room (`game_rooms.stake_status`):
 *   pending  → room created; the entry amount is locked and never changes.
 *              Nothing is deducted yet. Cancelling here costs nobody anything.
 *   charged  → the match officially started. Every player's entry was
 *              deducted in ONE database transaction together with the room
 *              switching to `playing` (idempotency key per player+bucket).
 *   paid     → the server verified the result and paid the winner(s).
 *   refunded → match voided/abandoned after the charge; entries returned.
 *   cancelled → cancelled before it started; nothing was ever deducted.
 * Each transition is a conditional UPDATE … WHERE stake_status = <from>, so a
 * second attempt (retry, double click, concurrent poll) changes nothing.
 */

export type Room = typeof gameRooms.$inferSelect

export async function getArenaConfig(): Promise<ArenaConfig> {
  const [row] = await db.select().from(settings).where(eq(settings.key, 'arena'))
  return mergeArena(row?.value)
}

export async function saveArenaConfig(value: ArenaConfig, by: string) {
  await db
    .insert(settings)
    .values({ key: 'arena', value, updatedBy: by })
    .onConflictDoUpdate({ target: settings.key, set: { value, updatedBy: by, updatedAt: new Date() } })
}

export async function spendableBalance(userId: string) {
  const [w] = await db.select().from(wallets).where(eq(wallets.userId, userId))
  return w ? w.bonus + w.purchased + w.winnings : 0
}

export async function assertCanAfford(userId: string, entry: number) {
  if (entry <= 0) return
  const bal = await spendableBalance(userId)
  if (bal < entry) throw new UserError(`You need ${entry.toLocaleString()} coins for this match but have ${bal.toLocaleString()}. Top up your wallet first.`)
}

const BUCKETS = ['bonus', 'purchased', 'winnings'] as const
const gameName = (g: string) => ({ ludo: 'Ludo', pool: '8 Ball Pool', carrom: 'Carrom', chess: 'Chess' })[g] ?? g

/** Deducts one player's entry (bonus → purchased → winnings) inside `tx`. Throws if they can't afford it. */
async function chargeSeat(tx: Tx, room: Room, userId: string) {
  const rows = await tx.execute<{ bonus: number; purchased: number; winnings: number }>(
    sql`select bonus, purchased, winnings from wallets where user_id = ${userId} for update`,
  )
  const w = ((rows as unknown as { rows?: unknown[] }).rows ?? rows) as { bonus: number | string; purchased: number | string; winnings: number | string }[]
  const have = { bonus: Number(w[0]?.bonus ?? 0), purchased: Number(w[0]?.purchased ?? 0), winnings: Number(w[0]?.winnings ?? 0) }
  let left = room.entryFee
  const paid = { bonus: 0, purchased: 0, winnings: 0 }
  for (const b of BUCKETS) {
    const take = Math.min(left, have[b])
    paid[b] = take
    left -= take
  }
  if (left > 0) throw new InsufficientCoins(userId)
  for (const b of BUCKETS) {
    if (!paid[b]) continue
    await postLedger(tx, {
      userId,
      bucket: b,
      amount: -paid[b],
      type: 'game_entry',
      label: `${gameName(room.game)} match entry #${room.code}`,
      idempotencyKey: `entry:${room.id}:${userId}:${b}`,
      refType: 'room',
      refId: room.id,
    })
  }
  return paid
}

export class InsufficientCoins extends UserError {
  constructor(public userId: string) {
    super('A player does not have enough coins for the entry.')
  }
}

/**
 * Starts a room: for coin-entry rooms every human seat is charged exactly once
 * and the room flips to `playing` in the same transaction (optimistic lock on
 * `version`). If any player can't pay, nothing is deducted from anyone; that
 * player is removed from the room and notified, and the room keeps waiting.
 */
export async function chargeAndStart(room: Room, patch: Partial<Room>): Promise<Room | null> {
  if (room.entryFee <= 0) {
    const [row] = await db
      .update(gameRooms)
      .set({ ...patch, startedAt: new Date(), version: room.version + 1, updatedAt: new Date() })
      .where(and(eq(gameRooms.id, room.id), eq(gameRooms.version, room.version), eq(gameRooms.status, 'waiting')))
      .returning()
    return row ?? null
  }
  // Only a waiting, never-charged room can start. A second start attempt is a no-op.
  if (room.status !== 'waiting' || room.stakeStatus !== 'pending') return null
  const seats = (patch.seats ?? room.seats) as SeatInfo[]
  if (seats.some((s) => s.isBot || !s.userId)) throw new UserError('Coin-entry matches need real players in every seat.')
  if (seats.some((s) => !s.confirmed)) throw new UserError('Every player must confirm the entry amount first.')
  try {
    return await db.transaction(async (tx) => {
      const paidSeats: SeatInfo[] = []
      for (const s of seats) paidSeats.push({ ...s, owner: s.userId!, paid: await chargeSeat(tx, room, s.userId!) })
      const [row] = await tx
        .update(gameRooms)
        .set({ ...patch, seats: paidSeats, stakeStatus: 'charged', startedAt: new Date(), version: room.version + 1, updatedAt: new Date() })
        .where(and(eq(gameRooms.id, room.id), eq(gameRooms.version, room.version), eq(gameRooms.stakeStatus, 'pending')))
        .returning()
      if (!row) throw new LostRace()
      return row
    })
  } catch (e) {
    if (e instanceof LostRace) return null
    if (e instanceof InsufficientCoins) {
      const kicked = seats.map((s) => (s.userId === e.userId ? { userId: null, name: '', isBot: false, missed: 0 } : s))
      const hostId = kicked.find((s) => s.userId)?.userId ?? room.hostId
      await db
        .update(gameRooms)
        .set({ seats: kicked, hostId, version: room.version + 1, updatedAt: new Date() })
        .where(and(eq(gameRooms.id, room.id), eq(gameRooms.version, room.version), eq(gameRooms.status, 'waiting'), eq(gameRooms.stakeStatus, 'pending')))
      await notify(e.userId, {
        kind: 'game',
        title: 'Removed from match',
        body: `You no longer had ${room.entryFee.toLocaleString()} coins for room #${room.code}, so you were removed before it started. No coins were deducted.`,
        link: '/app/wallet',
      })
      throw new UserError('A player did not have enough coins when the match tried to start, so they were removed. No coins were deducted.')
    }
    throw e
  }
}
class LostRace extends Error {}

/**
 * Pays the verified result. `ranking` lists the winning side first; each side
 * is a list of seat indexes (2v2 teams share a side). Forfeited/left seats are
 * never paid. With a single eligible side everything goes to it; with more,
 * the game's `prizeSplit` is applied. Idempotent: guarded by stake_status.
 */
export async function settleRoom(roomId: string, ranking: number[][], reason: string, opts: { draw?: boolean } = {}) {
  const cfg = await getArenaConfig()
  return db.transaction(async (tx) => {
    const [room] = await tx.select().from(gameRooms).where(eq(gameRooms.id, roomId)).for('update')
    if (!room || room.stakeStatus !== 'charged') return null
    const seats = room.seats
    const paidSeats = seats.filter((s) => s.owner && s.paid)
    const { pool, fee, prize } = prizeMath(room.entryFee, paidSeats.length, room.feePercent)
    const prizes: Record<string, number> = {}
    let feeTaken = fee

    if (opts.draw) {
      // Draw: every player gets their full entry back (same buckets), no platform fee.
      feeTaken = 0
      for (const s of paidSeats) prizes[s.owner!] = room.entryFee
    } else {
      const sides = ranking
        .map((side) => side.map((i) => seats[i]).filter((s): s is SeatInfo => !!s && !!s.owner && !s.forfeited))
        .filter((side) => side.length > 0)
      if (!sides.length) {
        // Nobody eligible (everyone left): treat as void and refund.
        feeTaken = 0
        for (const s of paidSeats) prizes[s.owner!] = room.entryFee
      } else {
        const split = sides.length > 2 ? (cfg[room.game as GameKey]?.prizeSplit ?? [100]) : [100]
        const shares = splitPrize(prize, split, sides.length)
        sides.forEach((side, i) => {
          const share = shares[i] ?? 0
          side.forEach((s, j) => {
            const part = Math.floor(share / side.length) + (j === 0 ? share % side.length : 0)
            if (part > 0) prizes[s.owner!] = (prizes[s.owner!] ?? 0) + part
          })
        })
      }
    }

    const returnsAll =
      opts.draw || (feeTaken === 0 && Object.keys(prizes).length === paidSeats.length && paidSeats.every((s) => prizes[s.owner!] === room.entryFee))
    if (returnsAll) {
      // Entries go back to exactly the buckets they came from.
      for (const s of paidSeats)
        for (const b of BUCKETS) {
          if (!s.paid![b]) continue
          await postLedger(tx, {
            userId: s.owner!,
            bucket: b,
            amount: s.paid![b],
            type: 'game_refund',
            label: `${gameName(room.game)} ${opts.draw ? 'draw' : 'void'} — entry returned #${room.code}`,
            idempotencyKey: `prize:${room.id}:${s.owner}:${b}`,
            refType: 'room',
            refId: room.id,
          })
        }
    } else {
      for (const [userId, amount] of Object.entries(prizes)) {
        if (amount <= 0) continue
        await postLedger(tx, {
          userId,
          bucket: 'winnings',
          amount,
          type: 'game_win',
          label: `${gameName(room.game)} prize #${room.code}`,
          idempotencyKey: `prize:${room.id}:${userId}`,
          refType: 'room',
          refId: room.id,
        })
      }
    }
    const winners = Object.keys(prizes).filter((u) => (prizes[u] ?? 0) > 0)
    const [saved] = await tx
      .update(gameRooms)
      .set({
        stakeStatus: 'paid',
        result: { winners: opts.draw ? [] : winners, reason, prizes, fee: feeTaken, pool, draw: opts.draw },
        updatedAt: new Date(),
      })
      .where(and(eq(gameRooms.id, room.id), eq(gameRooms.stakeStatus, 'charged')))
      .returning()
    if (!saved) throw new Error('Settlement raced — rolled back')
    for (const s of paidSeats) {
      const won = prizes[s.owner!] ?? 0
      await notify(
        s.owner!,
        {
          kind: 'game',
          title: opts.draw ? 'Match drawn — entry returned' : won > 0 ? `You won ${won.toLocaleString()} coins!` : 'Match lost',
          body: opts.draw
            ? `Your ${room.entryFee.toLocaleString()}-coin entry for #${room.code} was returned.`
            : won > 0
              ? `${gameName(room.game)} #${room.code}: prize pool ${pool.toLocaleString()}, platform fee ${feeTaken.toLocaleString()}, you received ${won.toLocaleString()} coins.`
              : `${gameName(room.game)} #${room.code}: your ${room.entryFee.toLocaleString()}-coin entry went to the prize pool.`,
          link: '/app/transactions',
        },
        tx,
      )
    }
    return saved
  })
}

/** Returns every charged entry (exact buckets). Used for voided/abandoned matches and admin cancellations. */
export async function refundRoom(roomId: string, reason: string, actor?: { id: string; email: string }) {
  return db.transaction(async (tx) => {
    const [room] = await tx.select().from(gameRooms).where(eq(gameRooms.id, roomId)).for('update')
    if (!room) throw new UserError('Room not found.')
    if (room.stakeStatus === 'pending' || room.stakeStatus === 'none') {
      // Never charged: nothing to return.
      const [r] = await tx
        .update(gameRooms)
        .set({ status: 'cancelled', cancelReason: reason, stakeStatus: room.stakeStatus === 'pending' ? 'cancelled' : 'none', endedAt: new Date(), updatedAt: new Date(), version: room.version + 1 })
        .where(eq(gameRooms.id, room.id))
        .returning()
      if (actor) await audit(actor, 'Cancelled match (not started, nothing deducted)', { type: 'room', id: room.id }, { reason }, tx)
      return r!
    }
    if (room.stakeStatus !== 'charged') throw new UserError(`This match is already ${room.stakeStatus}.`)
    for (const s of room.seats) {
      if (!s.owner || !s.paid) continue
      for (const b of BUCKETS) {
        const amt = s.paid[b]
        if (!amt) continue
        await postLedger(tx, {
          userId: s.owner,
          bucket: b,
          amount: amt,
          type: 'game_refund',
          label: `${gameName(room.game)} entry refund #${room.code}`,
          idempotencyKey: `refund:${room.id}:${s.owner}:${b}`,
          refType: 'room',
          refId: room.id,
          createdBy: actor?.id,
        })
      }
      await notify(s.owner, { kind: 'game', title: 'Match cancelled — coins refunded', body: `Your ${room.entryFee.toLocaleString()}-coin entry for #${room.code} was refunded. ${reason}`, link: '/app/transactions' }, tx)
    }
    const [r] = await tx
      .update(gameRooms)
      .set({ status: 'cancelled', stakeStatus: 'refunded', cancelReason: reason, endedAt: new Date(), updatedAt: new Date(), version: room.version + 1 })
      .where(and(eq(gameRooms.id, room.id), eq(gameRooms.stakeStatus, 'charged')))
      .returning()
    if (!r) throw new Error('Refund raced — rolled back')
    if (actor) await audit(actor, 'Voided match and refunded entries', { type: 'room', id: room.id }, { reason, entry: room.entryFee }, tx)
    return r
  })
}

/** Public stake summary for a room, shown before joining and during the match. */
export function stakeView(room: Room) {
  const seatsN = room.seats.length
  const m = prizeMath(room.entryFee, seatsN, room.feePercent)
  return { entryFee: room.entryFee, feePercent: room.feePercent, pool: m.pool, fee: m.fee, prize: m.prize, stakeStatus: room.stakeStatus, result: room.result }
}
