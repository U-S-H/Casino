import { admin as identityAdmin, getUser, type User as IdentityUser } from '@netlify/identity'
import { and, eq, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { admins, referrals, users, wallets } from '../../../db/schema.js'
import { audit, notify, notifyAdmins } from './audit.js'
import { postLedger } from './ledger.js'
import { clientGeo, clientIp, refCookie } from './request.js'
import { getSettings } from './settings.js'
import { hashIp, isUniqueViolation, randomCode, UserError } from './util.js'

export type Profile = typeof users.$inferSelect

export interface Viewer {
  identity: IdentityUser
  profile: Profile
  isAdmin: boolean
}

/**
 * The primary administrator email comes from ADMIN_EMAILS (default
 * webhub262@gmail.com). Admin access is granted only to an Identity account
 * whose email has been confirmed. Passwords are never stored by this app —
 * Netlify Identity owns credentials.
 */
const bootstrapEmails = () =>
  (process.env.ADMIN_EMAILS ?? 'webhub262@gmail.com')
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean)

function cleanName(identity: IdentityUser) {
  const meta = identity.userMetadata as { full_name?: string } | undefined
  const raw = meta?.full_name || identity.name || identity.email?.split('@')[0] || 'Player'
  return raw.replace(/[^\p{L}\p{N} ._-]/gu, '').trim().slice(0, 24) || 'Player'
}

async function createProfile(identity: IdentityUser): Promise<Profile> {
  const s = await getSettings()
  const ipHash = hashIp(clientIp())
  const { country } = clientGeo()
  const name = cleanName(identity)
  const refCode = refCookie()?.trim().toUpperCase().slice(0, 20) || null

  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      return await db.transaction(async (tx) => {
        const [p] = await tx
          .insert(users)
          .values({
            id: identity.id,
            publicId: `LKA-${randomCode(6)}`,
            email: (identity.email ?? '').toLowerCase(),
            displayName: name,
            referralCode: `${name.replace(/[^A-Za-z0-9]/g, '').slice(0, 6).toUpperCase() || 'LKA'}${randomCode(4)}`,
            signupIpHash: ipHash,
            country,
            ageConfirmed: (identity.userMetadata as { age_confirmed?: boolean } | undefined)?.age_confirmed === true,
          })
          .onConflictDoNothing()
          .returning()
        if (!p) {
          const [existing] = await tx.select().from(users).where(eq(users.id, identity.id))
          return existing!
        }
        await tx.insert(wallets).values({ userId: p.id }).onConflictDoNothing()
        if (s.welcomeBonus > 0)
          await postLedger(tx, {
            userId: p.id,
            bucket: 'bonus',
            amount: s.welcomeBonus,
            type: 'welcome',
            label: 'Welcome bonus',
            idempotencyKey: `welcome:${p.id}`,
          })

        // Referral attribution with basic anti-fraud checks.
        if (refCode && s.referral.enabled) {
          const [referrer] = await tx.select().from(users).where(eq(users.referralCode, refCode))
          if (referrer && referrer.id !== p.id) {
            const flags: string[] = []
            if (ipHash && referrer.signupIpHash === ipHash) flags.push('Same network as referrer')
            if (referrer.email.split('@')[1] === p.email.split('@')[1] && /\+/.test(p.email)) flags.push('Email alias pattern')
            const [{ today }] = await tx
              .select({ today: sql<number>`count(*)::int` })
              .from(referrals)
              .where(and(eq(referrals.referrerId, referrer.id), sql`${referrals.createdAt} > now() - interval '1 day'`))
            if (today >= s.referral.dailyCapPerReferrer) flags.push('Daily referral cap exceeded')
            await tx.update(users).set({ referredBy: referrer.id }).where(eq(users.id, p.id))
            await tx.insert(referrals).values({
              referrerId: referrer.id,
              referredId: p.id,
              code: refCode,
              status: flags.length ? 'flagged' : 'pending',
              flags,
            })
            await notify(
              referrer.id,
              {
                kind: 'referral',
                title: 'A friend joined with your code',
                body: `${p.displayName} signed up. You earn ${s.referral.referrerReward} coins once they play ${s.referral.qualifyGames} online games.`,
                link: '/app/profile',
              },
              tx,
            )
          }
        }
        await notify(
          p.id,
          {
            kind: 'welcome',
            title: 'Welcome to Ludo King Arena',
            body: `Your account is ready. ${s.welcomeBonus} welcome coins were added to your bonus balance.`,
            link: '/app/wallet',
          },
          tx,
        )
        return p
      })
    } catch (e) {
      // Retry on the (very unlikely) public id / referral code collision.
      if (!isUniqueViolation(e)) throw e
    }
  }
  throw new Error('Could not create profile')
}

async function setIdentityAdminRole(userId: string, grant: boolean) {
  // Mirror the grant as an Identity role (Netlify's equivalent of a custom claim).
  try {
    const iu = await identityAdmin.getUser(userId)
    const roles = new Set(iu.roles ?? [])
    if (grant) roles.add('admin')
    else roles.delete('admin')
    await identityAdmin.updateUser(userId, { app_metadata: { ...(iu.appMetadata ?? {}), roles: [...roles] } })
  } catch {
    /* role mirror is best-effort; the admins table is authoritative */
  }
}

async function resolveAdmin(identity: IdentityUser, profile: Profile) {
  const email = (identity.email ?? '').toLowerCase()
  const isPrimary = bootstrapEmails().includes(email)
  let confirmed = !!identity.confirmedAt || identity.provider === 'google'
  if (isPrimary && !confirmed) {
    // getUser() can fall back to JWT claims, which carry no confirmation date.
    // Read the live Identity record so a confirmed admin is not missed.
    try {
      const iu = await identityAdmin.getUser(identity.id)
      confirmed = !!iu.confirmedAt || iu.provider === 'google'
    } catch {
      /* keep the stricter answer */
    }
  }
  const [row] = await db.select().from(admins).where(eq(admins.userId, identity.id))

  if (row) {
    // A bootstrap grant follows the configured admin email. When that email is
    // replaced, the old bootstrap admin loses access. Admins promoted by
    // another admin ("Make admin") are not affected.
    if (row.grantedBy !== 'bootstrap' || isPrimary) return true
    await db.delete(admins).where(eq(admins.userId, identity.id))
    await setIdentityAdminRole(identity.id, false)
    await audit({ id: identity.id, email }, 'Revoked previous primary administrator', { type: 'user', id: profile.publicId })
    return false
  }

  // The configured admin email gets admin access once its address is verified,
  // so a stranger cannot register the address and inherit admin rights.
  if (isPrimary && confirmed) {
    await db.insert(admins).values({ userId: identity.id, email, grantedBy: 'bootstrap' }).onConflictDoNothing()
    await setIdentityAdminRole(identity.id, true)
    await audit({ id: identity.id, email }, 'Activated primary administrator', { type: 'user', id: profile.publicId })
    await notifyAdmins({ kind: 'admin', title: 'Administrator activated', body: `${email} is now the platform administrator.` })
    return true
  }

  // Role set directly in the Identity dashboard without an admins row. Check the
  // live record, so a role that was just revoked in a still-valid token is ignored.
  if (identity.roles?.includes('admin')) {
    try {
      const iu = await identityAdmin.getUser(identity.id)
      return !!iu.roles?.includes('admin')
    } catch {
      return false
    }
  }
  return false
}

export async function getViewer(): Promise<Viewer | null> {
  const identity = await getUser()
  if (!identity) return null
  let [profile] = await db.select().from(users).where(eq(users.id, identity.id))
  if (!profile) profile = await createProfile(identity)
  const isAdmin = await resolveAdmin(identity, profile)
  return { identity, profile, isAdmin }
}

export function assertActive(profile: Profile) {
  if (profile.status === 'blocked') throw new UserError('This account is blocked. Contact support if you think this is a mistake.')
  if (profile.status === 'suspended' && (!profile.suspendedUntil || profile.suspendedUntil > new Date()))
    throw new UserError('This account is temporarily suspended.')
}

export async function requireViewer(): Promise<Viewer> {
  const v = await getViewer()
  if (!v) throw new UserError('Please log in to continue.')
  assertActive(v.profile)
  return v
}

export async function requireAdmin(): Promise<Viewer> {
  const v = await getViewer()
  if (!v || !v.isAdmin) throw new UserError('Administrator access required.')
  return v
}
