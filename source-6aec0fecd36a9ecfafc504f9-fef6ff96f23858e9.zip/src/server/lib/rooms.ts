import { and, eq, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { gamePlayers, gameRooms, games, referrals, tournamentEntries, tournaments, users, type SeatInfo } from '../../../db/schema.js'
import {
  COLORS,
  FINISH,
  applyMove,
  chooseBotMove,
  movableTokens,
  nextTurn,
  type Color,
  type GameState,
  type Mode,
} from '../../lib/ludo.js'
import { audit, notify } from './audit.js'
import { postLedger } from './ledger.js'
import { getSettings } from './settings.js'
import { chargeAndStart, refundRoom, settleRoom } from './stakes.js'
import { newId, secureDie, UserError } from './util.js'

export type Room = typeof gameRooms.$inferSelect

export interface RoomState {
  game: GameState
  lastRoll: { seat: number; value: number; n: number } | null
  lastMove: { seat: number; token: number; from: number; to: number; n: number } | null
  /** Monotonic action counter so clients can detect new rolls/moves. */
  n: number
  turns: number
  startedAt: string
}

export const seatCount = (mode: Mode) => (mode === '1v1' ? 2 : 4)
const colorsFor = (mode: Mode): Color[] => (mode === '1v1' ? ['red', 'yellow'] : COLORS)
const BOT_NAMES = ['Zara (bot)', 'Bilal (bot)', 'Hina (bot)', 'Omar (bot)']
const BOT_DELAY_MS = 1100

export function emptySeat(): SeatInfo {
  return { userId: null, name: '', isBot: false, missed: 0 }
}

function buildGame(mode: Mode, seats: SeatInfo[]): GameState {
  const colors = colorsFor(mode)
  return {
    mode,
    players: colors.map((color, i) => ({
      color,
      name: seats[i]!.name,
      isBot: seats[i]!.isBot,
      team: mode === '2v2' ? (color === 'red' || color === 'yellow' ? 0 : 1) : i,
      tokens: [-1, -1, -1, -1],
    })),
    turn: 0,
    dice: null,
    sixStreak: 0,
    winnerTeam: null,
    finishOrder: [],
    log: ['Match started. Roll a 6 to bring a token out.'],
  }
}

/** Optimistic-locked write: succeeds only if nobody else changed the room. */
export async function saveRoom(room: Room, patch: Partial<Room>) {
  const [row] = await db
    .update(gameRooms)
    .set({ ...patch, version: room.version + 1, updatedAt: new Date() })
    .where(and(eq(gameRooms.id, room.id), eq(gameRooms.version, room.version)))
    .returning()
  return row ?? null
}

export async function loadRoom(id: string) {
  const [r] = await db.select().from(gameRooms).where(eq(gameRooms.id, id))
  if (!r) throw new UserError('Room not found.')
  return r
}

export async function startRoom(room: Room, fillBots: boolean) {
  if (room.entryFee > 0) fillBots = false // coin-entry matches are humans only
  const seats = room.seats.map((s, i) =>
    s.userId || s.isBot ? s : fillBots ? { userId: null, name: BOT_NAMES[i]!, isBot: true, missed: 0 } : s,
  )
  if (seats.some((s) => !s.userId && !s.isBot)) throw new UserError('Waiting for more players.')
  const s = await getSettings()
  const state: RoomState = {
    game: buildGame(room.mode as Mode, seats),
    lastRoll: null,
    lastMove: null,
    n: 0,
    turns: 0,
    startedAt: new Date().toISOString(),
  }
  // Coin-entry rooms deduct every entry exactly once, atomically with the start.
  return chargeAndStart(room, {
    seats,
    status: 'playing',
    state: state as unknown as Record<string, unknown>,
    turnDeadline: new Date(Date.now() + s.game.turnSeconds * 1000),
  })
}

export interface ActResult {
  state: RoomState
  seats: SeatInfo[]
  finished: boolean
}

/** Rolls for the current seat and, when the move is forced or automatic, plays it. */
function doRoll(st: RoomState, seats: SeatInfo[], auto: boolean): ActResult {
  let g = st.game
  const seat = g.turn
  const me = g.players[seat]!
  const d = secureDie()
  const streak = d === 6 ? g.sixStreak + 1 : 0
  g = { ...g, dice: d, sixStreak: streak, log: [...g.log, `${me.name} rolled a ${d}.`].slice(-30) }
  const n = st.n + 1
  let next: RoomState = { ...st, game: g, lastRoll: { seat, value: d, n }, n }
  if (streak === 3) {
    g = { ...g, log: [...g.log, 'Three sixes in a row — turn lost.'] }
    return { state: { ...next, game: nextTurn(g, false), turns: st.turns + 1 }, seats, finished: false }
  }
  const opts = movableTokens(me, d)
  if (opts.length === 0) return { state: { ...next, game: nextTurn(g, d === 6), turns: st.turns + 1 }, seats, finished: false }
  if (auto || opts.length === 1) {
    const token = opts.length === 1 ? opts[0]! : chooseBotMove(g, opts)
    return doMove(next, seats, token)
  }
  next = { ...next, game: g }
  return { state: next, seats, finished: false }
}

function doMove(st: RoomState, seats: SeatInfo[], token: number): ActResult {
  const g = st.game
  if (g.dice === null) throw new UserError('Roll the dice first.')
  const me = g.players[g.turn]!
  if (!movableTokens(me, g.dice).includes(token)) throw new UserError('That token cannot move.')
  const from = me.tokens[token]!
  const res = applyMove(g, token)
  const n = st.n + 1
  const to = res.state.players[g.turn]!.tokens[token]!
  const lastMove = { seat: g.turn, token, from, to, n }
  if (res.state.winnerTeam !== null) {
    return { state: { ...st, game: { ...res.state, dice: null }, lastMove, n, turns: st.turns + 1 }, seats, finished: true }
  }
  return {
    state: { ...st, game: nextTurn(res.state, res.extraTurn), lastMove, n, turns: st.turns + 1 },
    seats,
    finished: false,
  }
}

export async function commit(room: Room, r: ActResult) {
  const s = await getSettings()
  const saved = await saveRoom(room, {
    state: r.state as unknown as Record<string, unknown>,
    seats: r.seats,
    status: r.finished ? 'finished' : 'playing',
    turnDeadline: r.finished ? null : new Date(Date.now() + s.game.turnSeconds * 1000),
    ...(r.finished ? { endedAt: new Date() } : {}),
  })
  if (saved && r.finished) await finishGame(saved, r.state)
  return saved
}

export async function playerAction(room: Room, userId: string, action: { type: 'roll' } | { type: 'move'; token: number }) {
  if (room.status !== 'playing') throw new UserError('This game is not in progress.')
  const st = room.state as unknown as RoomState
  const seat = st.game.turn
  if (room.seats[seat]?.userId !== userId) throw new UserError('It is not your turn.')
  const seats = room.seats.map((s, i) => (i === seat ? { ...s, missed: 0 } : s))
  let r: ActResult
  if (action.type === 'roll') {
    if (st.game.dice !== null) throw new UserError('You already rolled — move a token.')
    r = doRoll(st, seats, false)
  } else {
    r = doMove(st, seats, action.token)
  }
  const saved = await commit(room, r)
  if (!saved) throw new UserError('The game moved on — try again.')
  return saved
}

/**
 * Advances bots and timed-out humans. Called on every poll so the game keeps
 * moving without a long-running server process.
 */
export async function tick(room: Room): Promise<Room> {
  const s = await getSettings()
  if (room.status === 'waiting' && room.entryFee > 0) {
    // Coin-entry rooms never fill with bots; stale ones are cancelled (nothing was deducted).
    const age = Date.now() - room.createdAt.getTime()
    if (age > (room.isPrivate ? 60 : 10) * 60_000) return (await refundRoom(room.id, 'No opponent joined in time.').catch(() => null)) ?? room
    return room
  }
  if (room.status === 'waiting' && !room.isPrivate) {
    const age = Date.now() - room.createdAt.getTime()
    if (age > s.game.botFillSeconds * 1000) {
      try {
        const started = await startRoom(room, true)
        if (started) return started
      } catch {
        /* still waiting */
      }
    }
    return room
  }
  if (room.status === 'finished' && room.stakeStatus === 'charged' && room.state && Date.now() - room.updatedAt.getTime() > 5000) {
    // Repair an interrupted payout (idempotent).
    await settleRoom(room.id, ludoRanking((room.state as unknown as RoomState).game), 'Won the Ludo race').catch(() => undefined)
    return loadRoom(room.id)
  }
  if (room.status !== 'playing') return room
  const st = room.state as unknown as RoomState
  const seat = st.game.turn
  const info = room.seats[seat]!
  const now = Date.now()
  const timedOut = room.turnDeadline && room.turnDeadline.getTime() < now
  const botReady = info.isBot && now - room.updatedAt.getTime() > BOT_DELAY_MS
  if (!botReady && !timedOut) return room

  let seats = room.seats
  if (timedOut && !info.isBot) {
    const missed = info.missed + 1
    seats = seats.map((x, i) =>
      i === seat
        ? { ...x, missed, isBot: missed >= 3, forfeited: x.forfeited || (missed >= 3 && room.entryFee > 0), name: missed >= 3 ? `${x.name} (auto)` : x.name }
        : x,
    )
    const ended = room.entryFee > 0 ? lastSideStanding(room, st, seats) : null
    if (ended) {
      const saved = await commit(room, ended)
      return saved ?? (await loadRoom(room.id))
    }
  }
  const r =
    st.game.dice === null
      ? doRoll(st, seats, true)
      : doMove({ ...st }, seats, chooseBotMove(st.game, movableTokens(st.game.players[seat]!, st.game.dice)))
  if (timedOut && !info.isBot) r.state.game.log = [...r.state.game.log, `${info.name} ran out of time — auto-played.`].slice(-30)
  const saved = await commit(room, r)
  return saved ?? (await loadRoom(room.id))
}

/**
 * Coin-entry Ludo: when every player of all sides but one has left or
 * forfeited, the match ends at once and the remaining side is the winner.
 */
export function lastSideStanding(room: Room, st: RoomState, seats: SeatInfo[]): ActResult | null {
  const live = new Set(st.game.players.map((p, i) => (seats[i]?.owner && !seats[i]?.forfeited ? p.team : -1)).filter((t) => t >= 0))
  if (live.size !== 1 || room.status !== 'playing') return null
  const team = [...live][0]!
  const name = st.game.players.filter((p) => p.team === team).map((p) => p.name).join(' & ')
  return {
    state: { ...st, game: { ...st.game, winnerTeam: team, dice: null, log: [...st.game.log, `Opponents forfeited — ${name} wins.`].slice(-30) }, n: st.n + 1 },
    seats,
    finished: true,
  }
}

/** Sides in finishing order: the winning team first, then by tokens home and distance travelled. */
export function ludoRanking(g: GameState): number[][] {
  const teams = [...new Set(g.players.map((p) => p.team))]
  const score = (team: number) =>
    g.players.filter((p) => p.team === team).reduce((a, p) => a + p.tokens.reduce((x, t) => x + (t === FINISH ? 1000 : Math.max(0, t + 1)), 0), 0)
  teams.sort((a, b) => (a === g.winnerTeam ? -1 : b === g.winnerTeam ? 1 : score(b) - score(a)))
  return teams.map((team) => g.players.map((p, i) => (p.team === team ? i : -1)).filter((i) => i >= 0))
}

export async function finishGame(room: Room, st: RoomState) {
  try {
    await recordLudoGame(room, st)
  } finally {
    // Pay the server-verified result (no-op for free matches or if already paid).
    if (room.entryFee > 0) await settleRoom(room.id, ludoRanking(st.game), 'Won the Ludo race')
  }
}

async function recordLudoGame(room: Room, st: RoomState) {
  const g = st.game
  const gameId = newId('GM')
  const players = g.players.map((p, i) => ({
    userId: room.seats[i]!.userId ?? room.seats[i]!.owner ?? null,
    name: room.seats[i]!.name,
    color: p.color,
    team: p.team,
    won: p.team === g.winnerTeam,
    finished: p.tokens.filter((t) => t === FINISH).length,
  }))
  const inserted = await db
    .insert(games)
    .values({
      id: gameId,
      roomId: room.id,
      game: 'ludo',
      mode: room.mode,
      entryFee: room.entryFee,
      prizePool: room.entryFee * room.seats.length,
      platformFee: Math.floor((room.entryFee * room.seats.length * room.feePercent) / 100),
      reason: 'Finished',
      players,
      winnerTeam: g.winnerTeam,
      tournamentId: room.tournamentId,
      turns: st.turns,
      startedAt: new Date(st.startedAt),
    })
    .onConflictDoNothing()
    .returning()
  if (!inserted.length) return

  const humans = players.filter((p) => p.userId)
  const s = await getSettings()
  for (const p of humans) {
    const delta = p.won ? 16 : -12
    await db.insert(gamePlayers).values({ gameId, userId: p.userId!, won: p.won, ratingDelta: delta }).onConflictDoNothing()
    const [u] = await db
      .update(users)
      .set({
        gamesPlayed: sql`${users.gamesPlayed} + 1`,
        gamesWon: p.won ? sql`${users.gamesWon} + 1` : users.gamesWon,
        rating: sql`greatest(100, ${users.rating} + ${delta})`,
      })
      .where(eq(users.id, p.userId!))
      .returning()
    await notify(p.userId!, {
      kind: 'game',
      title: p.won ? 'Victory!' : 'Match finished',
      body: p.won ? `You won a ${room.mode} match. Rating +${delta}.` : `Your ${room.mode} match ended. Rating ${delta}.`,
      link: '/app/play',
    })

    // Tournament points: any online match played during a live tournament of the same mode counts.
    const live = await db
      .select({ id: tournaments.id })
      .from(tournamentEntries)
      .innerJoin(tournaments, eq(tournaments.id, tournamentEntries.tournamentId))
      .where(
        and(
          eq(tournamentEntries.userId, p.userId!),
          eq(tournaments.mode, room.mode),
          sql`${tournaments.startsAt} <= now() and ${tournaments.endsAt} > now() and ${tournaments.status} <> 'cancelled'`,
        ),
      )
    for (const t of live)
      await db
        .update(tournamentEntries)
        .set({
          games: sql`${tournamentEntries.games} + 1`,
          wins: p.won ? sql`${tournamentEntries.wins} + 1` : tournamentEntries.wins,
          points: sql`${tournamentEntries.points} + ${p.won ? 3 : 1}`,
        })
        .where(and(eq(tournamentEntries.tournamentId, t.id), eq(tournamentEntries.userId, p.userId!)))

    // Referral qualification.
    if (u && u.referredBy && u.gamesPlayed >= s.referral.qualifyGames && s.referral.enabled)
      await qualifyReferral(u.id, s.referral.referrerReward, s.referral.refereeReward)
  }
}

export async function qualifyReferral(referredId: string, referrerReward: number, refereeReward: number, actor?: { id: string; email: string }) {
  await db.transaction(async (tx) => {
    const [ref] = await tx
      .update(referrals)
      .set({ status: 'rewarded', reward: referrerReward, resolvedAt: new Date() })
      .where(and(eq(referrals.referredId, referredId), actor ? sql`status in ('pending','flagged')` : eq(referrals.status, 'pending')))
      .returning()
    if (!ref) return
    await postLedger(tx, {
      userId: ref.referrerId,
      bucket: 'bonus',
      amount: referrerReward,
      type: 'referral',
      label: 'Referral reward',
      idempotencyKey: `referral:${ref.id}:referrer`,
      refType: 'referral',
      refId: String(ref.id),
      createdBy: actor?.id,
    })
    if (refereeReward > 0)
      await postLedger(tx, {
        userId: ref.referredId,
        bucket: 'bonus',
        amount: refereeReward,
        type: 'referral',
        label: 'Joined with a referral code',
        idempotencyKey: `referral:${ref.id}:referee`,
        refType: 'referral',
        refId: String(ref.id),
        createdBy: actor?.id,
      })
    await notify(
      ref.referrerId,
      { kind: 'referral', title: 'Referral reward earned', body: `+${referrerReward} bonus coins — your friend qualified.`, link: '/app/wallet' },
      tx,
    )
    if (actor) await audit(actor, 'Approved referral reward', { type: 'referral', id: String(ref.id) }, { referredId }, tx)
  })
}
