import { db } from '../../../db/index.js'
import { auditLogs, notifications } from '../../../db/schema.js'

import type { Exec } from './db-types.js'

export async function audit(
  actor: { id: string; email: string },
  action: string,
  target?: { type: string; id: string },
  details?: Record<string, unknown>,
  tx: Exec = db,
) {
  await tx.insert(auditLogs).values({
    actorId: actor.id,
    actorEmail: actor.email,
    action,
    targetType: target?.type,
    targetId: target?.id,
    details,
  })
}

export async function notify(
  userId: string,
  n: { kind: string; title: string; body: string; link?: string },
  tx: Exec = db,
) {
  await tx.insert(notifications).values({ userId, audience: 'user', ...n })
}

export async function notifyAdmins(n: { kind: string; title: string; body: string; link?: string }, tx: Exec = db) {
  await tx.insert(notifications).values({ userId: null, audience: 'admins', ...n })
}

export async function broadcast(n: { kind: string; title: string; body: string; link?: string }, tx: Exec = db) {
  await tx.insert(notifications).values({ userId: null, audience: 'all', ...n })
}
