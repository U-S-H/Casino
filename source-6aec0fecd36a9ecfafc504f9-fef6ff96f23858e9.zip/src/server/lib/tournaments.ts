import { and, desc, eq, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { tournamentEntries, tournaments } from '../../../db/schema.js'
import { broadcast, notify } from './audit.js'
import { postLedger } from './ledger.js'
import { newId } from './util.js'

const PRIZE_SPLIT = [0.5, 0.3, 0.2]

/** Moves tournaments through upcoming → live → finished and pays promo prizes once. */
export async function settleDueTournaments() {
  await db.execute(sql`update tournaments set status = 'live' where status = 'upcoming' and starts_at <= now() and ends_at > now()`)
  const due = await db
    .select()
    .from(tournaments)
    .where(and(sql`${tournaments.status} in ('upcoming','live')`, sql`${tournaments.endsAt} <= now()`))
  for (const t of due) {
    await db.transaction(async (tx) => {
      const [locked] = await tx
        .update(tournaments)
        .set({ status: 'finished', settledAt: new Date() })
        .where(and(eq(tournaments.id, t.id), sql`${tournaments.settledAt} is null`))
        .returning()
      if (!locked) return
      const entries = await tx
        .select()
        .from(tournamentEntries)
        .where(eq(tournamentEntries.tournamentId, t.id))
        .orderBy(desc(tournamentEntries.points), desc(tournamentEntries.wins), tournamentEntries.joinedAt)
      for (const [i, e] of entries.entries()) {
        const prize = e.games > 0 && i < PRIZE_SPLIT.length ? Math.floor(t.prizeCoins * PRIZE_SPLIT[i]!) : 0
        await tx
          .update(tournamentEntries)
          .set({ rank: i + 1, prize })
          .where(and(eq(tournamentEntries.tournamentId, t.id), eq(tournamentEntries.userId, e.userId)))
        if (prize > 0) {
          await postLedger(tx, {
            userId: e.userId,
            bucket: 'bonus',
            amount: prize,
            type: 'tournament',
            label: `${t.name} · #${i + 1}`,
            idempotencyKey: `tournament:${t.id}:${e.userId}`,
            refType: 'tournament',
            refId: t.id,
          })
        }
        await notify(
          e.userId,
          {
            kind: 'tournament',
            title: `${t.name} finished`,
            body: prize > 0 ? `You placed #${i + 1} and won ${prize} bonus coins!` : `You placed #${i + 1} of ${entries.length}.`,
            link: '/app/tournaments',
          },
          tx,
        )
      }
    })
  }
}

/** Keeps one daily and one weekly free tournament scheduled per mode. */
export async function ensureRecurringTournaments() {
  const now = new Date()
  const plans = [
    { kind: 'daily', mode: '4p', name: 'Daily Dash', hours: 24, prize: 1000, capacity: 256 },
    { kind: 'daily', mode: '1v1', name: 'Daily Duel', hours: 24, prize: 600, capacity: 128 },
    { kind: 'weekly', mode: '4p', name: 'Weekly Arena Cup', hours: 24 * 7, prize: 5000, capacity: 1024 },
    { kind: 'weekly', mode: '2v2', name: 'Team Clash Weekly', hours: 24 * 7, prize: 3000, capacity: 512 },
  ] as const
  for (const p of plans) {
    const [existing] = await db
      .select({ id: tournaments.id })
      .from(tournaments)
      .where(and(eq(tournaments.kind, p.kind), eq(tournaments.mode, p.mode), eq(tournaments.createdBy, 'system'), sql`${tournaments.endsAt} > now()`, sql`${tournaments.status} <> 'cancelled'`))
      .limit(1)
    if (existing) continue
    const start = new Date(now)
    start.setUTCMinutes(0, 0, 0)
    const end = new Date(start.getTime() + p.hours * 3600_000)
    const stamp = start.toISOString().slice(0, 10)
    await db.insert(tournaments).values({
      id: newId('TN', 6),
      name: `${p.name} · ${stamp}`,
      kind: p.kind,
      mode: p.mode,
      prizeCoins: p.prize,
      capacity: p.capacity,
      startsAt: start,
      endsAt: end,
      status: 'live',
      createdBy: 'system',
    })
    if (p.kind === 'weekly')
      await broadcast({ kind: 'tournament', title: `${p.name} is live`, body: 'A new free weekly tournament has started. Join and climb the rankings!', link: '/app/tournaments' })
  }
}
