import { sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { UserError } from './util.js'

/**
 * Fixed-window rate limiter backed by Postgres (works across all function
 * instances). Throws a user-facing error once `limit` is exceeded.
 */
export async function rateLimit(key: string, limit: number, windowSeconds: number) {
  const res = await db.execute<{ count: number }>(sql`
    insert into rate_limits (key, window_start, count) values (${key}, now(), 1)
    on conflict (key) do update set
      count = case when rate_limits.window_start < now() - make_interval(secs => ${windowSeconds}) then 1 else rate_limits.count + 1 end,
      window_start = case when rate_limits.window_start < now() - make_interval(secs => ${windowSeconds}) then now() else rate_limits.window_start end
    returning count
  `)
  const rows = (res as unknown as { rows?: { count: number }[] }).rows ?? (res as unknown as { count: number }[])
  const count = Number(rows[0]?.count ?? 0)
  if (count > limit) throw new UserError('Too many requests. Please slow down and try again shortly.')
}
