import { and, eq, inArray, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { transactions, withdrawals } from '../../../db/schema.js'
import { audit, notify, notifyAdmins } from './audit.js'
import { postLedger } from './ledger.js'
import { isUniqueViolation, newId, UserError } from './util.js'

/**
 * Cash-out flow. Only winnings can be withdrawn.
 *
 *   request  → winnings −coins, reserved +coins (ledger row "pending")
 *   paid     → reserved −coins (ledger row "completed"): the deduction is final
 *   rejected → reserved −coins, winnings +coins (ledger row "refunded" + a credit row)
 *
 * Every step runs in one DB transaction and is guarded by status checks, so a
 * request can never be reserved, paid or refunded twice.
 */

export type WithdrawStatus = 'pending' | 'approved' | 'processing' | 'paid' | 'rejected'
export const OPEN_STATUSES: WithdrawStatus[] = ['pending', 'approved', 'processing']

export const coinsToPkr = (coins: number, coinsPerPkr: number) => Math.floor(coins / Math.max(coinsPerPkr, 0.01))

export interface WithdrawRequest {
  userId: string
  displayName: string
  method: 'easypaisa' | 'jazzcash' | 'sadapay'
  accountHolder: string
  accountNumber: string
  coins: number
  idempotencyKey: string
  coinsPerPkr: number
}

export async function createWithdrawal(r: WithdrawRequest): Promise<{ id: string; duplicate: boolean }> {
  const existing = async () => {
    const [w] = await db.select({ id: withdrawals.id, userId: withdrawals.userId }).from(withdrawals).where(eq(withdrawals.idempotencyKey, r.idempotencyKey))
    return w && w.userId === r.userId ? { id: w.id, duplicate: true } : null
  }
  const prior = await existing()
  if (prior) return prior

  const id = newId('WR', 6)
  try {
    return await db.transaction(async (tx) => {
      // Lock the wallet row so two simultaneous requests are serialised.
      await tx.execute(sql`insert into wallets (user_id) values (${r.userId}) on conflict do nothing`)
      const res = await tx.execute(sql`select winnings from wallets where user_id = ${r.userId} for update`)
      const rows = ((res as unknown as { rows?: unknown[] }).rows ?? res) as { winnings: number | string }[]
      const winnings = Number(rows[0]?.winnings ?? 0)

      // Re-check under the lock: a concurrent retry with the same key may have just committed.
      const [same] = await tx.select({ id: withdrawals.id }).from(withdrawals).where(and(eq(withdrawals.idempotencyKey, r.idempotencyKey), eq(withdrawals.userId, r.userId)))
      if (same) return { id: same.id, duplicate: true }

      const open = await tx
        .select({ id: withdrawals.id })
        .from(withdrawals)
        .where(and(eq(withdrawals.userId, r.userId), inArray(withdrawals.status, OPEN_STATUSES)))
        .limit(1)
      if (open.length) throw new UserError(`You already have an open withdrawal (${open[0]!.id}). Wait until it is paid or rejected.`)
      if (winnings < r.coins) throw new UserError(`Insufficient withdrawable balance. You can withdraw up to ${winnings.toLocaleString()} coins.`)

      const led = await postLedger(tx, {
        userId: r.userId,
        bucket: 'winnings',
        amount: -r.coins,
        type: 'withdrawal',
        label: `Withdrawal ${id} (reserved)`,
        idempotencyKey: `withdraw:${r.idempotencyKey}`,
        refType: 'withdrawal',
        refId: id,
      })
      if (led.duplicate) throw new UserError('This request was already submitted.')
      await tx.update(transactions).set({ status: 'pending' }).where(eq(transactions.id, led.id))
      await tx.execute(sql`update wallets set reserved = reserved + ${r.coins} where user_id = ${r.userId}`)
      await tx.insert(withdrawals).values({
        id,
        userId: r.userId,
        method: r.method,
        accountHolder: r.accountHolder,
        accountNumber: r.accountNumber,
        coins: r.coins,
        amountPkr: coinsToPkr(r.coins, r.coinsPerPkr),
        idempotencyKey: r.idempotencyKey,
      })
      await notify(r.userId, { kind: 'withdrawal', title: 'Withdrawal submitted', body: `${r.coins.toLocaleString()} coins reserved for request ${id}.`, link: '/app/withdraw' }, tx)
      await notifyAdmins({ kind: 'withdrawal', title: 'New withdrawal request', body: `${r.displayName} · ${r.coins.toLocaleString()} coins`, link: '/admin?section=withdrawals' }, tx)
      return { id, duplicate: false }
    })
  } catch (e) {
    // A concurrent retry with the same key won the race — return its result.
    if (isUniqueViolation(e)) {
      const again = await existing()
      if (again) return again
    }
    throw e
  }
}

/** Allowed previous statuses for each admin action. */
export const WD_FLOW: Record<Exclude<WithdrawStatus, 'pending'>, WithdrawStatus[]> = {
  approved: ['pending'],
  processing: ['approved'],
  paid: ['approved', 'processing'],
  rejected: ['pending', 'approved', 'processing'],
}

export interface WithdrawUpdate {
  id: string
  status: Exclude<WithdrawStatus, 'pending'>
  reference: string
  note: string
  admin: { id: string; email: string }
}

export async function updateWithdrawal(u: WithdrawUpdate) {
  if (u.status === 'paid' && !u.reference) throw new UserError('Add the payment transaction reference before marking as paid.')
  if (u.status === 'rejected' && !u.note) throw new UserError('Add a rejection reason.')
  try {
    return await db.transaction(async (tx) => {
      const [w] = await tx
        .update(withdrawals)
        .set({
          status: u.status,
          paymentReference: u.reference || undefined,
          adminNote: u.note || undefined,
          reviewedBy: u.admin.id,
          updatedAt: new Date(),
        })
        .where(and(eq(withdrawals.id, u.id), inArray(withdrawals.status, WD_FLOW[u.status])))
        .returning()
      if (!w) throw new UserError('This withdrawal cannot move to that status (it may already have been handled).')

      const reservation = and(eq(transactions.refType, 'withdrawal'), eq(transactions.refId, w.id), eq(transactions.idempotencyKey, sql`'withdraw:' || ${w.idempotencyKey}`))
      if (u.status === 'paid') {
        const r = await tx.execute(sql`update wallets set reserved = reserved - ${w.coins} where user_id = ${w.userId} and reserved >= ${w.coins} returning user_id`)
        const n = ((r as unknown as { rows?: unknown[] }).rows ?? (r as unknown as unknown[])).length
        if (!n) throw new UserError('Reserved balance mismatch — investigate before paying.')
        await tx.update(transactions).set({ status: 'completed', label: `Withdrawal ${w.id} paid · ref ${u.reference}` }).where(reservation)
      }
      if (u.status === 'rejected') {
        const r = await tx.execute(sql`update wallets set reserved = reserved - ${w.coins} where user_id = ${w.userId} and reserved >= ${w.coins} returning user_id`)
        const n = ((r as unknown as { rows?: unknown[] }).rows ?? (r as unknown as unknown[])).length
        if (!n) throw new UserError('Reserved balance mismatch — investigate before rejecting.')
        await tx.update(transactions).set({ status: 'refunded' }).where(reservation)
        await postLedger(tx, {
          userId: w.userId,
          bucket: 'winnings',
          amount: w.coins,
          type: 'withdrawal',
          label: `Withdrawal ${w.id} rejected · coins returned`,
          idempotencyKey: `withdraw-return:${w.id}`,
          refType: 'withdrawal',
          refId: w.id,
          createdBy: u.admin.id,
        })
      }
      await audit(u.admin, `Withdrawal ${u.status}`, { type: 'withdrawal', id: w.id }, { coins: w.coins, amountPkr: w.amountPkr, reference: u.reference, note: u.note }, tx)
      const body =
        u.status === 'paid'
          ? `Rs ${(w.amountPkr ?? 0).toLocaleString()} sent · reference ${u.reference}`
          : u.status === 'rejected'
            ? `${w.coins.toLocaleString()} coins returned to your winnings. Reason: ${u.note}`
            : u.note || `Request ${w.id} is ${u.status}.`
      await notify(w.userId, { kind: 'withdrawal', title: `Withdrawal ${u.status}`, body, link: '/app/withdraw' }, tx)
      return { ok: true }
    })
  } catch (e) {
    if (isUniqueViolation(e)) throw new UserError('That payment reference is already used on another withdrawal.')
    throw e
  }
}
