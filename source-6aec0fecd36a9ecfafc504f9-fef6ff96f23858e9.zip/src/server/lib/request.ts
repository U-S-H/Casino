import { getCookie, getRequestHeader, getRequestIP } from '@tanstack/react-start/server'

export function clientIp() {
  return getRequestHeader('x-nf-client-connection-ip') ?? getRequestIP({ xForwardedFor: true }) ?? null
}

export function clientGeo(): { country: string | null; city: string | null } {
  const raw = getRequestHeader('x-nf-geo')
  if (raw) {
    try {
      const g = JSON.parse(Buffer.from(raw, 'base64').toString('utf8')) as { country?: { code?: string }; city?: string }
      return { country: g.country?.code ?? null, city: g.city ?? null }
    } catch {
      /* ignore malformed header */
    }
  }
  return { country: getRequestHeader('x-country') ?? null, city: null }
}

export const userAgent = () => (getRequestHeader('user-agent') ?? '').slice(0, 300)
export const refCookie = () => getCookie('lka_ref') ?? null
