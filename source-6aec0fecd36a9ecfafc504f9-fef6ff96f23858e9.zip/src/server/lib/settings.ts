import { eq } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { settings } from '../../../db/schema.js'

/**
 * Cash-out (winnings → mobile-wallet payout requests, paid manually by an
 * admin) is enabled by the owner. Wagering stays hard-locked off in code;
 * no database setting can change either constant.
 */
export const CASHOUT_ENABLED = true
export const WAGERING_ENABLED = false

export interface CoinPackage {
  id: string
  name: string
  coins: number
  bonus: number
  price: number
  tag: string | null
  active: boolean
}
export interface PaymentMethod {
  id: 'easypaisa' | 'jazzcash' | 'sadapay'
  name: string
  account: string
  accountTitle: string
  enabled: boolean
}
export interface Banner {
  id: string
  title: string
  body: string
  active: boolean
}

export interface SiteSettings {
  siteName: string
  logoUrl: string
  paymentMethods: PaymentMethod[]
  coinPackages: CoinPackage[]
  referral: {
    enabled: boolean
    referrerReward: number
    refereeReward: number
    qualifyGames: number
    dailyCapPerReferrer: number
    campaignName: string
  }
  welcomeBonus: number
  dailyRewards: number[]
  limits: {
    depositMinPkr: number
    depositMaxPkr: number
    depositDailyMaxPkr: number
    depositsPerDay: number
    withdrawMinCoins: number
    withdrawMaxCoins: number
    /** Payout rate: how many coins equal Rs 1 when a withdrawal is paid. */
    withdrawCoinsPerPkr: number
  }
  maintenance: { enabled: boolean; message: string }
  banners: Banner[]
  support: { email: string; whatsapp: string; hours: string }
  blockedCountries: string[]
  game: { turnSeconds: number; botFillSeconds: number }
}

export const DEFAULT_SETTINGS: SiteSettings = {
  siteName: 'Ludo King Arena',
  logoUrl: '',
  paymentMethods: [
    { id: 'easypaisa', name: 'EasyPaisa', account: '03379827882', accountTitle: 'Ludo King Arena', enabled: true },
    { id: 'jazzcash', name: 'JazzCash', account: '03705519562', accountTitle: 'Ludo King Arena', enabled: true },
    { id: 'sadapay', name: 'SadaPay', account: '03705519562', accountTitle: 'Ludo King Arena', enabled: true },
  ],
  coinPackages: [
    { id: 'pk-starter', name: 'Starter', coins: 500, bonus: 0, price: 100, tag: null, active: true },
    { id: 'pk-player', name: 'Player', coins: 1200, bonus: 100, price: 230, tag: null, active: true },
    { id: 'pk-pro', name: 'Pro', coins: 2600, bonus: 300, price: 480, tag: 'Popular', active: true },
    { id: 'pk-champ', name: 'Champ', coins: 5500, bonus: 900, price: 950, tag: 'Best value', active: true },
    { id: 'pk-legend', name: 'Legend', coins: 12000, bonus: 2500, price: 1950, tag: null, active: true },
  ],
  referral: {
    enabled: true,
    referrerReward: 250,
    refereeReward: 100,
    qualifyGames: 3,
    dailyCapPerReferrer: 10,
    campaignName: 'Invite & earn',
  },
  welcomeBonus: 500,
  dailyRewards: [50, 75, 100, 150, 200, 300, 500],
  limits: {
    depositMinPkr: 100,
    depositMaxPkr: 25000,
    depositDailyMaxPkr: 50000,
    depositsPerDay: 5,
    withdrawMinCoins: 1000,
    withdrawMaxCoins: 50000,
    withdrawCoinsPerPkr: 5,
  },
  maintenance: { enabled: false, message: 'We are upgrading the arena. Back shortly!' },
  banners: [{ id: 'b1', title: 'Weekend free-play cup', body: 'Join any free tournament this weekend and climb the rankings.', active: true }],
  support: { email: 'support@ludupro.netlify.app', whatsapp: '', hours: '10am – 10pm PKT' },
  blockedCountries: [],
  game: { turnSeconds: 20, botFillSeconds: 25 },
}

export async function getSettings(): Promise<SiteSettings> {
  const [row] = await db.select().from(settings).where(eq(settings.key, 'site'))
  const v = (row?.value ?? {}) as Partial<SiteSettings>
  return {
    ...DEFAULT_SETTINGS,
    ...v,
    referral: { ...DEFAULT_SETTINGS.referral, ...v.referral },
    limits: { ...DEFAULT_SETTINGS.limits, ...v.limits },
    maintenance: { ...DEFAULT_SETTINGS.maintenance, ...v.maintenance },
    support: { ...DEFAULT_SETTINGS.support, ...v.support },
    game: { ...DEFAULT_SETTINGS.game, ...v.game },
  }
}

export async function saveSettings(value: SiteSettings, by: string) {
  await db
    .insert(settings)
    .values({ key: 'site', value, updatedBy: by })
    .onConflictDoUpdate({ target: settings.key, set: { value, updatedBy: by, updatedAt: new Date() } })
}

/** The subset of settings safe to show any visitor. */
export function publicSettings(s: SiteSettings) {
  return {
    siteName: s.siteName,
    logoUrl: s.logoUrl,
    paymentMethods: s.paymentMethods.filter((m) => m.enabled),
    coinPackages: s.coinPackages.filter((p) => p.active),
    referral: s.referral,
    welcomeBonus: s.welcomeBonus,
    dailyRewards: s.dailyRewards,
    limits: s.limits,
    maintenance: s.maintenance,
    banners: s.banners.filter((b) => b.active),
    support: s.support,
    cashoutEnabled: CASHOUT_ENABLED,
    wageringEnabled: WAGERING_ENABLED,
  }
}
export type PublicSettings = ReturnType<typeof publicSettings>
