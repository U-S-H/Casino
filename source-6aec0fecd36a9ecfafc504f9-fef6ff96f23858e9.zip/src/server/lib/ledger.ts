import { eq, sql } from 'drizzle-orm'

import { transactions, wallets } from '../../../db/schema.js'
import type { Tx } from './db-types.js'
import { newId, UserError } from './util.js'

export type Bucket = 'purchased' | 'bonus' | 'winnings'

export interface LedgerEntry {
  userId: string
  bucket: Bucket
  amount: number // positive = credit, negative = debit
  type: string
  label: string
  idempotencyKey: string
  refType?: string
  refId?: string
  createdBy?: string
}

/**
 * Applies one balance change atomically. Must be called inside
 * `db.transaction`. The unique idempotency key makes retries harmless: a
 * second call with the same key returns `{ duplicate: true }` and changes
 * nothing. Debits never push a bucket below zero.
 */
export async function postLedger(tx: Tx, e: LedgerEntry) {
  const existing = await tx
    .select({ id: transactions.id })
    .from(transactions)
    .where(eq(transactions.idempotencyKey, e.idempotencyKey))
  if (existing.length) return { duplicate: true as const, id: existing[0]!.id }

  await tx.insert(wallets).values({ userId: e.userId }).onConflictDoNothing()
  const col = wallets[e.bucket]
  const updated = await tx
    .update(wallets)
    .set({ [e.bucket]: sql`${col} + ${e.amount}`, updatedAt: new Date() })
    .where(e.amount < 0 ? sql`${wallets.userId} = ${e.userId} and ${col} >= ${-e.amount}` : eq(wallets.userId, e.userId))
    .returning()
  if (!updated.length) throw new UserError('Insufficient balance for this operation.')
  const w = updated[0]!
  const id = newId('TX')
  await tx.insert(transactions).values({
    id,
    userId: e.userId,
    type: e.type,
    bucket: e.bucket,
    amount: e.amount,
    balanceAfter: w.purchased + w.bonus + w.winnings,
    label: e.label,
    refType: e.refType,
    refId: e.refId,
    idempotencyKey: e.idempotencyKey,
    createdBy: e.createdBy,
  })
  return { duplicate: false as const, id, wallet: w }
}
