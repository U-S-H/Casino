import { createHmac, randomBytes } from 'node:crypto'
import { and, desc, eq, inArray, lte, sql } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { casinoBets, casinoRounds, settings, wallets } from '../../../db/schema.js'
import {
  avCrash,
  avEffectiveAuto,
  avMultAt,
  avPayout,
  avTimeTo,
  CASINO_INFO,
  dtDeal,
  dtMaxReturn,
  dtSettle,
  DT_SIDES,
  fmtX,
  mergeCasino,
  type CasinoConfig,
  type CasinoKey,
  type DtResult,
  type DtSide,
} from '../../lib/games/casino.js'
import type { Tx } from './db-types.js'
import { postLedger, type Bucket } from './ledger.js'
import { isUniqueViolation, newId, sha256, UserError } from './util.js'

/**
 * Dragon Tiger and Aviator: shared rounds, bets, settlement and cash-outs.
 *
 * There is no long-running game server. Rounds follow a fixed schedule stored
 * on the round row, and every request (player polls, bets, the per-minute
 * scheduled function) "ticks" the game: it settles rounds whose result time
 * has passed and opens the next round. Every step is a conditional update
 * inside a DB transaction, so concurrent ticks and retries never double-pay.
 *
 * Money: stakes are deducted from the main wallet (bonus → purchased →
 * winnings) when the bet is accepted; wins are credited to the winnings
 * bucket; losses write a zero-amount ledger row so history is complete.
 * Ledger idempotency keys:
 *   cas:bet:<bet>:<bucket>    stake deduction
 *   cas:cancel:<bet>:<bucket> stake refund (cancelled while betting is open)
 *   cas:pay:<bet>             win / tie refund
 *   cas:loss:<bet>            loss record (0 coins)
 */

export type Round = typeof casinoRounds.$inferSelect
export type Bet = typeof casinoBets.$inferSelect

/** Aviator settles this long after the crash so in-flight cash-out requests received before the crash are honoured. */
const AV_GRACE_MS = 600

export const hmacDigest = (seed: string, roundId: string) => createHmac('sha256', seed).update(roundId).digest('hex')

export async function getCasinoConfig(): Promise<CasinoConfig> {
  const [row] = await db.select().from(settings).where(eq(settings.key, 'casino'))
  return mergeCasino(row?.value)
}

export async function saveCasinoConfig(value: CasinoConfig, by: string) {
  await db
    .insert(settings)
    .values({ key: 'casino', value, updatedBy: by })
    .onConflictDoUpdate({ target: settings.key, set: { value, updatedBy: by, updatedAt: new Date() } })
}

const rowsOf = <T,>(res: unknown) => ((res as { rows?: T[] }).rows ?? (res as T[])) as T[]

// ───────────────────────────── rounds ─────────────────────────────

export async function latestRound(game: CasinoKey) {
  const [r] = await db.select().from(casinoRounds).where(eq(casinoRounds.game, game)).orderBy(desc(casinoRounds.roundNo)).limit(1)
  return r ?? null
}

/** Opens the next round (seed committed now, before any bet). Safe to call concurrently. */
async function openNextRound(game: CasinoKey, cfg: CasinoConfig, prev: Round | null) {
  const nowMs = Date.now()
  const roundNo = Math.max(0, prev?.roundNo ?? 0) + 1
  const id = `${CASINO_INFO[game].prefix}-${String(roundNo).padStart(7, '0')}`
  const serverSeed = randomBytes(32).toString('hex')
  const opens = Math.max(nowMs, prev ? prev.endsAt.getTime() : 0)
  let params: Record<string, number>
  let closes: number, resultAt: number, ends: number
  if (game === 'dragon_tiger') {
    const c = cfg.dragon_tiger
    params = {}
    closes = opens + c.bettingSeconds * 1000
    resultAt = closes
    ends = closes + c.revealSeconds * 1000
  } else {
    const c = cfg.aviator
    params = { edgeBps: Math.round(c.houseEdgePercent * 100), maxX100: Math.round(c.maxMultiplier * 100) }
    const crash = avCrash(hmacDigest(serverSeed, id), params.edgeBps!, params.maxX100!)
    closes = opens + c.bettingSeconds * 1000
    resultAt = closes + avTimeTo(crash)
    ends = resultAt + c.pauseSeconds * 1000
  }
  await db
    .insert(casinoRounds)
    .values({
      id,
      game,
      roundNo,
      serverSeed,
      seedHash: sha256(serverSeed),
      params,
      opensAt: new Date(opens),
      closesAt: new Date(closes),
      resultAt: new Date(resultAt),
      endsAt: new Date(ends),
    })
    .onConflictDoNothing()
}

/** Settles every round of `game` whose result time has passed. */
export async function settleDue(game: CasinoKey) {
  const grace = game === 'aviator' ? AV_GRACE_MS : 0
  const due = await db
    .select({ id: casinoRounds.id })
    .from(casinoRounds)
    .where(and(eq(casinoRounds.game, game), eq(casinoRounds.status, 'betting'), lte(casinoRounds.resultAt, new Date(Date.now() - grace))))
    .orderBy(casinoRounds.roundNo)
    .limit(5)
  for (const r of due) await settleRound(r.id)
  return due.length
}

/**
 * Advances a game: settles due rounds, opens the next round when the current
 * one is over (unless the game is disabled or paused), and pays Aviator
 * automatic cash-outs the multiplier has already passed.
 */
export async function tick(game: CasinoKey) {
  const cfg = await getCasinoConfig()
  await settleDue(game)
  let cur = await latestRound(game)
  const gc = cfg[game]
  if ((!cur || Date.now() >= cur.endsAt.getTime()) && gc.enabled && !gc.paused) {
    await openNextRound(game, cfg, cur)
    cur = await latestRound(game)
  }
  if (game === 'aviator' && cur && cur.status === 'betting') await processAutoCashouts(cur)
  return { cfg, round: cur }
}

/** Phase of a round at `now` (ms). */
export function phaseOf(r: Round, now = Date.now()) {
  if (now < r.opensAt.getTime()) return 'waiting' as const
  if (now < r.closesAt.getTime()) return 'betting' as const
  if (r.game === 'aviator') return now < r.resultAt.getTime() ? ('flying' as const) : ('crashed' as const)
  return 'result' as const
}

/** Server-side result of a round (never sent to clients before the result time). */
export function roundResult(r: Round) {
  const digest = hmacDigest(r.serverSeed, r.id)
  if (r.game === 'dragon_tiger') return { kind: 'dt' as const, ...dtDeal(digest) }
  return { kind: 'av' as const, crashX100: avCrash(digest, r.params.edgeBps!, r.params.maxX100!) }
}

// ───────────────────────────── wallet helpers ─────────────────────────────

const ORDER = ['bonus', 'purchased', 'winnings'] as const
const label = (game: CasinoKey) => CASINO_INFO[game].name

async function lockWallet(tx: Tx, userId: string) {
  await tx.insert(wallets).values({ userId }).onConflictDoNothing()
  const w = rowsOf<{ bonus: string | number; purchased: string | number; winnings: string | number }>(
    await tx.execute(sql`select bonus, purchased, winnings from wallets where user_id = ${userId} for update`),
  )[0]
  return { bonus: Number(w?.bonus ?? 0), purchased: Number(w?.purchased ?? 0), winnings: Number(w?.winnings ?? 0) }
}

async function credit(tx: Tx, bet: Bet, amount: number, type: string, text: string) {
  return postLedger(tx, {
    userId: bet.userId,
    bucket: 'winnings',
    amount,
    type,
    label: text,
    idempotencyKey: amount > 0 ? `cas:pay:${bet.id}` : `cas:loss:${bet.id}`,
    refType: bet.game,
    refId: bet.id,
  })
}

const choiceLabel = (b: { game: string; choice: string }) =>
  b.game === 'dragon_tiger' ? b.choice[0]!.toUpperCase() + b.choice.slice(1) : `bet ${b.choice}`

// ───────────────────────────── placing bets ─────────────────────────────

export interface BetInput {
  game: CasinoKey
  roundId: string
  choice: string
  amount: number
  autoX100?: number | null
  clientKey: string
}

/**
 * Accepts one bet: the round must still be open (server clock), the amount
 * inside the limits, the round exposure under its cap and the wallet able to
 * pay. The stake is deducted in the same transaction the bet is written in.
 * Re-sending the same clientKey returns the original bet without charging again.
 */
export async function placeBet(userId: string, cfg: CasinoConfig, input: BetInput) {
  return db.transaction(async (tx) => {
    const [dup] = await tx.select().from(casinoBets).where(and(eq(casinoBets.userId, userId), eq(casinoBets.clientKey, input.clientKey)))
    if (dup) return { bet: dup, duplicate: true }

    const [round] = await tx.select().from(casinoRounds).where(eq(casinoRounds.id, input.roundId)).for('update')
    if (!round || round.game !== input.game) throw new UserError('That round does not exist.')
    const now = Date.now()
    if (round.status !== 'betting' || now >= round.closesAt.getTime()) throw new UserError('Betting for this round is closed. Your bet was not placed and no coins were taken.')
    if (now < round.opensAt.getTime()) throw new UserError('Betting for this round has not opened yet.')

    const open = await tx
      .select({ choice: casinoBets.choice, stake: casinoBets.stake, terms: casinoBets.terms, autoX100: casinoBets.autoX100 })
      .from(casinoBets)
      .where(and(eq(casinoBets.roundId, round.id), eq(casinoBets.status, 'active')))

    let terms: Record<string, number | null>
    let autoX100: number | null = null
    if (input.game === 'dragon_tiger') {
      const c = cfg.dragon_tiger
      const side = input.choice as DtSide
      if (!DT_SIDES.includes(side)) throw new UserError('Pick Dragon, Tiger or Tie.')
      terms = { oddsX100: Math.round(c.odds[side] * 100), tieRefundPercent: c.tieRefundPercent, feePercent: c.feePercent }
      const t = terms as { oddsX100: number; tieRefundPercent: number; feePercent: number }
      if (dtMaxReturn(input.amount, t) > c.maxPayoutPerBet) throw new UserError(`The maximum payout per bet is ${c.maxPayoutPerBet.toLocaleString()} coins. Lower your stake.`)
      // Worst case for the house over the three possible outcomes.
      const all = [...open, { choice: side, stake: input.amount, terms, autoX100: null }]
      const worst = Math.max(
        ...DT_SIDES.map((w) => all.reduce((sum, b) => sum + dtSettle(b.choice as DtSide, b.stake, b.terms as typeof t, w).payout, 0)),
      )
      if (worst > c.maxRoundExposure) throw new UserError('This round has reached its betting limit. Please try a smaller bet or the next round.')
    } else {
      const c = cfg.aviator
      if (input.choice !== '1' && input.choice !== '2') throw new UserError('Unknown bet slot.')
      const maxX100 = round.params.maxX100!
      const userAuto = input.autoX100 ?? null
      if (userAuto !== null && (userAuto < 101 || userAuto > maxX100)) throw new UserError(`Auto cash-out must be between 1.01x and ${fmtX(maxX100)}.`)
      autoX100 = avEffectiveAuto(input.amount, userAuto, maxX100, c.maxPayoutPerBet)
      terms = { maxPayout: c.maxPayoutPerBet, userAutoX100: userAuto }
      const exposure = open.reduce((s, b) => s + avPayout(b.stake, b.autoX100 ?? maxX100, Number(b.terms.maxPayout)), 0) + avPayout(input.amount, autoX100, c.maxPayoutPerBet)
      if (exposure > c.maxRoundExposure) throw new UserError('This round has reached its betting limit. Please try a smaller bet or the next round.')
    }

    // Balance check + deduction under the wallet row lock: never below zero.
    const have = await lockWallet(tx, userId)
    let left = input.amount
    const paid = { bonus: 0, purchased: 0, winnings: 0 }
    for (const b of ORDER) {
      const take = Math.min(left, have[b])
      paid[b] = take
      left -= take
    }
    if (left > 0)
      throw new UserError(`Not enough coins. This bet needs ${input.amount.toLocaleString()} and your balance is ${(have.bonus + have.purchased + have.winnings).toLocaleString()}.`)

    const id = newId('BT', 10)
    try {
      const [bet] = await tx
        .insert(casinoBets)
        .values({ id, roundId: round.id, game: input.game, userId, choice: input.choice, stake: input.amount, terms, autoX100, paid, clientKey: input.clientKey })
        .returning()
      for (const b of ORDER) {
        if (!paid[b]) continue
        await postLedger(tx, {
          userId,
          bucket: b as Bucket,
          amount: -paid[b],
          type: 'casino_bet',
          label: `${label(input.game)} ${choiceLabel(bet!)} · round ${round.id}`,
          idempotencyKey: `cas:bet:${id}:${b}`,
          refType: input.game,
          refId: id,
        })
      }
      return { bet: bet!, duplicate: false }
    } catch (e) {
      if (isUniqueViolation(e))
        throw new UserError(input.game === 'dragon_tiger' ? `You already have a ${choiceLabel({ game: input.game, choice: input.choice })} bet in this round.` : 'That bet slot is already used in this round.')
      throw e
    }
  })
}

/** Cancels an active bet while betting is still open and returns the exact coins to the buckets they came from. */
export async function cancelBet(userId: string, betId: string) {
  return db.transaction(async (tx) => {
    const [bet] = await tx.select().from(casinoBets).where(and(eq(casinoBets.id, betId), eq(casinoBets.userId, userId)))
    if (!bet) throw new UserError('Bet not found.')
    const [round] = await tx.select().from(casinoRounds).where(eq(casinoRounds.id, bet.roundId)).for('update')
    if (!round || round.status !== 'betting' || Date.now() >= round.closesAt.getTime()) throw new UserError('Betting is closed, so this bet can no longer be cancelled.')
    const [row] = await tx
      .update(casinoBets)
      .set({ status: 'cancelled', settledAt: new Date() })
      .where(and(eq(casinoBets.id, bet.id), eq(casinoBets.status, 'active')))
      .returning()
    if (!row) throw new UserError('This bet is no longer active.')
    for (const b of ORDER) {
      const amt = bet.paid[b]
      if (!amt) continue
      await postLedger(tx, {
        userId,
        bucket: b,
        amount: amt,
        type: 'casino_refund',
        label: `${label(bet.game as CasinoKey)} bet cancelled · round ${bet.roundId}`,
        idempotencyKey: `cas:cancel:${bet.id}:${b}`,
        refType: bet.game,
        refId: bet.id,
      })
    }
    return row
  })
}

// ───────────────────────────── Aviator cash-outs ─────────────────────────────

async function payCashout(tx: Tx, bet: Bet, x100: number, auto: boolean) {
  const payout = avPayout(bet.stake, x100, Number(bet.terms.maxPayout))
  const [row] = await tx
    .update(casinoBets)
    .set({ status: 'won', cashoutX100: x100, payout, settledAt: new Date() })
    .where(and(eq(casinoBets.id, bet.id), eq(casinoBets.status, 'active')))
    .returning()
  if (!row) return null
  await credit(tx, bet, payout, 'casino_win', `Aviator ${auto ? 'auto ' : ''}cash-out ${fmtX(x100)} · round ${bet.roundId}`)
  return row
}

/**
 * Manual cash-out. The server's receive time decides: it must be strictly
 * before the crash time. The multiplier is computed from that time on the
 * server (the client never sends a multiplier). If the bet's automatic target
 * was already passed, it is paid at the target instead.
 */
export async function cashOut(userId: string, betId: string) {
  const at = Date.now()
  return db.transaction(async (tx) => {
    const [bet] = await tx.select().from(casinoBets).where(and(eq(casinoBets.id, betId), eq(casinoBets.userId, userId)))
    if (!bet || bet.game !== 'aviator') throw new UserError('Bet not found.')
    const [round] = await tx.select().from(casinoRounds).where(eq(casinoRounds.id, bet.roundId)).for('share')
    if (!round) throw new UserError('Round not found.')
    if (bet.status !== 'active') {
      if (bet.status === 'won') return { bet, duplicate: true }
      throw new UserError('This bet is already settled.')
    }
    if (at < round.closesAt.getTime()) throw new UserError('The plane has not taken off yet. You can cancel the bet instead.')
    if (round.status !== 'betting' || at >= round.resultAt.getTime()) throw new UserError('Too late. The plane flew away before your cash-out reached the server.')
    const res = roundResult(round)
    if (res.kind !== 'av') throw new UserError('Bet not found.')
    let x = Math.min(avMultAt(at - round.closesAt.getTime()), res.crashX100)
    if (bet.autoX100 && bet.autoX100 <= x) x = bet.autoX100
    const row = await payCashout(tx, bet, x, false)
    if (!row) {
      const [now] = await tx.select().from(casinoBets).where(eq(casinoBets.id, bet.id))
      if (now?.status === 'won') return { bet: now, duplicate: true }
      throw new UserError('This bet is already settled.')
    }
    return { bet: row, duplicate: false }
  })
}

/** Pays automatic cash-outs whose target the live multiplier has reached (never above the crash point). */
export async function processAutoCashouts(round: Round) {
  const now = Date.now()
  if (round.game !== 'aviator' || now < round.closesAt.getTime()) return 0
  const res = roundResult(round)
  if (res.kind !== 'av') return 0
  const reached = Math.min(avMultAt(now - round.closesAt.getTime()), res.crashX100)
  const due = await db
    .select({ id: casinoBets.id })
    .from(casinoBets)
    .where(and(eq(casinoBets.roundId, round.id), eq(casinoBets.status, 'active'), lte(casinoBets.autoX100, reached)))
    .limit(50)
  for (const { id } of due)
    await db.transaction(async (tx) => {
      const [r] = await tx.select({ status: casinoRounds.status }).from(casinoRounds).where(eq(casinoRounds.id, round.id)).for('share')
      if (r?.status !== 'betting') return
      const [bet] = await tx.select().from(casinoBets).where(eq(casinoBets.id, id))
      if (bet?.status === 'active' && bet.autoX100 && bet.autoX100 <= res.crashX100) await payCashout(tx, bet, bet.autoX100, true)
    })
  return due.length
}

// ───────────────────────────── settlement ─────────────────────────────

/**
 * Settles a round exactly once: computes the result from the committed seed,
 * settles every active bet, records totals and marks the round settled, all in
 * one transaction under the round row lock. A second call is a no-op.
 */
export async function settleRound(roundId: string) {
  return db.transaction(async (tx) => {
    const [round] = await tx.select().from(casinoRounds).where(eq(casinoRounds.id, roundId)).for('update')
    if (!round || round.status !== 'betting' || Date.now() < round.resultAt.getTime()) return null
    const res = roundResult(round)
    const bets = await tx.select().from(casinoBets).where(and(eq(casinoBets.roundId, round.id), eq(casinoBets.status, 'active'))).for('update')
    for (const bet of bets) {
      if (res.kind === 'dt') {
        const t = bet.terms as { oddsX100: number; tieRefundPercent: number; feePercent: number }
        const s = dtSettle(bet.choice as DtSide, bet.stake, t, res.winner)
        await tx.update(casinoBets).set({ status: s.status, payout: s.payout, fee: s.fee, settledAt: new Date() }).where(and(eq(casinoBets.id, bet.id), eq(casinoBets.status, 'active')))
        const head = `Dragon Tiger ${choiceLabel(bet)} · round ${round.id}`
        if (s.status === 'won') await credit(tx, bet, s.payout, 'casino_win', `${head} · won`)
        else if (s.status === 'push' && s.payout > 0) await credit(tx, bet, s.payout, 'casino_refund', `${head} · tie, ${t.tieRefundPercent}% returned`)
        else await credit(tx, bet, 0, 'casino_loss', `${head} · lost`)
      } else if (bet.autoX100 && bet.autoX100 <= res.crashX100) {
        await payCashout(tx, bet, bet.autoX100, true)
      } else {
        await tx.update(casinoBets).set({ status: 'lost', settledAt: new Date() }).where(and(eq(casinoBets.id, bet.id), eq(casinoBets.status, 'active')))
        await credit(tx, bet, 0, 'casino_loss', `Aviator ${choiceLabel(bet)} · crashed at ${fmtX(res.crashX100)} · round ${round.id}`)
      }
    }
    const [tot] = await tx
      .select({ n: sql<number>`count(*)::int`, stake: sql<number>`coalesce(sum(${casinoBets.stake}),0)::bigint`, payout: sql<number>`coalesce(sum(${casinoBets.payout}),0)::bigint` })
      .from(casinoBets)
      .where(and(eq(casinoBets.roundId, round.id), sql`${casinoBets.status} <> 'cancelled'`))
    const result: Record<string, unknown> = res.kind === 'dt' ? { dragon: res.dragon, tiger: res.tiger, winner: res.winner } : { crashX100: res.crashX100 }
    const [done] = await tx
      .update(casinoRounds)
      .set({ status: 'settled', result, betCount: Number(tot?.n ?? 0), totalStake: Number(tot?.stake ?? 0), totalPayout: Number(tot?.payout ?? 0), settledAt: new Date() })
      .where(and(eq(casinoRounds.id, round.id), eq(casinoRounds.status, 'betting')))
      .returning()
    return done ?? null
  })
}

// ───────────────────────────── views ─────────────────────────────

/** What any player may see about a round right now. Seeds and future results stay hidden. */
export function publicRound(r: Round, now = Date.now()) {
  const phase = phaseOf(r, now)
  const settled = r.status === 'settled'
  const past = now >= r.resultAt.getTime()
  const res = past ? (settled ? r.result : roundResult(r)) : null
  return {
    id: r.id,
    game: r.game as CasinoKey,
    roundNo: r.roundNo,
    phase,
    settled,
    seedHash: r.seedHash,
    serverSeed: settled ? r.serverSeed : null,
    params: r.params,
    opensAt: r.opensAt,
    closesAt: r.closesAt,
    // Aviator: the crash time and round end would reveal the crash point, so they stay hidden until the crash.
    resultAt: r.game === 'dragon_tiger' || past ? r.resultAt : null,
    endsAt: r.game === 'dragon_tiger' || past ? r.endsAt : null,
    dt: r.game === 'dragon_tiger' && res ? (res as unknown as DtResult) : null,
    crashX100: r.game === 'aviator' && res ? Number((res as { crashX100: number }).crashX100) : null,
    betCount: r.betCount,
    totalStake: r.totalStake,
    totalPayout: r.totalPayout,
  }
}
export type PublicRound = ReturnType<typeof publicRound>

export function publicBet(b: Bet) {
  return {
    id: b.id,
    roundId: b.roundId,
    game: b.game as CasinoKey,
    choice: b.choice,
    stake: b.stake,
    terms: b.terms,
    autoX100: b.autoX100,
    status: b.status,
    cashoutX100: b.cashoutX100,
    payout: b.payout,
    fee: b.fee,
    createdAt: b.createdAt,
    settledAt: b.settledAt,
  }
}
export type PublicBet = ReturnType<typeof publicBet>

export async function recentRounds(game: CasinoKey, limit = 30) {
  return db
    .select()
    .from(casinoRounds)
    .where(and(eq(casinoRounds.game, game), eq(casinoRounds.status, 'settled')))
    .orderBy(desc(casinoRounds.roundNo))
    .limit(limit)
}

export async function betsOf(userId: string, roundIds: string[]) {
  if (!roundIds.length) return []
  return db.select().from(casinoBets).where(and(eq(casinoBets.userId, userId), inArray(casinoBets.roundId, roundIds)))
}
