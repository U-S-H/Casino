import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, ilike, inArray, or, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { friendships, gamePlayers, games, gameRooms, notifications, referrals, supportTickets, transactions, users } from '../../db/schema.js'
import { requireViewer } from './lib/auth.js'
import { notify, notifyAdmins } from './lib/audit.js'
import { rateLimit } from './lib/ratelimit.js'
import { getSettings } from './lib/settings.js'
import { newId, UserError } from './lib/util.js'

const avatarUrl = (u: { id: string; avatarKey: string | null }) =>
  u.avatarKey ? `/api/avatar/${u.id}?v=${encodeURIComponent(u.avatarKey.split('/').pop() ?? '')}` : null

/* ---------------- Notifications ---------------- */

export const listNotifications = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  const aud = v.isAdmin ? ['all', 'admins'] : ['all']
  const items = await db
    .select()
    .from(notifications)
    .where(or(eq(notifications.userId, v.profile.id), and(sql`${notifications.userId} is null`, inArray(notifications.audience, aud))))
    .orderBy(desc(notifications.createdAt))
    .limit(30)
  const seen = v.profile.notificationsSeenAt?.getTime() ?? 0
  return {
    items: items.map((n) => ({ ...n, unread: n.createdAt.getTime() > seen })),
    unread: items.filter((n) => n.createdAt.getTime() > seen).length,
  }
})

export const markNotificationsRead = createServerFn({ method: 'POST' }).handler(async () => {
  const v = await requireViewer()
  await db.update(users).set({ notificationsSeenAt: new Date() }).where(eq(users.id, v.profile.id))
  await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.userId, v.profile.id), sql`read_at is null`))
  return { ok: true }
})

/* ---------------- Referrals ---------------- */

export const getReferralSummary = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  const s = await getSettings()
  const rows = await db
    .select({ id: referrals.id, status: referrals.status, reward: referrals.reward, createdAt: referrals.createdAt, name: users.displayName, games: users.gamesPlayed })
    .from(referrals)
    .innerJoin(users, eq(users.id, referrals.referredId))
    .where(eq(referrals.referrerId, v.profile.id))
    .orderBy(desc(referrals.createdAt))
    .limit(100)
  const [{ earned }] = await db
    .select({ earned: sql<number>`coalesce(sum(amount),0)::int` })
    .from(transactions)
    .where(and(eq(transactions.userId, v.profile.id), eq(transactions.type, 'referral')))
  return {
    code: v.profile.referralCode,
    settings: s.referral,
    joined: rows.length,
    qualified: rows.filter((r) => r.status === 'rewarded').length,
    pending: rows.filter((r) => r.status === 'pending').length,
    earned,
    history: rows,
  }
})

/* ---------------- Friends ---------------- */

export const listFriends = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  const me = v.profile.id
  const rows = await db
    .select()
    .from(friendships)
    .where(or(eq(friendships.requesterId, me), eq(friendships.addresseeId, me)))
  const ids = rows.map((r) => (r.requesterId === me ? r.addresseeId : r.requesterId))
  const people = ids.length
    ? await db
        .select({ id: users.id, publicId: users.publicId, displayName: users.displayName, avatarKey: users.avatarKey, rating: users.rating, lastSeenAt: users.lastSeenAt })
        .from(users)
        .where(inArray(users.id, ids))
    : []
  const byId = new Map(people.map((p) => [p.id, p]))
  const now = Date.now()
  const view = (id: string) => {
    const p = byId.get(id)!
    return {
      id: p.id,
      publicId: p.publicId,
      name: p.displayName,
      avatarUrl: avatarUrl(p),
      rating: p.rating,
      online: now - p.lastSeenAt.getTime() < 2 * 60_000,
      lastSeenAt: p.lastSeenAt,
    }
  }
  return {
    friends: rows.filter((r) => r.status === 'accepted').map((r) => view(r.requesterId === me ? r.addresseeId : r.requesterId)),
    incoming: rows.filter((r) => r.status === 'pending' && r.addresseeId === me).map((r) => view(r.requesterId)),
    outgoing: rows.filter((r) => r.status === 'pending' && r.requesterId === me).map((r) => view(r.addresseeId)),
  }
})

export const searchPlayers = createServerFn({ method: 'GET' })
  .validator(z.object({ q: z.string().trim().min(2).max(40) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const q = data.q.replace(/[%_]/g, '')
    const rows = await db
      .select({ id: users.id, publicId: users.publicId, displayName: users.displayName, avatarKey: users.avatarKey, rating: users.rating })
      .from(users)
      .where(and(or(ilike(users.displayName, `%${q}%`), eq(users.publicId, q.toUpperCase())), sql`${users.id} <> ${v.profile.id}`, eq(users.status, 'active')))
      .limit(10)
    return rows.map((r) => ({ id: r.id, publicId: r.publicId, name: r.displayName, avatarUrl: avatarUrl(r), rating: r.rating }))
  })

export const sendFriendRequest = createServerFn({ method: 'POST' })
  .validator(z.object({ userId: z.string().min(1) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    if (data.userId === v.profile.id) throw new UserError('You cannot add yourself.')
    await rateLimit(`friend:${v.profile.id}`, 30, 3600)
    const [target] = await db.select().from(users).where(eq(users.id, data.userId))
    if (!target) throw new UserError('Player not found.')
    // If they already asked us, accept instead.
    const [reverse] = await db
      .select()
      .from(friendships)
      .where(and(eq(friendships.requesterId, target.id), eq(friendships.addresseeId, v.profile.id)))
    if (reverse) {
      await db.update(friendships).set({ status: 'accepted' }).where(and(eq(friendships.requesterId, target.id), eq(friendships.addresseeId, v.profile.id)))
      await notify(target.id, { kind: 'friend', title: 'Friend request accepted', body: `${v.profile.displayName} is now your friend.`, link: '/app/friends' })
      return { status: 'accepted' }
    }
    await db.insert(friendships).values({ requesterId: v.profile.id, addresseeId: target.id }).onConflictDoNothing()
    await notify(target.id, { kind: 'friend', title: 'New friend request', body: `${v.profile.displayName} wants to be friends.`, link: '/app/friends' })
    return { status: 'pending' }
  })

export const respondFriendRequest = createServerFn({ method: 'POST' })
  .validator(z.object({ userId: z.string().min(1), accept: z.boolean() }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const where = and(eq(friendships.requesterId, data.userId), eq(friendships.addresseeId, v.profile.id))
    if (data.accept) {
      await db.update(friendships).set({ status: 'accepted' }).where(where)
      await notify(data.userId, { kind: 'friend', title: 'Friend request accepted', body: `${v.profile.displayName} accepted your request.`, link: '/app/friends' })
    } else await db.delete(friendships).where(where)
    return { ok: true }
  })

export const removeFriend = createServerFn({ method: 'POST' })
  .validator(z.object({ userId: z.string().min(1) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const me = v.profile.id
    await db
      .delete(friendships)
      .where(
        or(
          and(eq(friendships.requesterId, me), eq(friendships.addresseeId, data.userId)),
          and(eq(friendships.requesterId, data.userId), eq(friendships.addresseeId, me)),
        ),
      )
    return { ok: true }
  })

/** Sends an in-app game invitation containing a room code. Only to accepted friends. */
export const inviteToRoom = createServerFn({ method: 'POST' })
  .validator(z.object({ userId: z.string().min(1), roomId: z.string().min(1) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`invite:${v.profile.id}`, 30, 600)
    const me = v.profile.id
    const [f] = await db
      .select()
      .from(friendships)
      .where(
        and(
          eq(friendships.status, 'accepted'),
          or(
            and(eq(friendships.requesterId, me), eq(friendships.addresseeId, data.userId)),
            and(eq(friendships.requesterId, data.userId), eq(friendships.addresseeId, me)),
          ),
        ),
      )
    if (!f) throw new UserError('You can only invite friends.')
    const [room] = await db.select().from(gameRooms).where(eq(gameRooms.id, data.roomId))
    if (!room || room.status !== 'waiting') throw new UserError('That room is no longer open.')
    await notify(data.userId, {
      kind: 'invite',
      title: `${v.profile.displayName} invited you`,
      body: `Join a ${room.game === 'ludo' ? 'Ludo' : room.game === 'pool' ? '8 Ball Pool' : room.game === 'carrom' ? 'Carrom' : 'Chess'} ${room.mode} room · code ${room.code}${room.entryFee ? ` · ${room.entryFee} coin entry` : ''}${room.passwordHash ? ' (password protected — ask your friend)' : ''}`,
      link: room.game === 'ludo' ? `/app/play?code=${room.code}` : `/app/arena/${room.game}?code=${room.code}`,
    })
    return { ok: true }
  })

/* ---------------- Leaderboard & history ---------------- */

export const getLeaderboard = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  const top = await db
    .select({ id: users.id, publicId: users.publicId, name: users.displayName, avatarKey: users.avatarKey, rating: users.rating, wins: users.gamesWon, played: users.gamesPlayed, country: users.country })
    .from(users)
    .where(and(eq(users.status, 'active'), sql`${users.gamesPlayed} > 0`))
    .orderBy(desc(users.rating), desc(users.gamesWon))
    .limit(50)
  const [{ rank }] = await db
    .select({ rank: sql<number>`count(*)::int + 1` })
    .from(users)
    .where(and(eq(users.status, 'active'), sql`${users.gamesPlayed} > 0`, sql`${users.rating} > ${v.profile.rating}`))
  return {
    top: top.map((t, i) => ({ ...t, rank: i + 1, avatarUrl: avatarUrl(t), me: t.id === v.profile.id })),
    me: { rank: v.profile.gamesPlayed > 0 ? rank : null, rating: v.profile.rating, wins: v.profile.gamesWon, played: v.profile.gamesPlayed },
  }
})

export const getGameHistory = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  const rows = await db
    .select({ id: games.id, game: games.game, mode: games.mode, entryFee: games.entryFee, reason: games.reason, players: games.players, endedAt: games.endedAt, won: gamePlayers.won, ratingDelta: gamePlayers.ratingDelta, turns: games.turns })
    .from(gamePlayers)
    .innerJoin(games, eq(games.id, gamePlayers.gameId))
    .where(eq(gamePlayers.userId, v.profile.id))
    .orderBy(desc(gamePlayers.endedAt))
    .limit(30)
  const names: Record<string, string> = { pool: '8 Ball Pool', carrom: 'Carrom', chess: 'Chess' }
  return rows.map((r) => ({
    ...r,
    // Non-Ludo games are labelled with their name so existing history lists read naturally.
    mode: r.game === 'ludo' ? r.mode : `${names[r.game] ?? r.game} · ${r.mode}`,
    opponents: r.players.filter((p) => p.userId !== v.profile.id).map((p) => p.name).join(', '),
  }))
})

/* ---------------- Support ---------------- */

export const createTicket = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      subject: z.string().trim().min(4).max(120),
      message: z.string().trim().min(10).max(2000),
      category: z.enum(['deposit', 'withdrawal', 'game', 'account', 'referral', 'general']),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`ticket:${v.profile.id}`, 5, 3600)
    const id = newId('ST', 6)
    const priority = data.category === 'deposit' || data.category === 'withdrawal' ? 'high' : 'medium'
    await db.insert(supportTickets).values({ id, userId: v.profile.id, ...data, priority })
    await notifyAdmins({ kind: 'support', title: 'New support ticket', body: `${v.profile.displayName}: ${data.subject}`, link: '/admin?section=support' })
    return { id }
  })

export const listMyTickets = createServerFn({ method: 'GET' }).handler(async () => {
  const v = await requireViewer()
  return db.select().from(supportTickets).where(eq(supportTickets.userId, v.profile.id)).orderBy(desc(supportTickets.createdAt)).limit(30)
})
