// @vitest-environment node
/**
 * Server integration tests against a real Postgres (the local Netlify dev DB).
 * Run with: LKA_IT_DB=postgres://… npx vitest run src/server/integration.test.ts
 * Skipped automatically when LKA_IT_DB is not set.
 */
import { beforeAll, describe, expect, it } from 'vitest'

const url = process.env.LKA_IT_DB
if (url) {
  process.env.NETLIFY_DB_URL = url
  process.env.NETLIFY_DB_DRIVER = 'server'
}

describe.skipIf(!url)('server integration', () => {
  let m: {
    db: typeof import('../../db/index.js')['db']
    s: typeof import('../../db/schema.js')
    ledger: typeof import('./lib/ledger.js')
    rooms: typeof import('./lib/rooms.js')
    tours: typeof import('./lib/tournaments.js')
    util: typeof import('./lib/util.js')
    eq: typeof import('drizzle-orm')['eq']
  }
  const uid = (n: string) => `it-${n}-${Date.now()}`
  const A = uid('a')
  const B = uid('b')

  beforeAll(async () => {
    const [{ db }, s, ledger, rooms, tours, util, { eq }] = await Promise.all([
      import('../../db/index.js'),
      import('../../db/schema.js'),
      import('./lib/ledger.js'),
      import('./lib/rooms.js'),
      import('./lib/tournaments.js'),
      import('./lib/util.js'),
      import('drizzle-orm'),
    ])
    m = { db, s, ledger, rooms, tours, util, eq }
    for (const [id, name] of [
      [A, 'Alice'],
      [B, 'Bob'],
    ])
      await db.insert(s.users).values({ id, publicId: `LKA-${util.randomCode(6)}`, email: `${id}@x.test`, displayName: name, referralCode: util.randomCode(8) })
  })

  it('ledger credits are idempotent and debits never go negative', async () => {
    const { db, ledger, s, eq } = m
    const e = { userId: A, bucket: 'bonus' as const, amount: 500, type: 'promo', label: 'test', idempotencyKey: `k-${A}` }
    const r1 = await db.transaction((tx) => ledger.postLedger(tx, e))
    const r2 = await db.transaction((tx) => ledger.postLedger(tx, e))
    expect(r1.duplicate).toBe(false)
    expect(r2.duplicate).toBe(true)
    await expect(db.transaction((tx) => ledger.postLedger(tx, { ...e, amount: -9999, idempotencyKey: `d-${A}` }))).rejects.toThrow(/Insufficient/)
    const [w] = await db.select().from(s.wallets).where(eq(s.wallets.userId, A))
    expect(w!.bonus).toBe(500)
    const txs = await db.select().from(s.transactions).where(eq(s.transactions.userId, A))
    expect(txs).toHaveLength(1)
    expect(txs[0]!.balanceAfter).toBe(500)
  })

  it('rejects a duplicate (method, TID) even with different spacing/case', async () => {
    const { db, s, util } = m
    const base = { userId: A, packageId: 'pk', packageName: 'P', coins: 1, amountPkr: 100, method: 'jazzcash', payToAccount: '03', flags: [] as string[] }
    await db.insert(s.deposits).values({ ...base, id: util.newId('DR'), tid: 'ab12 3456', tidNormalized: util.normalizeTid('ab12 3456') })
    await expect(
      db.insert(s.deposits).values({ ...base, id: util.newId('DR'), userId: B, tid: 'AB123456', tidNormalized: util.normalizeTid('AB123456') }),
    ).rejects.toSatisfy((e: unknown) => util.isUniqueViolation(e))
    // Same TID on a different provider is allowed.
    await db.insert(s.deposits).values({ ...base, id: util.newId('DR'), method: 'easypaisa', tid: 'AB123456', tidNormalized: 'AB123456' })
  })

  it('runs a full server-authoritative 1v1 game to completion', async () => {
    const { db, s, rooms, eq } = m
    const [room] = await db
      .insert(s.gameRooms)
      .values({
        id: `RM-${A}`,
        code: String(100000 + Math.floor(Math.random() * 899999)),
        mode: '1v1',
        isPrivate: true,
        hostId: A,
        seats: [
          { userId: A, name: 'Alice', isBot: false, missed: 0 },
          { userId: B, name: 'Bob', isBot: false, missed: 0 },
        ],
      })
      .returning()
    let r = (await rooms.startRoom(room!, false))!
    expect(r.status).toBe('playing')
    // Wrong player cannot act.
    const st0 = r.state as unknown as import('./lib/rooms.js').RoomState
    const notTurn = st0.game.turn === 0 ? B : A
    await expect(rooms.playerAction(r, notTurn, { type: 'roll' })).rejects.toThrow(/not your turn/)
    // Illegal move (no roll yet) is rejected.
    await expect(rooms.playerAction(r, st0.game.turn === 0 ? A : B, { type: 'move', token: 0 })).rejects.toThrow()

    for (let i = 0; i < 3000 && r.status === 'playing'; i++) {
      const st = r.state as unknown as import('./lib/rooms.js').RoomState
      const me = r.seats[st.game.turn]!.userId!
      if (st.game.dice === null) r = await rooms.playerAction(r, me, { type: 'roll' })
      else {
        const p = st.game.players[st.game.turn]!
        const { movableTokens } = await import('../lib/ludo.js')
        r = await rooms.playerAction(r, me, { type: 'move', token: movableTokens(p, st.game.dice)[0]! })
      }
    }
    expect(r.status).toBe('finished')
    const g = await db.select().from(s.games).where(eq(s.games.roomId, r.id))
    expect(g).toHaveLength(1)
    const gp = await db.select().from(s.gamePlayers).where(eq(s.gamePlayers.gameId, g[0]!.id))
    expect(gp.filter((x) => x.won)).toHaveLength(1)
    const [ua] = await db.select().from(s.users).where(eq(s.users.id, A))
    expect(ua!.gamesPlayed).toBe(1)
  }, 120_000)

  it('optimistic locking rejects a stale write', async () => {
    const { db, s, rooms, eq } = m
    const [r] = await db.select().from(s.gameRooms).where(eq(s.gameRooms.id, `RM-${A}`))
    expect(await rooms.saveRoom(r!, { status: 'finished' })).not.toBeNull()
    expect(await rooms.saveRoom(r!, { status: 'finished' })).toBeNull()
  })

  it('qualifies a referral exactly once', async () => {
    const { db, s, rooms, eq } = m
    await db.insert(s.referrals).values({ referrerId: A, referredId: B, code: 'X' })
    await rooms.qualifyReferral(B, 250, 100)
    await rooms.qualifyReferral(B, 250, 100)
    const refTx = await db.select().from(s.transactions).where(eq(s.transactions.type, 'referral'))
    expect(refTx.filter((t) => t.userId === A)).toHaveLength(1)
    expect(refTx.filter((t) => t.userId === B)).toHaveLength(1)
  })

  it('settles a finished tournament once and pays the winner', async () => {
    const { db, s, tours, eq } = m
    const id = `TN-${A}`
    await db.insert(s.tournaments).values({ id, name: 'IT cup', kind: 'daily', mode: '1v1', prizeCoins: 1000, startsAt: new Date(Date.now() - 7200e3), endsAt: new Date(Date.now() - 1000), createdBy: 'it', status: 'live' })
    await db.insert(s.tournamentEntries).values([
      { tournamentId: id, userId: A, points: 9, wins: 3, games: 3 },
      { tournamentId: id, userId: B, points: 2, wins: 0, games: 2 },
    ])
    await tours.settleDueTournaments()
    await tours.settleDueTournaments()
    const entries = await db.select().from(s.tournamentEntries).where(eq(s.tournamentEntries.tournamentId, id))
    expect(entries.find((e) => e.userId === A)!.rank).toBe(1)
    expect(entries.find((e) => e.userId === A)!.prize).toBe(500)
    const paid = await db.select().from(s.transactions).where(eq(s.transactions.refId, id))
    expect(paid).toHaveLength(2)
  })
})
