import { createServerFn } from '@tanstack/react-start'
import { and, asc, desc, eq, gt, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { gameRooms, matchReports, roomMessages, type SeatInfo } from '../../db/schema.js'
import { entryError, GAME_INFO, type GameKey } from '../lib/games/catalog.js'
import type { Mode } from '../lib/ludo.js'
import { arenaAction, arenaForfeit, arenaTick, isArena, startArena, type ArenaRoomState } from './lib/arena.js'
import { notifyAdmins } from './lib/audit.js'
import { requireViewer, type Viewer } from './lib/auth.js'
import { rateLimit } from './lib/ratelimit.js'
import { commit, emptySeat, lastSideStanding, loadRoom, playerAction, saveRoom, seatCount, startRoom, tick, type Room, type RoomState } from './lib/rooms.js'
import { getSettings } from './lib/settings.js'
import { assertCanAfford, getArenaConfig, refundRoom, spendableBalance, stakeView } from './lib/stakes.js'
import { checkPassword, hashPassword, isUniqueViolation, newId, roomCode, UserError } from './lib/util.js'

const gameEnum = z.enum(['ludo', 'pool', 'carrom', 'chess'])
const modeStr = z.string().trim().min(2).max(12)
const entryNum = z.number().int().min(0).max(1_000_000)

function view(room: Room, userId: string) {
  const ludo = room.game === 'ludo'
  const st = ludo ? (room.state as unknown as RoomState | null) : null
  const arena = !ludo ? (room.state as unknown as ArenaRoomState | null) : null
  return {
    id: room.id,
    game: room.game as GameKey,
    code: room.code,
    mode: room.mode as Mode,
    isPrivate: room.isPrivate,
    hasPassword: !!room.passwordHash,
    status: room.status,
    isHost: room.hostId === userId,
    seats: room.seats.map((s) => ({
      name: s.name,
      isBot: s.isBot,
      filled: !!s.userId || s.isBot,
      me: s.userId === userId || s.owner === userId,
      confirmed: !!s.confirmed,
      forfeited: !!s.forfeited,
      missed: s.missed,
    })),
    mySeat: room.seats.findIndex((s) => s.userId === userId),
    state: st,
    arena: arena ? { json: JSON.stringify(arena.g), turnSeconds: arena.turnSeconds, outcome: arena.outcome } : null,
    stake: stakeView(room),
    cancelReason: room.cancelReason,
    disputed: room.disputed,
    turnDeadline: room.turnDeadline,
    serverNow: new Date(),
    version: room.version,
    createdAt: room.createdAt,
  }
}
export type RoomView = ReturnType<typeof view>

async function playable(v: Viewer, game: GameKey = 'ludo') {
  const s = await getSettings()
  if (s.maintenance.enabled && !v.isAdmin) throw new UserError('The arena is in maintenance mode. Please try again soon.')
  if (v.profile.selfExcludedUntil && v.profile.selfExcludedUntil > new Date()) throw new UserError('Play is paused while your self-exclusion is active.')
  const cfg = (await getArenaConfig())[game]
  if (!cfg.enabled && !v.isAdmin) throw new UserError(`${GAME_INFO[game].name} is currently unavailable.`)
  return cfg
}

/** Validates game, match type and entry amount against the admin configuration. */
async function checkMatch(v: Viewer, game: GameKey, mode: string, entry: number) {
  const cfg = await playable(v, game)
  const mt = cfg.matchTypes.find((m) => m.id === mode)
  if (!mt || !mt.enabled) throw new UserError('That match type is not available.')
  const err = entryError(cfg, entry)
  if (err) throw new UserError(err)
  await assertCanAfford(v.profile.id, entry)
  return { cfg, mt }
}

async function insertRoom(v: Viewer, game: GameKey, mode: string, isPrivate: boolean, entry: number, password?: string) {
  const { cfg, mt } = await checkMatch(v, game, mode, entry)
  const seats: SeatInfo[] = Array.from({ length: game === 'ludo' ? seatCount(mode as Mode) : mt.players }, emptySeat)
  // Creating the room is the host's confirmation of the (now locked) entry amount.
  seats[0] = { userId: v.profile.id, name: v.profile.displayName, isBot: false, missed: 0, confirmed: true }
  for (let i = 0; i < 5; i++) {
    try {
      const [r] = await db
        .insert(gameRooms)
        .values({
          id: newId('RM'),
          code: roomCode(),
          game,
          mode,
          isPrivate,
          passwordHash: password ? hashPassword(password) : null,
          hostId: v.profile.id,
          seats,
          entryFee: entry,
          feePercent: entry > 0 ? cfg.feePercent : 0,
          stakeStatus: entry > 0 ? 'pending' : 'none',
        })
        .returning()
      return r!
    } catch (e) {
      if (!isUniqueViolation(e)) throw e
    }
  }
  throw new Error('Could not allocate a room code')
}

async function begin(room: Room) {
  return room.game === 'ludo' ? startRoom(room, false) : startArena(room)
}

/** One unfinished match per player keeps stakes and turn timers simple. */
async function assertNotBusy(v: Viewer, exceptRoom?: string) {
  const [r] = await db
    .select({ id: gameRooms.id, game: gameRooms.game })
    .from(gameRooms)
    .where(and(sql`${gameRooms.status} in ('waiting','playing')`, sql`${gameRooms.seats} @> ${JSON.stringify([{ userId: v.profile.id }])}::jsonb`))
    .limit(1)
  if (r && r.id !== exceptRoom) throw new UserError(`You already have an unfinished ${GAME_INFO[r.game as GameKey]?.name ?? ''} match. Finish or leave it first.`)
}

async function seatInto(room: Room, v: Viewer, acceptEntry?: number): Promise<Room> {
  for (let attempt = 0; attempt < 4; attempt++) {
    if (room.seats.some((s) => s.userId === v.profile.id)) return room
    if (room.status !== 'waiting') throw new UserError('This game has already started.')
    if (room.entryFee > 0) {
      // The joiner must explicitly agree to the exact locked amount shown to them.
      if (acceptEntry !== room.entryFee) throw new UserError(`This room's entry is ${room.entryFee.toLocaleString()} coins. Review and confirm it to join.`)
      await assertCanAfford(v.profile.id, room.entryFee)
    }
    const idx = room.seats.findIndex((s) => !s.userId && !s.isBot)
    if (idx < 0) throw new UserError('This room is full.')
    const seats = room.seats.map((s, i) =>
      i === idx ? { userId: v.profile.id, name: v.profile.displayName, isBot: false, missed: 0, confirmed: true } : s,
    )
    const saved = await saveRoom(room, { seats })
    if (saved) {
      if (saved.seats.every((s) => s.userId || s.isBot)) return (await begin(saved)) ?? (await loadRoom(saved.id))
      return saved
    }
    room = await loadRoom(room.id)
  }
  throw new UserError('Room is busy — please try again.')
}

/** Finds the caller's unfinished room so a refresh or reconnect resumes the game. */
export const getActiveRoom = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum.optional() }).optional())
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const [r] = await db
      .select()
      .from(gameRooms)
      .where(
        and(
          sql`${gameRooms.status} in ('waiting','playing')`,
          sql`${gameRooms.seats} @> ${JSON.stringify([{ userId: v.profile.id }])}::jsonb`,
          data?.game ? eq(gameRooms.game, data.game) : undefined,
        ),
      )
      .orderBy(desc(gameRooms.updatedAt))
      .limit(1)
    return r ? view(r, v.profile.id) : null
  })

/** Per-game availability and entry limits for the game cards. */
export const getGamesConfig = createServerFn({ method: 'GET' }).handler(async () => {
  await requireViewer()
  return getArenaConfig()
})

/** Lobby data: the game's coin-entry configuration and the caller's spendable balance. */
export const getLobby = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const cfg = (await getArenaConfig())[data.game]
    const open = await db
      .select({ entryFee: gameRooms.entryFee, mode: gameRooms.mode, n: sql<number>`count(*)::int` })
      .from(gameRooms)
      .where(and(eq(gameRooms.game, data.game), eq(gameRooms.status, 'waiting'), eq(gameRooms.isPrivate, false), sql`${gameRooms.createdAt} > now() - interval '10 minutes'`))
      .groupBy(gameRooms.entryFee, gameRooms.mode)
    return { config: cfg, balance: await spendableBalance(v.profile.id), openTables: open }
  })

/** Everything a player needs to see before agreeing to join a room: entry, prize pool, fee, seats and their balance. */
export const previewRoom = createServerFn({ method: 'GET' })
  .validator(z.object({ code: z.string().trim().regex(/^\d{6}$/, 'Room codes have 6 digits') }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`preview:${v.profile.id}`, 60, 600)
    const [room] = await db.select().from(gameRooms).where(eq(gameRooms.code, data.code))
    if (!room || room.status !== 'waiting') throw new UserError('No open room with that code.')
    return {
      code: room.code,
      game: room.game as GameKey,
      mode: room.mode,
      hasPassword: !!room.passwordHash,
      host: room.seats[0]?.name ?? '',
      filled: room.seats.filter((s) => s.userId || s.isBot).length,
      seats: room.seats.length,
      stake: stakeView(room),
      balance: await spendableBalance(v.profile.id),
    }
  })

export const createRoom = createServerFn({ method: 'POST' })
  .validator(z.object({ game: gameEnum.default('ludo'), mode: modeStr, entry: entryNum.default(0), password: z.string().trim().max(32).optional() }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`room:${v.profile.id}`, 20, 600)
    await assertNotBusy(v)
    const r = await insertRoom(v, data.game, data.mode, true, data.entry, data.password || undefined)
    return view(r, v.profile.id)
  })

export const joinRoomByCode = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      code: z.string().trim().regex(/^\d{6}$/, 'Room codes have 6 digits'),
      password: z.string().max(32).optional(),
      acceptEntry: entryNum.optional(),
    }),
  )
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`join:${v.profile.id}`, 30, 600)
    const [room] = await db.select().from(gameRooms).where(eq(gameRooms.code, data.code))
    if (!room || !['waiting', 'playing'].includes(room.status)) throw new UserError('No open room with that code.')
    const already = room.seats.some((s) => s.userId === v.profile.id)
    if (!already) {
      await playable(v, room.game as GameKey)
      await assertNotBusy(v)
      if (!checkPassword(data.password ?? '', room.passwordHash)) throw new UserError('Wrong room password.')
    }
    return view(await seatInto(room, v, data.acceptEntry ?? (room.entryFee === 0 ? 0 : undefined)), v.profile.id)
  })

export const quickMatch = createServerFn({ method: 'POST' })
  .validator(z.object({ game: gameEnum.default('ludo'), mode: modeStr, entry: entryNum.default(0) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`match:${v.profile.id}`, 30, 600)
    await checkMatch(v, data.game, data.mode, data.entry)
    await assertNotBusy(v)
    // Only tables with exactly the same entry amount match — both players agreed to it.
    const open = await db
      .select()
      .from(gameRooms)
      .where(
        and(
          eq(gameRooms.status, 'waiting'),
          eq(gameRooms.isPrivate, false),
          eq(gameRooms.game, data.game),
          eq(gameRooms.mode, data.mode),
          eq(gameRooms.entryFee, data.entry),
          sql`${gameRooms.createdAt} > now() - interval '5 minutes'`,
        ),
      )
      .orderBy(asc(gameRooms.createdAt))
      .limit(5)
    for (const room of open) {
      try {
        return view(await seatInto(room, v, data.entry), v.profile.id)
      } catch {
        /* try next room */
      }
    }
    return view(await insertRoom(v, data.game, data.mode, false, data.entry), v.profile.id)
  })

export const startWithBots = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    const room = await loadRoom(data.roomId)
    if (room.hostId !== v.profile.id) throw new UserError('Only the host can start the game.')
    if (room.status !== 'waiting') throw new UserError('The game already started.')
    if (room.game !== 'ludo' || room.entryFee > 0) throw new UserError('Coin-entry matches start automatically when every seat is filled.')
    const r = await startRoom(room, true)
    return view(r ?? (await loadRoom(room.id)), v.profile.id)
  })

export const getRoom = createServerFn({ method: 'GET' })
  .validator(z.object({ roomId: z.string(), sinceMessage: z.number().int().default(0) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    let room = await loadRoom(data.roomId)
    room = room.game === 'ludo' ? await tick(room) : await arenaTick(room)
    const messages = await db
      .select({ id: roomMessages.id, name: roomMessages.name, text: roomMessages.text, userId: roomMessages.userId, createdAt: roomMessages.createdAt })
      .from(roomMessages)
      .where(and(eq(roomMessages.roomId, room.id), gt(roomMessages.id, data.sinceMessage)))
      .orderBy(asc(roomMessages.id))
      .limit(50)
    return { room: view(room, v.profile.id), messages: messages.map((m) => ({ ...m, me: m.userId === v.profile.id })) }
  })

export const rollDice = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`act:${v.profile.id}`, 120, 60)
    const room = await loadRoom(data.roomId)
    if (room.game !== 'ludo') throw new UserError('Not a Ludo room.')
    return view(await playerAction(room, v.profile.id, { type: 'roll' }), v.profile.id)
  })

export const moveToken = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string(), token: z.number().int().min(0).max(3) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`act:${v.profile.id}`, 120, 60)
    const room = await loadRoom(data.roomId)
    if (room.game !== 'ludo') throw new UserError('Not a Ludo room.')
    return view(await playerAction(room, v.profile.id, { type: 'move', token: data.token }), v.profile.id)
  })

/** 8 Ball Pool / Carrom / Chess action. The payload is validated by the game's server-side rules engine. */
export const arenaAct = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string(), action: z.record(z.string(), z.unknown()) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`act:${v.profile.id}`, 120, 60)
    const room = await loadRoom(data.roomId)
    if (!isArena(room.game)) throw new UserError('Not an arena room.')
    return view(await arenaAction(room, v.profile.id, data.action), v.profile.id)
  })

/** Lets a player flag a finished or live match for admin review. */
export const reportMatch = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string(), reason: z.string().trim().min(5).max(500) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`report:${v.profile.id}`, 5, 3600)
    const room = await loadRoom(data.roomId)
    if (!room.seats.some((s) => s.userId === v.profile.id || s.owner === v.profile.id)) throw new UserError('Only players in this match can report it.')
    await db.insert(matchReports).values({ roomId: room.id, userId: v.profile.id, reason: data.reason }).onConflictDoNothing()
    await db.update(gameRooms).set({ disputed: true }).where(eq(gameRooms.id, room.id))
    await notifyAdmins({ kind: 'dispute', title: 'Match reported', body: `${v.profile.displayName} reported ${GAME_INFO[room.game as GameKey]?.name} #${room.code}.`, link: '/admin?section=matches' })
    return { ok: true }
  })

export const sendChat = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string(), text: z.string().trim().min(1).max(200) }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    await rateLimit(`chat:${v.profile.id}`, 20, 60)
    const room = await loadRoom(data.roomId)
    if (!room.seats.some((s) => s.userId === v.profile.id)) throw new UserError('Only players in this room can chat.')
    const clean = data.text.replace(/https?:\/\/\S+/gi, '[link]')
    await db.insert(roomMessages).values({ roomId: room.id, userId: v.profile.id, name: v.profile.displayName, text: clean })
    return { ok: true }
  })

export const leaveRoom = createServerFn({ method: 'POST' })
  .validator(z.object({ roomId: z.string() }))
  .handler(async ({ data }) => {
    const v = await requireViewer()
    for (let i = 0; i < 4; i++) {
      const room = await loadRoom(data.roomId)
      const idx = room.seats.findIndex((s) => s.userId === v.profile.id)
      if (idx < 0 || room.status !== 'waiting' && room.status !== 'playing') return { ok: true }
      if (room.status === 'waiting') {
        // Nothing has been deducted before the start, so leaving costs nothing.
        const seats = room.seats.map((s, j) => (j === idx ? emptySeat() : s))
        const anyone = seats.some((s) => s.userId)
        if (!anyone && room.entryFee > 0) {
          await refundRoom(room.id, 'Host cancelled before the match started.')
          return { ok: true }
        }
        const nextHost = seats.find((s) => s.userId)?.userId ?? room.hostId
        if (await saveRoom(room, { seats, status: anyone ? 'waiting' : 'abandoned', hostId: nextHost })) return { ok: true }
        continue
      }
      if (isArena(room.game)) {
        if (await arenaForfeit(room, v.profile.id)) return { ok: true }
        continue
      }
      // Ludo mid-game: a bot takes the seat. In coin matches that seat forfeits any prize.
      const seats = room.seats.map((s, j) =>
        j === idx ? { ...s, userId: null, isBot: true, name: `${s.name} (left)`, forfeited: true, owner: s.owner ?? s.userId ?? undefined } : s,
      )
      const st = room.state as unknown as RoomState
      st.game.players[idx]!.isBot = true
      const ended = room.entryFee > 0 ? lastSideStanding(room, st, seats) : null
      if (ended) {
        if (await commit(room, ended)) return { ok: true }
        continue
      }
      const humans = seats.filter((s) => s.userId).length
      if (!humans && room.entryFee > 0) {
        await refundRoom(room.id, 'Every player left the match.')
        return { ok: true }
      }
      if (await saveRoom(room, { seats, status: humans ? 'playing' : 'abandoned', state: st as unknown as Record<string, unknown> })) return { ok: true }
    }
    throw new UserError('Could not leave the room, try again.')
  })
