import { createServerFn } from '@tanstack/react-start'
import { and, desc, eq, gte, ilike, or, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import { auditLogs, casinoBets, casinoDisputes, casinoRounds, transactions, users } from '../../db/schema.js'
import { avPayout, CASINO_INFO, dtSettle, DT_SIDES, mergeCasino, type CasinoKey, type DtSide } from '../lib/games/casino.js'
import { audit, notify } from './lib/audit.js'
import { requireAdmin, type Viewer } from './lib/auth.js'
import { getCasinoConfig, phaseOf, publicRound, saveCasinoConfig, settleDue } from './lib/casino.js'
import { UserError } from './lib/util.js'

/**
 * Admin console for Dragon Tiger and Aviator. Admins can configure limits,
 * published odds, fees and pauses, and can view everything — but there is
 * deliberately no function that sets, edits or re-rolls a round result.
 * Seeds of rounds that have not settled are never sent to the console.
 */

const actor = (v: Viewer) => ({ id: v.profile.id, email: v.profile.email })
const gameEnum = z.enum(['dragon_tiger', 'aviator'])

const commonSchema = {
  enabled: z.boolean(),
  paused: z.boolean(),
  pauseMessage: z.string().trim().max(200),
  minBet: z.number().int().min(1).max(1_000_000),
  maxBet: z.number().int().min(1).max(1_000_000),
  presets: z.array(z.number().int().min(1).max(1_000_000)).min(1).max(8),
  maxPayoutPerBet: z.number().int().min(1).max(100_000_000),
  maxRoundExposure: z.number().int().min(1).max(1_000_000_000),
}
const dtSchema = z
  .object({
    ...commonSchema,
    odds: z.object({ dragon: z.number().min(0.1).max(5), tiger: z.number().min(0.1).max(5), tie: z.number().min(1).max(15) }),
    tieRefundPercent: z.number().int().min(0).max(100),
    feePercent: z.number().int().min(0).max(20),
    bettingSeconds: z.number().int().min(8).max(60),
    revealSeconds: z.number().int().min(5).max(20),
  })
  .refine((g) => g.minBet <= g.maxBet, 'Minimum bet must not be above the maximum.')
const avSchema = z
  .object({
    ...commonSchema,
    houseEdgePercent: z.number().min(0).max(10),
    maxMultiplier: z.number().int().min(2).max(10000),
    bettingSeconds: z.number().int().min(5).max(30),
    pauseSeconds: z.number().int().min(2).max(15),
  })
  .refine((g) => g.minBet <= g.maxBet, 'Minimum bet must not be above the maximum.')

export const adminGetCasino = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  return getCasinoConfig()
})

export const adminSaveCasino = createServerFn({ method: 'POST' })
  .validator(z.discriminatedUnion('game', [z.object({ game: z.literal('dragon_tiger'), config: dtSchema }), z.object({ game: z.literal('aviator'), config: avSchema })]))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const before = await getCasinoConfig()
    const cfg = { ...data.config, presets: [...new Set(data.config.presets.filter((p) => p >= data.config.minBet && p <= data.config.maxBet))].sort((a, b) => a - b) }
    if (!cfg.presets.length) cfg.presets = [data.config.minBet]
    const next = mergeCasino({ ...before, [data.game]: cfg })
    await saveCasinoConfig(next, v.profile.id)
    const prev = before[data.game] as unknown as Record<string, unknown>
    const now = next[data.game] as unknown as Record<string, unknown>
    const changes = Object.fromEntries(Object.keys(now).filter((k) => JSON.stringify(prev[k]) !== JSON.stringify(now[k])).map((k) => [k, { from: prev[k], to: now[k] }]))
    await audit(actor(v), `Updated ${CASINO_INFO[data.game].name} settings`, { type: 'casino', id: data.game }, changes)
    return next
  })

/** KPIs, live round and liabilities for one game. */
export const adminCasinoOverview = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum }))
  .handler(async ({ data }) => {
    await requireAdmin()
    await settleDue(data.game)
    const game = data.game
    const stats = async (since: Date | null) => {
      const [r] = await db
        .select({
          bets: sql<number>`count(*)::int`,
          players: sql<number>`count(distinct ${casinoBets.userId})::int`,
          stake: sql<number>`coalesce(sum(${casinoBets.stake}),0)::bigint`,
          payout: sql<number>`coalesce(sum(${casinoBets.payout}),0)::bigint`,
          fees: sql<number>`coalesce(sum(${casinoBets.fee}),0)::bigint`,
          won: sql<number>`count(*) filter (where ${casinoBets.status} = 'won')::int`,
        })
        .from(casinoBets)
        .where(and(eq(casinoBets.game, game), sql`${casinoBets.status} not in ('cancelled','active')`, since ? gte(casinoBets.createdAt, since) : undefined))
      const stake = Number(r?.stake ?? 0)
      const payout = Number(r?.payout ?? 0)
      return { bets: r?.bets ?? 0, players: r?.players ?? 0, stake, payout, fees: Number(r?.fees ?? 0), won: r?.won ?? 0, net: stake - payout, rtp: stake ? Math.round((payout / stake) * 1000) / 10 : null }
    }
    const [today, week, all] = await Promise.all([stats(new Date(Date.now() - 864e5)), stats(new Date(Date.now() - 7 * 864e5)), stats(null)])
    const [rounds] = await db.select({ n: sql<number>`count(*)::int` }).from(casinoRounds).where(and(eq(casinoRounds.game, game), eq(casinoRounds.status, 'settled')))

    // Liabilities: every unsettled bet's stake and its maximum possible return.
    const open = await db
      .select({ roundId: casinoBets.roundId, choice: casinoBets.choice, stake: casinoBets.stake, terms: casinoBets.terms, autoX100: casinoBets.autoX100 })
      .from(casinoBets)
      .where(and(eq(casinoBets.game, game), eq(casinoBets.status, 'active')))
    const active = await db.select().from(casinoRounds).where(and(eq(casinoRounds.game, game), eq(casinoRounds.status, 'betting'))).orderBy(desc(casinoRounds.roundNo)).limit(5)
    let worst = 0
    for (const r of active) {
      const bs = open.filter((b) => b.roundId === r.id)
      if (game === 'dragon_tiger')
        worst += Math.max(0, ...DT_SIDES.map((w) => bs.reduce((s, b) => s + dtSettle(b.choice as DtSide, b.stake, b.terms as { oddsX100: number; tieRefundPercent: number; feePercent: number }, w).payout, 0)))
      else worst += bs.reduce((s, b) => s + avPayout(b.stake, b.autoX100 ?? r.params.maxX100!, Number(b.terms.maxPayout)), 0)
    }
    const [disputes] = await db.select({ n: sql<number>`count(*)::int` }).from(casinoDisputes).where(and(eq(casinoDisputes.game, game), eq(casinoDisputes.status, 'open')))
    const now = Date.now()
    return {
      today,
      week,
      all,
      rounds: rounds?.n ?? 0,
      openDisputes: disputes?.n ?? 0,
      liability: { openBets: open.length, openStake: open.reduce((s, b) => s + b.stake, 0), maxPayout: worst },
      active: active.map((r) => ({ ...publicRound(r, now), phase: phaseOf(r, now), openBets: open.filter((b) => b.roundId === r.id).length, openStake: open.filter((b) => b.roundId === r.id).reduce((s, b) => s + b.stake, 0) })),
    }
  })

export const adminCasinoRounds = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum, filter: z.enum(['active', 'completed']).default('completed'), q: z.string().trim().max(20).default('') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const rows = await db
      .select()
      .from(casinoRounds)
      .where(and(eq(casinoRounds.game, data.game), eq(casinoRounds.status, data.filter === 'active' ? 'betting' : 'settled'), data.q ? ilike(casinoRounds.id, `%${data.q}%`) : undefined))
      .orderBy(desc(casinoRounds.roundNo))
      .limit(60)
    const now = Date.now()
    return rows.map((r) => publicRound(r, now))
  })

export const adminCasinoBets = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum, status: z.enum(['all', 'active', 'won', 'lost', 'push', 'cancelled']).default('all'), q: z.string().trim().max(60).default('') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const q = data.q
    return db
      .select({
        id: casinoBets.id,
        roundId: casinoBets.roundId,
        choice: casinoBets.choice,
        stake: casinoBets.stake,
        status: casinoBets.status,
        autoX100: casinoBets.autoX100,
        cashoutX100: casinoBets.cashoutX100,
        payout: casinoBets.payout,
        fee: casinoBets.fee,
        terms: casinoBets.terms,
        createdAt: casinoBets.createdAt,
        settledAt: casinoBets.settledAt,
        userId: casinoBets.userId,
        name: users.displayName,
        publicId: users.publicId,
        email: users.email,
      })
      .from(casinoBets)
      .leftJoin(users, eq(users.id, casinoBets.userId))
      .where(
        and(
          eq(casinoBets.game, data.game),
          data.status !== 'all' ? eq(casinoBets.status, data.status) : undefined,
          q ? or(ilike(casinoBets.id, `%${q}%`), ilike(casinoBets.roundId, `%${q}%`), ilike(users.displayName, `%${q}%`), ilike(users.publicId, `%${q}%`), ilike(users.email, `%${q}%`)) : undefined,
        ),
      )
      .orderBy(desc(casinoBets.createdAt))
      .limit(100)
  })

/** Wallet ledger rows written by this game (bets, wins, refunds, loss records). */
export const adminCasinoLedger = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum, type: z.enum(['all', 'casino_bet', 'casino_win', 'casino_loss', 'casino_refund']).default('all') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    return db
      .select({ id: transactions.id, type: transactions.type, bucket: transactions.bucket, amount: transactions.amount, balanceAfter: transactions.balanceAfter, label: transactions.label, refId: transactions.refId, createdAt: transactions.createdAt, name: users.displayName, publicId: users.publicId })
      .from(transactions)
      .leftJoin(users, eq(users.id, transactions.userId))
      .where(and(eq(transactions.refType, data.game), data.type !== 'all' ? eq(transactions.type, data.type) : undefined))
      .orderBy(desc(transactions.createdAt))
      .limit(150)
  })

export const adminCasinoDisputes = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum, status: z.enum(['open', 'resolved', 'dismissed', 'all']).default('open') }))
  .handler(async ({ data }) => {
    await requireAdmin()
    return db
      .select({
        id: casinoDisputes.id,
        betId: casinoDisputes.betId,
        roundId: casinoDisputes.roundId,
        reason: casinoDisputes.reason,
        status: casinoDisputes.status,
        resolution: casinoDisputes.resolution,
        createdAt: casinoDisputes.createdAt,
        resolvedAt: casinoDisputes.resolvedAt,
        name: users.displayName,
        publicId: users.publicId,
        stake: casinoBets.stake,
        betStatus: casinoBets.status,
        payout: casinoBets.payout,
        choice: casinoBets.choice,
      })
      .from(casinoDisputes)
      .leftJoin(users, eq(users.id, casinoDisputes.userId))
      .leftJoin(casinoBets, eq(casinoBets.id, casinoDisputes.betId))
      .where(and(eq(casinoDisputes.game, data.game), data.status !== 'all' ? eq(casinoDisputes.status, data.status) : undefined))
      .orderBy(desc(casinoDisputes.createdAt))
      .limit(100)
  })

/**
 * Closes a dispute with a written answer to the player. It never changes the
 * round or the bet; any goodwill credit must go through Users → wallet
 * adjustment, which is separately audit-logged.
 */
export const adminResolveCasinoDispute = createServerFn({ method: 'POST' })
  .validator(z.object({ id: z.number().int(), status: z.enum(['resolved', 'dismissed']), resolution: z.string().trim().min(5).max(500) }))
  .handler(async ({ data }) => {
    const v = await requireAdmin()
    const [d] = await db
      .update(casinoDisputes)
      .set({ status: data.status, resolution: data.resolution, resolvedBy: v.profile.id, resolvedAt: new Date() })
      .where(and(eq(casinoDisputes.id, data.id), eq(casinoDisputes.status, 'open')))
      .returning()
    if (!d) throw new UserError('This dispute is already closed.')
    const name = CASINO_INFO[d.game as CasinoKey].name
    await audit(actor(v), `${data.status === 'resolved' ? 'Resolved' : 'Dismissed'} ${name} dispute`, { type: 'casino_bet', id: d.betId }, { roundId: d.roundId, resolution: data.resolution })
    await notify(d.userId, { kind: 'dispute', title: `${name} report ${data.status}`, body: data.resolution, link: d.game === 'aviator' ? '/app/aviator' : '/app/dragon-tiger' })
    return d
  })

/** Admin audit entries for this game (settings changes and dispute decisions). */
export const adminCasinoAudit = createServerFn({ method: 'GET' })
  .validator(z.object({ game: gameEnum }))
  .handler(async ({ data }) => {
    await requireAdmin()
    const name = CASINO_INFO[data.game].name
    const rows = await db
      .select()
      .from(auditLogs)
      .where(or(and(eq(auditLogs.targetType, 'casino'), eq(auditLogs.targetId, data.game)), ilike(auditLogs.action, `%${name}%`)))
      .orderBy(desc(auditLogs.createdAt))
      .limit(100)
    return rows.map((a) => ({ ...a, details: a.details ? JSON.stringify(a.details) : null }))
  })
