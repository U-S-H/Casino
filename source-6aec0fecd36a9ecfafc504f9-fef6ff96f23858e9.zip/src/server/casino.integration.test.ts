// @vitest-environment node
/**
 * Dragon Tiger + Aviator integration tests against a real Postgres.
 * Run with: LKA_IT_DB=postgres://… npx vitest run src/server/casino.integration.test.ts
 */
import { randomBytes } from 'node:crypto'
import { afterEach, beforeAll, describe, expect, it, vi } from 'vitest'

const url = process.env.LKA_IT_DB
if (url) {
  process.env.NETLIFY_DB_URL = url
  process.env.NETLIFY_DB_DRIVER = 'server'
}

describe.skipIf(!url)('Dragon Tiger & Aviator', () => {
  let db: typeof import('../../db/index.js')['db']
  let s: typeof import('../../db/schema.js')
  let ledger: typeof import('./lib/ledger.js')
  let cas: typeof import('./lib/casino.js')
  let eng: typeof import('../lib/games/casino.js')
  let util: typeof import('./lib/util.js')
  let orm: typeof import('drizzle-orm')
  const run = Date.now()
  let seq = 0
  const U = (n: string) => `cas-${n}-${run}`
  const key = () => `k-${run}-${++seq}-${randomBytes(4).toString('hex')}`

  beforeAll(async () => {
    db = (await import('../../db/index.js')).db
    s = await import('../../db/schema.js')
    ledger = await import('./lib/ledger.js')
    cas = await import('./lib/casino.js')
    eng = await import('../lib/games/casino.js')
    util = await import('./lib/util.js')
    orm = await import('drizzle-orm')
  })
  afterEach(() => vi.useRealTimers())

  async function user(n: string, coins: { bonus?: number; purchased?: number; winnings?: number }) {
    const id = U(n)
    await db.insert(s.users).values({ id, publicId: `LKA-${util.randomCode(6)}`, email: `${id}@x.test`, displayName: n, referralCode: util.randomCode(8) })
    await db.insert(s.wallets).values({ userId: id }).onConflictDoNothing()
    for (const [bucket, amount] of Object.entries(coins))
      if (amount) await db.transaction((tx) => ledger.postLedger(tx, { userId: id, bucket: bucket as 'bonus', amount, type: 'promo', label: 'seed', idempotencyKey: `seed:${id}:${bucket}` }))
    return id
  }
  const wallet = async (id: string) => {
    const [w] = await db.select().from(s.wallets).where(orm.eq(s.wallets.userId, id))
    return { ...w!, total: w!.bonus + w!.purchased + w!.winnings }
  }
  const txs = (id: string) => db.select().from(s.transactions).where(orm.and(orm.eq(s.transactions.userId, id), orm.sql`${s.transactions.type} like 'casino_%'`))
  const cfg = () => eng.mergeCasino({})

  /** Inserts a round with a seed chosen so the result satisfies `want`. Times are relative to now (ms). */
  async function round(game: 'dragon_tiger' | 'aviator', want: (seed: string, id: string) => boolean, t: { closes: number; result?: number }) {
    const no = Math.floor(Math.random() * 1e9)
    const id = `${game === 'aviator' ? 'AV' : 'DT'}-T${no}`
    let seed = ''
    for (let i = 0; i < 20000; i++) {
      seed = randomBytes(32).toString('hex')
      if (want(seed, id)) break
    }
    const now = Date.now()
    const params = game === 'aviator' ? { edgeBps: 300, maxX100: 10000 } : {}
    let resultAt = now + (t.result ?? t.closes)
    if (game === 'aviator') resultAt = now + t.closes + eng.avTimeTo(eng.avCrash(cas.hmacDigest(seed, id), 300, 10000))
    await db.insert(s.casinoRounds).values({
      id,
      game,
      roundNo: -no, // negative so test rounds never interfere with the live schedule
      serverSeed: seed,
      seedHash: util.sha256(seed),
      params,
      opensAt: new Date(now - 1000),
      closesAt: new Date(now + t.closes),
      resultAt: new Date(resultAt),
      endsAt: new Date(resultAt + 3000),
    })
    const [r] = await db.select().from(s.casinoRounds).where(orm.eq(s.casinoRounds.id, id))
    return r!
  }
  const dtWinner = (w: string) => (seed: string, id: string) => eng.dtDeal(cas.hmacDigest(seed, id)).winner === w
  const crashBetween = (lo: number, hi: number) => (seed: string, id: string) => {
    const c = eng.avCrash(cas.hmacDigest(seed, id), 300, 10000)
    return c >= lo && c <= hi
  }
  const at = (ms: number) => {
    vi.useFakeTimers({ toFake: ['Date'] })
    vi.setSystemTime(ms)
  }
  const bet = (uid: string, game: 'dragon_tiger' | 'aviator', roundId: string, choice: string, amount: number, extra: { autoX100?: number | null; clientKey?: string } = {}) =>
    cas.placeBet(uid, cfg(), { game, roundId, choice, amount, autoX100: extra.autoX100 ?? null, clientKey: extra.clientKey ?? key() })

  // ───────────── Dragon Tiger ─────────────

  it('Dragon Tiger: deducts once, pays 1:1 and 8:1 as stake + profit, records losses', async () => {
    const a = await user('dt-a', { bonus: 300, purchased: 5000 })
    const r = await round('dragon_tiger', dtWinner('dragon'), { closes: 5000 })
    const k = key()
    const b1 = await bet(a, 'dragon_tiger', r.id, 'dragon', 1000, { clientKey: k })
    // Same client key again (retry / double click): same bet, no second deduction.
    const b1again = await bet(a, 'dragon_tiger', r.id, 'dragon', 1000, { clientKey: k })
    expect(b1again.duplicate).toBe(true)
    expect(b1again.bet.id).toBe(b1.bet.id)
    expect(b1.bet.paid).toEqual({ bonus: 300, purchased: 700, winnings: 0 })
    await expect(bet(a, 'dragon_tiger', r.id, 'dragon', 500)).rejects.toThrow(/already have/)
    await bet(a, 'dragon_tiger', r.id, 'tie', 200)
    await bet(a, 'dragon_tiger', r.id, 'tiger', 300)
    expect((await wallet(a)).total).toBe(5300 - 1500)

    // Late bet refused; settlement is a no-op before the result time.
    at(r.closesAt.getTime() + 1)
    await expect(bet(a, 'dragon_tiger', r.id, 'tiger', 200)).rejects.toThrow(/closed/)
    const done = await cas.settleRound(r.id)
    expect(done?.status).toBe('settled')
    expect(await cas.settleRound(r.id)).toBeNull() // second settlement: nothing happens
    const w = await wallet(a)
    expect(w.winnings).toBe(2000) // dragon 1000 → 2000 total return
    expect(w.total).toBe(3800 + 2000)
    const t = await txs(a)
    expect(t.filter((x) => x.type === 'casino_bet').reduce((s2, x) => s2 + x.amount, 0)).toBe(-1500)
    expect(t.filter((x) => x.type === 'casino_win').map((x) => x.amount)).toEqual([2000])
    expect(t.filter((x) => x.type === 'casino_loss').length).toBe(2)
    expect(done!.totalStake).toBe(1500)
    expect(done!.totalPayout).toBe(2000)
  })

  it('Dragon Tiger: tie pays 8:1 and returns half of Dragon/Tiger stakes', async () => {
    const a = await user('dt-tie', { purchased: 3000 })
    const r = await round('dragon_tiger', dtWinner('tie'), { closes: 5000 })
    await bet(a, 'dragon_tiger', r.id, 'tie', 200)
    await bet(a, 'dragon_tiger', r.id, 'dragon', 1000)
    at(r.resultAt.getTime() + 1)
    await cas.settleRound(r.id)
    const bets = await db.select().from(s.casinoBets).where(orm.eq(s.casinoBets.roundId, r.id))
    expect(bets.find((b) => b.choice === 'tie')).toMatchObject({ status: 'won', payout: 1800 })
    expect(bets.find((b) => b.choice === 'dragon')).toMatchObject({ status: 'push', payout: 500 })
    expect((await wallet(a)).total).toBe(3000 - 1200 + 1800 + 500)
  })

  it('rejects bets over the balance and never goes negative', async () => {
    const a = await user('dt-poor', { bonus: 100, purchased: 900 })
    const r = await round('dragon_tiger', () => true, { closes: 5000 })
    await expect(bet(a, 'dragon_tiger', r.id, 'dragon', 1200)).rejects.toThrow(/Not enough coins/)
    await bet(a, 'dragon_tiger', r.id, 'dragon', 600)
    await expect(bet(a, 'dragon_tiger', r.id, 'tiger', 600)).rejects.toThrow(/Not enough coins/)
    expect(await wallet(a)).toMatchObject({ bonus: 0, purchased: 400, total: 400 })
  })

  // The local Netlify DB emulator shares one session across connections (no row locks or isolation),
  // so same-wallet races can only be checked against a real Postgres: set LKA_IT_REAL_PG=1.
  it.skipIf(!process.env.LKA_IT_REAL_PG)('parallel bets on one wallet: only what the balance covers is accepted', async () => {
    const a = await user('dt-race', { bonus: 100, purchased: 900 })
    const r = await round('dragon_tiger', () => true, { closes: 5000 })
    const res = await Promise.allSettled([bet(a, 'dragon_tiger', r.id, 'dragon', 600), bet(a, 'dragon_tiger', r.id, 'tiger', 600), bet(a, 'dragon_tiger', r.id, 'tie', 600)])
    expect(res.filter((x) => x.status === 'fulfilled').length).toBe(1)
    expect((await wallet(a)).total).toBe(400)
  })

  it('cancel while betting is open returns the exact buckets; not after close', async () => {
    const a = await user('dt-cancel', { bonus: 250, purchased: 1000, winnings: 400 })
    const r = await round('dragon_tiger', () => true, { closes: 5000 })
    const { bet: b } = await bet(a, 'dragon_tiger', r.id, 'dragon', 1500)
    expect(b.paid).toEqual({ bonus: 250, purchased: 1000, winnings: 250 })
    await cas.cancelBet(a, b.id)
    await expect(cas.cancelBet(a, b.id)).rejects.toThrow()
    expect(await wallet(a)).toMatchObject({ bonus: 250, purchased: 1000, winnings: 400 })
    // The slot is free again after cancelling.
    const { bet: b2 } = await bet(a, 'dragon_tiger', r.id, 'dragon', 500)
    at(r.closesAt.getTime() + 10)
    await expect(cas.cancelBet(a, b2.id)).rejects.toThrow(/closed/)
  })

  it('enforces max payout per bet and round exposure', async () => {
    const a = await user('dt-limit', { purchased: 200000 })
    const r = await round('dragon_tiger', () => true, { closes: 5000 })
    const c = cfg()
    c.dragon_tiger.maxRoundExposure = 19500
    await cas.placeBet(a, c, { game: 'dragon_tiger', roundId: r.id, choice: 'tie', amount: 2000, clientKey: key() }) // worst case (tie) 18000
    await expect(cas.placeBet(a, c, { game: 'dragon_tiger', roundId: r.id, choice: 'dragon', amount: 2000, clientKey: key() })).resolves.toBeTruthy() // tie: 18000 + 1000 half-refund
    await expect(cas.placeBet(a, c, { game: 'dragon_tiger', roundId: r.id, choice: 'tiger', amount: 2000, clientKey: key() })).rejects.toThrow(/betting limit/)
    c.dragon_tiger.maxPayoutPerBet = 5000
    const r2 = await round('dragon_tiger', () => true, { closes: 5000 })
    await expect(cas.placeBet(a, c, { game: 'dragon_tiger', roundId: r2.id, choice: 'tie', amount: 1000, clientKey: key() })).rejects.toThrow(/maximum payout/)
  })

  it('settled rounds and bets are immutable in the database; rounds cannot be deleted', async () => {
    const a = await user('dt-imm', { purchased: 1000 })
    const r = await round('dragon_tiger', () => true, { closes: 5000 })
    const { bet: b } = await bet(a, 'dragon_tiger', r.id, 'dragon', 500)
    await expect(db.update(s.casinoRounds).set({ serverSeed: 'x' }).where(orm.eq(s.casinoRounds.id, r.id))).rejects.toThrow()
    at(r.resultAt.getTime() + 1)
    await cas.settleRound(r.id)
    await expect(db.update(s.casinoRounds).set({ result: { winner: 'tiger' } }).where(orm.eq(s.casinoRounds.id, r.id))).rejects.toThrow()
    await expect(db.update(s.casinoBets).set({ payout: 999999 }).where(orm.eq(s.casinoBets.id, b.id))).rejects.toThrow()
    await expect(db.delete(s.casinoRounds).where(orm.eq(s.casinoRounds.id, r.id))).rejects.toThrow()
  })

  it('public view hides the seed and result until the reveal', async () => {
    const r = await round('dragon_tiger', () => true, { closes: 5000 })
    const v = cas.publicRound(r)
    expect(v.serverSeed).toBeNull()
    expect(v.dt).toBeNull()
    expect(v.seedHash).toBe(util.sha256(r.serverSeed))
    const ra = await round('aviator', crashBetween(150, 500), { closes: 2000 })
    const va = cas.publicRound(ra, ra.closesAt.getTime() + 100)
    expect(va.phase).toBe('flying')
    expect(va.crashX100).toBeNull()
    expect(va.resultAt).toBeNull()
    expect(va.endsAt).toBeNull()
  })

  // ───────────── Aviator ─────────────

  it('Aviator: manual cash-out uses the server time multiplier, pays once, refused after the crash', async () => {
    const a = await user('av-a', { purchased: 5000 })
    const r = await round('aviator', crashBetween(300, 800), { closes: 3000 })
    const { bet: b1 } = await bet(a, 'aviator', r.id, '1', 1000)
    const { bet: b2 } = await bet(a, 'aviator', r.id, '2', 500)
    await expect(bet(a, 'aviator', r.id, '1', 500)).rejects.toThrow(/slot/)
    await expect(cas.cashOut(a, b1.id)).rejects.toThrow(/not taken off/)
    const tFly = r.closesAt.getTime() + eng.avTimeTo(200) + 5 // ≈2.00x
    at(tFly)
    await expect(bet(a, 'aviator', r.id, '1', 500)).rejects.toThrow(/closed/)
    const x = eng.avMultAt(tFly - r.closesAt.getTime())
    const c1 = await cas.cashOut(a, b1.id)
    expect(c1.bet.cashoutX100).toBe(x)
    expect(c1.bet.payout).toBe(Math.floor((1000 * x) / 100))
    const again = await cas.cashOut(a, b1.id)
    expect(again.duplicate).toBe(true)
    // Slot 2 waits too long: the plane crashes first.
    at(r.resultAt.getTime())
    await expect(cas.cashOut(a, b2.id)).rejects.toThrow(/Too late/)
    at(r.resultAt.getTime() + 1000)
    await cas.settleRound(r.id)
    const w = await wallet(a)
    expect(w.total).toBe(5000 - 1500 + c1.bet.payout)
    const t = await txs(a)
    expect(t.filter((y) => y.type === 'casino_win').length).toBe(1)
    expect(t.filter((y) => y.type === 'casino_loss').length).toBe(1)
  })

  it('Aviator: auto cash-out pays at the target when reached, loses when the crash comes first', async () => {
    const a = await user('av-auto', { purchased: 5000 })
    const r = await round('aviator', crashBetween(250, 260), { closes: 3000 })
    const { bet: hit } = await bet(a, 'aviator', r.id, '1', 1000, { autoX100: 150 })
    const { bet: miss } = await bet(a, 'aviator', r.id, '2', 1000, { autoX100: 400 })
    // Live auto cash-out during flight (tick path).
    at(r.closesAt.getTime() + eng.avTimeTo(160))
    expect(await cas.processAutoCashouts(r)).toBe(1)
    // A manual cash-out after the target was passed is paid at the target, not higher.
    const dup = await cas.cashOut(a, hit.id)
    expect(dup.duplicate).toBe(true)
    at(r.resultAt.getTime() + 1000)
    await cas.settleRound(r.id)
    const bets = await db.select().from(s.casinoBets).where(orm.eq(s.casinoBets.roundId, r.id))
    expect(bets.find((b) => b.id === hit.id)).toMatchObject({ status: 'won', cashoutX100: 150, payout: 1500 })
    expect(bets.find((b) => b.id === miss.id)).toMatchObject({ status: 'lost', payout: 0 })
    expect((await wallet(a)).total).toBe(5000 - 2000 + 1500)
  })

  it('Aviator: auto cash-outs are paid at settlement even if nobody was online', async () => {
    const a = await user('av-off', { purchased: 2000 })
    const r = await round('aviator', crashBetween(300, 900), { closes: 2000 })
    await bet(a, 'aviator', r.id, '1', 1000, { autoX100: 200 })
    at(r.resultAt.getTime() + 5000)
    expect(await cas.settleDue('aviator')).toBeGreaterThanOrEqual(1)
    expect((await wallet(a)).total).toBe(2000 - 1000 + 2000)
  })

  it('Aviator: instant 1.00x crash loses every bet', async () => {
    const a = await user('av-inst', { purchased: 2000 })
    const r = await round('aviator', crashBetween(100, 100), { closes: 2000 })
    await bet(a, 'aviator', r.id, '1', 1000, { autoX100: 101 })
    at(r.closesAt.getTime() + 1)
    await expect(cas.cashOut(a, (await db.select().from(s.casinoBets).where(orm.eq(s.casinoBets.roundId, r.id)))[0]!.id)).rejects.toThrow(/Too late/)
    at(r.resultAt.getTime() + 1000)
    await cas.settleRound(r.id)
    expect((await wallet(a)).total).toBe(1000)
  })

  it('many players bet and cash out concurrently without conflicts', async () => {
    const ids = await Promise.all(Array.from({ length: 8 }, (_, i) => user(`av-c${i}`, { purchased: 3000 })))
    const r = await round('aviator', crashBetween(400, 2000), { closes: 3000 })
    const placed = await Promise.all(ids.map((id) => bet(id, 'aviator', r.id, '1', 1000)))
    at(r.closesAt.getTime() + eng.avTimeTo(250))
    const outs = await Promise.all(placed.map((p, i) => cas.cashOut(ids[i]!, p.bet.id)))
    // Double-tap from everyone at the same moment: no second payout.
    const again = await Promise.allSettled(placed.map((p, i) => cas.cashOut(ids[i]!, p.bet.id)))
    expect(again.every((x) => x.status === 'fulfilled' && x.value.duplicate)).toBe(true)
    at(r.resultAt.getTime() + 1000)
    await Promise.all([cas.settleRound(r.id), cas.settleRound(r.id), cas.settleDue('aviator')])
    for (const [i, id] of ids.entries()) {
      expect((await wallet(id)).total).toBe(3000 - 1000 + outs[i]!.bet.payout)
      expect((await txs(id)).filter((t) => t.type === 'casino_win').length).toBe(1)
    }
    const [done] = await db.select().from(s.casinoRounds).where(orm.eq(s.casinoRounds.id, r.id))
    expect(done!.status).toBe('settled')
    expect(done!.betCount).toBe(8)
  })

  it('tick opens a round with a committed seed and the schedule matches the crash point', async () => {
    const { round: r } = await cas.tick('aviator')
    expect(r).toBeTruthy()
    expect(r!.seedHash).toBe(util.sha256(r!.serverSeed))
    const crash = eng.avCrash(cas.hmacDigest(r!.serverSeed, r!.id), r!.params.edgeBps!, r!.params.maxX100!)
    expect(r!.resultAt.getTime() - r!.closesAt.getTime()).toBe(eng.avTimeTo(crash))
    const { round: d } = await cas.tick('dragon_tiger')
    expect(d!.id).toMatch(/^DT-\d{7}$/)
  })
})
