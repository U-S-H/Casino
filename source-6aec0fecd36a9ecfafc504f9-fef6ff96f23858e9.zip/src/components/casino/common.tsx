import { useRouter } from '@tanstack/react-router'
import { useCallback, useEffect, useRef, useState } from 'react'
import { CheckCircle2, Copy, Flag, Loader2, ShieldCheck, WifiOff, XCircle } from 'lucide-react'
import { toast } from 'sonner'

import { Coins } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { errMsg, fmtDate } from '@/lib/client'
import { avCrash, betError, card, dtDeal, fairDigests, fmtX, type CasinoKey } from '@/lib/games/casino'
import { cn } from '@/lib/utils'
import { getCasinoRound, getCasinoState, myCasinoBets, reportCasinoBet, type CasinoState } from '@/server/casino.functions'

/**
 * Polls the live game state. The interval adapts to the phase, failures keep
 * retrying with back-off (the "reconnecting" banner shows meanwhile), and the
 * server clock offset is estimated from each response so countdowns and the
 * Aviator multiplier follow the server's time, not the device clock.
 */
export function useCasino(game: CasinoKey, fastMs: number, slowMs: number) {
  const [state, setState] = useState<CasinoState | null>(null)
  const [offline, setOffline] = useState(false)
  const [skew, setSkew] = useState(0)
  const timer = useRef<number | undefined>(undefined)
  const fails = useRef(0)
  const alive = useRef(true)
  const stateRef = useRef<CasinoState | null>(null)

  const load = useCallback(async () => {
    const t0 = Date.now()
    try {
      const s = await getCasinoState({ data: { game } })
      const t1 = Date.now()
      if (!alive.current) return s
      setSkew(s.serverNow - (t0 + t1) / 2)
      stateRef.current = s
      setState(s)
      setOffline(false)
      fails.current = 0
      return s
    } catch {
      fails.current++
      if (fails.current >= 2) setOffline(true)
      return null
    }
  }, [game])

  useEffect(() => {
    alive.current = true
    const loop = async () => {
      if (document.visibilityState === 'visible') await load()
      if (!alive.current) return
      const s = stateRef.current
      const fast = s?.round && (s.round.phase === 'flying' || s.round.phase === 'betting' || (s.round.phase === 'result' && !s.round.settled))
      const wait = fails.current ? Math.min(8000, 1000 * 2 ** fails.current) : fast ? fastMs : slowMs
      timer.current = window.setTimeout(loop, wait)
    }
    void loop()
    return () => {
      alive.current = false
      clearTimeout(timer.current)
    }
  }, [load, fastMs, slowMs])

  return { state, setState, offline, skew, reload: load }
}

/** Server-synchronised clock that re-renders every `ms`. */
export function useNow(skew: number, ms = 100) {
  const [now, setNow] = useState(() => Date.now() + skew)
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now() + skew), ms)
    return () => clearInterval(id)
  }, [skew, ms])
  return now
}

/** Refreshes the header wallet (route context) after money moved. */
export function useWalletRefresh() {
  const router = useRouter()
  return useCallback(() => void router.invalidate(), [router])
}

export const newKey = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`)

export function OfflineBanner({ show }: { show: boolean }) {
  if (!show) return null
  return (
    <div className="flex items-center gap-2 rounded-xl bg-ludo-yellow/10 p-3 text-sm text-ludo-yellow ring-1 ring-ludo-yellow/30">
      <WifiOff className="size-4 shrink-0" /> Connection lost. Reconnecting… Bets you already placed are safe and settle on the server.
    </div>
  )
}

/** Amount selector: presets, custom input, ½ and 2× shortcuts. */
export function AmountPicker({
  cfg,
  value,
  onChange,
  balance,
  disabled,
  compact,
  id,
}: {
  cfg: CasinoState['config']
  value: number
  onChange: (v: number) => void
  balance: number
  disabled?: boolean
  compact?: boolean
  id: string
}) {
  const clamp = (v: number) => Math.max(cfg.minBet, Math.min(cfg.maxBet, Math.round(v)))
  const err = betError(cfg, value)
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Button type="button" variant="secondary" size="sm" disabled={disabled} onClick={() => onChange(clamp(value / 2))} aria-label="Half">
          ½
        </Button>
        <div className="relative flex-1">
          <span className="coin pointer-events-none absolute top-1/2 left-3 -translate-y-1/2" aria-hidden />
          <Input
            id={id}
            aria-label="Bet amount"
            inputMode="numeric"
            disabled={disabled}
            className="h-10 pl-9 text-center font-display text-lg font-extrabold tabular-nums"
            value={value || ''}
            onChange={(e) => onChange(Number(e.target.value.replace(/\D/g, '').slice(0, 7)) || 0)}
          />
        </div>
        <Button type="button" variant="secondary" size="sm" disabled={disabled} onClick={() => onChange(clamp(value * 2))} aria-label="Double">
          2×
        </Button>
      </div>
      <div className={cn('grid gap-1.5', compact ? 'grid-cols-3' : 'grid-cols-3 sm:grid-cols-6')}>
        {cfg.presets.map((p) => (
          <button
            key={p}
            type="button"
            disabled={disabled}
            onClick={() => onChange(p)}
            className={cn(
              'rounded-lg py-1.5 text-xs font-bold tabular-nums ring-1 ring-white/10 transition hover:bg-white/10 disabled:opacity-50',
              value === p && 'bg-primary/15 text-primary ring-primary',
              p > balance && 'opacity-50',
            )}
          >
            {p >= 1000 ? `${p / 1000}K` : p}
          </button>
        ))}
      </div>
      <p className={cn('text-[11px]', err && value ? 'font-semibold text-ludo-red' : value > balance ? 'font-semibold text-ludo-red' : 'text-muted-foreground')}>
        {err && value ? err : value > balance ? 'Not enough coins in your wallet.' : `Min ${cfg.minBet.toLocaleString()} · Max ${cfg.maxBet.toLocaleString()} coins`}
      </p>
    </div>
  )
}

export function Countdown({ ms, total, label, tone = 'primary' }: { ms: number; total: number; label: string; tone?: 'primary' | 'red' }) {
  const pct = Math.max(0, Math.min(1, ms / total))
  const r = 22
  const c = 2 * Math.PI * r
  return (
    <div className="flex items-center gap-2" role="timer" aria-label={`${label}: ${Math.ceil(ms / 1000)} seconds`}>
      <svg viewBox="0 0 52 52" className="size-12 -rotate-90">
        <circle cx="26" cy="26" r={r} fill="none" stroke="currentColor" strokeOpacity=".12" strokeWidth="5" />
        <circle
          cx="26"
          cy="26"
          r={r}
          fill="none"
          stroke={tone === 'red' || pct < 0.25 ? 'var(--ludo-red)' : 'var(--primary)'}
          strokeWidth="5"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - pct)}
          style={{ transition: 'stroke-dashoffset 0.1s linear' }}
        />
        <text x="26" y="31" textAnchor="middle" className="rotate-90 fill-foreground font-display text-[15px] font-extrabold" transform="rotate(90 26 26)">
          {Math.ceil(ms / 1000)}
        </text>
      </svg>
      <div className="text-xs leading-tight">
        <div className="font-bold">{label}</div>
        <div className="text-muted-foreground">{Math.max(0, ms / 1000).toFixed(1)}s</div>
      </div>
    </div>
  )
}

export function RoundTag({ id, hash }: { id?: string; hash?: string }) {
  return (
    <div className="flex min-w-0 flex-col text-xs">
      <span className="font-mono font-bold">Round {id ?? '—'}</span>
      {hash && (
        <button
          type="button"
          className="flex min-w-0 items-center gap-1 text-left font-mono text-[10px] text-muted-foreground hover:text-foreground"
          title="SHA-256 of this round's server seed, published before betting. Click to copy."
          onClick={() => void navigator.clipboard?.writeText(hash).then(() => toast.success('Seed hash copied'))}
        >
          <ShieldCheck className="size-3 shrink-0 text-ludo-green" /> <span className="truncate">hash {hash.slice(0, 16)}…</span>
          <Copy className="size-3 shrink-0" />
        </button>
      )}
    </div>
  )
}

const STATUS_TONE: Record<string, string> = {
  won: 'text-ludo-green',
  lost: 'text-ludo-red',
  push: 'text-ludo-yellow',
  active: 'text-primary',
  cancelled: 'text-muted-foreground',
}

/** The player's bet history for this game, with dispute reporting. */
export function MyBets({ game, version }: { game: CasinoKey; version: number }) {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof myCasinoBets>> | null>(null)
  const [report, setReport] = useState<string | null>(null)
  useEffect(() => {
    let on = true
    void myCasinoBets({ data: { game } })
      .then((r) => on && setRows(r))
      .catch(() => undefined)
    return () => {
      on = false
    }
  }, [game, version])
  if (!rows) return <p className="py-4 text-center text-sm text-muted-foreground">Loading…</p>
  if (!rows.length) return <p className="py-4 text-center text-sm text-muted-foreground">No bets yet. Your bets and results appear here.</p>
  return (
    <>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-[11px] text-muted-foreground uppercase">
            <tr>
              <th className="py-2 pr-3">Round</th>
              <th className="pr-3">Bet</th>
              <th className="pr-3 text-right">Stake</th>
              <th className="pr-3">Result</th>
              <th className="pr-3 text-right">Return</th>
              <th />
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((b) => (
              <tr key={b.id}>
                <td className="py-2 pr-3 font-mono text-xs">
                  {b.roundId}
                  <div className="text-[10px] text-muted-foreground">{fmtDate(b.createdAt)}</div>
                </td>
                <td className="pr-3 capitalize">
                  {game === 'aviator' ? `Slot ${b.choice}${b.autoX100 && b.terms.userAutoX100 ? ` · auto ${fmtX(b.autoX100)}` : ''}` : b.choice}
                </td>
                <td className="pr-3 text-right tabular-nums">{b.stake.toLocaleString()}</td>
                <td className={cn('pr-3 font-semibold capitalize', STATUS_TONE[b.status])}>
                  {b.status === 'push' ? 'Tie (partial refund)' : b.status === 'active' ? 'Open' : b.status}
                  {b.cashoutX100 ? ` @ ${fmtX(b.cashoutX100)}` : ''}
                </td>
                <td className="pr-3 text-right font-bold tabular-nums">{b.payout ? `+${b.payout.toLocaleString()}` : '0'}</td>
                <td className="text-right">
                  {b.dispute ? (
                    <span className="text-[11px] text-muted-foreground capitalize" title={b.dispute.resolution ?? ''}>
                      {b.dispute.status}
                    </span>
                  ) : (
                    <button type="button" className="text-muted-foreground hover:text-foreground" title="Report a problem with this bet" onClick={() => setReport(b.id)}>
                      <Flag className="size-3.5" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ReportDialog betId={report} onClose={() => setReport(null)} onDone={() => setRows((r) => r?.map((x) => (x.id === report ? { ...x, dispute: { betId: x.id, status: 'open', resolution: null } } : x)) ?? r)} />
    </>
  )
}

function ReportDialog({ betId, onClose, onDone }: { betId: string | null; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState('')
  const [busy, setBusy] = useState(false)
  return (
    <Dialog open={!!betId} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Report bet {betId}</DialogTitle>
          <DialogDescription>Tell us what went wrong. An admin reviews every report and answers in your notifications.</DialogDescription>
        </DialogHeader>
        <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. I pressed cash out at 2.1x but it shows lost" maxLength={500} />
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            disabled={busy || reason.trim().length < 10}
            onClick={async () => {
              setBusy(true)
              try {
                await reportCasinoBet({ data: { betId: betId!, reason } })
                toast.success('Report sent')
                onDone()
                setReason('')
                onClose()
              } catch (e) {
                toast.error(errMsg(e))
              } finally {
                setBusy(false)
              }
            }}
          >
            Send report
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

/** Browser-side provably-fair verifier: recomputes hash and result from a revealed seed. */
export function VerifyDialog({ open, onOpenChange, game, initialId }: { open: boolean; onOpenChange: (o: boolean) => void; game: CasinoKey; initialId?: string }) {
  const [id, setId] = useState(initialId ?? '')
  const [busy, setBusy] = useState(false)
  const [out, setOut] = useState<null | { id: string; seed: string; hash: string; hashOk: boolean; digest: string; stored: string; computed: string; ok: boolean }>(null)
  const [err, setErr] = useState<string | null>(null)
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- prefill when opened from a history chip
    if (open && initialId) setId(initialId)
  }, [open, initialId])

  const verify = async () => {
    setBusy(true)
    setErr(null)
    setOut(null)
    try {
      const r = await getCasinoRound({ data: { id } })
      if (!r.settled || !r.serverSeed) throw new Error('This round has not settled yet. Its seed is revealed after the result.')
      const { seedHash, digest } = await fairDigests(r.serverSeed, r.id)
      let stored = ''
      let computed = ''
      if (r.game === 'dragon_tiger' && r.dt) {
        const d = dtDeal(digest)
        const show = (x: { dragon: number; tiger: number; winner: string }) => `Dragon ${card(x.dragon).rank}${card(x.dragon).suit} · Tiger ${card(x.tiger).rank}${card(x.tiger).suit} → ${x.winner}`
        stored = show(r.dt)
        computed = show(d)
      } else if (r.crashX100 != null) {
        stored = fmtX(r.crashX100)
        computed = fmtX(avCrash(digest, r.params.edgeBps!, r.params.maxX100!))
      }
      setOut({ id: r.id, seed: r.serverSeed, hash: r.seedHash, hashOk: seedHash === r.seedHash, digest, stored, computed, ok: stored === computed })
    } catch (e) {
      setErr(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="size-5 text-ludo-green" /> Verify a round
          </DialogTitle>
          <DialogDescription>
            Your browser recomputes the result itself from the revealed server seed, using the formula below. Nothing is taken on trust.
          </DialogDescription>
        </DialogHeader>
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault()
            void verify()
          }}
        >
          <Input value={id} onChange={(e) => setId(e.target.value.toUpperCase())} placeholder={game === 'aviator' ? 'AV-0000123' : 'DT-0000123'} className="font-mono" />
          <Button type="submit" disabled={busy || id.length < 4}>
            {busy ? <Loader2 className="animate-spin" /> : 'Verify'}
          </Button>
        </form>
        {err && <p className="text-sm font-semibold text-ludo-red">{err}</p>}
        {out && (
          <div className="space-y-2 text-xs">
            <Row label="Server seed (revealed)" value={out.seed} />
            <Row label="Published hash" value={out.hash} />
            <Check ok={out.hashOk} text={out.hashOk ? 'SHA-256(seed) matches the hash published before betting' : 'Hash does NOT match'} />
            <Row label={`HMAC-SHA256(seed, "${out.id}")`} value={out.digest} />
            <Row label="Recorded result" value={out.stored} />
            <Row label="Recomputed in your browser" value={out.computed} />
            <Check ok={out.ok} text={out.ok ? 'Result matches' : 'Result does NOT match'} />
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-semibold text-muted-foreground">{label}</div>
      <div className="font-mono break-all">{value}</div>
    </div>
  )
}
function Check({ ok, text }: { ok: boolean; text: string }) {
  return (
    <div className={cn('flex items-center gap-1.5 font-bold', ok ? 'text-ludo-green' : 'text-ludo-red')}>
      {ok ? <CheckCircle2 className="size-4" /> : <XCircle className="size-4" />} {text}
    </div>
  )
}

export function BalancePill({ value }: { value: number }) {
  return (
    <div className="glass flex items-center gap-2 rounded-xl px-3 py-2 text-xs">
      <span className="text-muted-foreground">Wallet</span>
      <Coins value={value} className="text-sm text-primary" />
    </div>
  )
}
