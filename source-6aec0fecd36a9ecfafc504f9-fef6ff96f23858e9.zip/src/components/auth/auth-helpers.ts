import { AuthError, MissingIdentityError, getSettings, logout, oauthLogin } from '@netlify/identity'
import { toast } from 'sonner'

import { errMsg } from '@/lib/client'
import { getSession } from '@/server/account.functions'

export function authErrorMessage(e: unknown) {
  if (e instanceof MissingIdentityError) return 'Sign-in is not available right now. Please try again shortly.'
  if (e instanceof AuthError) {
    if (e.status === 401 || e.status === 400) {
      if (/confirm/i.test(e.message)) return 'Please confirm your email first — check your inbox for the verification link.'
      return 'Invalid email or password.'
    }
    if (e.status === 403) return 'Sign-ups are currently closed.'
    if (e.status === 422) return e.message || 'Please check your details.'
    if (e.status === 429) return 'Too many attempts. Please wait a minute and try again.'
    return e.message
  }
  return errMsg(e)
}

export async function google() {
  try {
    const settings = await getSettings().catch(() => null)
    if (settings && !settings.providers.google) {
      toast.error('Google sign-in is not enabled yet. Please log in with email for now.')
      return
    }
    // Full-page redirect (no popup), so it also works in Android/iOS mobile browsers.
    oauthLogin('google')
  } catch (e) {
    toast.error(authErrorMessage(e))
  }
}

/**
 * Sends a freshly signed-in user to the right dashboard: administrators go to
 * /admin, everyone else to /app. The admin flag is decided by the server.
 */
export async function goToDashboard() {
  sessionStorage.removeItem('lka_login_recorded')
  let dest = '/app'
  try {
    const s = await getSession()
    if (s.me?.isAdmin) dest = '/admin'
  } catch {
    /* fall back to the player area */
  }
  window.location.href = dest
}

export async function signOut() {
  try {
    await logout()
  } finally {
    sessionStorage.removeItem('lka_login_recorded')
    window.location.href = '/'
  }
}
