import { handleAuthCallback, updateUser } from '@netlify/identity'
import { useEffect, useState } from 'react'
import { toast } from 'sonner'

import { goToDashboard } from '@/components/auth/auth-helpers'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { errMsg, setReferralCookie } from '@/lib/client'
import { markPasswordChanged } from '@/server/account.functions'

const TOKENS = ['confirmation_token', 'recovery_token', 'invite_token', 'email_change_token', 'access_token', 'error']

/**
 * Processes Netlify Identity redirects (email confirmation, OAuth, password
 * recovery, invites) on any page, and stores `?ref=` referral codes.
 */
export function AuthCallback() {
  const [mode, setMode] = useState<null | 'recovery' | 'invite'>(null)
  const [inviteToken, setInviteToken] = useState<string | null>(null)
  const [pending, setPending] = useState(false)

  useEffect(() => {
    const ref = new URLSearchParams(window.location.search).get('ref')
    if (ref) setReferralCookie(ref)

    const hash = new URLSearchParams(window.location.hash.slice(1))
    if (!TOKENS.some((t) => hash.has(t))) return
    if (hash.has('error')) {
      toast.error(hash.get('error_description') ?? 'Sign-in failed.')
      history.replaceState(null, '', window.location.pathname + window.location.search)
      return
    }
    void (async () => {
      try {
        const r = await handleAuthCallback()
        history.replaceState(null, '', window.location.pathname + window.location.search)
        if (!r) return
        if (r.type === 'recovery') return setMode('recovery')
        if (r.type === 'invite') {
          setInviteToken(r.token ?? null)
          return setMode('invite')
        }
        if (r.type === 'confirmation') toast.success('Email verified! Welcome to the arena.')
        if (r.type === 'email_change') toast.success('Email address updated.')
        if (r.type === 'oauth' || r.type === 'confirmation') await goToDashboard()
      } catch (e) {
        toast.error(errMsg(e))
      }
    })()
  }, [])

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const pw = String(fd.get('password'))
    if (pw !== String(fd.get('confirm'))) return toast.error('Passwords do not match.')
    setPending(true)
    try {
      if (mode === 'invite' && inviteToken) {
        const { acceptInvite } = await import('@netlify/identity')
        await acceptInvite(inviteToken, pw)
      } else {
        await updateUser({ password: pw })
      }
      await markPasswordChanged().catch(() => undefined)
      toast.success('Password saved. You are signed in.')
      window.location.href = '/app'
    } catch (err) {
      toast.error(errMsg(err))
    } finally {
      setPending(false)
    }
  }

  return (
    <Dialog open={mode !== null} onOpenChange={() => undefined}>
      <DialogContent onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>{mode === 'invite' ? 'Set your password' : 'Choose a new password'}</DialogTitle>
          <DialogDescription>Use at least 8 characters. You will stay signed in after saving.</DialogDescription>
        </DialogHeader>
        <form className="space-y-3" onSubmit={submit}>
          <Input name="password" type="password" required minLength={8} placeholder="New password" className="h-11" autoComplete="new-password" />
          <Input name="confirm" type="password" required minLength={8} placeholder="Confirm password" className="h-11" autoComplete="new-password" />
          <Button type="submit" disabled={pending} className="h-11 w-full rounded-xl font-bold">
            {pending ? 'Saving…' : 'Save password'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
