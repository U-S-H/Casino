import { useMemo, useState } from 'react'

import {
  inCheck,
  legalMoves,
  pieceSeat,
  squareIndex,
  squareName,
  type ChessAction,
  type ChessMove,
  type ChessState,
  type Promotion,
} from '@/lib/games/chess'
import type { BoardProps } from '@/lib/games/types'
import { cn } from '@/lib/utils'

/** Solid glyphs for both sides (coloured via CSS); U+FE0E forces text presentation on iOS. */
const GLYPH: Record<string, string> = {
  k: '♚︎',
  q: '♛︎',
  r: '♜︎',
  b: '♝︎',
  n: '♞︎',
  p: '♟︎',
}
const VALUE: Record<string, number> = { q: 9, r: 5, b: 3, n: 3, p: 1, k: 0 }
const PROMO_ORDER: Promotion[] = ['q', 'r', 'b', 'n']

const LIGHT = 'oklch(0.86 0.07 78)'
const DARK = 'oklch(0.58 0.09 60)'

function Piece({ p, className }: { p: string; className?: string }) {
  const white = pieceSeat(p) === 0
  return (
    <span
      aria-hidden
      className={cn('pointer-events-none select-none leading-none', className)}
      style={{
        color: white ? 'oklch(0.97 0.02 85)' : 'oklch(0.2 0.03 285)',
        textShadow: white
          ? '0 0 1px oklch(0.25 0.04 60), 0 1px 0 oklch(0.25 0.04 60), 0 -1px 0 oklch(0.25 0.04 60), 1px 0 0 oklch(0.25 0.04 60), -1px 0 0 oklch(0.25 0.04 60), 0 3px 6px oklch(0 0 0 / 0.45)'
          : '0 0 1px oklch(0.9 0.05 85 / 0.8), 0 1px 0 oklch(0.9 0.05 85 / 0.55), 0 3px 6px oklch(0 0 0 / 0.5)',
      }}
    >
      {GLYPH[p.toLowerCase()]}
    </span>
  )
}

function Captured({ pieces, lead }: { pieces: string[]; lead: number }) {
  const sorted = [...pieces].sort(
    (a, b) => VALUE[b.toLowerCase()] - VALUE[a.toLowerCase()],
  )
  return (
    <div className="flex min-h-5 flex-wrap items-center gap-x-px text-base sm:text-lg">
      {sorted.map((p, i) => (
        <Piece key={i} p={p} className="-mr-1 text-[1.05em] opacity-90" />
      ))}
      {lead > 0 && (
        <span className="ml-1.5 text-xs font-semibold text-muted-foreground">
          +{lead}
        </span>
      )}
    </div>
  )
}

export function ChessBoard({
  state,
  mySeat,
  canAct,
  onAction,
  names,
}: BoardProps<ChessState, ChessAction>) {
  // Selection is tagged with the state counter so any new server state (or losing
  // the right to act) silently invalidates it without an effect.
  const [selRaw, setSelRaw] = useState<{ sq: string; n: number } | null>(null)
  const [pendRaw, setPendRaw] = useState<{
    from: string
    to: string
    n: number
  } | null>(null)
  const sel = canAct && selRaw?.n === state.n ? selRaw.sq : null
  const pending = canAct && pendRaw?.n === state.n ? pendRaw : null
  const setSel = (sq: string | null) =>
    setSelRaw(sq ? { sq, n: state.n } : null)
  const setPending = (p: { from: string; to: string } | null) =>
    setPendRaw(p ? { ...p, n: state.n } : null)

  const flipped = mySeat === 1
  const over = !!state.result
  const targets = useMemo<ChessMove[]>(
    () => (sel ? legalMoves(state, sel) : []),
    [state, sel],
  )
  const checkSq = useMemo(() => {
    if (!inCheck(state)) return null
    const i = state.board.indexOf(state.turn === 0 ? 'K' : 'k')
    return i >= 0 ? squareName(i) : null
  }, [state])

  const material = (seat: number) =>
    state.captured[seat].reduce((sum, p) => sum + VALUE[p.toLowerCase()], 0)
  const lead = material(0) - material(1)

  const mine = (sq: string) => {
    const p = state.board[squareIndex(sq)]
    return p !== '' && pieceSeat(p) === mySeat && state.turn === mySeat
  }

  const tap = (sq: string) => {
    if (!canAct || over || pending) return
    const move = targets.find((m) => m.to === sq)
    if (sel && move) {
      if (move.promotion) setPending({ from: sel, to: sq })
      else onAction({ type: 'move', from: sel, to: sq })
      setSel(null)
      return
    }
    if (mine(sq) && sq !== sel) setSel(sq)
    else setSel(null)
  }

  const promote = (promotion: Promotion) => {
    if (!pending) return
    onAction({ type: 'move', from: pending.from, to: pending.to, promotion })
    setPending(null)
  }

  const topSeat = flipped ? 0 : 1
  const bottomSeat = 1 - topSeat

  const strip = (seat: number) => {
    const toMove = !over && state.turn === seat
    return (
      <div className="flex items-center gap-2.5 px-1">
        <span
          className={cn(
            'size-3.5 shrink-0 rounded-full ring-1 ring-black/40',
            seat === 0
              ? 'bg-[oklch(0.96_0.02_85)]'
              : 'bg-[oklch(0.2_0.03_285)] ring-white/30',
            toMove &&
              'ring-2 ring-primary ring-offset-2 ring-offset-background',
          )}
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span
              className={cn(
                'truncate text-sm font-semibold',
                toMove ? 'text-foreground' : 'text-muted-foreground',
              )}
            >
              {names[seat]}
            </span>
            {seat === mySeat && (
              <span className="text-[10px] uppercase tracking-wider text-primary">
                You
              </span>
            )}
            {toMove && (
              <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary">
                {checkSq ? 'Check' : 'To move'}
              </span>
            )}
          </div>
          <Captured
            pieces={state.captured[seat]}
            lead={seat === 0 ? lead : -lead}
          />
        </div>
      </div>
    )
  }

  // Pair SAN moves into "1. e4 e5" rows, counting back from the current move number.
  const rows: { no: number; w?: string; b?: string }[] = []
  {
    const lastSeat = 1 - state.turn
    const lastAbs =
      (lastSeat === 1 ? state.fullmove - 1 : state.fullmove) * 2 + lastSeat
    state.moves.forEach((san, i) => {
      const abs = lastAbs - (state.moves.length - 1 - i)
      const no = Math.floor(abs / 2)
      const row =
        rows.at(-1)?.no === no
          ? rows.at(-1)!
          : (rows.push({ no }), rows.at(-1)!)
      if (abs % 2 === 0) row.w = san
      else row.b = san
    })
  }
  const recent = rows.slice(-8)

  return (
    <div className="mx-auto flex w-full max-w-[min(100%,80vh)] flex-col gap-2.5">
      {strip(topSeat)}

      <div
        className="relative rounded-xl p-1.5 shadow-[0_20px_60px_-20px_oklch(0_0_0/0.7)] sm:p-2"
        style={{
          background:
            'linear-gradient(145deg, oklch(0.5 0.1 70), oklch(0.32 0.07 55) 55%, oklch(0.45 0.09 65))',
        }}
      >
        <div className="relative grid aspect-square w-full grid-cols-8 grid-rows-8 overflow-hidden rounded-md ring-1 ring-black/40">
          {Array.from({ length: 64 }, (_, k) => {
            const dr = k >> 3
            const dc = k % 8
            const rank = flipped ? dr : 7 - dr
            const file = flipped ? 7 - dc : dc
            const idx = rank * 8 + file
            const sq = squareName(idx)
            const p = state.board[idx]
            const light = (rank + file) % 2 === 1
            const isSel = sel === sq
            const isLast =
              state.lastMove &&
              (state.lastMove.from === sq || state.lastMove.to === sq)
            const target = targets.find((m) => m.to === sq)
            const selectable = canAct && !over && mine(sq)
            return (
              <button
                key={sq}
                type="button"
                aria-label={`${sq}${p ? ` ${p}` : ''}`}
                onClick={() => tap(sq)}
                disabled={!canAct || over}
                className={cn(
                  'relative flex items-center justify-center outline-none disabled:cursor-default',
                  (selectable || target) && 'cursor-pointer',
                )}
                style={{ background: light ? LIGHT : DARK }}
              >
                {isLast && (
                  <span className="absolute inset-0 bg-[oklch(0.85_0.17_90/0.42)]" />
                )}
                {isSel && (
                  <span className="absolute inset-0 bg-[oklch(0.83_0.16_82/0.65)]" />
                )}
                {checkSq === sq && (
                  <span className="absolute inset-0 bg-[radial-gradient(circle,oklch(0.63_0.24_25/0.95)_0%,oklch(0.63_0.24_25/0.55)_45%,transparent_75%)]" />
                )}
                {dc === 0 && (
                  <span
                    className="absolute left-0.5 top-0.5 text-[9px] font-bold leading-none sm:text-[11px]"
                    style={{ color: light ? DARK : LIGHT }}
                  >
                    {rank + 1}
                  </span>
                )}
                {dr === 7 && (
                  <span
                    className="absolute bottom-0.5 right-1 text-[9px] font-bold leading-none sm:text-[11px]"
                    style={{ color: light ? DARK : LIGHT }}
                  >
                    {'abcdefgh'[file]}
                  </span>
                )}
                {p && (
                  <Piece
                    p={p}
                    className={cn(
                      'relative text-[min(9.5vw,7.4vh)] transition-transform duration-150 sm:text-[min(4.6rem,8vw,7.4vh)]',
                      isSel && '-translate-y-0.5 scale-110',
                    )}
                  />
                )}
                {target &&
                  (p || target.enPassant ? (
                    <span className="pointer-events-none absolute inset-[6%] rounded-full ring-[3px] ring-[oklch(0.25_0.05_285/0.55)] sm:ring-4" />
                  ) : (
                    <span className="pointer-events-none absolute size-[28%] rounded-full bg-[oklch(0.25_0.05_285/0.45)]" />
                  ))}
              </button>
            )
          })}
        </div>

        {pending && (
          <div
            className="absolute inset-0 z-10 flex items-center justify-center rounded-xl bg-black/55 backdrop-blur-[2px]"
            onClick={() => setPending(null)}
          >
            <div
              className="glass rounded-2xl p-3 text-center shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <p className="mb-2 font-display text-sm font-semibold">
                Promote to
              </p>
              <div className="flex gap-2">
                {PROMO_ORDER.map((t) => {
                  const p = mySeat === 0 ? t.toUpperCase() : t
                  return (
                    <button
                      key={t}
                      type="button"
                      onClick={() => promote(t)}
                      aria-label={`Promote to ${{ q: 'queen', r: 'rook', b: 'bishop', n: 'knight' }[t]}`}
                      className="flex size-14 items-center justify-center rounded-xl border border-primary/30 transition hover:scale-105 hover:border-primary sm:size-16"
                      style={{ background: LIGHT }}
                    >
                      <Piece p={p} className="text-4xl sm:text-5xl" />
                    </button>
                  )
                })}
              </div>
              <button
                type="button"
                onClick={() => setPending(null)}
                className="mt-2 text-xs text-muted-foreground hover:text-foreground"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {strip(bottomSeat)}

      <div className="glass flex items-center gap-3 rounded-xl px-3 py-2 text-sm">
        {state.result ? (
          <span className="shrink-0 font-semibold text-primary">
            {state.result.winner === null
              ? 'Draw'
              : `${names[state.result.winner]} wins`}{' '}
            · {state.result.reason}
          </span>
        ) : (
          <span className="shrink-0 text-xs uppercase tracking-wider text-muted-foreground">
            Moves
          </span>
        )}
        <div className="flex min-w-0 flex-1 gap-3 overflow-x-auto whitespace-nowrap font-mono text-xs [scrollbar-width:none]">
          {recent.length === 0 && !state.result && (
            <span className="text-muted-foreground">No moves yet</span>
          )}
          {recent.map((r, i) => (
            <span
              key={r.no}
              className={cn(
                i === recent.length - 1
                  ? 'text-foreground'
                  : 'text-muted-foreground',
              )}
            >
              <span className="opacity-60">{r.no}.</span> {r.w ?? '…'}{' '}
              {r.b ?? ''}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
