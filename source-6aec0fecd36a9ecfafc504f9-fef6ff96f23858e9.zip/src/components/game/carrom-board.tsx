import { useEffect, useMemo, useRef, useState } from 'react'
import { Crosshair, Crown, Target, Zap } from 'lucide-react'

import { Button } from '@/components/ui/button'
import {
  BASE_INNER,
  BASE_LEN,
  BASE_MAX,
  BASE_MIN,
  BASE_OFFSET,
  BASE_OUTER,
  BOARD,
  CENTER,
  CENTER_CIRCLE_R,
  COIN_R,
  FRAME,
  POCKETS,
  POCKET_R,
  SIM_FRAME_SECONDS,
  STRIKER_R,
  isForward,
  simulate,
  strikerPlacementError,
  strikerPos,
} from '@/lib/games/carrom'
import type { CarromAction, CarromState, Coin, CoinKind, LastStrike, SimFrame } from '@/lib/games/carrom'
import type { BoardProps } from '@/lib/games/types'
import { cn } from '@/lib/utils'

const TOTAL = BOARD + 2 * FRAME
const LOCK_MS = 5000

type PieceKind = CoinKind | 's'
interface Piece {
  k: PieceKind
  x: number
  y: number
}
interface Scene {
  pieces: Piece[]
  striker: { x: number; y: number; bad: boolean; ghost: boolean } | null
  aim: { dx: number; dy: number; power: number } | null
}

// ---------------------------------------------------------------- drawing
function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

/** Static board, drawn in board units (playing surface 0..BOARD). */
function drawBoard(ctx: CanvasRenderingContext2D) {
  // frame
  const fg = ctx.createLinearGradient(-FRAME, -FRAME, BOARD + FRAME, BOARD + FRAME)
  fg.addColorStop(0, '#6b3416')
  fg.addColorStop(0.5, '#4a230d')
  fg.addColorStop(1, '#2f1607')
  roundRect(ctx, -FRAME, -FRAME, BOARD + 2 * FRAME, BOARD + 2 * FRAME, 34)
  ctx.fillStyle = fg
  ctx.fill()
  ctx.save()
  ctx.clip()
  ctx.strokeStyle = 'rgba(255,220,170,0.06)'
  ctx.lineWidth = 2
  for (let i = 0; i < 40; i++) {
    const y = -FRAME + (i * (BOARD + 2 * FRAME)) / 40
    ctx.beginPath()
    ctx.moveTo(-FRAME, y)
    for (let x = -FRAME; x <= BOARD + FRAME; x += 40) ctx.lineTo(x, y + Math.sin(x / 70 + i) * 5)
    ctx.stroke()
  }
  ctx.restore()
  ctx.strokeStyle = 'rgba(255,200,120,0.35)'
  ctx.lineWidth = 3
  roundRect(ctx, -FRAME + 6, -FRAME + 6, BOARD + 2 * FRAME - 12, BOARD + 2 * FRAME - 12, 28)
  ctx.stroke()
  // inner shadow lip
  ctx.fillStyle = '#1d0d04'
  ctx.fillRect(-6, -6, BOARD + 12, BOARD + 12)

  // playing surface
  const sg = ctx.createRadialGradient(CENTER, CENTER, 40, CENTER, CENTER, BOARD * 0.75)
  sg.addColorStop(0, '#f6e2b8')
  sg.addColorStop(1, '#ddb57a')
  ctx.fillStyle = sg
  ctx.fillRect(0, 0, BOARD, BOARD)
  ctx.save()
  ctx.beginPath()
  ctx.rect(0, 0, BOARD, BOARD)
  ctx.clip()
  ctx.strokeStyle = 'rgba(140,90,40,0.08)'
  ctx.lineWidth = 1.5
  for (let i = 0; i < 70; i++) {
    const x0 = (i * BOARD) / 70
    ctx.beginPath()
    ctx.moveTo(x0, 0)
    for (let y = 0; y <= BOARD; y += 30) ctx.lineTo(x0 + Math.sin(y / 90 + i * 1.7) * 6, y)
    ctx.stroke()
  }
  ctx.restore()
  ctx.strokeStyle = 'rgba(0,0,0,0.35)'
  ctx.lineWidth = 2
  ctx.strokeRect(1, 1, BOARD - 2, BOARD - 2)

  const ink = '#3a2210'
  const red = '#b3232f'
  // baselines + arrows on all four sides
  for (let side = 0; side < 4; side++) {
    ctx.save()
    ctx.translate(CENTER, CENTER)
    ctx.rotate((side * Math.PI) / 2)
    ctx.translate(-CENTER, -CENTER)
    const x0 = (BOARD - BASE_LEN) / 2
    ctx.strokeStyle = ink
    ctx.lineWidth = 2
    for (const off of [BASE_INNER, BASE_OUTER]) {
      ctx.beginPath()
      ctx.moveTo(x0, BOARD - off)
      ctx.lineTo(x0 + BASE_LEN, BOARD - off)
      ctx.stroke()
    }
    for (const cx of [BASE_MIN, BASE_MAX]) {
      ctx.beginPath()
      ctx.arc(cx, BOARD - BASE_OFFSET, COIN_R, 0, Math.PI * 2)
      ctx.fillStyle = red
      ctx.fill()
      ctx.stroke()
      ctx.beginPath()
      ctx.arc(cx, BOARD - BASE_OFFSET, COIN_R - 5, 0, Math.PI * 2)
      ctx.strokeStyle = 'rgba(255,230,200,0.6)'
      ctx.lineWidth = 1.2
      ctx.stroke()
      ctx.strokeStyle = ink
      ctx.lineWidth = 2
    }
    // diagonal arrow from the bottom-left pocket toward the centre
    const u = Math.SQRT1_2
    const p = { x: POCKET_R, y: BOARD - POCKET_R }
    const a = { x: p.x + 55 * u, y: p.y - 55 * u }
    const b = { x: p.x + 265 * u, y: p.y - 265 * u }
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(b.x, b.y)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(a.x + 14, a.y - 2)
    ctx.moveTo(a.x, a.y)
    ctx.lineTo(a.x + 2, a.y - 14)
    ctx.stroke()
    ctx.beginPath()
    ctx.arc(b.x - 18 * u, b.y + 18 * u, 32, -Math.PI * 0.95, Math.PI * 0.45, true)
    ctx.stroke()
    ctx.restore()
  }

  // centre pattern
  ctx.strokeStyle = ink
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.arc(CENTER, CENTER, CENTER_CIRCLE_R, 0, Math.PI * 2)
  ctx.stroke()
  ctx.beginPath()
  ctx.arc(CENTER, CENTER, CENTER_CIRCLE_R - 8, 0, Math.PI * 2)
  ctx.lineWidth = 1
  ctx.stroke()
  for (let i = 0; i < 8; i++) {
    const t = (i * Math.PI) / 4
    const t1 = t - Math.PI / 8
    const t2 = t + Math.PI / 8
    ctx.beginPath()
    ctx.moveTo(CENTER + Math.cos(t) * (CENTER_CIRCLE_R - 12), CENTER + Math.sin(t) * (CENTER_CIRCLE_R - 12))
    ctx.lineTo(CENTER + Math.cos(t1) * 26, CENTER + Math.sin(t1) * 26)
    ctx.lineTo(CENTER + Math.cos(t2) * 26, CENTER + Math.sin(t2) * 26)
    ctx.closePath()
    ctx.fillStyle = i % 2 === 0 ? 'rgba(179,35,47,0.85)' : 'rgba(58,34,16,0.75)'
    ctx.fill()
  }
  ctx.beginPath()
  ctx.arc(CENTER, CENTER, COIN_R + 2, 0, Math.PI * 2)
  ctx.fillStyle = red
  ctx.fill()
  ctx.stroke()

  // pockets with nets
  for (const p of POCKETS) {
    ctx.save()
    ctx.beginPath()
    ctx.arc(p.x, p.y, POCKET_R + 1, 0, Math.PI * 2)
    const pg = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, POCKET_R + 1)
    pg.addColorStop(0, '#000')
    pg.addColorStop(1, '#2a1a10')
    ctx.fillStyle = pg
    ctx.fill()
    ctx.clip()
    ctx.strokeStyle = 'rgba(255,255,255,0.14)'
    ctx.lineWidth = 1
    for (let d = -POCKET_R * 2; d <= POCKET_R * 2; d += 7) {
      ctx.beginPath()
      ctx.moveTo(p.x + d - POCKET_R, p.y - POCKET_R)
      ctx.lineTo(p.x + d + POCKET_R, p.y + POCKET_R)
      ctx.moveTo(p.x + d + POCKET_R, p.y - POCKET_R)
      ctx.lineTo(p.x + d - POCKET_R, p.y + POCKET_R)
      ctx.stroke()
    }
    ctx.restore()
    ctx.beginPath()
    ctx.arc(p.x, p.y, POCKET_R + 1, 0, Math.PI * 2)
    ctx.strokeStyle = '#c9a24a'
    ctx.lineWidth = 2.5
    ctx.stroke()
  }
}

function drawPiece(ctx: CanvasRenderingContext2D, p: Piece, alpha = 1, bad = false) {
  const r = p.k === 's' ? STRIKER_R : COIN_R
  ctx.save()
  ctx.globalAlpha = alpha
  ctx.beginPath()
  ctx.arc(p.x + 2.5, p.y + 3.5, r, 0, Math.PI * 2)
  ctx.fillStyle = 'rgba(0,0,0,0.35)'
  ctx.fill()
  const colors: Record<PieceKind, [string, string, string]> = {
    w: ['#fffaf0', '#e9dcc0', 'rgba(120,90,50,0.35)'],
    b: ['#555', '#151515', 'rgba(255,255,255,0.18)'],
    q: ['#ff5a6a', '#a50d22', 'rgba(255,220,220,0.45)'],
    s: ['#ffffff', '#dcd6c8', 'rgba(30,60,140,0.7)'],
  }
  const [hi, lo, ring] = colors[p.k]
  const g = ctx.createRadialGradient(p.x - r * 0.35, p.y - r * 0.4, r * 0.1, p.x, p.y, r)
  g.addColorStop(0, hi)
  g.addColorStop(1, lo)
  ctx.beginPath()
  ctx.arc(p.x, p.y, r, 0, Math.PI * 2)
  ctx.fillStyle = g
  ctx.fill()
  ctx.lineWidth = 1
  ctx.strokeStyle = 'rgba(0,0,0,0.35)'
  ctx.stroke()
  ctx.strokeStyle = ring
  ctx.lineWidth = p.k === 's' ? 2.5 : 1.3
  for (const f of p.k === 's' ? [0.75, 0.45] : [0.72, 0.4]) {
    ctx.beginPath()
    ctx.arc(p.x, p.y, r * f, 0, Math.PI * 2)
    ctx.stroke()
  }
  if (p.k === 's') {
    ctx.beginPath()
    ctx.arc(p.x, p.y, r * 0.2, 0, Math.PI * 2)
    ctx.fillStyle = '#d9a93a'
    ctx.fill()
    ctx.beginPath()
    ctx.arc(p.x, p.y, r + 1.5, 0, Math.PI * 2)
    ctx.strokeStyle = bad ? '#ef4444' : '#d9a93a'
    ctx.lineWidth = bad ? 3 : 2
    ctx.stroke()
  }
  ctx.restore()
}

/** First coin hit by a striker moving from s along unit d, or the travel to the cushion. */
function traceAim(coins: Piece[], s: { x: number; y: number }, d: { dx: number; dy: number }) {
  let best = Infinity
  let hit: Piece | null = null
  const R = STRIKER_R + COIN_R
  for (const c of coins) {
    const ox = c.x - s.x
    const oy = c.y - s.y
    const t = ox * d.dx + oy * d.dy
    if (t <= 0) continue
    const perp2 = ox * ox + oy * oy - t * t
    if (perp2 > R * R) continue
    const tt = t - Math.sqrt(R * R - perp2)
    if (tt < best) {
      best = tt
      hit = c
    }
  }
  let wall = Infinity
  if (d.dx > 1e-9) wall = Math.min(wall, (BOARD - STRIKER_R - s.x) / d.dx)
  if (d.dx < -1e-9) wall = Math.min(wall, (STRIKER_R - s.x) / d.dx)
  if (d.dy > 1e-9) wall = Math.min(wall, (BOARD - STRIKER_R - s.y) / d.dy)
  if (d.dy < -1e-9) wall = Math.min(wall, (STRIKER_R - s.y) / d.dy)
  if (hit && best < wall) return { t: best, hit }
  return { t: Math.max(0, wall), hit: null }
}

function paint(canvas: HTMLCanvasElement, bg: HTMLCanvasElement, css: number, rotate: boolean, scene: Scene) {
  const ctx = canvas.getContext('2d')
  if (!ctx) return
  const dpr = canvas.width / css
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.clearRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(bg, 0, 0)
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
  ctx.translate(css / 2, css / 2)
  if (rotate) ctx.rotate(Math.PI)
  ctx.translate(-css / 2, -css / 2)
  const k = css / TOTAL
  ctx.scale(k, k)
  ctx.translate(FRAME, FRAME)

  const { striker, aim } = scene
  if (striker && aim && !striker.ghost) {
    const coins = scene.pieces.filter((p) => p.k !== 's')
    const tr = traceAim(coins, striker, aim)
    const ex = striker.x + aim.dx * tr.t
    const ey = striker.y + aim.dy * tr.t
    ctx.save()
    ctx.setLineDash([8, 8])
    ctx.strokeStyle = 'rgba(255,255,255,0.75)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(striker.x, striker.y)
    ctx.lineTo(ex, ey)
    ctx.stroke()
    ctx.setLineDash([])
    ctx.beginPath()
    ctx.arc(ex, ey, STRIKER_R, 0, Math.PI * 2)
    ctx.strokeStyle = 'rgba(255,255,255,0.6)'
    ctx.stroke()
    if (tr.hit) {
      const nx = (tr.hit.x - ex) / (STRIKER_R + COIN_R)
      const ny = (tr.hit.y - ey) / (STRIKER_R + COIN_R)
      ctx.beginPath()
      ctx.moveTo(tr.hit.x, tr.hit.y)
      ctx.lineTo(tr.hit.x + nx * 90, tr.hit.y + ny * 90)
      ctx.strokeStyle = 'rgba(250,204,21,0.85)'
      ctx.lineWidth = 2.5
      ctx.stroke()
    }
    // power arrow
    const L = STRIKER_R + 20 + aim.power * 110
    const ax = striker.x + aim.dx * L
    const ay = striker.y + aim.dy * L
    ctx.strokeStyle = '#facc15'
    ctx.fillStyle = '#facc15'
    ctx.lineWidth = 5
    ctx.lineCap = 'round'
    ctx.beginPath()
    ctx.moveTo(striker.x + aim.dx * (STRIKER_R + 4), striker.y + aim.dy * (STRIKER_R + 4))
    ctx.lineTo(ax, ay)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(ax + aim.dx * 16, ay + aim.dy * 16)
    ctx.lineTo(ax - aim.dy * 10, ay + aim.dx * 10)
    ctx.lineTo(ax + aim.dy * 10, ay - aim.dx * 10)
    ctx.closePath()
    ctx.fill()
    ctx.restore()
  }
  for (const p of scene.pieces) drawPiece(ctx, p)
  if (striker) drawPiece(ctx, { k: 's', x: striker.x, y: striker.y }, striker.ghost ? 0.45 : 1, striker.bad)
}

// ---------------------------------------------------------------- component
const clamp01 = (v: number) => Math.min(1, Math.max(0, v))

export function CarromBoard({ state, mySeat, canAct, onAction, names }: BoardProps<CarromState, CarromAction>) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const bgRef = useRef<{ key: string; canvas: HTMLCanvasElement } | null>(null)
  const animRef = useRef<{ frame: SimFrame; kinds: PieceKind[] } | null>(null)
  const seenRef = useRef(state.lastStrike?.n ?? 0)
  const lastStrikeRef = useRef<LastStrike | null>(state.lastStrike)
  const drawRef = useRef<() => void>(() => {})
  const dragRef = useRef<'place' | 'aim' | null>(null)

  const [css, setCss] = useState(0)
  const [pos, setPos] = useState(0.5)
  const seat = mySeat === 1 ? 1 : 0
  const [aim, setAim] = useState(() => ({ dx: 0, dy: seat === 0 ? -1 : 1 }))
  const [power, setPower] = useState(0.55)
  const [animating, setAnimating] = useState(false)
  const [sentN, setSentN] = useState<number | null>(null)

  const rotate = mySeat === 1
  const locked = sentN !== null && sentN === state.n
  const interactive = canAct && !animating && !locked && !state.over && mySeat === state.turn
  const placementError = useMemo(() => strikerPlacementError(state.coins, seat, pos), [state.coins, seat, pos])

  // resize to container
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const ro = new ResizeObserver(() => setCss(Math.floor(el.clientWidth)))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  // keep the latest strike in a ref for the replay effect
  useEffect(() => {
    lastStrikeRef.current = state.lastStrike
  })

  // redraw after every render
  useEffect(() => {
    drawRef.current = () => {
      const canvas = canvasRef.current
      if (!canvas || css <= 0) return
      const dpr = Math.min(3, window.devicePixelRatio || 1)
      const px = Math.round(css * dpr)
      if (canvas.width !== px) {
        canvas.width = px
        canvas.height = px
      }
      const key = `${px}:${rotate}`
      if (!bgRef.current || bgRef.current.key !== key) {
        const bg = document.createElement('canvas')
        bg.width = px
        bg.height = px
        const b = bg.getContext('2d')
        if (b) {
          b.scale(dpr, dpr)
          b.translate(css / 2, css / 2)
          if (rotate) b.rotate(Math.PI)
          b.translate(-css / 2, -css / 2)
          b.scale(css / TOTAL, css / TOTAL)
          b.translate(FRAME, FRAME)
          drawBoard(b)
        }
        bgRef.current = { key, canvas: bg }
      }
      let scene: Scene
      const anim = animRef.current
      if (anim) {
        const pieces: Piece[] = []
        let striker: Scene['striker'] = null
        anim.frame.forEach((p, i) => {
          if (!p) return
          if (anim.kinds[i] === 's') striker = { x: p.x, y: p.y, bad: false, ghost: false }
          else pieces.push({ k: anim.kinds[i], x: p.x, y: p.y })
        })
        scene = { pieces, striker, aim: null }
      } else {
        const pieces = state.coins.map((c: Coin) => ({ k: c.k, x: c.x, y: c.y }))
        if (state.over) scene = { pieces, striker: null, aim: null }
        else if (interactive) {
          const sp = strikerPos(seat, pos)
          scene = { pieces, striker: { ...sp, bad: !!placementError, ghost: false }, aim: { ...aim, power } }
        } else {
          const sp = strikerPos(state.turn, 0.5)
          scene = { pieces, striker: { ...sp, bad: false, ghost: true }, aim: null }
        }
      }
      paint(canvas, bgRef.current.canvas, css, rotate, scene)
    }
    drawRef.current()
  })

  // replay new strikes
  const lastN = state.lastStrike?.n ?? 0
  useEffect(() => {
    const ls = lastStrikeRef.current
    if (!ls || ls.n !== lastN || ls.n <= seenRef.current) return
    seenRef.current = ls.n
    const sim = simulate(ls.before.coins, { seat: ls.seat, ...ls.strike }, { frames: true })
    const frames = sim.frames ?? []
    const kinds: PieceKind[] = [...ls.before.coins.map((c) => c.k), 's']
    const speed = Math.max(1, frames.length / 420) // cap long replays at ~7s
    let start = 0
    let raf = 0
    const tick = (t: number) => {
      if (!start) {
        start = t
        setAnimating(true)
      }
      const i = Math.floor(((t - start) / 1000 / SIM_FRAME_SECONDS) * speed)
      if (i >= frames.length) {
        animRef.current = null
        setAnimating(false)
        drawRef.current()
        return
      }
      animRef.current = { frame: frames[i], kinds }
      drawRef.current()
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(raf)
      animRef.current = null
      setAnimating(false)
    }
  }, [lastN])

  // release the post-strike lock after LOCK_MS even if the server never answers
  useEffect(() => {
    if (sentN === null) return
    const t = window.setTimeout(() => setSentN(null), LOCK_MS)
    return () => window.clearTimeout(t)
  }, [sentN])

  const toBoard = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    let sx = ((e.clientX - r.left) / r.width) * TOTAL
    let sy = ((e.clientY - r.top) / r.height) * TOTAL
    if (rotate) {
      sx = TOTAL - sx
      sy = TOTAL - sy
    }
    return { x: sx - FRAME, y: sy - FRAME }
  }
  const aimAt = (p: { x: number; y: number }) => {
    const s = strikerPos(seat, pos)
    const dx = p.x - s.x
    let dy = p.y - s.y
    if (!isForward(seat, dy)) dy = 0
    const len = Math.sqrt(dx * dx + dy * dy)
    if (len < 4) return
    setAim({ dx: dx / len, dy: dy / len })
  }
  const placeAt = (p: { x: number }) => setPos(clamp01((p.x - BASE_MIN) / (BASE_MAX - BASE_MIN)))

  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!interactive) return
    const p = toBoard(e)
    const s = strikerPos(seat, pos)
    const near = Math.hypot(p.x - s.x, p.y - s.y) < STRIKER_R * 2.2
    dragRef.current = near ? 'place' : 'aim'
    e.currentTarget.setPointerCapture(e.pointerId)
    if (!near) aimAt(p)
  }
  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!interactive || !dragRef.current) return
    const p = toBoard(e)
    if (dragRef.current === 'place') placeAt(p)
    else aimAt(p)
  }
  const onUp = () => {
    dragRef.current = null
  }

  const strike = () => {
    if (!interactive || placementError || !isForward(seat, aim.dy)) return
    setSentN(state.n)
    onAction({ type: 'strike', x: pos, dx: aim.dx, dy: aim.dy, power })
  }

  // aim angle relative to "straight ahead" on the viewer's screen, -90..90 (right positive)
  const fwd = seat === 0 ? -aim.dy : aim.dy
  const side = seat === 0 ? aim.dx : -aim.dx
  const angle = Math.round((Math.atan2(side, fwd) * 180) / Math.PI)
  const setAngle = (deg: number) => {
    const a = (deg * Math.PI) / 180
    const sd = Math.sin(a)
    const fw = Math.cos(a)
    setAim(seat === 0 ? { dx: sd, dy: -fw } : { dx: -sd, dy: fw })
  }
  const sliderPos = rotate ? 1 - pos : pos

  const myTurn = mySeat === state.turn && !state.over
  const queenText =
    state.queen.s === 'board'
      ? 'Queen on the board'
      : state.queen.s === 'pending'
        ? `${names[state.queen.seat]} must cover the queen`
        : `Queen covered by ${names[state.queen.seat]}`

  const status = state.over
    ? `${names[state.winner ?? 0]} wins${state.points !== null ? ` · ${state.points} pts` : ''}`
    : animating
      ? 'Striking…'
      : myTurn
        ? locked
          ? 'Waiting for the server…'
          : 'Your turn — place, aim, strike'
        : `${names[state.turn]}'s turn`

  return (
    <div className="flex w-full flex-col gap-3 lg:flex-row lg:items-start">
      <div className="mx-auto w-full max-w-[min(100%,78vh)] flex-1">
        <div ref={wrapRef} className="relative aspect-square w-full">
          <canvas
            ref={canvasRef}
            className={cn('block rounded-[1.4rem] shadow-2xl', interactive ? 'cursor-crosshair' : 'cursor-default')}
            style={{ width: css || '100%', height: css || '100%', touchAction: 'none' }}
            onPointerDown={onDown}
            onPointerMove={onMove}
            onPointerUp={onUp}
            onPointerCancel={onUp}
            aria-label="Carrom board"
            role="img"
          />
        </div>

        {mySeat >= 0 && !state.over && (
          <div className={cn('glass mt-3 grid gap-3 rounded-2xl p-3 sm:grid-cols-[1fr_auto]', !interactive && 'opacity-60')}>
            <div className="grid gap-2 text-xs">
              <label className="flex items-center gap-2">
                <Target className="size-4 shrink-0 text-primary" />
                <span className="w-14 shrink-0 text-muted-foreground">Striker</span>
                <input
                  type="range"
                  min={0}
                  max={1000}
                  value={Math.round(sliderPos * 1000)}
                  disabled={!interactive}
                  onChange={(e) => {
                    const v = Number(e.target.value) / 1000
                    setPos(rotate ? 1 - v : v)
                  }}
                  className="w-full accent-[var(--primary)]"
                  aria-label="Striker position"
                />
              </label>
              <label className="flex items-center gap-2">
                <Crosshair className="size-4 shrink-0 text-primary" />
                <span className="w-14 shrink-0 text-muted-foreground">Aim {angle}°</span>
                <input
                  type="range"
                  min={-90}
                  max={90}
                  value={angle}
                  disabled={!interactive}
                  onChange={(e) => setAngle(Number(e.target.value))}
                  className="w-full accent-[var(--primary)]"
                  aria-label="Aim angle"
                />
              </label>
              <label className="flex items-center gap-2">
                <Zap className="size-4 shrink-0 text-primary" />
                <span className="w-14 shrink-0 text-muted-foreground">Power {Math.round(power * 100)}%</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(power * 100)}
                  disabled={!interactive}
                  onChange={(e) => setPower(Number(e.target.value) / 100)}
                  className="w-full accent-[var(--primary)]"
                  aria-label="Strike power"
                />
              </label>
              {interactive && placementError && <p className="text-destructive">{placementError}</p>}
            </div>
            <Button
              size="lg"
              className="h-14 min-w-32 font-display text-lg"
              disabled={!interactive || !!placementError}
              onClick={strike}
            >
              Strike
            </Button>
          </div>
        )}
      </div>

      <aside className="flex w-full flex-col gap-3 lg:w-72">
        <div className="glass rounded-2xl p-4">
          <p className={cn('font-display text-base', myTurn || state.over ? 'gold-text' : 'text-foreground')}>{status}</p>
          <p className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
            <Crown className="size-3.5 text-ludo-red" /> {queenText}
          </p>
          {state.foul && (
            <p className="mt-2 rounded-lg bg-destructive/15 px-2 py-1 text-xs text-destructive">Foul: {state.foul}</p>
          )}
        </div>
        {[0, 1].map((s) => {
          const left = state.coins.filter((c) => c.k === (s === 0 ? 'w' : 'b')).length
          return (
            <div
              key={s}
              className={cn(
                'glass rounded-2xl p-3 transition',
                state.turn === s && !state.over && 'ring-2 ring-primary',
                state.winner === s && 'ring-2 ring-primary',
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2">
                  <span
                    className={cn(
                      'size-4 shrink-0 rounded-full border',
                      s === 0 ? 'border-amber-200 bg-amber-50' : 'border-zinc-600 bg-zinc-900',
                    )}
                  />
                  <span className="truncate text-sm font-semibold">
                    {names[s]}
                    {s === mySeat && <span className="text-muted-foreground"> (you)</span>}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground">{s === 0 ? 'White' : 'Black'}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                {Array.from({ length: 9 }, (_, i) => (
                  <span
                    key={i}
                    className={cn(
                      'size-3.5 rounded-full border',
                      i < state.pocketed[s]
                        ? s === 0
                          ? 'border-amber-200 bg-amber-50'
                          : 'border-zinc-500 bg-zinc-800'
                        : 'border-border bg-transparent',
                    )}
                  />
                ))}
                {state.queen.s === 'covered' && state.queen.seat === s && (
                  <span className="size-3.5 rounded-full border border-red-300 bg-ludo-red" title="Queen" />
                )}
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">
                {state.pocketed[s]}/9 pocketed · {left} left
              </p>
            </div>
          )
        })}
        <div className="glass max-h-40 overflow-y-auto rounded-2xl p-3 text-xs text-muted-foreground">
          {state.log
            .slice(-8)
            .reverse()
            .map((l, i) => (
              <p key={i} className={cn(i === 0 && 'text-foreground')}>
                {l}
              </p>
            ))}
        </div>
      </aside>
    </div>
  )
}
