import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react'
import { Crosshair, Hand, RotateCcw, RotateCw, Target } from 'lucide-react'

import { Button } from '@/components/ui/button'
import {
  BALL_R,
  FOOT_SPOT,
  HEAD_X,
  POCKETS,
  RAIL,
  TABLE_H,
  TABLE_W,
  aimPreview,
  groupIds,
  groupOf,
  isStripe,
  isValidCuePlacement,
  onEight,
  remainingFor,
  simulate,
  type PoolAction,
  type PoolBall,
  type PoolState,
} from '@/lib/games/pool'
import type { BoardProps } from '@/lib/games/types'
import { cn } from '@/lib/utils'

const OW = TABLE_W + 2 * RAIL
const OH = TABLE_H + 2 * RAIL
const FRAME_MS = 1000 / 60

const BALL_COLORS: Record<number, string> = {
  0: '#f8f5ec',
  1: '#f5c518',
  2: '#1d4ed8',
  3: '#dc2626',
  4: '#7c3aed',
  5: '#f97316',
  6: '#16a34a',
  7: '#8b1e1e',
  8: '#111111',
}
const colorOf = (id: number) => BALL_COLORS[id > 8 ? id - 8 : id] ?? '#fff'

interface Aim {
  dx: number
  dy: number
}

interface Layout {
  w: number
  rot: boolean
}

// ---------------------------------------------------------------- drawing

interface DrawOpts {
  layout: Layout
  balls: PoolBall[]
  aim: Aim | null
  power: number
  kitchen: boolean
  placing: boolean
}

function drawBall(ctx: CanvasRenderingContext2D, b: PoolBall, rot: boolean) {
  const { x, y, id } = b
  const R = BALL_R
  // Shadow
  ctx.fillStyle = 'rgba(0,0,0,0.35)'
  ctx.beginPath()
  ctx.ellipse(x + 2.5, y + 3, R, R * 0.9, 0, 0, Math.PI * 2)
  ctx.fill()

  ctx.save()
  ctx.beginPath()
  ctx.arc(x, y, R, 0, Math.PI * 2)
  ctx.clip()
  if (isStripe(id)) {
    ctx.fillStyle = '#f8f5ec'
    ctx.fillRect(x - R, y - R, 2 * R, 2 * R)
    ctx.fillStyle = colorOf(id)
    if (rot) ctx.fillRect(x - R * 0.58, y - R, R * 1.16, 2 * R)
    else ctx.fillRect(x - R, y - R * 0.58, 2 * R, R * 1.16)
  } else {
    ctx.fillStyle = colorOf(id)
    ctx.fillRect(x - R, y - R, 2 * R, 2 * R)
  }
  if (id > 0) {
    ctx.fillStyle = '#fbfaf5'
    ctx.beginPath()
    ctx.arc(x, y, R * 0.46, 0, Math.PI * 2)
    ctx.fill()
    ctx.save()
    ctx.translate(x, y)
    if (rot) ctx.rotate(Math.PI / 2)
    ctx.fillStyle = '#111'
    ctx.font = `800 ${R * 0.62}px Manrope, system-ui, sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(String(id), 0, R * 0.04)
    ctx.restore()
  }
  // Shading
  const g = ctx.createRadialGradient(x - R * 0.38, y - R * 0.42, R * 0.05, x, y, R * 1.05)
  g.addColorStop(0, 'rgba(255,255,255,0.75)')
  g.addColorStop(0.25, 'rgba(255,255,255,0.12)')
  g.addColorStop(0.7, 'rgba(0,0,0,0)')
  g.addColorStop(1, 'rgba(0,0,0,0.45)')
  ctx.fillStyle = g
  ctx.fillRect(x - R, y - R, 2 * R, 2 * R)
  ctx.restore()
}

function drawTable(canvas: HTMLCanvasElement, o: DrawOpts) {
  const ctx = canvas.getContext('2d')
  if (!ctx || o.layout.w <= 0) return
  const dpr = window.devicePixelRatio || 1
  const cssW = o.layout.w
  const cssH = o.layout.rot ? (cssW * OW) / OH : (cssW * OH) / OW
  const pw = Math.round(cssW * dpr)
  const ph = Math.round(cssH * dpr)
  if (canvas.width !== pw || canvas.height !== ph) {
    canvas.width = pw
    canvas.height = ph
  }
  const k = (o.layout.rot ? cssW / OH : cssW / OW) * dpr
  ctx.setTransform(1, 0, 0, 1, 0, 0)
  ctx.clearRect(0, 0, pw, ph)
  // World (playfield) coords -> canvas.
  if (o.layout.rot) ctx.setTransform(0, -k, k, 0, RAIL * k, (RAIL + TABLE_W) * k)
  else ctx.setTransform(k, 0, 0, k, RAIL * k, RAIL * k)

  // Wooden rails
  const wood = ctx.createLinearGradient(0, -RAIL, 0, TABLE_H + RAIL)
  wood.addColorStop(0, '#6b3a1f')
  wood.addColorStop(0.08, '#4a2412')
  wood.addColorStop(0.92, '#4a2412')
  wood.addColorStop(1, '#2e160a')
  ctx.fillStyle = wood
  roundRect(ctx, -RAIL, -RAIL, TABLE_W + 2 * RAIL, TABLE_H + 2 * RAIL, 26)
  ctx.fill()
  ctx.strokeStyle = 'rgba(255,214,150,0.18)'
  ctx.lineWidth = 2
  roundRect(ctx, -RAIL + 4, -RAIL + 4, TABLE_W + 2 * RAIL - 8, TABLE_H + 2 * RAIL - 8, 22)
  ctx.stroke()

  // Cushions
  ctx.fillStyle = '#0c5a3a'
  ctx.fillRect(-16, -16, TABLE_W + 32, TABLE_H + 32)

  // Felt
  const felt = ctx.createRadialGradient(TABLE_W / 2, TABLE_H / 2, 40, TABLE_W / 2, TABLE_H / 2, TABLE_W * 0.65)
  felt.addColorStop(0, '#1f9a63')
  felt.addColorStop(1, '#0f6a43')
  ctx.fillStyle = felt
  ctx.fillRect(0, 0, TABLE_W, TABLE_H)

  // Diamonds
  ctx.fillStyle = 'rgba(255,236,200,0.75)'
  for (let i = 1; i < 8; i++) {
    if (i === 4) continue
    const x = (TABLE_W / 8) * i
    dot(ctx, x, -RAIL / 2 - 8, 3)
    dot(ctx, x, TABLE_H + RAIL / 2 + 8, 3)
  }
  for (let i = 1; i < 4; i++) {
    const y = (TABLE_H / 4) * i
    dot(ctx, -RAIL / 2 - 8, y, 3)
    dot(ctx, TABLE_W + RAIL / 2 + 8, y, 3)
  }

  // Head string + foot spot
  ctx.strokeStyle = o.kitchen && o.placing ? 'rgba(250,204,21,0.55)' : 'rgba(255,255,255,0.12)'
  ctx.lineWidth = o.kitchen && o.placing ? 2.5 : 1.5
  ctx.setLineDash([8, 8])
  ctx.beginPath()
  ctx.moveTo(HEAD_X, 0)
  ctx.lineTo(HEAD_X, TABLE_H)
  ctx.stroke()
  ctx.setLineDash([])
  ctx.fillStyle = 'rgba(255,255,255,0.25)'
  dot(ctx, FOOT_SPOT.x, FOOT_SPOT.y, 3)
  if (o.kitchen && o.placing) {
    ctx.fillStyle = 'rgba(250,204,21,0.06)'
    ctx.fillRect(0, 0, HEAD_X, TABLE_H)
  }

  // Pockets
  for (const p of POCKETS) {
    const r = p.side ? 21 : 25
    ctx.fillStyle = '#1a1a1a'
    dot(ctx, p.x, p.y, r + 4)
    const pg = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, r)
    pg.addColorStop(0, '#000')
    pg.addColorStop(1, '#0b0b0b')
    ctx.fillStyle = pg
    dot(ctx, p.x, p.y, r)
  }

  const cue = o.balls.find((b) => b.id === 0)

  // Aim line + ghost ball
  if (o.aim && cue) {
    const pre = aimPreview(o.balls, cue.x, cue.y, o.aim.dx, o.aim.dy)
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'
    ctx.lineWidth = 2
    ctx.setLineDash([10, 7])
    ctx.beginPath()
    ctx.moveTo(cue.x, cue.y)
    ctx.lineTo(pre.ghost.x, pre.ghost.y)
    ctx.stroke()
    ctx.setLineDash([])
    ctx.strokeStyle = 'rgba(255,255,255,0.85)'
    ctx.beginPath()
    ctx.arc(pre.ghost.x, pre.ghost.y, BALL_R, 0, Math.PI * 2)
    ctx.stroke()
    if (pre.objDir && pre.hit !== null) {
      const hit = o.balls.find((b) => b.id === pre.hit)
      if (hit) {
        ctx.strokeStyle = 'rgba(250,204,21,0.9)'
        ctx.lineWidth = 2.5
        ctx.beginPath()
        ctx.moveTo(hit.x, hit.y)
        ctx.lineTo(hit.x + pre.objDir.x * 90, hit.y + pre.objDir.y * 90)
        ctx.stroke()
      }
    }
  }

  for (const b of o.balls) drawBall(ctx, b, o.layout.rot)

  // Placement ring
  if (o.placing && cue) {
    ctx.strokeStyle = 'rgba(250,204,21,0.9)'
    ctx.lineWidth = 2
    ctx.setLineDash([4, 4])
    ctx.beginPath()
    ctx.arc(cue.x, cue.y, BALL_R + 7, 0, Math.PI * 2)
    ctx.stroke()
    ctx.setLineDash([])
  }

  // Cue stick
  if (o.aim && cue) {
    const ang = Math.atan2(o.aim.dy, o.aim.dx)
    const back = BALL_R + 6 + o.power * 70
    const len = 430
    ctx.save()
    ctx.translate(cue.x, cue.y)
    ctx.rotate(ang)
    ctx.shadowColor = 'rgba(0,0,0,0.5)'
    ctx.shadowBlur = 10
    ctx.shadowOffsetY = 4
    const sg = ctx.createLinearGradient(-back - len, 0, -back, 0)
    sg.addColorStop(0, '#1c0f08')
    sg.addColorStop(0.35, '#3b1d0d')
    sg.addColorStop(0.36, '#c9a227')
    sg.addColorStop(0.39, '#c9a227')
    sg.addColorStop(0.4, '#d9b98a')
    sg.addColorStop(0.97, '#ecd9b4')
    sg.addColorStop(0.975, '#f4f4f4')
    sg.addColorStop(1, '#3b82f6')
    ctx.fillStyle = sg
    ctx.beginPath()
    ctx.moveTo(-back, -2.6)
    ctx.lineTo(-back - len, -6.5)
    ctx.lineTo(-back - len, 6.5)
    ctx.lineTo(-back, 2.6)
    ctx.closePath()
    ctx.fill()
    ctx.restore()
  }
}

function dot(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.beginPath()
  ctx.arc(x, y, r, 0, Math.PI * 2)
  ctx.fill()
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

// ---------------------------------------------------------------- helpers

function defaultAim(state: PoolState, seat: number): Aim {
  const cue = state.balls.find((b) => b.id === 0)
  if (!cue) return { dx: 1, dy: 0 }
  const g = seat >= 0 ? state.groups[seat] : null
  const want = (id: number) => (g ? (onEight(state, seat) ? id === 8 : groupOf(id) === g) : id !== 8)
  let best: PoolBall | null = null
  let bd = Infinity
  for (const b of state.balls) {
    if (b.id === 0 || !want(b.id)) continue
    const d = (b.x - cue.x) ** 2 + (b.y - cue.y) ** 2
    if (d < bd) {
      bd = d
      best = b
    }
  }
  const t = best ?? FOOT_SPOT
  const dx = t.x - cue.x
  const dy = t.y - cue.y
  const l = Math.hypot(dx, dy)
  return l > 0 ? { dx: dx / l, dy: dy / l } : { dx: 1, dy: 0 }
}

function MiniBall({ id, faded }: { id: number; faded?: boolean }) {
  const c = colorOf(id)
  return (
    <span
      className={cn(
        'inline-flex size-5 items-center justify-center rounded-full text-[9px] font-extrabold text-black shadow-inner ring-1 ring-black/30',
        faded && 'opacity-25',
      )}
      style={{
        background: isStripe(id) ? `linear-gradient(180deg,#f8f5ec 22%,${c} 22%,${c} 78%,#f8f5ec 78%)` : c,
      }}
    >
      <span className="flex size-3 items-center justify-center rounded-full bg-white/95 leading-none">{id}</span>
    </span>
  )
}

// ---------------------------------------------------------------- component

export function PoolTable({ state, mySeat, canAct, onAction, names }: BoardProps<PoolState, PoolAction>) {
  const wrapRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const dragRef = useRef<'cue' | 'aim' | null>(null)

  const [layout, setLayout] = useState<Layout>({ w: 0, rot: false })
  const [power, setPower] = useState(0.55)
  const [aim, setAim] = useState<Aim>(() => defaultAim(state, mySeat))
  const [cuePos, setCuePos] = useState<{ x: number; y: number } | null>(null)
  const [seenN, setSeenN] = useState(state.lastShot?.n ?? 0)
  const [turnKey, setTurnKey] = useState(state.n)
  const [sentAt, setSentAt] = useState<number | null>(null)
  const [anim, setAnim] = useState<{ n: number; frames: PoolBall[][] } | null>(null)
  const [frame, setFrame] = useState<PoolBall[] | null>(null)

  // New authoritative shot -> replay it locally (adjusting state during render).
  const ls = state.lastShot
  if (ls && ls.n > seenN) {
    setSeenN(ls.n)
    const sim = simulate(ls.before, ls.shot, { frames: true })
    setAnim({ n: ls.n, frames: sim.frames ?? [] })
    setFrame(sim.frames?.[0] ?? null)
  }
  if (state.n !== turnKey) {
    setTurnKey(state.n)
    setAim(defaultAim(state, mySeat))
    setCuePos(null)
  }

  const animating = anim !== null
  const myTurn = mySeat >= 0 && state.turn === mySeat && !state.over
  const interactive = canAct && myTurn && !animating && sentAt !== state.n
  const placing = interactive && state.ballInHand

  const displayBalls: PoolBall[] = (() => {
    if (animating && frame) return frame
    if (placing && cuePos) return state.balls.map((b) => (b.id === 0 ? { id: 0, ...cuePos } : b))
    return state.balls
  })()
  const cue = displayBalls.find((b) => b.id === 0)

  // Track container width.
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const measure = () => {
      const w = el.clientWidth
      const rot = w < 560 && window.innerHeight > window.innerWidth
      setLayout((l) => (l.w === w && l.rot === rot ? l : { w, rot }))
    }
    const ro = new ResizeObserver(measure)
    ro.observe(el)
    window.addEventListener('resize', measure)
    measure()
    return () => {
      ro.disconnect()
      window.removeEventListener('resize', measure)
    }
  }, [])

  // Play the replay frames.
  useEffect(() => {
    if (!anim) return
    let raf = 0
    const start = performance.now()
    const tick = (t: number) => {
      const i = Math.floor((t - start) / FRAME_MS)
      if (i >= anim.frames.length) {
        setAnim(null)
        setFrame(null)
        return
      }
      setFrame(anim.frames[i]!)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [anim])

  // Draw.
  useEffect(() => {
    const c = canvasRef.current
    if (!c) return
    drawTable(c, {
      layout,
      balls: displayBalls,
      aim: interactive ? aim : null,
      power,
      kitchen: state.kitchen,
      placing,
    })
  })

  const toWorld = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    const s = layout.rot ? r.width / OH : r.width / OW
    const px = (e.clientX - r.left) / s
    const py = (e.clientY - r.top) / s
    return layout.rot ? { x: RAIL + TABLE_W - py, y: px - RAIL } : { x: px - RAIL, y: py - RAIL }
  }

  const aimAt = (p: { x: number; y: number }) => {
    if (!cue) return
    const dx = p.x - cue.x
    const dy = p.y - cue.y
    const l = Math.hypot(dx, dy)
    if (l > BALL_R * 0.5) setAim({ dx: dx / l, dy: dy / l })
  }

  const placeAt = (p: { x: number; y: number }) => {
    const x = Math.min(TABLE_W - BALL_R, Math.max(BALL_R, p.x))
    const y = Math.min(TABLE_H - BALL_R, Math.max(BALL_R, p.y))
    const cx = state.kitchen ? Math.min(HEAD_X, x) : x
    if (isValidCuePlacement(state.balls, cx, y, state.kitchen)) setCuePos({ x: cx, y })
  }

  const onDown = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!interactive) return
    const p = toWorld(e)
    e.currentTarget.setPointerCapture(e.pointerId)
    if (placing && cue && Math.hypot(p.x - cue.x, p.y - cue.y) < BALL_R * 3) {
      dragRef.current = 'cue'
    } else {
      dragRef.current = 'aim'
      aimAt(p)
    }
  }
  const onMove = (e: ReactPointerEvent<HTMLCanvasElement>) => {
    if (!interactive || !dragRef.current) return
    const p = toWorld(e)
    if (dragRef.current === 'cue') placeAt(p)
    else aimAt(p)
  }
  const onUp = () => {
    dragRef.current = null
  }

  const nudge = (deg: number) => {
    const a = (deg * Math.PI) / 180
    const c = Math.cos(a)
    const s = Math.sin(a)
    setAim((v) => ({ dx: v.dx * c - v.dy * s, dy: v.dx * s + v.dy * c }))
  }

  const shoot = () => {
    if (!interactive || !cue) return
    const action: PoolAction = { type: 'shot', dx: aim.dx, dy: aim.dy, power }
    if (state.ballInHand) {
      action.cueX = cue.x
      action.cueY = cue.y
    }
    setSentAt(state.n)
    // Re-enable input if the server rejects the shot and nothing changes.
    window.setTimeout(() => setSentAt(null), 5000)
    onAction(action)
  }

  const cssH = layout.w ? (layout.rot ? (layout.w * OW) / OH : (layout.w * OH) / OW) : undefined

  // Status line
  let status: string
  let tone: 'info' | 'warn' | 'win' = 'info'
  if (state.over) {
    status = state.reason ?? 'Game over'
    tone = 'win'
  } else if (animating) {
    status = `${names[ls?.seat ?? state.turn]} shoots…`
  } else {
    const who = myTurn ? 'Your turn' : `${names[state.turn]}'s turn`
    const extra = state.breakShot
      ? ' to break'
      : state.ballInHand
        ? ' · ball in hand'
        : ''
    status = who + extra
  }
  const foul = !animating && !state.over ? state.foul : null
  if (foul) tone = 'warn'

  return (
    <div className="flex w-full flex-col gap-3">
      {/* Players */}
      <div className="grid grid-cols-2 gap-2">
        {[0, 1].map((seat) => {
          const g = state.groups[seat]
          const left = remainingFor(state, seat)
          const active = !state.over && state.turn === seat
          const won = state.over && state.winner === seat
          return (
            <div
              key={seat}
              className={cn(
                'glass rounded-xl p-2.5 transition-shadow',
                active && 'ring-2 ring-primary shadow-[0_0_24px_-6px_var(--primary)]',
                won && 'ring-2 ring-primary',
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate font-display text-sm font-semibold">
                  {names[seat]}
                  {seat === mySeat && <span className="ml-1 text-xs text-muted-foreground">(you)</span>}
                </span>
                <span className="shrink-0 text-[11px] uppercase tracking-wide text-muted-foreground">
                  {g ? (onEight(state, seat) ? 'On the 8' : g) : 'Open'}
                </span>
              </div>
              <div className="mt-1.5 flex min-h-5 flex-wrap gap-1">
                {g ? (
                  onEight(state, seat) ? (
                    <MiniBall id={8} />
                  ) : (
                    groupIds(g).map((id) => <MiniBall key={id} id={id} faded={!left.includes(id)} />)
                  )
                ) : (
                  <span className="text-xs text-muted-foreground">Groups not assigned</span>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Status */}
      <div
        className={cn(
          'flex min-h-9 items-center justify-center gap-2 rounded-lg px-3 py-1.5 text-center text-sm font-medium',
          tone === 'info' && 'bg-secondary/60 text-foreground',
          tone === 'warn' && 'bg-destructive/15 text-destructive-foreground ring-1 ring-destructive/40',
          tone === 'win' && 'bg-primary/15 text-primary ring-1 ring-primary/40',
        )}
      >
        {state.ballInHand && !state.over && !animating ? <Hand className="size-4 shrink-0" /> : <Target className="size-4 shrink-0" />}
        <span>
          {foul && <span className="font-semibold">Foul: {foul}. </span>}
          {status}
        </span>
      </div>

      {/* Table */}
      <div ref={wrapRef} className={cn('w-full', layout.rot && 'mx-auto max-w-[420px]')}>
        <canvas
          ref={canvasRef}
          className={cn('block w-full select-none rounded-[18px]', interactive ? 'cursor-crosshair' : 'cursor-default')}
          style={{ height: cssH, touchAction: 'none' }}
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
          aria-label="8 ball pool table"
        />
      </div>

      {/* Controls */}
      {myTurn && !state.over && (
        <div className={cn('glass flex flex-col gap-3 rounded-xl p-3 sm:flex-row sm:items-center', !interactive && 'opacity-50')}>
          <div className="flex flex-1 items-center gap-3">
            <span className="w-12 shrink-0 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Power</span>
            <input
              type="range"
              min={3}
              max={100}
              step={1}
              value={Math.round(power * 100)}
              disabled={!interactive}
              onChange={(e) => setPower(Number(e.target.value) / 100)}
              className="h-8 flex-1 cursor-pointer accent-[var(--primary)]"
              style={{ touchAction: 'pan-x' }}
              aria-label="Shot power"
            />
            <span className="w-10 shrink-0 text-right font-display text-sm tabular-nums text-primary">
              {Math.round(power * 100)}%
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="icon" disabled={!interactive} onClick={() => nudge(-0.5)} aria-label="Rotate aim left">
              <RotateCcw className="size-4" />
            </Button>
            <Button variant="secondary" size="icon" disabled={!interactive} onClick={() => nudge(0.5)} aria-label="Rotate aim right">
              <RotateCw className="size-4" />
            </Button>
            <Button className="h-11 flex-1 px-8 text-base font-bold sm:flex-none" disabled={!interactive} onClick={shoot}>
              <Crosshair className="size-5" />
              Shoot
            </Button>
          </div>
        </div>
      )}
      {myTurn && interactive && (
        <p className="text-center text-xs text-muted-foreground">
          {placing ? 'Drag the cue ball to place it, then ' : ''}Drag on the table to aim. Fine-tune with the arrows.
        </p>
      )}
    </div>
  )
}
