import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, Crown, RotateCcw, Star } from 'lucide-react'

import { Button } from '@/components/ui/button'
import {
  FINISH,
  HOME_COLUMN,
  SAFE_CELLS,
  START_INDEX,
  TRACK,
  applyMove,
  chooseBotMove,
  createGame,
  movableTokens,
  nextTurn,
  rollDie,
  tokenPoint,
  type Color,
  type GameState,
  type Mode,
} from '@/lib/ludo'
import { cn } from '@/lib/utils'

export const COLOR_VAR: Record<Color, string> = {
  red: 'var(--ludo-red)',
  green: 'var(--ludo-green)',
  yellow: 'var(--ludo-yellow)',
  blue: 'var(--ludo-blue)',
}
const CELL = 100 / 15
const STEP_MS = 140

type Phase = 'roll' | 'rolling' | 'choose' | 'moving' | 'over'

const cellStyle = (r: number, c: number, w = 1, h = 1) => ({
  top: `${r * CELL}%`,
  left: `${c * CELL}%`,
  width: `${w * CELL}%`,
  height: `${h * CELL}%`,
})

export function LudoGame({
  mode,
  onExit,
}: {
  mode: Mode
  onExit: () => void
}) {
  const [game, setGame] = useState<GameState>(() => createGame(mode))
  const [phase, setPhase] = useState<Phase>('roll')
  const [movable, setMovable] = useState<number[]>([])
  const [face, setFace] = useState(6)
  const [rolling, setRolling] = useState(false)
  const [anim, setAnim] = useState<{ p: number; t: number; pos: number } | null>(null)

  const gameRef = useRef(game)
  const timers = useRef<number[]>([])
  const intervals = useRef<number[]>([])

  useEffect(
    () => () => {
      timers.current.forEach(clearTimeout)
      intervals.current.forEach(clearInterval)
    },
    [],
  )

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms))
  }
  const commit = (g: GameState) => {
    gameRef.current = g
    setGame(g)
  }

  const endTurn = (g: GameState, keep: boolean) => {
    commit(nextTurn(g, keep))
    setPhase('roll')
  }

  const move = (tokenIndex: number) => {
    const g = gameRef.current
    setMovable([])
    setPhase('moving')
    const from = g.players[g.turn].tokens[tokenIndex]
    const steps =
      from < 0 ? [0] : Array.from({ length: g.dice! }, (_, k) => from + k + 1)
    steps.forEach((pos, k) =>
      later(() => setAnim({ p: g.turn, t: tokenIndex, pos }), k * STEP_MS),
    )
    later(() => {
      setAnim(null)
      const res = applyMove(g, tokenIndex)
      commit(res.state)
      if (res.state.winnerTeam !== null) {
        setPhase('over')
        return
      }
      later(() => endTurn(res.state, res.extraTurn), 250)
    }, steps.length * STEP_MS + 80)
  }

  const roll = () => {
    const g = gameRef.current
    setPhase('rolling')
    setRolling(true)
    const iv = window.setInterval(() => setFace(rollDie()), 80)
    intervals.current.push(iv)
    later(() => {
      clearInterval(iv)
      setRolling(false)
      const d = rollDie()
      setFace(d)
      const me = g.players[g.turn]
      const streak = d === 6 ? g.sixStreak + 1 : 0
      const log = [...g.log, `${me.name} rolled a ${d}.`]
      const ng: GameState = { ...g, dice: d, sixStreak: streak, log: log.slice(-30) }
      if (streak === 3) {
        ng.log = [...ng.log, 'Three sixes in a row — turn lost.']
        commit(ng)
        later(() => endTurn(ng, false), 900)
        return
      }
      commit(ng)
      const opts = movableTokens(me, d)
      if (opts.length === 0) {
        later(() => endTurn(ng, d === 6), 900)
        return
      }
      if (me.isBot) {
        later(() => move(chooseBotMove(ng, opts)), 500)
        return
      }
      if (opts.length === 1) {
        setPhase('moving')
        later(() => move(opts[0]), 350)
        return
      }
      setMovable(opts)
      setPhase('choose')
    }, 600)
  }

  // Drive bot turns.
  const current = game.players[game.turn]
  useEffect(() => {
    if (phase !== 'roll' || !current.isBot) return
    const id = window.setTimeout(roll, 750)
    return () => clearTimeout(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, game.turn, current.isBot])

  const restart = () => {
    timers.current.forEach(clearTimeout)
    intervals.current.forEach(clearInterval)
    timers.current = []
    intervals.current = []
    setRolling(false)
    commit(createGame(mode))
    setPhase('roll')
    setMovable([])
    setAnim(null)
  }

  const winnerTeam = game.winnerTeam
  const youWon = winnerTeam !== null && game.players[0].team === winnerTeam
  const winners = game.players.filter((p) => p.team === winnerTeam)
  const humanTurn = !current.isBot

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
      <div className="relative mx-auto w-full max-w-[min(100%,82vh)]">
        <BoardView game={game} movable={movable} anim={anim} activeColor={phase !== 'over' ? current.color : null} onToken={move} />
        {phase === 'over' && (
          <WinOverlay
            youWon={youWon}
            names={winners.map((w) => w.name).join(' & ')}
            note="Practice match vs bots — no coins at stake."
            onRematch={restart}
            onExit={onExit}
          />
        )}
      </div>

      <aside className="space-y-4">
        <div className="glass rounded-2xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-bold tracking-wider text-muted-foreground uppercase">
              {mode === '1v1' ? '1 vs 1' : mode === '2v2' ? '2 vs 2 · Teams' : '4-player classic'}
            </span>
            <button onClick={onExit} className="flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground">
              <ArrowLeft className="size-3" /> Leave
            </button>
          </div>
          <ul className="space-y-2">
            {game.players.map((p, i) => {
              const home = p.tokens.filter((t) => t === FINISH).length
              return (
                <li
                  key={p.color}
                  className={cn(
                    'flex items-center gap-3 rounded-xl px-3 py-2 transition',
                    i === game.turn && phase !== 'over' ? 'bg-white/10 ring-1 ring-white/20' : 'opacity-75',
                  )}
                >
                  <span className="size-4 rounded-full ring-2 ring-white" style={{ background: COLOR_VAR[p.color] }} />
                  <span className="flex-1 text-sm font-semibold">
                    {p.name}
                    {mode === '2v2' && (
                      <span className="ml-2 text-[10px] font-bold text-muted-foreground uppercase">Team {p.team === 0 ? 'A' : 'B'}</span>
                    )}
                  </span>
                  <span className="text-xs text-muted-foreground tabular-nums">{home}/4 home</span>
                </li>
              )
            })}
          </ul>
        </div>

        <div className="glass flex flex-col items-center gap-4 rounded-2xl p-5">
          <Dice value={face} rolling={rolling} color={COLOR_VAR[current.color]} />
          <Button
            size="lg"
            className="h-12 w-full rounded-xl text-base font-bold"
            disabled={!humanTurn || phase !== 'roll'}
            onClick={roll}
          >
            {phase === 'over'
              ? 'Game over'
              : !humanTurn
                ? `${current.name} is playing…`
                : phase === 'choose'
                  ? 'Tap a glowing token'
                  : phase === 'roll'
                    ? 'Roll the dice'
                    : 'Moving…'}
          </Button>
          <p className="text-center text-xs text-muted-foreground">
            Roll a 6 to leave the yard. Sixes, captures and reaching home earn an extra roll. Stars are safe squares.
          </p>
        </div>

        <div className="glass max-h-48 overflow-y-auto rounded-2xl p-4 text-xs">
          <div className="mb-2 font-bold tracking-wider text-muted-foreground uppercase">Match log</div>
          <ul className="space-y-1">
            {[...game.log].reverse().slice(0, 12).map((l, i) => (
              <li key={`${i}-${l}`} className={cn(i === 0 ? 'text-foreground' : 'text-muted-foreground')}>
                {l}
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  )
}

export function BoardView({
  game,
  movable,
  anim,
  activeColor,
  onToken,
}: {
  game: GameState
  movable: number[]
  anim: { p: number; t: number; pos: number } | null
  activeColor: Color | null
  onToken: (token: number) => void
}) {
  // Compute token render positions, nudging stacked tokens apart.
  const placed: { key: string; color: Color; x: number; y: number; pi: number; ti: number; movable: boolean }[] = []
  game.players.forEach((p, pi) =>
    p.tokens.forEach((prog, ti) => {
      const pos = anim && anim.p === pi && anim.t === ti ? anim.pos : prog
      const [y, x] = tokenPoint(p.color, pos, ti)
      placed.push({
        key: `${p.color}-${ti}`,
        color: p.color,
        x,
        y,
        pi,
        ti,
        movable: pi === game.turn && movable.includes(ti),
      })
    }),
  )
  const groups = new Map<string, number[]>()
  placed.forEach((t, i) => {
    const k = `${t.x.toFixed(2)},${t.y.toFixed(2)}`
    groups.set(k, [...(groups.get(k) ?? []), i])
  })
  const offsets = new Map<number, [number, number, number]>()
  groups.forEach((idx) => {
    if (idx.length === 1) return offsets.set(idx[0], [0, 0, 1])
    idx.forEach((i, n) => {
      const a = (n / idx.length) * Math.PI * 2
      offsets.set(i, [Math.cos(a) * 0.22, Math.sin(a) * 0.22, 0.72])
    })
  })


  return (
        <div className="relative aspect-square w-full overflow-hidden rounded-3xl bg-[oklch(0.96_0.01_90)] p-0 shadow-2xl ring-8 ring-[oklch(0.3_0.07_285)]">
          {/* Track */}
          {TRACK.map(([r, c], i) => {
            const startOf = (Object.keys(START_INDEX) as Color[]).find((k) => START_INDEX[k] === i)
            return (
              <div
                key={`t${i}`}
                className="absolute grid place-items-center border border-black/10"
                style={{ ...cellStyle(r, c), background: startOf ? COLOR_VAR[startOf] : undefined }}
              >
                {SAFE_CELLS.has(i) && <Star className={cn('size-[55%]', startOf ? 'text-white/80' : 'text-black/25')} />}
              </div>
            )
          })}
          {/* Home columns */}
          {(Object.keys(HOME_COLUMN) as Color[]).map((col) =>
            HOME_COLUMN[col].map(([r, c], i) => (
              <div
                key={`${col}${i}`}
                className="absolute border border-black/10"
                style={{ ...cellStyle(r, c), background: COLOR_VAR[col] }}
              />
            )),
          )}
          {/* Yards */}
          {(
            [
              ['red', 0, 0],
              ['green', 0, 9],
              ['yellow', 9, 9],
              ['blue', 9, 0],
            ] as const
          ).map(([col, r, c]) => {
            const active = activeColor === col
            return (
              <div key={col} className="absolute p-[1.2%]" style={{ ...cellStyle(r, c, 6, 6), background: COLOR_VAR[col] }}>
                <div
                  className={cn(
                    'h-full w-full rounded-[18%] bg-white/90 shadow-inner transition',
                    active && 'ring-4 ring-white',
                  )}
                >
                  {[
                    [2, 2],
                    [2, 4],
                    [4, 2],
                    [4, 4],
                  ].map(([dr, dc]) => (
                    <span
                      key={`${dr}${dc}`}
                      className="absolute size-[11%] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-35"
                      style={{
                        top: `${((dr - 0.0) / 6) * 100}%`,
                        left: `${((dc - 0.0) / 6) * 100}%`,
                        background: COLOR_VAR[col],
                      }}
                    />
                  ))}
                </div>
              </div>
            )
          })}
          {/* Centre */}
          <div
            className="absolute"
            style={{
              ...cellStyle(6, 6, 3, 3),
              background: `conic-gradient(from -45deg, ${COLOR_VAR.green} 0 90deg, ${COLOR_VAR.yellow} 90deg 180deg, ${COLOR_VAR.blue} 180deg 270deg, ${COLOR_VAR.red} 270deg 360deg)`,
            }}
          >
            <Crown className="absolute top-1/2 left-1/2 size-[40%] -translate-x-1/2 -translate-y-1/2 text-white/80 drop-shadow" />
          </div>

          {/* Tokens */}
          {placed.map((t, i) => {
            const [ox, oy, scale] = offsets.get(i) ?? [0, 0, 1]
            return (
              <button
                key={t.key}
                type="button"
                disabled={!t.movable}
                onClick={() => t.movable && onToken(t.ti)}
                aria-label={`${t.color} token ${t.ti + 1}`}
                className={cn(
                  'absolute z-10 grid place-items-center rounded-full border-[3px] border-white shadow-[0_3px_6px_rgba(0,0,0,0.45)] transition-[top,left,transform] duration-150 ease-out',
                  t.movable && 'token-movable z-20 ring-4 ring-white/80',
                )}
                style={{
                  width: `${CELL * 0.78}%`,
                  height: `${CELL * 0.78}%`,
                  left: `${(t.x + ox) * CELL}%`,
                  top: `${(t.y + oy) * CELL}%`,
                  transform: `translate(-50%, -50%) scale(${scale})`,
                  background: `radial-gradient(circle at 35% 30%, white -40%, ${COLOR_VAR[t.color]} 55%)`,
                }}
              >
                <span className="size-[35%] rounded-full bg-white/70" />
              </button>
            )
          })}
        </div>
  )
}

const PIPS: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
}

export function Dice({ value, rolling, color }: { value: number; rolling: boolean; color: string }) {
  return (
    <div
      className={cn('grid size-20 grid-cols-3 grid-rows-3 gap-1 rounded-2xl bg-white p-3 shadow-xl', rolling && 'dice-rolling')}
      style={{ boxShadow: `0 0 0 4px ${color}, 0 12px 30px -8px ${color}` }}
      aria-label={`Dice showing ${value}`}
    >
      {Array.from({ length: 9 }, (_, i) => (
        <span key={i} className={cn('rounded-full', PIPS[value].includes(i) ? 'bg-zinc-900' : 'bg-transparent')} />
      ))}
    </div>
  )
}

export function WinOverlay({
  youWon,
  names,
  note,
  onRematch,
  onExit,
}: {
  youWon: boolean
  names: string
  note: string
  onRematch?: () => void
  onExit: () => void
}) {
  const [pieces] = useState(() =>
    Array.from({ length: 48 }, (_, i) => ({
      left: Math.random() * 100,
      delay: Math.random() * 1.2,
      dur: 2.2 + Math.random() * 1.8,
      color: ['var(--ludo-red)', 'var(--ludo-green)', 'var(--ludo-yellow)', 'var(--ludo-blue)'][i % 4],
    })),
  )
  return (
    <div className="absolute inset-0 z-30 grid place-items-center overflow-hidden rounded-3xl bg-background/75 backdrop-blur-sm">
      {youWon &&
        pieces.map((p, i) => (
          <span
            key={i}
            className="confetti"
            style={{ left: `${p.left}%`, background: p.color, animationDelay: `${p.delay}s`, animationDuration: `${p.dur}s` }}
          />
        ))}
      <div className="splash-in relative text-center">
        <Crown className={cn('mx-auto size-16 drop-shadow-lg', youWon ? 'text-primary' : 'text-muted-foreground')} />
        <h2 className="mt-3 text-4xl font-extrabold">{youWon ? 'Victory!' : `${names} win`}</h2>
        <p className="mt-2 text-muted-foreground">
          {youWon ? (
            <>
              {note}
            </>
          ) : (
            'So close — run it back?'
          )}
        </p>
        <div className="mt-6 flex justify-center gap-3">
          {onRematch && (
            <Button onClick={onRematch} className="rounded-full font-bold">
              <RotateCcw /> Rematch
            </Button>
          )}
          <Button variant="outline" onClick={onExit} className="rounded-full font-bold">
            Back to lobby
          </Button>
        </div>
      </div>
    </div>
  )
}
