import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, Bot, Copy, MessageCircle, Send, Share2, Timer, UserPlus } from 'lucide-react'
import { toast } from 'sonner'

import { Avatar } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { errMsg, initialsOf, useServer } from '@/lib/client'
import { FINISH, movableTokens } from '@/lib/ludo'
import { cn } from '@/lib/utils'
import type { RoomView } from '@/server/game.functions'
import { getRoom, leaveRoom, moveToken, rollDice, sendChat, startWithBots } from '@/server/game.functions'
import { inviteToRoom, listFriends } from '@/server/social.functions'
import { StakeBanner } from './entry-picker'
import { BoardView, COLOR_VAR, Dice, WinOverlay } from './ludo-board'

const STEP_MS = 130
const EMOJIS = ['😀', '😂', '😎', '😡', '😭', '👍', '🔥', '🎲', 'GG!', 'Nice move!']

interface Msg {
  id: number
  name: string
  text: string
  me: boolean
}

export function OnlineGame({ initial, onExit }: { initial: RoomView; onExit: () => void }) {
  const [room, setRoom] = useState<RoomView>(initial)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [anim, setAnim] = useState<{ p: number; t: number; pos: number } | null>(null)
  const [rolling, setRolling] = useState(false)
  const [face, setFace] = useState(6)
  const [busy, setBusy] = useState(false)
  const [now, setNow] = useState(() => Date.now())
  const seen = useRef({ roll: initial.state?.lastRoll?.n ?? 0, move: initial.state?.lastMove?.n ?? 0, msg: 0 })
  const [skew, setSkew] = useState(0)

  const apply = (r: RoomView) => {
    setSkew(new Date(r.serverNow).getTime() - Date.now())
    const st = r.state
    if (st?.lastRoll && st.lastRoll.n > seen.current.roll) {
      seen.current.roll = st.lastRoll.n
      const v = st.lastRoll.value
      setRolling(true)
      let k = 0
      const iv = window.setInterval(() => {
        setFace(1 + Math.floor(Math.random() * 6))
        if (++k > 5) {
          clearInterval(iv)
          setRolling(false)
          setFace(v)
        }
      }, 70)
    }
    if (st?.lastMove && st.lastMove.n > seen.current.move) {
      seen.current.move = st.lastMove.n
      const { seat, token, from, to } = st.lastMove
      const steps = from < 0 ? [0] : Array.from({ length: Math.max(0, to - from) }, (_, i) => from + i + 1)
      steps.forEach((pos, i) => window.setTimeout(() => setAnim({ p: seat, t: token, pos }), i * STEP_MS))
      window.setTimeout(() => {
        setAnim(null)
      }, steps.length * STEP_MS + 40)
    }
    setRoom(r)
  }

  // Poll the authoritative server state. Each poll also advances bots / timeouts server-side.
  useEffect(() => {
    let alive = true
    let t: number
    const loop = async () => {
      try {
        const r = await getRoom({ data: { roomId: room.id, sinceMessage: seen.current.msg } })
        if (!alive) return
        apply(r.room)
        if (r.messages.length) {
          seen.current.msg = r.messages[r.messages.length - 1]!.id
          setMsgs((m) => [...m, ...r.messages].slice(-60))
        }
      } catch (e) {
        if (alive) toast.error(errMsg(e))
      }
      if (alive && room.status !== 'finished') t = window.setTimeout(loop, document.visibilityState === 'visible' ? 900 : 4000)
    }
    t = window.setTimeout(loop, 300)
    return () => {
      alive = false
      clearTimeout(t)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room.id, room.status === 'finished'])

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 500)
    return () => clearInterval(id)
  }, [])

  const act = async (fn: () => Promise<RoomView>) => {
    if (busy) return
    setBusy(true)
    try {
      apply(await fn())
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  const leave = async () => {
    const msg =
      room.stake.entryFee > 0
        ? `Leave the match? You forfeit your ${room.stake.entryFee.toLocaleString()}-coin entry.`
        : 'Leave the match? A bot will take over your seat and it counts as a loss.'
    if (room.status === 'playing' && !confirm(msg)) return
    await leaveRoom({ data: { roomId: room.id } }).catch(() => undefined)
    onExit()
  }

  if (room.status === 'waiting') return <WaitingRoom room={room} onUpdate={apply} onLeave={leave} />
  if (room.status === 'abandoned' || room.status === 'cancelled' || !room.state) {
    return (
      <div className="glass mx-auto max-w-md rounded-2xl p-8 text-center">
        <h2 className="text-2xl font-extrabold">{room.status === 'cancelled' ? 'Match cancelled' : 'Room closed'}</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          {room.cancelReason ?? 'This room is no longer active.'}
          {room.stake.entryFee > 0 && (room.stake.stakeStatus === 'refunded' ? ' All entries were refunded.' : ' No coins were deducted.')}
        </p>
        <Button className="mt-6 rounded-full" onClick={onExit}>
          Back to lobby
        </Button>
      </div>
    )
  }

  const g = room.state.game
  const current = g.players[g.turn]!
  const myTurn = room.mySeat === g.turn && room.status === 'playing'
  const canMove = myTurn && g.dice !== null && !anim
  const movable = canMove ? movableTokens(g.players[room.mySeat]!, g.dice!) : []
  const deadline = room.turnDeadline ? new Date(room.turnDeadline).getTime() - skew : null
  const secs = deadline ? Math.max(0, Math.ceil((deadline - now) / 1000)) : null
  const myTeam = room.mySeat >= 0 ? g.players[room.mySeat]!.team : -1
  const winners = g.players.filter((p) => p.team === g.winnerTeam)
  const over = room.status === 'finished' && !anim

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
      <div className="relative mx-auto w-full max-w-[min(100%,82vh)]">
        <BoardView
          game={g}
          movable={movable}
          anim={anim}
          activeColor={room.status === 'playing' ? current.color : null}
          onToken={(t) => act(() => moveToken({ data: { roomId: room.id, token: t } }))}
        />
        {over && (
          <WinOverlay
            youWon={g.winnerTeam === myTeam}
            names={winners.map((w) => w.name).join(' & ')}
            note={
              room.stake.entryFee > 0
                ? room.stake.stakeStatus === 'paid'
                  ? `Server-verified result. Prize of ${room.stake.prize.toLocaleString()} coins paid (fee ${room.stake.fee.toLocaleString()}).`
                  : 'Verifying the result and paying the prize…'
                : 'Result saved to your game history and leaderboard rating.'
            }
            onExit={onExit}
          />
        )}
      </div>

      <aside className="space-y-4">
        <StakeBanner stake={room.stake} seats={room.seats.length} />
        <div className="glass rounded-2xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-bold tracking-wider text-muted-foreground uppercase">
              Live · {room.mode === '1v1' ? '1 vs 1' : room.mode === '2v2' ? '2 vs 2 Teams' : '4 players'} · #{room.code}
            </span>
            <button onClick={leave} className="flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground">
              <ArrowLeft className="size-3" /> Leave
            </button>
          </div>
          <ul className="space-y-2">
            {g.players.map((p, i) => (
              <li
                key={p.color}
                className={cn(
                  'flex items-center gap-3 rounded-xl px-3 py-2 transition',
                  i === g.turn && room.status === 'playing' ? 'bg-white/10 ring-1 ring-white/20' : 'opacity-75',
                )}
              >
                <span className="size-4 rounded-full ring-2 ring-white" style={{ background: COLOR_VAR[p.color] }} />
                <span className="flex-1 truncate text-sm font-semibold">
                  {p.name}
                  {room.seats[i]?.me && <span className="ml-1 text-primary">(you)</span>}
                  {room.mode === '2v2' && <span className="ml-2 text-[10px] font-bold text-muted-foreground uppercase">Team {p.team === 0 ? 'A' : 'B'}</span>}
                </span>
                <span className="text-xs text-muted-foreground tabular-nums">{p.tokens.filter((t) => t === FINISH).length}/4</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="glass flex flex-col items-center gap-4 rounded-2xl p-5">
          <Dice value={face} rolling={rolling} color={COLOR_VAR[current.color]} />
          {secs !== null && room.status === 'playing' && (
            <div className={cn('flex items-center gap-1 text-xs font-bold', secs <= 5 ? 'text-ludo-red' : 'text-muted-foreground')}>
              <Timer className="size-3.5" /> {secs}s {myTurn ? 'left for your move' : `· ${current.name}`}
            </div>
          )}
          <Button
            size="lg"
            className="h-12 w-full rounded-xl text-base font-bold"
            disabled={!myTurn || g.dice !== null || busy || rolling}
            onClick={() => act(() => rollDice({ data: { roomId: room.id } }))}
          >
            {room.status === 'finished'
              ? 'Game over'
              : !myTurn
                ? `${current.name} is playing…`
                : g.dice !== null
                  ? 'Tap a glowing token'
                  : 'Roll the dice'}
          </Button>
          <p className="text-center text-xs text-muted-foreground">
            Dice are rolled on the server and every move is validated — no client can cheat. Miss 3 turns and a bot takes over.
          </p>
        </div>

        <Chat roomId={room.id} msgs={msgs} canChat={room.mySeat >= 0} />

        <div className="glass max-h-40 overflow-y-auto rounded-2xl p-4 text-xs">
          <div className="mb-2 font-bold tracking-wider text-muted-foreground uppercase">Match log</div>
          <ul className="space-y-1">
            {[...g.log].reverse().slice(0, 12).map((l, i) => (
              <li key={`${i}-${l}`} className={cn(i === 0 ? 'text-foreground' : 'text-muted-foreground')}>
                {l}
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  )
}

export function Chat({ roomId, msgs, canChat }: { roomId: string; msgs: Msg[]; canChat: boolean }) {
  const [text, setText] = useState('')
  const box = useRef<HTMLDivElement>(null)
  useEffect(() => {
    box.current?.scrollTo({ top: box.current.scrollHeight })
  }, [msgs.length])
  const send = async (t: string) => {
    if (!t.trim()) return
    try {
      await sendChat({ data: { roomId, text: t } })
      setText('')
    } catch (e) {
      toast.error(errMsg(e))
    }
  }
  return (
    <div className="glass rounded-2xl p-4">
      <div className="mb-2 flex items-center gap-2 text-xs font-bold tracking-wider text-muted-foreground uppercase">
        <MessageCircle className="size-3.5" /> Chat
      </div>
      <div ref={box} className="h-32 space-y-1 overflow-y-auto text-sm">
        {msgs.length === 0 && <p className="text-xs text-muted-foreground">Say hi to your opponents 👋</p>}
        {msgs.map((m) => (
          <div key={m.id} className={cn(m.me && 'text-primary')}>
            <span className="font-semibold">{m.name}:</span> {m.text}
          </div>
        ))}
      </div>
      {canChat && (
        <>
          <div className="mt-2 flex flex-wrap gap-1">
            {EMOJIS.map((e) => (
              <button key={e} onClick={() => send(e)} className="rounded-lg bg-white/5 px-2 py-1 text-xs hover:bg-white/15">
                {e}
              </button>
            ))}
          </div>
          <form
            className="mt-2 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault()
              void send(text)
            }}
          >
            <Input value={text} onChange={(e) => setText(e.target.value)} maxLength={200} placeholder="Message…" className="h-9" />
            <Button size="icon" type="submit" className="size-9 shrink-0" aria-label="Send">
              <Send />
            </Button>
          </form>
        </>
      )}
    </div>
  )
}

function WaitingRoom({ room, onUpdate, onLeave }: { room: RoomView; onUpdate: (r: RoomView) => void; onLeave: () => void }) {
  const friends = useServer(() => listFriends())
  const [busy, setBusy] = useState(false)
  const link = typeof window !== 'undefined' ? `${window.location.origin}/app/play?code=${room.code}` : ''
  const filled = room.seats.filter((s) => s.filled).length
  return (
    <div className="mx-auto grid max-w-3xl gap-4 md:grid-cols-2">
      <div className="glass rounded-2xl p-6">
        <div className="text-xs font-bold tracking-wider text-muted-foreground uppercase">{room.isPrivate ? 'Private room' : 'Matchmaking'}</div>
        <h2 className="mt-1 text-2xl font-extrabold">
          {room.isPrivate ? 'Waiting for friends' : 'Finding opponents…'} ({filled}/{room.seats.length})
        </h2>
        <div className="mt-3">
          <StakeBanner stake={room.stake} seats={room.seats.length} />
        </div>
        <div className="mt-4 rounded-xl bg-white/5 p-4">
          <div className="text-xs text-muted-foreground">Room code</div>
          <div className="flex items-center justify-between">
            <span className="font-display text-3xl font-extrabold tracking-[0.3em]">{room.code}</span>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                void navigator.clipboard?.writeText(link)
                toast.success('Room link copied')
              }}
            >
              <Copy /> Copy link
            </Button>
          </div>
          {room.hasPassword && <div className="mt-1 text-xs text-muted-foreground">Password protected — share the password with your friends.</div>}
          <a
            className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-ludo-green hover:underline"
            href={`https://wa.me/?text=${encodeURIComponent(`Join my Ludo King Arena room ${room.code}${room.stake.entryFee ? ` (${room.stake.entryFee} coin entry)` : ''}: ${link}`)}`}
            target="_blank"
            rel="noreferrer"
          >
            <Share2 className="size-3.5" /> Share on WhatsApp
          </a>
        </div>
        <ul className="mt-4 space-y-2">
          {room.seats.map((s, i) => (
            <li key={i} className="flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2 text-sm">
              {s.filled ? <Avatar initials={initialsOf(s.name)} className="size-8" /> : <span className="size-8 animate-pulse rounded-full bg-white/10" />}
              <span className={cn('font-semibold', !s.filled && 'text-muted-foreground')}>{s.filled ? s.name : 'Open seat'}</span>
              {s.me && <span className="text-xs text-primary">(you)</span>}
              {room.stake.entryFee > 0 && s.filled && <span className="ml-auto text-[10px] font-bold text-ludo-green uppercase">Entry agreed ✓</span>}
            </li>
          ))}
        </ul>
        {room.stake.entryFee > 0 ? (
          <p className="mt-3 text-xs text-muted-foreground">
            Coin matches start automatically when every seat is taken by a real player. Coins are deducted only at that moment. Leave any time before then at no cost.
          </p>
        ) : (
          !room.isPrivate && <p className="mt-3 text-xs text-muted-foreground">If no one joins within ~25 seconds, bots fill the empty seats.</p>
        )}
        <div className="mt-5 flex gap-2">
          {room.isHost && room.stake.entryFee === 0 && (
            <Button
              className="flex-1 rounded-xl font-bold"
              disabled={busy}
              onClick={async () => {
                setBusy(true)
                try {
                  onUpdate(await startWithBots({ data: { roomId: room.id } }))
                } catch (e) {
                  toast.error(errMsg(e))
                }
                setBusy(false)
              }}
            >
              <Bot /> Start now{filled < room.seats.length ? ' (fill with bots)' : ''}
            </Button>
          )}
          <Button variant="outline" className="rounded-xl" onClick={onLeave}>
            Leave
          </Button>
        </div>
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="flex items-center gap-2 font-bold">
          <UserPlus className="size-4 text-primary" /> Invite friends
        </h3>
        {friends.data?.friends.length === 0 && <p className="mt-3 text-sm text-muted-foreground">Add friends on the Friends page to invite them here.</p>}
        <ul className="mt-3 space-y-2">
          {friends.data?.friends.map((f) => (
            <li key={f.id} className="flex items-center gap-3">
              <Avatar initials={initialsOf(f.name)} src={f.avatarUrl} status={f.online ? 'online' : 'offline'} className="size-8" />
              <span className="flex-1 text-sm font-semibold">{f.name}</span>
              <Button
                size="xs"
                variant="secondary"
                onClick={() =>
                  inviteToRoom({ data: { userId: f.id, roomId: room.id } })
                    .then(() => toast.success(`Invite sent to ${f.name}`))
                    .catch((e) => toast.error(errMsg(e)))
                }
              >
                Invite
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
