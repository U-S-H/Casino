import { useEffect, useMemo, useRef, useState, type ComponentType } from 'react'
import { ArrowLeft, Copy, Flag, Handshake, Loader2, Share2, Timer, Trophy, UserPlus, X } from 'lucide-react'
import { toast } from 'sonner'

import { Avatar } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { errMsg, initialsOf, useServer } from '@/lib/client'
import { GAME_INFO } from '@/lib/games/catalog'
import type { BoardProps } from '@/lib/games/types'
import { cn } from '@/lib/utils'
import { arenaAct, getRoom, leaveRoom, reportMatch, type RoomView } from '@/server/game.functions'
import { inviteToRoom, listFriends } from '@/server/social.functions'
import { CarromBoard } from './carrom-board'
import { ChessBoard } from './chess-board'
import { StakeBanner } from './entry-picker'
import { Chat } from './online-game'
import { PoolTable } from './pool-table'

type AnyBoard = ComponentType<BoardProps<never, never>>
export const BOARDS: Record<'pool' | 'carrom' | 'chess', AnyBoard> = {
  pool: PoolTable as unknown as AnyBoard,
  carrom: CarromBoard as unknown as AnyBoard,
  chess: ChessBoard as unknown as AnyBoard,
}

interface Msg {
  id: number
  name: string
  text: string
  me: boolean
}

/** Live 2-player arena match (8 Ball Pool, Carrom, Chess). All state is server-authoritative; we poll it. */
export function ArenaMatch({ initial, onExit }: { initial: RoomView; onExit: () => void }) {
  const [room, setRoom] = useState<RoomView>(initial)
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [busy, setBusy] = useState(false)
  const [now, setNow] = useState(() => Date.now())
  const [skew, setSkew] = useState(0)
  const [reporting, setReporting] = useState(false)
  const lastMsg = useRef(0)
  const game = room.game as 'pool' | 'carrom' | 'chess'
  const Board = BOARDS[game]

  const apply = (r: RoomView) => {
    setSkew(new Date(r.serverNow).getTime() - Date.now())
    setRoom((prev) => (r.version >= prev.version ? r : prev))
  }

  const done = room.status === 'finished' || room.status === 'cancelled' || room.status === 'abandoned'
  const settled = room.stake.entryFee === 0 || ['paid', 'refunded', 'cancelled'].includes(room.stake.stakeStatus)
  useEffect(() => {
    let alive = true
    let t: number
    const loop = async () => {
      try {
        const r = await getRoom({ data: { roomId: room.id, sinceMessage: lastMsg.current } })
        if (!alive) return
        apply(r.room)
        if (r.messages.length) {
          lastMsg.current = r.messages[r.messages.length - 1]!.id
          setMsgs((m) => [...m, ...r.messages].slice(-60))
        }
      } catch (e) {
        if (alive) toast.error(errMsg(e))
      }
      if (alive) t = window.setTimeout(loop, document.visibilityState === 'visible' ? 1000 : 4000)
    }
    if (!(done && settled)) t = window.setTimeout(loop, 300)
    return () => {
      alive = false
      clearTimeout(t)
    }
  }, [room.id, done, settled])

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 500)
    return () => clearInterval(id)
  }, [])

  const state = useMemo(() => (room.arena ? (JSON.parse(room.arena.json) as Record<string, unknown>) : null), [room.arena])

  const act = async (action: Record<string, unknown>) => {
    if (busy) return
    setBusy(true)
    try {
      apply(await arenaAct({ data: { roomId: room.id, action } }))
    } catch (e) {
      toast.error(errMsg(e))
      // Re-sync the board after a rejected action.
      getRoom({ data: { roomId: room.id, sinceMessage: lastMsg.current } }).then((r) => apply(r.room)).catch(() => undefined)
    } finally {
      setBusy(false)
    }
  }

  const leave = async () => {
    if (room.status === 'playing') {
      const msg = room.stake.entryFee > 0 ? `Leave and forfeit? Your opponent wins the ${room.stake.prize.toLocaleString()}-coin prize.` : 'Leave and forfeit the match?'
      if (!confirm(msg)) return
    }
    await leaveRoom({ data: { roomId: room.id } }).catch(() => undefined)
    onExit()
  }

  if (room.status === 'waiting') return <ArenaWaiting room={room} onLeave={leave} />
  if (!state || room.status === 'cancelled' || room.status === 'abandoned') {
    return (
      <div className="glass mx-auto max-w-md rounded-2xl p-8 text-center">
        <h2 className="text-2xl font-extrabold">{room.status === 'cancelled' ? 'Match cancelled' : 'Room closed'}</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          {room.cancelReason ?? 'This room is no longer active.'}
          {room.stake.entryFee > 0 && (room.stake.stakeStatus === 'refunded' ? ' All entries were refunded.' : ' No coins were deducted.')}
        </p>
        <Button className="mt-6 rounded-full" onClick={onExit}>
          Back to lobby
        </Button>
      </div>
    )
  }

  const names: [string, string] = [room.seats[0]?.name ?? 'Player 1', room.seats[1]?.name ?? 'Player 2']
  const turn = Number((state as { turn?: number }).turn ?? 0)
  const myTurn = room.status === 'playing' && room.mySeat === turn
  const deadline = room.turnDeadline ? new Date(room.turnDeadline).getTime() - skew : null
  const secs = deadline ? Math.max(0, Math.ceil((deadline - now) / 1000)) : null
  const outcome = room.arena?.outcome
  const youWon = !!outcome && outcome.winner !== null && outcome.winner === room.mySeat
  const chess = game === 'chess'
  const drawOffer = chess ? ((state as { drawOffer?: number | null }).drawOffer ?? null) : null

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
      <div className="relative mx-auto w-full min-w-0">
        <Board state={state as never} mySeat={room.mySeat} canAct={myTurn && !busy} onAction={(a) => void act(a as unknown as Record<string, unknown>)} names={names} />
        {room.status === 'finished' && outcome && (
          <div className="mt-4 rounded-2xl bg-gradient-to-br from-primary/25 to-card p-6 text-center ring-1 ring-primary/40">
            <Trophy className="mx-auto size-12 text-primary" />
            <h2 className="mt-2 font-display text-3xl font-extrabold">{outcome.winner === null ? 'Draw' : youWon ? 'You win!' : room.mySeat < 0 ? `${names[outcome.winner]} wins` : 'You lost'}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{outcome.reason}</p>
            {room.stake.entryFee > 0 && (
              <p className="mt-2 text-sm font-semibold">
                {room.stake.stakeStatus === 'paid'
                  ? outcome.winner === null
                    ? 'Entries were returned to both players.'
                    : `Server-verified result · ${room.stake.prize.toLocaleString()} coins paid to ${names[outcome.winner]} (fee ${room.stake.fee.toLocaleString()}).`
                  : (
                    <span className="inline-flex items-center gap-1"><Loader2 className="size-4 animate-spin" /> Verifying result and paying the prize…</span>
                  )}
              </p>
            )}
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <Button className="rounded-full font-bold" onClick={onExit}>Back to lobby</Button>
              {room.mySeat >= 0 && !room.disputed && (
                <Button variant="outline" className="rounded-full" onClick={() => setReporting(true)}>
                  <Flag /> Report a problem
                </Button>
              )}
            </div>
          </div>
        )}
      </div>

      <aside className="space-y-4">
        <StakeBanner stake={room.stake} seats={room.seats.length} />
        <div className="glass rounded-2xl p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-bold tracking-wider text-muted-foreground uppercase">
              {GAME_INFO[game].name} · {room.mode} · #{room.code}
            </span>
            {room.status === 'playing' && (
              <button onClick={leave} className="flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground">
                <ArrowLeft className="size-3" /> Leave
              </button>
            )}
          </div>
          <ul className="space-y-2">
            {room.seats.map((s, i) => (
              <li key={i} className={cn('flex items-center gap-3 rounded-xl px-3 py-2 transition', i === turn && room.status === 'playing' ? 'bg-white/10 ring-1 ring-primary/40' : 'opacity-75')}>
                <Avatar initials={initialsOf(s.name)} className="size-8" />
                <span className="flex-1 truncate text-sm font-semibold">
                  {s.name} {s.me && <span className="text-primary">(you)</span>}
                </span>
                {s.missed > 0 && room.status === 'playing' && <span className="text-[10px] font-bold text-ludo-red">{s.missed} missed</span>}
                {i === turn && room.status === 'playing' && <span className="size-2 animate-pulse rounded-full bg-primary" />}
              </li>
            ))}
          </ul>
          {secs !== null && room.status === 'playing' && (
            <div className={cn('mt-3 flex items-center justify-center gap-1 text-sm font-bold', secs <= 10 ? 'text-ludo-red' : 'text-muted-foreground')}>
              <Timer className="size-4" /> {secs}s {myTurn ? '— your turn' : `· ${names[turn]}’s turn`}
            </div>
          )}
          <p className="mt-2 text-center text-[11px] text-muted-foreground">
            Every {chess ? 'move' : 'shot'} is checked by the server{chess ? '' : ', which also runs the physics'}. Three missed turns in a row forfeits the match.
          </p>
        </div>

        {chess && room.status === 'playing' && room.mySeat >= 0 && (
          <div className="glass space-y-2 rounded-2xl p-4">
            {drawOffer !== null && drawOffer !== room.mySeat ? (
              <div className="space-y-2">
                <p className="text-sm font-semibold">{names[drawOffer]} offers a draw.</p>
                <div className="flex gap-2">
                  <Button className="flex-1" disabled={busy} onClick={() => act({ type: 'acceptDraw' })}><Handshake /> Accept</Button>
                  <Button className="flex-1" variant="outline" disabled={busy} onClick={() => act({ type: 'declineDraw' })}><X /> Decline</Button>
                </div>
              </div>
            ) : (
              <Button variant="secondary" className="w-full" disabled={busy || drawOffer === room.mySeat} onClick={() => act({ type: 'offerDraw' })}>
                <Handshake /> {drawOffer === room.mySeat ? 'Draw offered…' : 'Offer draw'}
              </Button>
            )}
            <Button variant="destructive" className="w-full" disabled={busy} onClick={() => confirm('Resign this game?') && act({ type: 'resign' })}>
              <Flag /> Resign
            </Button>
          </div>
        )}

        <Chat roomId={room.id} msgs={msgs} canChat={room.mySeat >= 0} />
        {room.disputed && <p className="text-center text-xs text-ludo-yellow">This match was reported and is being reviewed by an admin.</p>}
      </aside>

      {reporting && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => setReporting(false)}>
          <form
            className="glass w-full max-w-md space-y-3 rounded-2xl p-5"
            onClick={(e) => e.stopPropagation()}
            onSubmit={async (e) => {
              e.preventDefault()
              const reason = String(new FormData(e.currentTarget).get('reason') ?? '')
              try {
                await reportMatch({ data: { roomId: room.id, reason } })
                toast.success('Report sent to the admins')
                setReporting(false)
                setRoom((r) => ({ ...r, disputed: true }))
              } catch (err) {
                toast.error(errMsg(err))
              }
            }}
          >
            <h3 className="text-lg font-bold">Report this match</h3>
            <Textarea name="reason" required minLength={5} maxLength={500} placeholder="What went wrong?" />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setReporting(false)}>Cancel</Button>
              <Button type="submit">Send report</Button>
            </div>
          </form>
        </div>
      )}
    </div>
  )
}

function ArenaWaiting({ room, onLeave }: { room: RoomView; onLeave: () => void }) {
  const friends = useServer(() => listFriends())
  const link = typeof window !== 'undefined' ? `${window.location.origin}/app/arena/${room.game}?code=${room.code}` : ''
  const filled = room.seats.filter((s) => s.filled).length
  const name = GAME_INFO[room.game].name
  return (
    <div className="mx-auto grid max-w-3xl gap-4 md:grid-cols-2">
      <div className="glass rounded-2xl p-6">
        <div className="text-xs font-bold tracking-wider text-muted-foreground uppercase">{room.isPrivate ? 'Private room' : 'Matchmaking'} · {name}</div>
        <h2 className="mt-1 flex items-center gap-2 text-2xl font-extrabold">
          <Loader2 className="size-5 animate-spin text-primary" /> {room.isPrivate ? 'Waiting for your friend' : 'Finding an opponent…'} ({filled}/{room.seats.length})
        </h2>
        <div className="mt-3">
          <StakeBanner stake={room.stake} seats={room.seats.length} />
        </div>
        <div className="mt-4 rounded-xl bg-white/5 p-4">
          <div className="text-xs text-muted-foreground">Room code</div>
          <div className="flex items-center justify-between gap-2">
            <span className="font-display text-3xl font-extrabold tracking-[0.3em]">{room.code}</span>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                void navigator.clipboard?.writeText(link)
                toast.success('Room link copied')
              }}
            >
              <Copy /> Copy link
            </Button>
          </div>
          {room.hasPassword && <div className="mt-1 text-xs text-muted-foreground">Password protected — share the password too.</div>}
          <a
            className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-ludo-green hover:underline"
            href={`https://wa.me/?text=${encodeURIComponent(`Play ${name} with me on Ludo King Arena — room ${room.code}${room.stake.entryFee ? ` (${room.stake.entryFee} coin entry)` : ''}: ${link}`)}`}
            target="_blank"
            rel="noreferrer"
          >
            <Share2 className="size-3.5" /> Share on WhatsApp
          </a>
        </div>
        <ul className="mt-4 space-y-2">
          {room.seats.map((s, i) => (
            <li key={i} className="flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2 text-sm">
              {s.filled ? <Avatar initials={initialsOf(s.name)} className="size-8" /> : <span className="size-8 animate-pulse rounded-full bg-white/10" />}
              <span className={cn('font-semibold', !s.filled && 'text-muted-foreground')}>{s.filled ? s.name : 'Open seat'}</span>
              {s.me && <span className="text-xs text-primary">(you)</span>}
              {room.stake.entryFee > 0 && s.filled && <span className="ml-auto text-[10px] font-bold text-ludo-green uppercase">Entry agreed ✓</span>}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-muted-foreground">
          The match starts automatically when your opponent joins{room.stake.entryFee > 0 ? ' — entries are deducted only then. Leave before that and nothing is charged' : ''}.
        </p>
        <Button variant="outline" className="mt-4 w-full rounded-xl" onClick={onLeave}>
          {room.isHost && filled === 1 ? 'Cancel room' : 'Leave'}
        </Button>
      </div>
      <div className="glass rounded-2xl p-6">
        <h3 className="flex items-center gap-2 font-bold">
          <UserPlus className="size-4 text-primary" /> Invite friends
        </h3>
        {friends.data?.friends.length === 0 && <p className="mt-3 text-sm text-muted-foreground">Add friends on the Friends page to invite them here.</p>}
        <ul className="mt-3 space-y-2">
          {friends.data?.friends.map((f) => (
            <li key={f.id} className="flex items-center gap-3">
              <Avatar initials={initialsOf(f.name)} src={f.avatarUrl} status={f.online ? 'online' : 'offline'} className="size-8" />
              <span className="flex-1 text-sm font-semibold">{f.name}</span>
              <Button
                size="xs"
                variant="secondary"
                onClick={() =>
                  inviteToRoom({ data: { userId: f.id, roomId: room.id } })
                    .then(() => toast.success(`Invite sent to ${f.name}`))
                    .catch((e) => toast.error(errMsg(e)))
                }
              >
                Invite
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
