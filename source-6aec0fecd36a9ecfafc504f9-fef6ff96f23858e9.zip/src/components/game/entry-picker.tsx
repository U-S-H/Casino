import { useState } from 'react'
import { AlertTriangle, Coins as CoinsIcon, Lock, Trophy, Wallet } from 'lucide-react'
import { Link } from '@tanstack/react-router'

import { Coins } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { entryError, GAME_INFO, prizeMath, type GameConfig, type GameKey } from '@/lib/games/catalog'
import { cn } from '@/lib/utils'

/**
 * Coin-entry selector shared by all four games. Numbers shown here are a
 * preview only — the server re-validates the amount, the balance and the fee.
 */
export function EntryPicker({
  cfg,
  balance,
  players,
  value,
  onChange,
}: {
  cfg: GameConfig
  balance: number
  players: number
  value: number
  onChange: (v: number) => void
}) {
  const [custom, setCustom] = useState('')
  const presets = cfg.presets.filter((p) => p >= cfg.minEntry && p <= cfg.maxEntry)
  const err = value > 0 ? entryError(cfg, value) : null
  const short = value > balance
  const m = prizeMath(value, players, cfg.feePercent)
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
        <span className="font-bold">Select entry coins</span>
        <span className="flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 text-xs ring-1 ring-white/10">
          <Wallet className="size-3.5 text-primary" /> Available <Coins value={balance} />
        </span>
      </div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
        <button
          type="button"
          onClick={() => {
            setCustom('')
            onChange(0)
          }}
          className={cn('rounded-xl px-2 py-3 text-sm font-bold ring-1 ring-white/10 transition hover:bg-white/10', value === 0 && 'bg-ludo-green/15 text-ludo-green ring-2 ring-ludo-green')}
        >
          Free play
        </button>
        {cfg.entryEnabled &&
          presets.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => {
                setCustom('')
                onChange(p)
              }}
              className={cn(
                'flex items-center justify-center gap-1 rounded-xl px-2 py-3 text-sm font-bold tabular-nums ring-1 ring-white/10 transition hover:bg-white/10',
                value === p && !custom && 'bg-primary/15 text-primary ring-2 ring-primary',
                p > balance && 'opacity-50',
              )}
            >
              <span className="coin" aria-hidden /> {p >= 1000 ? `${p / 1000}K` : p}
            </button>
          ))}
      </div>
      {cfg.entryEnabled && cfg.customAmounts && (
        <div className="space-y-1">
          <label className="text-xs font-semibold text-muted-foreground" htmlFor="custom-entry">
            Or enter a custom amount
          </label>
          <Input
            id="custom-entry"
            inputMode="numeric"
            placeholder={`${cfg.minEntry.toLocaleString()} – ${cfg.maxEntry.toLocaleString()}`}
            value={custom}
            onChange={(e) => {
              const raw = e.target.value.replace(/\D/g, '').slice(0, 7)
              setCustom(raw)
              onChange(raw ? Number(raw) : 0)
            }}
          />
        </div>
      )}
      <p className="text-xs text-muted-foreground">
        {cfg.entryEnabled ? (
          <>
            Entry limits: <b className="text-foreground">{cfg.minEntry.toLocaleString()}</b> – <b className="text-foreground">{cfg.maxEntry.toLocaleString()}</b> virtual coins · platform fee {cfg.feePercent}%
          </>
        ) : (
          'Coin-entry matches are switched off for this game right now — free play only.'
        )}
      </p>
      {value > 0 && <PrizeSummary entry={value} players={players} feePercent={cfg.feePercent} pool={m.pool} fee={m.fee} prize={m.prize} />}
      {err && <p className="flex items-center gap-1.5 text-sm font-semibold text-ludo-red"><AlertTriangle className="size-4" /> {err}</p>}
      {!err && short && (
        <p className="flex flex-wrap items-center gap-1.5 text-sm font-semibold text-ludo-red">
          <AlertTriangle className="size-4" /> Not enough coins for this entry.
          <Link to="/app/deposit" className="underline">Top up</Link>
        </p>
      )}
    </div>
  )
}

/** True when the chosen amount can be submitted (UI check only; the server decides). */
export const entryOk = (cfg: GameConfig | undefined, value: number, balance: number) =>
  !!cfg && (value === 0 || (!entryError(cfg, value) && value <= balance))

export function PrizeSummary({ entry, players, feePercent, pool, fee, prize, className }: { entry: number; players: number; feePercent: number; pool: number; fee: number; prize: number; className?: string }) {
  return (
    <div className={cn('grid grid-cols-3 gap-2 rounded-xl bg-gradient-to-br from-primary/15 to-transparent p-3 text-center ring-1 ring-primary/30', className)}>
      <div>
        <div className="text-[10px] font-bold tracking-wider text-muted-foreground uppercase">Entry / player</div>
        <Coins value={entry} className="justify-center text-sm" />
      </div>
      <div>
        <div className="text-[10px] font-bold tracking-wider text-muted-foreground uppercase">Prize pool ×{players}</div>
        <Coins value={pool} className="justify-center text-sm" />
      </div>
      <div>
        <div className="text-[10px] font-bold tracking-wider text-primary uppercase">Winner gets</div>
        <Coins value={prize} className="justify-center text-sm text-primary" />
      </div>
      <div className="col-span-3 text-[11px] text-muted-foreground">
        Platform fee {feePercent}% = {fee.toLocaleString()} coins. Coins are deducted once, only when the match starts. Virtual coins only — no cash value.
      </div>
    </div>
  )
}

export interface RoomPreview {
  code: string
  game: GameKey
  mode: string
  hasPassword: boolean
  host: string
  filled: number
  seats: number
  stake: { entryFee: number; feePercent: number; pool: number; fee: number; prize: number }
  balance: number
}

/** "Review & confirm" step before joining a room: the player explicitly agrees to the locked entry. */
export function JoinConfirmDialog({
  preview,
  busy,
  onConfirm,
  onClose,
}: {
  preview: RoomPreview | null
  busy: boolean
  onConfirm: (p: RoomPreview) => void
  onClose: () => void
}) {
  const p = preview
  const short = !!p && p.stake.entryFee > p.balance
  return (
    <Dialog open={!!p} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        {p && (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Lock className="size-5 text-primary" /> Join {GAME_INFO[p.game].name} room #{p.code}
              </DialogTitle>
              <DialogDescription>
                Hosted by {p.host} · {p.filled}/{p.seats} seats filled · {p.mode}
              </DialogDescription>
            </DialogHeader>
            {p.stake.entryFee > 0 ? (
              <div className="space-y-3">
                <PrizeSummary entry={p.stake.entryFee} players={p.seats} feePercent={p.stake.feePercent} pool={p.stake.pool} fee={p.stake.fee} prize={p.stake.prize} />
                <div className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2 text-sm">
                  <span className="flex items-center gap-1.5 text-muted-foreground"><Wallet className="size-4" /> Your balance</span>
                  <Coins value={p.balance} />
                </div>
                <p className="text-xs text-muted-foreground">
                  The entry amount is locked by the host and cannot be changed. By confirming you agree to it. If the match is cancelled before it starts, nothing is deducted.
                </p>
                {short && <p className="text-sm font-semibold text-ludo-red">You don’t have enough coins for this entry.</p>}
              </div>
            ) : (
              <p className="flex items-center gap-2 rounded-xl bg-ludo-green/10 p-3 text-sm text-ludo-green"><Trophy className="size-4" /> Free match — no coins involved.</p>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button disabled={busy || short} onClick={() => onConfirm(p)} className="font-bold">
                <CoinsIcon /> {busy ? 'Joining…' : p.stake.entryFee > 0 ? `Confirm ${p.stake.entryFee.toLocaleString()} & join` : 'Join'}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

/** Live stake banner shown in waiting rooms and during matches. */
export function StakeBanner({ stake, seats }: { stake: { entryFee: number; pool: number; fee: number; prize: number; feePercent: number; stakeStatus: string }; seats: number }) {
  if (stake.entryFee <= 0) return null
  const label: Record<string, string> = {
    pending: 'Locked — deducted when the match starts',
    charged: 'Entries collected · prize held by the server',
    paid: 'Prize paid to the verified winner',
    refunded: 'Match voided · entries refunded',
    cancelled: 'Cancelled before start · nothing deducted',
  }
  return (
    <div className="rounded-2xl bg-gradient-to-br from-primary/20 to-transparent p-3 text-sm ring-1 ring-primary/30">
      <div className="flex items-center justify-between gap-2">
        <span className="flex items-center gap-1.5 font-bold"><Trophy className="size-4 text-primary" /> Prize <Coins value={stake.prize} className="text-primary" /></span>
        <span className="text-xs text-muted-foreground">Entry <Coins value={stake.entryFee} /> ×{seats}</span>
      </div>
      <div className="mt-1 text-[11px] text-muted-foreground">
        Pool {stake.pool.toLocaleString()} − fee {stake.fee.toLocaleString()} ({stake.feePercent}%) · {label[stake.stakeStatus] ?? stake.stakeStatus}
      </div>
    </div>
  )
}
