import { Link } from '@tanstack/react-router'
import { Coins as CoinsIcon, Play } from 'lucide-react'

import { CASINO_INFO, CASINO_KEYS, type CasinoConfig, type CasinoKey } from '@/lib/games/casino'
import { GAME_INFO, type ArenaConfig, type GameKey } from '@/lib/games/catalog'
import { cn } from '@/lib/utils'

/** Small hand-drawn SVG emblem for each game (no external assets). */
export function GameArt({ game, className }: { game: GameKey; className?: string }) {
  if (game === 'ludo')
    return (
      <svg viewBox="0 0 64 64" className={className} aria-hidden>
        <rect x="4" y="4" width="56" height="56" rx="10" fill="#fff" opacity=".95" />
        <rect x="6" y="6" width="22" height="22" rx="5" fill="var(--ludo-red)" />
        <rect x="36" y="6" width="22" height="22" rx="5" fill="var(--ludo-green)" />
        <rect x="6" y="36" width="22" height="22" rx="5" fill="var(--ludo-blue)" />
        <rect x="36" y="36" width="22" height="22" rx="5" fill="var(--ludo-yellow)" />
        <path d="M32 24 40 32 32 40 24 32Z" fill="#1a1a2e" opacity=".8" />
        {[17, 47].map((x) => [17, 47].map((y) => <circle key={`${x}${y}`} cx={x} cy={y} r="5" fill="#fff" opacity=".9" />))}
      </svg>
    )
  if (game === 'pool')
    return (
      <svg viewBox="0 0 64 64" className={className} aria-hidden>
        <defs>
          <radialGradient id="ga8" cx="35%" cy="30%" r="70%">
            <stop offset="0" stopColor="#555" />
            <stop offset="1" stopColor="#050505" />
          </radialGradient>
        </defs>
        <circle cx="32" cy="32" r="28" fill="url(#ga8)" />
        <circle cx="32" cy="30" r="12" fill="#fff" />
        <text x="32" y="36" textAnchor="middle" fontSize="16" fontWeight="900" fill="#111" fontFamily="system-ui">8</text>
        <ellipse cx="22" cy="18" rx="7" ry="4" fill="#fff" opacity=".25" />
      </svg>
    )
  if (game === 'carrom')
    return (
      <svg viewBox="0 0 64 64" className={className} aria-hidden>
        <rect x="3" y="3" width="58" height="58" rx="6" fill="#7a4a24" />
        <rect x="9" y="9" width="46" height="46" rx="2" fill="#f1d8a6" />
        {[
          [12, 12],
          [52, 12],
          [12, 52],
          [52, 52],
        ].map(([x, y]) => <circle key={`${x}${y}`} cx={x} cy={y} r="4.5" fill="#1d120a" />)}
        <circle cx="32" cy="32" r="10" fill="none" stroke="#a2472a" strokeWidth="1.5" />
        <circle cx="32" cy="32" r="4.5" fill="#d62f3a" />
        <circle cx="24" cy="30" r="4" fill="#fafafa" stroke="#333" strokeWidth=".6" />
        <circle cx="40" cy="34" r="4" fill="#222" />
        <circle cx="34" cy="23" r="4" fill="#222" />
        <circle cx="30" cy="41" r="4" fill="#fafafa" stroke="#333" strokeWidth=".6" />
      </svg>
    )
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      {Array.from({ length: 16 }, (_, i) => (
        <rect key={i} x={4 + (i % 4) * 14} y={4 + Math.floor(i / 4) * 14} width="14" height="14" fill={(i + Math.floor(i / 4)) % 2 ? '#8a5a2b' : '#f0d9b5'} />
      ))}
      <text x="32" y="47" textAnchor="middle" fontSize="44" fill="#fff" stroke="#111" strokeWidth="1.5" fontFamily="serif">♞</text>
    </svg>
  )
}

const GRAD: Record<GameKey, string> = {
  ludo: 'from-ludo-red/70',
  pool: 'from-ludo-green/70',
  carrom: 'from-ludo-yellow/70',
  chess: 'from-ludo-blue/70',
}

/** Emblems for the two live-round games. */
export function CasinoArt({ game, className }: { game: CasinoKey; className?: string }) {
  if (game === 'dragon_tiger')
    return (
      <svg viewBox="0 0 64 64" className={className} aria-hidden>
        <rect x="6" y="10" width="28" height="40" rx="4" fill="#fff" transform="rotate(-12 20 30)" />
        <text x="16" y="38" fontSize="18" fontWeight="900" fill="#d42a3a" fontFamily="system-ui" transform="rotate(-12 20 30)">K</text>
        <rect x="30" y="12" width="28" height="40" rx="4" fill="#fff" transform="rotate(12 44 32)" />
        <text x="40" y="40" fontSize="18" fontWeight="900" fill="#15151f" fontFamily="system-ui" transform="rotate(12 44 32)">A</text>
        <circle cx="32" cy="54" r="7" fill="var(--primary)" />
        <text x="32" y="58" textAnchor="middle" fontSize="9" fontWeight="900" fill="#1a1a2e" fontFamily="system-ui">VS</text>
      </svg>
    )
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <path d="M4 58 C 26 56, 42 44, 58 10" fill="none" stroke="#e8384f" strokeWidth="4" strokeLinecap="round" />
      <path d="M4 58 C 26 56, 42 44, 58 10 L58 58Z" fill="#e8384f" opacity=".25" />
      <g transform="translate(46 18) rotate(-40)">
        <path d="M12 0 Q8 -4 -10 -3 L-14 -8 L-17 -8 L-14 2 Q0 4 12 0Z" fill="#fff" />
        <path d="M3 1 L-5 9 L-8 9 L-4 1Z" fill="#ffd6dc" />
      </g>
    </svg>
  )
}

const CASINO_GRAD: Record<CasinoKey, string> = { dragon_tiger: 'from-ludo-red/60 via-accent/30', aviator: 'from-[oklch(0.55_0.22_15)]/70' }

/** Game cards: the four match games plus Dragon Tiger and Aviator. Each Play Now button opens a real, working game. */
export function GameCards({ config, casino, className }: { config?: ArenaConfig | null; casino?: CasinoConfig | null; className?: string }) {
  const keys: GameKey[] = ['ludo', 'pool', 'carrom', 'chess']
  return (
    <div className={cn('grid gap-4 sm:grid-cols-2 xl:grid-cols-3', className)}>
      {keys.map((k) => {
        const cfg = config?.[k]
        const off = cfg && !cfg.enabled
        const body = (
          <>
            <GameArt game={k} className="absolute -right-4 -bottom-4 size-32 rotate-12 opacity-25 transition group-hover:scale-110 group-hover:rotate-6" />
            <GameArt game={k} className="size-14 drop-shadow-lg" />
            <div className="mt-3 font-display text-2xl font-extrabold">{GAME_INFO[k].name}</div>
            <div className="text-sm opacity-80">{GAME_INFO[k].tagline}</div>
            <div className="mt-3 flex flex-wrap gap-1.5 text-[11px] font-semibold">
              <span className="rounded-full bg-black/25 px-2.5 py-1">Free play</span>
              {cfg?.entryEnabled !== false && (
                <span className="inline-flex items-center gap-1 rounded-full bg-black/25 px-2.5 py-1">
                  <CoinsIcon className="size-3" /> {(cfg?.minEntry ?? 200).toLocaleString()}–{(cfg?.maxEntry ?? 10000).toLocaleString()} entry
                </span>
              )}
            </div>
            <span className={cn('mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold', off ? 'bg-black/30 text-muted-foreground' : 'bg-primary text-primary-foreground shadow-lg')}>
              {off ? 'Temporarily unavailable' : (<><Play className="size-4" /> Play Now</>)}
            </span>
          </>
        )
        const cls = cn('group relative flex flex-col overflow-hidden rounded-2xl bg-gradient-to-br to-card p-5 ring-1 ring-white/10 transition', GRAD[k], off ? 'opacity-60' : 'hover:-translate-y-1')
        if (off) return <div key={k} className={cls}>{body}</div>
        return k === 'ludo' ? (
          <Link key={k} to="/app/play" className={cls}>{body}</Link>
        ) : (
          <Link key={k} to="/app/arena/$game" params={{ game: k }} className={cls}>{body}</Link>
        )
      })}
      {CASINO_KEYS.map((k) => {
        const cfg = casino?.[k]
        const off = cfg && (!cfg.enabled || cfg.paused)
        const info = CASINO_INFO[k]
        const cls = cn('group relative flex flex-col overflow-hidden rounded-2xl bg-gradient-to-br to-card p-5 ring-1 ring-white/10 transition', CASINO_GRAD[k], off ? 'opacity-60' : 'hover:-translate-y-1')
        const body = (
          <>
            <CasinoArt game={k} className="absolute -right-4 -bottom-4 size-32 rotate-12 opacity-25 transition group-hover:scale-110 group-hover:rotate-6" />
            <CasinoArt game={k} className="size-14 drop-shadow-lg" />
            <div className="mt-3 font-display text-2xl font-extrabold">{info.name}</div>
            <div className="text-sm opacity-80">{info.tagline}</div>
            <div className="mt-3 flex flex-wrap gap-1.5 text-[11px] font-semibold">
              <span className="rounded-full bg-black/25 px-2.5 py-1">Live rounds</span>
              <span className="inline-flex items-center gap-1 rounded-full bg-black/25 px-2.5 py-1">
                <CoinsIcon className="size-3" /> {(cfg?.minBet ?? 200).toLocaleString()}–{(cfg?.maxBet ?? 10000).toLocaleString()} bet
              </span>
              <span className="rounded-full bg-black/25 px-2.5 py-1">Provably fair</span>
            </div>
            <span className={cn('mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold', off ? 'bg-black/30 text-muted-foreground' : 'bg-primary text-primary-foreground shadow-lg')}>
              {off ? (cfg?.paused && cfg.enabled ? 'Paused for maintenance' : 'Temporarily unavailable') : (<><Play className="size-4" /> Play Now</>)}
            </span>
          </>
        )
        if (off) return <div key={k} className={cls}>{body}</div>
        return <Link key={k} to={info.path} className={cls}>{body}</Link>
      })}
    </div>
  )
}
