import { act, fireEvent, render, screen } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'

import { carromEngine, type CarromAction } from '@/lib/games/carrom'
import { DEFAULT_ARENA } from '@/lib/games/catalog'
import { chessEngine, type ChessAction } from '@/lib/games/chess'
import { poolEngine, type PoolAction } from '@/lib/games/pool'
import { CarromBoard } from './carrom-board'
import { ChessBoard } from './chess-board'
import { EntryPicker, entryOk } from './entry-picker'
import { PoolTable } from './pool-table'

vi.mock('@tanstack/react-router', () => ({ Link: ({ children }: { children: React.ReactNode }) => <a>{children}</a> }))

// jsdom lacks ResizeObserver (every supported browser has it).
globalThis.ResizeObserver ??= class {
  observe() {}
  unobserve() {}
  disconnect() {}
} as unknown as typeof ResizeObserver

const names: [string, string] = ['Ali', 'Sara']

describe('game boards', () => {
  it('chess: tapping a pawn then its target sends a legal move that the engine accepts', () => {
    const state = chessEngine.init(names, Math.random)
    const sent: ChessAction[] = []
    render(<ChessBoard state={state} mySeat={0} canAct onAction={(a) => sent.push(a)} names={names} />)
    fireEvent.click(screen.getByLabelText(/^e2/))
    fireEvent.click(screen.getByLabelText(/^e4/))
    expect(sent).toEqual([{ type: 'move', from: 'e2', to: 'e4' }])
    const r = chessEngine.apply(state, 0, chessEngine.parseAction(sent[0]))
    expect(r.state.turn).toBe(1)
  })

  it('chess: cannot select pieces when it is not your turn', () => {
    const state = chessEngine.init(names, Math.random)
    const sent: ChessAction[] = []
    render(<ChessBoard state={state} mySeat={1} canAct={false} onAction={(a) => sent.push(a)} names={names} />)
    fireEvent.click(screen.getByLabelText(/^e7/))
    fireEvent.click(screen.getByLabelText(/^e5/))
    expect(sent).toHaveLength(0)
  })

  it('pool: Shoot sends a valid shot the server engine accepts', () => {
    const state = poolEngine.init(names, () => 0.42)
    const sent: PoolAction[] = []
    render(<PoolTable state={state} mySeat={0} canAct onAction={(a) => sent.push(a)} names={names} />)
    fireEvent.click(screen.getByRole('button', { name: /shoot/i }))
    expect(sent).toHaveLength(1)
    const r = poolEngine.apply(state, 0, poolEngine.parseAction(sent[0]))
    expect(r.state.lastShot).toBeTruthy()
  })

  it('carrom: Strike sends a valid strike the server engine accepts', () => {
    const state = carromEngine.init(names, Math.random)
    const sent: CarromAction[] = []
    render(<CarromBoard state={state} mySeat={0} canAct onAction={(a) => sent.push(a)} names={names} />)
    fireEvent.click(screen.getByRole('button', { name: /strike/i }))
    expect(sent).toHaveLength(1)
    const r = carromEngine.apply(state, 0, carromEngine.parseAction(sent[0]))
    expect(r.state.lastStrike).toBeTruthy()
  })

  it('carrom & pool render for the opponent (seat 1 / rotated) without controls firing', () => {
    const sent: unknown[] = []
    render(<CarromBoard state={carromEngine.init(names, Math.random)} mySeat={1} canAct={false} onAction={(a) => sent.push(a)} names={names} />)
    render(<PoolTable state={poolEngine.init(names, Math.random)} mySeat={1} canAct={false} onAction={(a) => sent.push(a)} names={names} />)
    for (const b of screen.getAllByRole('button', { name: /strike|shoot/i })) fireEvent.click(b)
    expect(sent).toHaveLength(0)
  })
})

describe('entry picker', () => {
  it('shows limits, balance, prize pool and validates custom amounts', () => {
    const cfg = DEFAULT_ARENA.chess
    let v = 0
    const { rerender } = render(<EntryPicker cfg={cfg} balance={3000} players={2} value={v} onChange={(n) => (v = n)} />)
    expect(screen.getByText(/Available/)).toBeTruthy()
    expect(screen.getByText(/Entry limits/)).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: /1K/ }))
    expect(v).toBe(1000)
    rerender(<EntryPicker cfg={cfg} balance={3000} players={2} value={1000} onChange={(n) => (v = n)} />)
    expect(screen.getByText('Winner gets')).toBeTruthy()
    expect(screen.getByText('1,800')).toBeTruthy() // 2,000 pool − 10% fee
    act(() => {
      fireEvent.change(screen.getByLabelText(/custom amount/i), { target: { value: '150' } })
    })
    expect(v).toBe(150)
    rerender(<EntryPicker cfg={cfg} balance={3000} players={2} value={150} onChange={() => undefined} />)
    expect(screen.getByText(/Minimum entry is 200/)).toBeTruthy()
    expect(entryOk(cfg, 150, 3000)).toBe(false)
    expect(entryOk(cfg, 10001, 99999)).toBe(false)
    expect(entryOk(cfg, 5000, 3000)).toBe(false)
    expect(entryOk(cfg, 2500, 3000)).toBe(true)
    expect(entryOk(cfg, 0, 0)).toBe(true)
  })
})
