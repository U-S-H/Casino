import { cn } from '@/lib/utils'

export function Logo({ className, size = 'md' }: { className?: string; size?: 'sm' | 'md' | 'lg' }) {
  const box = size === 'lg' ? 'size-16' : size === 'sm' ? 'size-8' : 'size-10'
  const text = size === 'lg' ? 'text-3xl' : size === 'sm' ? 'text-base' : 'text-lg'
  return (
    <span className={cn('inline-flex items-center gap-2.5', className)}>
      <span className={cn('grid grid-cols-2 gap-0.5 rounded-xl p-1 bg-white/10 shadow-lg rotate-45', box)}>
        <span className="rounded-tl-md bg-ludo-red" />
        <span className="rounded-tr-md bg-ludo-green" />
        <span className="rounded-bl-md bg-ludo-blue" />
        <span className="rounded-br-md bg-ludo-yellow" />
      </span>
      <span className={cn('font-display font-extrabold leading-none', text)}>
        Ludo King <span className="gold-text">Arena</span>
      </span>
    </span>
  )
}

export function Coins({ value, className }: { value: number; className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 font-bold tabular-nums', className)}>
      <span className="coin" aria-hidden />
      {value.toLocaleString()}
    </span>
  )
}

const avatarColors = ['bg-ludo-red', 'bg-ludo-green', 'bg-ludo-blue', 'bg-ludo-yellow text-primary-foreground', 'bg-accent']

export function Avatar({
  initials,
  src,
  className,
  status,
}: {
  initials: string
  src?: string | null
  className?: string
  status?: 'online' | 'playing' | 'offline'
}) {
  const color = avatarColors[(initials.charCodeAt(0) + (initials.charCodeAt(1) || 0)) % avatarColors.length]
  return (
    <span className={cn('relative inline-grid size-10 shrink-0 place-items-center rounded-full font-bold text-sm text-white ring-2 ring-white/10', color, className)}>
      {src ? <img src={src} alt="" className="absolute inset-0 h-full w-full rounded-full object-cover" /> : initials}
      {status && (
        <span
          className={cn(
            'absolute -right-0.5 -bottom-0.5 size-3 rounded-full ring-2 ring-background',
            status === 'online' && 'bg-ludo-green',
            status === 'playing' && 'bg-ludo-yellow',
            status === 'offline' && 'bg-muted-foreground',
          )}
        />
      )}
    </span>
  )
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-extrabold md:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

export function Panel({ className, children }: { className?: string; children: React.ReactNode }) {
  return <section className={cn('glass rounded-2xl p-5', className)}>{children}</section>
}

export function img(path: string, w: number) {
  return `/.netlify/images?url=${encodeURIComponent(path)}&w=${w}&fm=webp`
}
