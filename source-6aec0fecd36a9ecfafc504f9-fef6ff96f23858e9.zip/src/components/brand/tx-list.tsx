import { ArrowDownLeft, ArrowUpRight, CalendarCheck, CircleSlash, Dices, Gamepad2, Gift, PartyPopper, RotateCcw, Sparkles, Swords, Trophy, UserPlus, Wrench } from 'lucide-react'

import { Badge } from '@/components/ui/badge'
import { fmtDate } from '@/lib/client'
import { cn } from '@/lib/utils'

const ICONS: Record<string, typeof Gift> = {
  deposit: ArrowDownLeft,
  withdrawal: ArrowUpRight,
  game_win: Gamepad2,
  game_entry: Swords,
  game_refund: RotateCcw,
  daily_reward: CalendarCheck,
  referral: UserPlus,
  promo: Sparkles,
  tournament: Trophy,
  welcome: Gift,
  adjustment: Wrench,
  casino_bet: Dices,
  casino_win: PartyPopper,
  casino_loss: CircleSlash,
  casino_refund: RotateCcw,
}

export interface TxItem {
  id: string
  type: string
  label: string
  amount: number
  status: string
  bucket?: string
  createdAt: Date | string
}

export function TxList({ items, empty = 'No transactions yet.' }: { items: TxItem[]; empty?: string }) {
  if (!items.length) return <p className="py-6 text-center text-sm text-muted-foreground">{empty}</p>
  return (
    <ul className="divide-y divide-white/5">
      {items.map((t) => {
        const Icon = ICONS[t.type] ?? Gift
        return (
          <li key={t.id} className="flex items-center gap-3 py-3">
            <span className="grid size-10 place-items-center rounded-xl bg-white/5">
              <Icon className="size-4" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold">{t.label}</div>
              <div className="text-xs text-muted-foreground">
                {t.id} · {fmtDate(t.createdAt)}
                {t.bucket && <span className="capitalize"> · {t.bucket}</span>}
              </div>
            </div>
            <div className="text-right">
              <div className={cn('font-bold tabular-nums', t.amount > 0 ? 'text-ludo-green' : 'text-foreground', t.status === 'rejected' && 'text-muted-foreground line-through')}>
                {t.amount > 0 ? '+' : ''}
                {t.amount.toLocaleString()}
              </div>
              {t.status !== 'completed' && (
                <Badge variant={t.status === 'rejected' ? 'destructive' : 'secondary'} className="mt-0.5 text-[10px] capitalize">
                  {t.status.replace('_', ' ')}
                </Badge>
              )}
            </div>
          </li>
        )
      })}
    </ul>
  )
}

export function StatusBadge({ status }: { status: string }) {
  const tone =
    status === 'approved' || status === 'paid' || status === 'rewarded' || status === 'verified'
      ? 'bg-ludo-green/15 text-ludo-green ring-ludo-green/30'
      : status === 'rejected' || status === 'flagged' || status === 'blocked'
        ? 'bg-ludo-red/15 text-ludo-red ring-ludo-red/30'
        : 'bg-ludo-yellow/15 text-ludo-yellow ring-ludo-yellow/30'
  return <span className={cn('inline-flex rounded-full px-2 py-0.5 text-[11px] font-bold capitalize ring-1', tone)}>{status.replace('_', ' ')}</span>
}
