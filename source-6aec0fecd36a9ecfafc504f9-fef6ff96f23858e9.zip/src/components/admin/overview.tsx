import { Activity, ArrowDownLeft, ArrowUpRight, Gamepad2, Gift, Headphones, IdCard, UserPlus, Users, Wallet } from 'lucide-react'

import { Panel } from '@/components/brand'
import { fmtDate, useServer } from '@/lib/client'
import { adminAuditLog, adminOverview } from '@/server/admin.functions'
import { Empty, Stat } from './common'

type Go = (s: 'deposits' | 'withdrawals' | 'users' | 'referrals' | 'games' | 'support' | 'wallet') => void

export function Overview({ go }: { go: Go }) {
  const { data, error } = useServer(() => adminOverview(), [], 30_000)
  if (error) return <Panel className="text-sm text-ludo-red">{error}</Panel>
  if (!data) return <Empty>Loading…</Empty>
  const max = Math.max(1, ...data.weekly.map((d) => d.games))
  const maxS = Math.max(1, ...data.weekly.map((d) => d.signups))
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Total users" value={data.totalUsers.toLocaleString()} icon={Users} onClick={() => go('users')} />
        <Stat label="Active (24h)" value={data.activeUsers.toLocaleString()} icon={Activity} />
        <Stat label="New users (7d)" value={data.newUsers.toLocaleString()} icon={UserPlus} />
        <Stat label="Total games" value={data.totalGames.toLocaleString()} icon={Gamepad2} hint={`${data.gamesToday} today · ${data.liveRooms} live`} onClick={() => go('games')} />
        <Stat label="Pending deposits" value={data.pendingDeposits} icon={ArrowDownLeft} onClick={() => go('deposits')} />
        <Stat label="Pending payouts" value={data.pendingWithdrawals} icon={ArrowUpRight} onClick={() => go('withdrawals')} />
        <Stat label="Referrals" value={data.referralsTotal} icon={Gift} hint={`${data.referralsRewarded} rewarded · ${data.flaggedReferrals} flagged`} onClick={() => go('referrals')} />
        <Stat label="Open tickets" value={data.openTickets} icon={Headphones} hint={`${data.pendingKyc} KYC pending`} onClick={() => go('support')} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <h2 className="mb-4 font-bold">Last 7 days</h2>
          <div className="flex h-48 items-end gap-3">
            {data.weekly.map((d, i) => (
              <div key={i} className="flex flex-1 flex-col items-center gap-1">
                <div className="flex h-40 w-full items-end justify-center gap-1">
                  <div className="w-1/2 rounded-t bg-primary/80" style={{ height: `${(d.games / max) * 100}%` }} title={`${d.games} games`} />
                  <div className="w-1/2 rounded-t bg-ludo-green/80" style={{ height: `${(d.signups / maxS) * 100}%` }} title={`${d.signups} sign-ups`} />
                </div>
                <span className="text-[11px] text-muted-foreground">{d.day}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="size-2 rounded-full bg-primary" /> Games
            </span>
            <span className="flex items-center gap-1.5">
              <span className="size-2 rounded-full bg-ludo-green" /> Sign-ups
            </span>
          </div>
        </Panel>
        <Panel>
          <h2 className="mb-3 flex items-center gap-2 font-bold">
            <Wallet className="size-4 text-primary" /> Transaction report
          </h2>
          <dl className="space-y-2 text-sm">
            <Row k="Approved deposits (all time)" v={`Rs ${data.money.approvedPkr.toLocaleString()}`} />
            <Row k="Approved deposits (30d)" v={`Rs ${data.money.approvedPkr30.toLocaleString()}`} />
            <Row k="Approved requests" v={data.money.approvedCount} />
            <Row k="Rejected requests" v={data.money.rejectedCount} />
          </dl>
          <button className="mt-4 flex items-center gap-1 text-xs font-semibold text-primary" onClick={() => go('wallet')}>
            <IdCard className="size-3" /> Open full ledger
          </button>
        </Panel>
      </div>
    </div>
  )
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-2">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="font-bold tabular-nums">{v}</dd>
    </div>
  )
}

export function AuditSection() {
  const { data } = useServer(() => adminAuditLog(), [], 30_000)
  return (
    <Panel>
      {data?.length === 0 && <Empty>No admin activity yet.</Empty>}
      <ul className="divide-y divide-white/5 text-sm">
        {data?.map((a) => (
          <li key={a.id} className="py-2.5">
            <div className="flex flex-wrap justify-between gap-2">
              <span className="font-semibold">
                {a.action}
                {a.targetId && <span className="ml-1 font-mono text-xs text-muted-foreground">{a.targetType}:{a.targetId}</span>}
              </span>
              <span className="text-xs text-muted-foreground">{fmtDate(a.createdAt)}</span>
            </div>
            <div className="text-xs text-muted-foreground">{a.actorEmail}</div>
            {a.details && <code className="mt-1 block truncate text-[11px] text-muted-foreground">{a.details}</code>}
          </li>
        ))}
      </ul>
    </Panel>
  )
}
