import { useState } from 'react'
import { Ban, Eye, Search, ShieldCheck } from 'lucide-react'

import { Coins, Panel } from '@/components/brand'
import { StatusBadge, TxList } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { fmtDate, METHOD_LABEL, useAction, useServer } from '@/lib/client'
import { adminAdjustWallet, adminGrantAdmin, adminListUsers, adminReviewKyc, adminSetUserStatus, adminUserDetail } from '@/server/admin.functions'
import { Empty, Filter, selectCls } from './common'

export function UsersSection() {
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const [status, setStatus] = useState('all')
  const { data, reload } = useServer(() => adminListUsers({ data: { q: query, status } }), [query, status])
  const [open, setOpen] = useState<string | null>(null)
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Filter
          value={status}
          onChange={setStatus}
          options={[
            ['all', 'All'],
            ['active', 'Active'],
            ['suspended', 'Suspended'],
            ['blocked', 'Blocked'],
            ['kyc', 'KYC pending'],
          ]}
        />
        <form
          className="relative ml-auto w-full sm:w-80"
          onSubmit={(e) => {
            e.preventDefault()
            setQuery(q)
          }}
        >
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Name, email, LKA-ID or referral code" className="pl-9" />
        </form>
      </div>
      <Panel className="overflow-x-auto p-0">
        {data?.length === 0 && <Empty>No users found.</Empty>}
        <table className="w-full min-w-[720px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">User</th>
              <th className="p-3">Coins (P / B / W)</th>
              <th className="p-3">Games</th>
              <th className="p-3">KYC</th>
              <th className="p-3">Status</th>
              <th className="p-3">Joined</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data?.map((u) => (
              <tr key={u.id}>
                <td className="p-3">
                  <div className="font-semibold">{u.name}</div>
                  <div className="text-xs text-muted-foreground">
                    <span className="font-mono">{u.publicId}</span> · {u.email}
                  </div>
                </td>
                <td className="p-3 tabular-nums">
                  {(u.purchased ?? 0).toLocaleString()} / {(u.bonus ?? 0).toLocaleString()} / {(u.winnings ?? 0).toLocaleString()}
                </td>
                <td className="p-3">{u.gamesPlayed}</td>
                <td className="p-3">
                  <StatusBadge status={u.kycStatus.replace('not_started', 'none')} />
                </td>
                <td className="p-3">
                  <StatusBadge status={u.status} />
                </td>
                <td className="p-3 text-xs text-muted-foreground">{fmtDate(u.createdAt, false)}</td>
                <td className="p-3">
                  <Button size="sm" variant="secondary" onClick={() => setOpen(u.id)}>
                    <Eye /> Details
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      {open && (
        <UserDialog
          id={open}
          onClose={() => {
            setOpen(null)
            void reload()
          }}
        />
      )}
    </div>
  )
}

function UserDialog({ id, onClose }: { id: string; onClose: () => void }) {
  const { data, reload } = useServer(() => adminUserDetail({ data: { id } }), [id])
  const { pending, run } = useAction()
  const [reason, setReason] = useState('')
  const [adj, setAdj] = useState({ amount: '', bucket: 'bonus' as 'bonus' | 'purchased', kind: 'promo' as 'promo' | 'adjustment', reason: '' })
  const u = data?.user
  const setStatus = async (status: 'active' | 'blocked' | 'suspended', days?: number) => {
    if (await run(() => adminSetUserStatus({ data: { id, status, reason, days } }), `User ${status}`)) void reload()
  }
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>{u ? `${u.displayName} · ${u.publicId}` : 'Loading…'}</DialogTitle>
        </DialogHeader>
        {u && data && (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-4">
              <Mini label="Purchased" value={<Coins value={data.wallet?.purchased ?? 0} />} />
              <Mini label="Bonus" value={<Coins value={data.wallet?.bonus ?? 0} />} />
              <Mini label="Winnings" value={<Coins value={data.wallet?.winnings ?? 0} />} />
              <Mini label="Rating / games" value={`${u.rating} / ${u.gamesPlayed}`} />
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <span>{u.email}</span>·<span>Referral code {u.referralCode}</span>·<span>Joined {fmtDate(u.createdAt)}</span>·<span>Last seen {fmtDate(u.lastSeenAt)}</span>
              <StatusBadge status={u.status} />
              {u.isAdmin && <span className="rounded-full bg-primary/20 px-2 font-bold text-primary">Admin</span>}
              {u.ageConfirmed ? <span>Age ✓ {u.dateOfBirth ?? ''}</span> : <span className="text-ludo-yellow">Age not confirmed</span>}
            </div>

            <Panel className="space-y-2 p-4">
              <div className="text-sm font-bold">Account status</div>
              <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason (shown to the user)" />
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="secondary" disabled={pending} onClick={() => setStatus('active')}>
                  Unblock / reactivate
                </Button>
                <Button size="sm" variant="secondary" disabled={pending} onClick={() => setStatus('suspended', 7)}>
                  Suspend 7 days
                </Button>
                <Button size="sm" variant="destructive" disabled={pending} onClick={() => setStatus('blocked')}>
                  <Ban /> Block
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={pending}
                  className="ml-auto"
                  onClick={async () => {
                    if (!confirm(u.isAdmin ? 'Revoke admin role?' : 'Grant full admin access to this user?')) return
                    if (await run(() => adminGrantAdmin({ data: { id, grant: !u.isAdmin } }), 'Role updated')) void reload()
                  }}
                >
                  <ShieldCheck /> {u.isAdmin ? 'Revoke admin' : 'Make admin'}
                </Button>
              </div>
            </Panel>

            {u.kycStatus === 'pending' && (
              <Panel className="space-y-2 p-4">
                <div className="text-sm font-bold">KYC review</div>
                <div className="text-sm">
                  {u.kycName} · CNIC {u.kycDocNumber}
                </div>
                {u.hasKycDoc && <img src={`/api/admin/kyc/${u.id}`} alt="KYC document" className="max-h-64 rounded-lg" />}
                <div className="flex gap-2">
                  <Button size="sm" disabled={pending} onClick={async () => (await run(() => adminReviewKyc({ data: { id, approve: true, note: '' } }), 'KYC approved')) && reload()}>
                    Approve KYC
                  </Button>
                  <Button size="sm" variant="destructive" disabled={pending} onClick={async () => (await run(() => adminReviewKyc({ data: { id, approve: false, note: reason } }), 'KYC rejected')) && reload()}>
                    Reject
                  </Button>
                </div>
              </Panel>
            )}

            <Panel className="space-y-2 p-4">
              <div className="text-sm font-bold">Promotional bonus / verified correction</div>
              <div className="grid gap-2 sm:grid-cols-4">
                <select className={selectCls} value={adj.kind} onChange={(e) => setAdj({ ...adj, kind: e.target.value as 'promo' | 'adjustment', bucket: e.target.value === 'promo' ? 'bonus' : adj.bucket })}>
                  <option value="promo">Promo bonus</option>
                  <option value="adjustment">Correction</option>
                </select>
                <select className={selectCls} value={adj.bucket} disabled={adj.kind === 'promo'} onChange={(e) => setAdj({ ...adj, bucket: e.target.value as 'bonus' | 'purchased' })}>
                  <option value="bonus">Bonus coins</option>
                  <option value="purchased">Purchased coins</option>
                </select>
                <Input type="number" placeholder="± coins" value={adj.amount} onChange={(e) => setAdj({ ...adj, amount: e.target.value })} />
                <Input placeholder="Reason (audited)" value={adj.reason} onChange={(e) => setAdj({ ...adj, reason: e.target.value })} />
              </div>
              <Button
                size="sm"
                disabled={pending || !Number(adj.amount) || adj.reason.length < 5}
                onClick={async () => {
                  const r = await run(
                    () => adminAdjustWallet({ data: { userId: id, bucket: adj.bucket, amount: Number(adj.amount), reason: adj.reason, kind: adj.kind, idempotencyKey: crypto.randomUUID() } }),
                    'Wallet updated',
                  )
                  if (r) {
                    setAdj({ ...adj, amount: '', reason: '' })
                    void reload()
                  }
                }}
              >
                Apply
              </Button>
            </Panel>

            <Tabs defaultValue="tx">
              <TabsList className="flex-wrap">
                <TabsTrigger value="tx">Transactions</TabsTrigger>
                <TabsTrigger value="dep">Deposits</TabsTrigger>
                <TabsTrigger value="wd">Withdrawals</TabsTrigger>
                <TabsTrigger value="games">Games</TabsTrigger>
                <TabsTrigger value="ref">Referrals</TabsTrigger>
                <TabsTrigger value="log">Logins</TabsTrigger>
              </TabsList>
              <TabsContent value="tx">
                <TxList items={data.transactions} />
              </TabsContent>
              <TabsContent value="dep">
                <SimpleList rows={data.deposits.map((d) => [`${d.id} · Rs ${d.amountPkr} · ${METHOD_LABEL[d.method]} · TID ${d.tid}`, fmtDate(d.createdAt), d.status])} />
              </TabsContent>
              <TabsContent value="wd">
                <SimpleList rows={data.withdrawals.map((w) => [`${w.id} · ${w.coins} coins · ${METHOD_LABEL[w.method]} ${w.accountNumber}`, fmtDate(w.createdAt), w.status])} />
              </TabsContent>
              <TabsContent value="games">
                <SimpleList rows={data.games.map((g) => [`${g.mode} · ${g.players.map((p) => p.name).join(', ')}`, fmtDate(g.endedAt), g.won ? 'won' : 'lost'])} />
              </TabsContent>
              <TabsContent value="ref">
                <SimpleList rows={data.referrals.map((r) => [`${r.name}${r.flags.length ? ` · ⚠ ${r.flags.join(', ')}` : ''}`, fmtDate(r.createdAt), r.status])} />
              </TabsContent>
              <TabsContent value="log">
                <SimpleList rows={data.logins.map((l) => [(l.userAgent ?? '').slice(0, 80), `${l.country ?? ''} ${fmtDate(l.createdAt)}`, ''])} />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function Mini({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-white/5 p-3">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className="font-bold">{value}</div>
    </div>
  )
}

function SimpleList({ rows }: { rows: [string, string, string][] }) {
  if (!rows.length) return <Empty>Nothing yet.</Empty>
  return (
    <ul className="divide-y divide-white/5 text-sm">
      {rows.map(([a, b, c], i) => (
        <li key={i} className="flex items-center gap-3 py-2">
          <span className="min-w-0 flex-1 truncate">{a}</span>
          <span className="shrink-0 text-xs text-muted-foreground">{b}</span>
          {c && <StatusBadge status={c} />}
        </li>
      ))}
    </ul>
  )
}
