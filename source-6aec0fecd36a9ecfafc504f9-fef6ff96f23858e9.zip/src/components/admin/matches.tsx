import { useState } from 'react'
import { AlertTriangle, Ban, CheckCircle2, Coins as CoinsIcon, Gamepad2, RefreshCw, Swords, XCircle } from 'lucide-react'

import { Coins, Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { GAME_INFO, GAME_KEYS, prizeMath, type ArenaConfig, type GameKey } from '@/lib/games/catalog'
import { adminCoinHistory, adminGetArena, adminMatches, adminResolveReport, adminRetrySettlement, adminSaveArena, adminVoidMatch } from '@/server/matches-admin.functions'
import { Empty, Filter, Stat } from './common'

/** Admin: per-game settings, live/completed/cancelled/problem matches, and the coin-entry ledger. */
export function MatchesSection() {
  return (
    <Tabs defaultValue="matches">
      <TabsList className="flex-wrap">
        <TabsTrigger value="matches">Matches</TabsTrigger>
        <TabsTrigger value="settings">Game settings</TabsTrigger>
        <TabsTrigger value="coins">Coin entries & rewards</TabsTrigger>
      </TabsList>
      <TabsContent value="matches" className="mt-4">
        <MatchList />
      </TabsContent>
      <TabsContent value="settings" className="mt-4">
        <ArenaSettings />
      </TabsContent>
      <TabsContent value="coins" className="mt-4">
        <CoinHistory />
      </TabsContent>
    </Tabs>
  )
}

function MatchList() {
  const [filter, setFilter] = useState<'active' | 'completed' | 'cancelled' | 'problems' | 'all'>('active')
  const [game, setGame] = useState<'all' | GameKey>('all')
  const m = useServer(() => adminMatches({ data: { filter, game } }), [filter, game], 15_000)
  const { pending, run } = useAction()
  const st = m.data?.stats ?? {}
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-6">
        <Stat label="Active" value={st.active ?? 0} icon={Swords} onClick={() => setFilter('active')} />
        <Stat label="Completed" value={st.completed ?? 0} icon={CheckCircle2} onClick={() => setFilter('completed')} />
        <Stat label="Cancelled" value={st.cancelled ?? 0} icon={XCircle} onClick={() => setFilter('cancelled')} />
        <Stat label="Failed / disputed" value={st.problems ?? 0} icon={AlertTriangle} onClick={() => setFilter('problems')} />
        <Stat label="Coin volume (paid)" value={(st.volume ?? 0).toLocaleString()} icon={CoinsIcon} />
        <Stat label="Platform fees" value={(st.fees ?? 0).toLocaleString()} icon={CoinsIcon} />
      </div>
      <div className="flex flex-wrap gap-2">
        <Filter value={filter} onChange={(v) => setFilter(v as typeof filter)} options={[['active', 'Active'], ['completed', 'Completed'], ['cancelled', 'Cancelled'], ['problems', 'Failed / disputed'], ['all', 'All history']]} />
        <Filter value={game} onChange={(v) => setGame(v as typeof game)} options={[['all', 'All games'], ...GAME_KEYS.map((k) => [k, GAME_INFO[k].name] as [string, string])]} />
      </div>
      <Panel className="p-0">
        {m.loading && !m.data && <Empty>Loading…</Empty>}
        {m.data?.rooms.length === 0 && <Empty>No matches here.</Empty>}
        <ul className="divide-y divide-white/5 text-sm">
          {m.data?.rooms.map((r) => (
            <li key={r.id} className="space-y-2 p-4">
              <div className="flex flex-wrap items-center gap-2">
                <Gamepad2 className="size-4 text-primary" />
                <span className="font-semibold">
                  {GAME_INFO[r.game as GameKey]?.name ?? r.game} · {r.mode} · #{r.code}
                </span>
                <StatusBadge status={r.status} />
                {r.stake.entryFee > 0 && <StatusBadge status={`coins ${r.stake.stakeStatus}`} />}
                {r.disputed && <span className="rounded-full bg-ludo-red/15 px-2 py-0.5 text-[11px] font-bold text-ludo-red ring-1 ring-ludo-red/30">Disputed</span>}
                <span className="ml-auto text-xs text-muted-foreground">{fmtDate(r.updatedAt)}</span>
              </div>
              <div className="text-xs text-muted-foreground">
                {r.seats.map((s) => `${s.name}${s.forfeited ? ' (forfeit)' : ''}${s.paid ? ` −${s.paid}` : ''}`).join(' · ')}
                {r.isPrivate ? ' · private' : ' · matchmaking'}
              </div>
              {r.stake.entryFee > 0 && (
                <div className="flex flex-wrap gap-x-4 text-xs">
                  <span>Entry <Coins value={r.stake.entryFee} /></span>
                  <span>Pool <Coins value={r.stake.pool} /></span>
                  <span>Fee {r.stake.feePercent}% <Coins value={r.stake.result?.fee ?? r.stake.fee} /></span>
                  {r.stake.result && (
                    <span className="text-ludo-green">
                      {r.stake.result.draw ? 'Draw — entries returned' : `Paid: ${Object.values(r.stake.result.prizes).reduce((a, b) => a + b, 0).toLocaleString()}`} · {r.stake.result.reason}
                    </span>
                  )}
                </div>
              )}
              {r.outcome && <div className="text-xs">Result: {r.outcome.reason}</div>}
              {r.cancelReason && <div className="text-xs text-ludo-yellow">Cancelled: {r.cancelReason}</div>}
              {r.reports.map((rep) => (
                <div key={rep.id} className="rounded-lg bg-ludo-red/10 p-2 text-xs">
                  <b>Report</b> ({rep.status}) {fmtDate(rep.createdAt)}: {rep.reason}
                  {rep.resolution && <div className="text-muted-foreground">Resolution: {rep.resolution}</div>}
                </div>
              ))}
              <div className="flex flex-wrap gap-2">
                {['waiting', 'playing'].includes(r.status) || (r.status === 'finished' && r.stake.stakeStatus === 'charged') ? (
                  <Button
                    size="xs"
                    variant="destructive"
                    disabled={pending}
                    onClick={async () => {
                      const reason = prompt('Reason for cancelling / voiding this match (all charged entries are refunded):')
                      if (reason && reason.trim().length >= 3 && (await run(() => adminVoidMatch({ data: { id: r.id, reason } }), 'Match cancelled and refunded'))) void m.reload()
                    }}
                  >
                    <Ban /> Cancel & refund
                  </Button>
                ) : null}
                {r.status === 'finished' && r.stake.stakeStatus === 'charged' && (
                  <Button size="xs" variant="secondary" disabled={pending} onClick={async () => (await run(() => adminRetrySettlement({ data: { id: r.id } }), 'Settlement completed')) && m.reload()}>
                    <RefreshCw /> Retry payout
                  </Button>
                )}
                {r.disputed && (
                  <>
                    <Button
                      size="xs"
                      variant="secondary"
                      disabled={pending}
                      onClick={async () => {
                        const resolution = prompt('Resolution note (optional):') ?? ''
                        if (await run(() => adminResolveReport({ data: { roomId: r.id, status: 'resolved', resolution } }), 'Marked resolved')) void m.reload()
                      }}
                    >
                      Resolve
                    </Button>
                    <Button size="xs" variant="outline" disabled={pending} onClick={async () => (await run(() => adminResolveReport({ data: { roomId: r.id, status: 'dismissed' } }), 'Dismissed')) && m.reload()}>
                      Dismiss
                    </Button>
                  </>
                )}
              </div>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  )
}

function ArenaSettings() {
  const { data, reload } = useServer(() => adminGetArena())
  if (!data) return <Empty>Loading…</Empty>
  return <ArenaEditor key={JSON.stringify(data)} initial={data} reload={reload} />
}

function NumField({ label, value, onChange, min = 0, max }: { label: string; value: number; onChange: (n: number) => void; min?: number; max?: number }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Input type="number" min={min} max={max} value={value} onChange={(e) => onChange(Math.round(Number(e.target.value) || 0))} />
    </div>
  )
}

function ArenaEditor({ initial, reload }: { initial: ArenaConfig; reload: () => Promise<void> }) {
  const [c, setC] = useState<ArenaConfig>(() => structuredClone(initial))
  const { pending, run } = useAction()
  const upd = (k: GameKey, patch: Partial<ArenaConfig[GameKey]>) => setC({ ...c, [k]: { ...c[k], ...patch } })
  return (
    <div className="space-y-6 pb-24">
      <p className="text-sm text-muted-foreground">
        Changes apply to new rooms only. A room’s entry amount and fee are locked when it is created. Prizes go to players’ winnings, which they can request to withdraw (Payouts).
      </p>
      <div className="grid gap-6 xl:grid-cols-2">
        {GAME_KEYS.map((k) => {
          const g = c[k]
          const ex = prizeMath(1000, 2, g.feePercent)
          const splitSum = g.prizeSplit.reduce((a, b) => a + b, 0)
          return (
            <Panel key={k} className="space-y-4">
              <h2 className="flex items-center justify-between font-bold">
                {GAME_INFO[k].name}
                <span className="flex items-center gap-2 text-xs font-semibold">
                  {g.enabled ? 'Enabled' : 'Disabled'} <Switch checked={g.enabled} onCheckedChange={(v) => upd(k, { enabled: v })} />
                </span>
              </h2>
              <div className="flex flex-wrap gap-6 text-sm">
                <label className="flex items-center gap-2">
                  <Switch checked={g.entryEnabled} onCheckedChange={(v) => upd(k, { entryEnabled: v })} /> Coin-entry matches
                </label>
                <label className="flex items-center gap-2">
                  <Switch checked={g.customAmounts} onCheckedChange={(v) => upd(k, { customAmounts: v })} /> Custom amounts
                </label>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <NumField label="Min entry" value={g.minEntry} min={1} onChange={(n) => upd(k, { minEntry: n })} />
                <NumField label="Max entry" value={g.maxEntry} min={1} onChange={(n) => upd(k, { maxEntry: n })} />
                <NumField label="Platform fee %" value={g.feePercent} min={0} max={50} onChange={(n) => upd(k, { feePercent: Math.max(0, Math.min(50, n)) })} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Preset amounts (comma separated)</Label>
                <Input
                  defaultValue={g.presets.join(', ')}
                  onBlur={(e) => upd(k, { presets: e.target.value.split(/[,\s]+/).map(Number).filter((n) => Number.isInteger(n) && n > 0).slice(0, 10) })}
                />
              </div>
              <div className="rounded-xl bg-white/5 p-3 text-xs text-muted-foreground">
                Example: 2 players × 1,000 = pool 2,000 · fee {ex.fee.toLocaleString()} · winner gets <b className="text-foreground">{ex.prize.toLocaleString()}</b>
              </div>
              {k === 'ludo' && (
                <div className="space-y-1">
                  <Label className="text-xs">Prize distribution for 3–4 sided matches (% for 1st, 2nd, 3rd…; must total 100). 1v1 and 2v2 always pay the winner 100%.</Label>
                  <Input
                    defaultValue={g.prizeSplit.join(', ')}
                    onBlur={(e) => upd(k, { prizeSplit: e.target.value.split(/[,\s]+/).map(Number).filter((n) => Number.isInteger(n) && n >= 0).slice(0, 4) })}
                  />
                  {splitSum !== 100 && <p className="text-xs text-ludo-red">Currently totals {splitSum}%.</p>}
                </div>
              )}
              <div className="space-y-2">
                <div className="text-xs font-bold text-muted-foreground uppercase">Match types</div>
                {g.matchTypes.map((mt, i) => (
                  <div key={mt.id} className="grid grid-cols-[auto_1fr_1fr_5rem] items-center gap-2">
                    <Switch
                      checked={mt.enabled}
                      onCheckedChange={(v) => upd(k, { matchTypes: g.matchTypes.map((x, j) => (j === i ? { ...x, enabled: v } : x)) })}
                    />
                    <Input value={mt.label} onChange={(e) => upd(k, { matchTypes: g.matchTypes.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} />
                    <Input value={mt.sub} onChange={(e) => upd(k, { matchTypes: g.matchTypes.map((x, j) => (j === i ? { ...x, sub: e.target.value } : x)) })} />
                    {mt.turnSeconds !== undefined ? (
                      <Input
                        type="number"
                        title="Seconds per turn"
                        value={mt.turnSeconds}
                        onChange={(e) => upd(k, { matchTypes: g.matchTypes.map((x, j) => (j === i ? { ...x, turnSeconds: Math.round(Number(e.target.value) || 0) } : x)) })}
                      />
                    ) : (
                      <span className="text-center text-xs text-muted-foreground">{mt.players}p</span>
                    )}
                  </div>
                ))}
                <p className="text-[11px] text-muted-foreground">Last column: seconds per turn (10–600).{k === 'ludo' && ' Ludo uses the global turn timer under Website settings.'}</p>
              </div>
            </Panel>
          )
        })}
      </div>
      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-white/10 bg-background/90 p-3 backdrop-blur lg:left-64">
        <div className="mx-auto flex max-w-5xl justify-end gap-2">
          <Button variant="outline" onClick={() => setC(structuredClone(initial))}>Reset</Button>
          <Button disabled={pending} className="font-bold" onClick={async () => (await run(() => adminSaveArena({ data: c }), 'Game settings saved')) && reload()}>
            Save game settings
          </Button>
        </div>
      </div>
    </div>
  )
}

function CoinHistory() {
  const [type, setType] = useState<'all' | 'game_entry' | 'game_win' | 'game_refund'>('all')
  const [q, setQ] = useState('')
  const h = useServer(() => adminCoinHistory({ data: { type, q } }), [type, q])
  const t = h.data?.totals
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <Stat label="Entries deducted" value={(t?.entries ?? 0).toLocaleString()} icon={CoinsIcon} />
        <Stat label="Rewards paid" value={(t?.rewards ?? 0).toLocaleString()} icon={CoinsIcon} />
        <Stat label="Refunds" value={(t?.refunds ?? 0).toLocaleString()} icon={CoinsIcon} />
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Filter value={type} onChange={(v) => setType(v as typeof type)} options={[['all', 'All'], ['game_entry', 'Deductions'], ['game_win', 'Rewards'], ['game_refund', 'Refunds']]} />
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault()
            setQ(String(new FormData(e.currentTarget).get('q') ?? ''))
          }}
        >
          <Input name="q" placeholder="Player ID, name or room ID" className="h-8 w-56" />
          <Button size="sm" type="submit" variant="secondary">Search</Button>
        </form>
      </div>
      <Panel className="overflow-x-auto p-0">
        {h.data?.rows.length === 0 && <Empty>No game coin transactions yet.</Empty>}
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">When</th>
              <th className="p-3">Player</th>
              <th className="p-3">Type</th>
              <th className="p-3">Detail</th>
              <th className="p-3 text-right">Amount</th>
              <th className="p-3 text-right">Wallet now</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {h.data?.rows.map((r) => (
              <tr key={r.id}>
                <td className="p-3 text-xs whitespace-nowrap text-muted-foreground">{fmtDate(r.createdAt)}</td>
                <td className="p-3">
                  {r.name} <span className="font-mono text-[10px] text-muted-foreground">{r.publicId}</span>
                </td>
                <td className="p-3"><StatusBadge status={r.type.replace('game_', '')} /></td>
                <td className="p-3 text-xs">{r.label} <span className="font-mono text-muted-foreground">{r.id}</span></td>
                <td className={`p-3 text-right font-bold tabular-nums ${r.amount < 0 ? 'text-ludo-red' : 'text-ludo-green'}`}>{r.amount > 0 ? '+' : ''}{r.amount.toLocaleString()}</td>
                <td className="p-3 text-right"><Coins value={r.balance} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  )
}
