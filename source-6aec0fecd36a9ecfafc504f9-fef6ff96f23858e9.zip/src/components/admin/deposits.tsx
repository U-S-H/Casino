import { useState } from 'react'
import { AlertTriangle, Check, ExternalLink, Eye, Search, X } from 'lucide-react'

import { Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { fmtDate, METHOD_LABEL, useAction, useServer } from '@/lib/client'
import { adminListDeposits, adminReviewDeposit } from '@/server/admin.functions'
import { Empty, Filter } from './common'

type Dep = Awaited<ReturnType<typeof adminListDeposits>>[number]

export function DepositsSection() {
  const [status, setStatus] = useState('open')
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const { data, reload } = useServer(() => adminListDeposits({ data: { status, q: query } }), [status, query], 20_000)
  const [open, setOpen] = useState<Dep | null>(null)
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Filter
          value={status}
          onChange={setStatus}
          options={[
            ['open', 'Open'],
            ['pending', 'Pending'],
            ['under_review', 'Under review'],
            ['approved', 'Approved'],
            ['rejected', 'Rejected'],
            ['all', 'All'],
          ]}
        />
        <form
          className="relative ml-auto w-full sm:w-72"
          onSubmit={(e) => {
            e.preventDefault()
            setQuery(q)
          }}
        >
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search TID, DR-ID, user…" className="pl-9" />
        </form>
      </div>
      <Panel className="p-0">
        {data?.length === 0 && <Empty>No deposit requests.</Empty>}
        <ul className="divide-y divide-white/5">
          {data?.map((d) => (
            <li key={d.id} className="flex flex-wrap items-center gap-3 p-4">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 font-semibold">
                  {d.name} <span className="font-mono text-xs text-muted-foreground">{d.publicId}</span>
                  {d.flags.map((f) => (
                    <span key={f} className="flex items-center gap-1 rounded-full bg-ludo-red/15 px-2 text-[10px] font-bold text-ludo-red">
                      <AlertTriangle className="size-3" /> {f}
                    </span>
                  ))}
                </div>
                <div className="text-xs text-muted-foreground">
                  {d.id} · {d.packageName} · <b>Rs {d.amountPkr}</b> via {METHOD_LABEL[d.method]} from {d.senderAccount} · TID <span className="font-mono text-foreground">{d.tid}</span> · {fmtDate(d.createdAt)}
                </div>
              </div>
              <StatusBadge status={d.status} />
              <Button size="sm" variant="secondary" onClick={() => setOpen(d)}>
                <Eye /> Review
              </Button>
            </li>
          ))}
        </ul>
      </Panel>
      {open && (
        <ReviewDialog
          d={open}
          onClose={(changed) => {
            setOpen(null)
            if (changed) void reload()
          }}
        />
      )}
    </div>
  )
}

function ReviewDialog({ d, onClose }: { d: Dep; onClose: (changed: boolean) => void }) {
  const [note, setNote] = useState(d.adminNote ?? '')
  const [verified, setVerified] = useState(false)
  const { pending, run } = useAction()
  const act = async (action: 'under_review' | 'approve' | 'reject') => {
    const r = await run(() => adminReviewDeposit({ data: { id: d.id, action, note, tidVerified: verified } }), action === 'approve' ? 'Approved and credited' : action === 'reject' ? 'Rejected' : 'Marked under review')
    if (r) onClose(true)
  }
  const openable = d.status === 'pending' || d.status === 'under_review'
  const shot = `/api/admin/screenshot/${d.id}`
  return (
    <Dialog open onOpenChange={() => onClose(false)}>
      <DialogContent className="max-h-[92dvh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            Deposit {d.id} · <StatusBadge status={d.status} />
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            {d.hasScreenshot ? (
              <a href={shot} target="_blank" rel="noreferrer" className="block">
                <img src={shot} alt="Payment screenshot" className="max-h-96 w-full rounded-xl object-contain ring-1 ring-white/10" />
                <span className="mt-1 flex items-center gap-1 text-xs text-primary">
                  <ExternalLink className="size-3" /> Open full size
                </span>
              </a>
            ) : (
              <Empty>No screenshot.</Empty>
            )}
          </div>
          <dl className="space-y-1.5 text-sm">
            {[
              ['User', `${d.name} (${d.publicId})`],
              ['Email', d.email],
              ['Package', `${d.packageName} · ${d.coins} + ${d.bonusCoins} bonus coins`],
              ['Amount', `Rs ${d.amountPkr}`],
              ['Method', METHOD_LABEL[d.method]],
              ['Paid to', d.payToAccount],
              ['Sender', d.senderAccount ?? '—'],
              ['TID', d.tid],
              ['Submitted', fmtDate(d.createdAt)],
              ['Reviewed', d.reviewedAt ? fmtDate(d.reviewedAt) : '—'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-3">
                <dt className="text-muted-foreground">{k}</dt>
                <dd className="text-right font-semibold break-all">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
        {openable ? (
          <div className="space-y-3">
            <div className="rounded-xl bg-ludo-yellow/10 p-3 text-xs text-ludo-yellow ring-1 ring-ludo-yellow/30">
              Never approve from the screenshot alone. Log in to the {METHOD_LABEL[d.method]} merchant account and confirm TID {d.tid} for Rs {d.amountPkr} from {d.senderAccount}.
            </div>
            <label className="flex items-start gap-2 text-sm">
              <Checkbox checked={verified} onCheckedChange={(v) => setVerified(v === true)} className="mt-0.5" />I verified this TID and amount in the provider’s statement.
            </label>
            <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Admin note (required to reject; shown to user)" rows={2} />
            <div className="flex flex-wrap gap-2">
              {d.status === 'pending' && (
                <Button variant="secondary" disabled={pending} onClick={() => act('under_review')}>
                  Mark under review
                </Button>
              )}
              <Button variant="destructive" disabled={pending} onClick={() => act('reject')}>
                <X /> Reject
              </Button>
              <Button disabled={pending || !verified} onClick={() => act('approve')} className="ml-auto bg-ludo-green text-white hover:bg-ludo-green/90">
                <Check /> Approve & credit {(d.coins + d.bonusCoins).toLocaleString()}
              </Button>
            </div>
          </div>
        ) : (
          d.adminNote && <p className="text-sm text-muted-foreground">Note: {d.adminNote}</p>
        )}
      </DialogContent>
    </Dialog>
  )
}
