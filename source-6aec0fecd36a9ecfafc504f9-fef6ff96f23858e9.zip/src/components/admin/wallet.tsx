import { useState } from 'react'
import { Search, Sparkles } from 'lucide-react'

import { Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { cn } from '@/lib/utils'
import { adminBulkPromo, adminListTransactions } from '@/server/admin.functions'
import { Empty, Filter } from './common'

export function WalletSection() {
  const [type, setType] = useState('all')
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const { data } = useServer(() => adminListTransactions({ data: { type, q: query } }), [type, query])
  const { pending, run } = useAction()
  return (
    <div className="space-y-4">
      <Panel>
        <h2 className="mb-2 flex items-center gap-2 font-bold">
          <Sparkles className="size-4 text-primary" /> Bulk promotional bonus
        </h2>
        <form
          className="grid gap-2 sm:grid-cols-[8rem_8rem_1fr_auto]"
          onSubmit={async (e) => {
            e.preventDefault()
            const fd = new FormData(e.currentTarget)
            if (!confirm('Credit this bonus to every active user in the window?')) return
            await run(
              () => adminBulkPromo({ data: { amount: Number(fd.get('amount')), activeDays: Number(fd.get('days')), reason: String(fd.get('reason')), idempotencyKey: crypto.randomUUID() } }),
              (r) => `Credited ${r.credited} users`,
            )
          }}
        >
          <Input name="amount" type="number" min={1} max={10000} required placeholder="Coins" />
          <Input name="days" type="number" min={1} max={90} defaultValue={7} required title="Active in last N days" />
          <Input name="reason" required minLength={5} placeholder="Reason, e.g. Eid bonus" />
          <Button type="submit" disabled={pending}>
            Send
          </Button>
        </form>
        <p className="mt-2 text-xs text-muted-foreground">Promo coins go to the non-withdrawable bonus balance. Per-user bonuses and corrections are in Users → Details. Coin packages and limits are in Website settings.</p>
      </Panel>
      <div className="flex flex-wrap items-center gap-3">
        <Filter
          value={type}
          onChange={setType}
          options={[
            ['all', 'All'],
            ['deposit', 'Deposits'],
            ['withdrawal', 'Withdrawals'],
            ['promo', 'Promo'],
            ['adjustment', 'Corrections'],
            ['referral', 'Referral'],
            ['daily_reward', 'Daily'],
            ['tournament', 'Tournament'],
            ['welcome', 'Welcome'],
            ['casino_bet', 'DT/Aviator bets'],
            ['casino_win', 'DT/Aviator wins'],
          ]}
        />
        <form
          className="relative ml-auto w-full sm:w-72"
          onSubmit={(e) => {
            e.preventDefault()
            setQuery(q)
          }}
        >
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="TX-ID, LKA-ID or name" className="pl-9" />
        </form>
      </div>
      <Panel className="overflow-x-auto p-0">
        {data?.length === 0 && <Empty>No transactions.</Empty>}
        <table className="w-full min-w-[720px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">Transaction</th>
              <th className="p-3">User</th>
              <th className="p-3">Type / bucket</th>
              <th className="p-3 text-right">Amount</th>
              <th className="p-3 text-right">Balance after</th>
              <th className="p-3">Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data?.map((t) => (
              <tr key={t.id}>
                <td className="p-3">
                  <div className="font-mono text-xs">{t.id}</div>
                  <div className="text-xs text-muted-foreground">{t.label}</div>
                </td>
                <td className="p-3 text-xs">
                  {t.name} <span className="font-mono text-muted-foreground">{t.publicId}</span>
                </td>
                <td className="p-3 text-xs capitalize">
                  {t.type.replace('_', ' ')} · {t.bucket}
                </td>
                <td className={cn('p-3 text-right font-bold tabular-nums', t.amount > 0 ? 'text-ludo-green' : 'text-ludo-red')}>
                  {t.amount > 0 ? '+' : ''}
                  {t.amount.toLocaleString()}
                </td>
                <td className="p-3 text-right tabular-nums">{t.balanceAfter.toLocaleString()}</td>
                <td className="p-3 text-xs text-muted-foreground">{fmtDate(t.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  )
}
