import { useState } from 'react'

import { Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { adminListTickets, adminReplyTicket } from '@/server/admin.functions'
import { Empty, Filter } from './common'

export function SupportSection() {
  const [status, setStatus] = useState('open')
  const { data, reload } = useServer(() => adminListTickets({ data: { status } }), [status], 30_000)
  const { pending, run } = useAction()
  const [reply, setReply] = useState<Record<string, string>>({})
  const send = async (id: string, close: boolean) => {
    if (await run(() => adminReplyTicket({ data: { id, reply: reply[id] ?? '', close } }), close ? 'Ticket closed' : 'Reply sent')) void reload()
  }
  return (
    <div className="space-y-4">
      <Filter
        value={status}
        onChange={setStatus}
        options={[
          ['open', 'Open'],
          ['answered', 'Answered'],
          ['closed', 'Closed'],
          ['all', 'All'],
        ]}
      />
      <Panel className="p-0">
        {data?.length === 0 && <Empty>No tickets.</Empty>}
        <ul className="divide-y divide-white/5">
          {data?.map((t) => (
            <li key={t.id} className="space-y-2 p-4 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex-1 font-semibold">
                  {t.subject} <span className="text-xs text-muted-foreground">· {t.id} · {t.category} · {t.priority}</span>
                </span>
                <StatusBadge status={t.status} />
              </div>
              <div className="text-xs text-muted-foreground">
                {t.name} ({t.publicId}, {t.email}) · {fmtDate(t.createdAt)}
              </div>
              <p className="whitespace-pre-wrap">{t.message}</p>
              {t.adminReply && <p className="rounded-lg bg-primary/10 p-2 text-xs">Last reply: {t.adminReply}</p>}
              {t.status !== 'closed' && (
                <>
                  <Textarea rows={2} value={reply[t.id] ?? ''} onChange={(e) => setReply({ ...reply, [t.id]: e.target.value })} placeholder="Reply to the player (sent as a notification)" />
                  <div className="flex gap-2">
                    <Button size="sm" disabled={pending || !(reply[t.id] ?? '').trim()} onClick={() => send(t.id, false)}>
                      Send reply
                    </Button>
                    <Button size="sm" variant="secondary" disabled={pending} onClick={() => send(t.id, true)}>
                      Close ticket
                    </Button>
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  )
}
