import { useState } from 'react'
import { Copy, Info } from 'lucide-react'
import { toast } from 'sonner'

import { Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { fmtDate, METHOD_LABEL, useAction, useServer } from '@/lib/client'
import { adminListWithdrawals, adminUpdateWithdrawal } from '@/server/admin.functions'
import { Empty, Filter } from './common'

type Next = 'approved' | 'processing' | 'paid' | 'rejected'

export function WithdrawalsSection() {
  const [status, setStatus] = useState('open')
  const { data, reload } = useServer(() => adminListWithdrawals({ data: { status } }), [status], 30_000)
  const { pending, run } = useAction()
  const [form, setForm] = useState<Record<string, { ref: string; note: string }>>({})
  const f = (id: string) => form[id] ?? { ref: '', note: '' }
  const update = async (w: { id: string; coins: number; amountPkr: number | null; accountNumber: string; method: string }, s: Next) => {
    if (s === 'paid' && !window.confirm(`Confirm you have sent Rs ${(w.amountPkr ?? 0).toLocaleString()} to ${METHOD_LABEL[w.method]} ${w.accountNumber}? This finalises the deduction.`)) return
    if (s === 'rejected' && !window.confirm(`Reject ${w.id} and return ${w.coins.toLocaleString()} coins to the player?`)) return
    const r = await run(() => adminUpdateWithdrawal({ data: { id: w.id, status: s, reference: f(w.id).ref, note: f(w.id).note } }), `${w.id} marked ${s}`)
    if (r) void reload()
  }
  const copy = (v: string) => void navigator.clipboard?.writeText(v).then(() => toast.success('Copied'))
  return (
    <div className="space-y-4">
      <div className="flex gap-3 rounded-2xl bg-primary/10 p-4 text-sm ring-1 ring-primary/40">
        <Info className="size-5 shrink-0 text-primary" />
        <div>
          Flow: <b>Approve</b> → <b>Processing</b> (optional) → send the money from your own EasyPaisa / JazzCash / SadaPay account → <b>Mark paid</b> with the transaction ID.
          Coins are reserved when the player submits; marking paid finalises the deduction and rejecting returns them.
        </div>
      </div>
      <Filter
        value={status}
        onChange={setStatus}
        options={[
          ['open', 'Open'],
          ['pending', 'Pending'],
          ['approved', 'Approved'],
          ['processing', 'Processing'],
          ['paid', 'Paid'],
          ['rejected', 'Rejected'],
          ['all', 'All history'],
        ]}
      />
      <Panel className="p-0">
        {data?.length === 0 && <Empty>No payout requests.</Empty>}
        <ul className="divide-y divide-white/5">
          {data?.map((w) => {
            const done = w.status === 'paid' || w.status === 'rejected'
            return (
              <li key={w.id} className="space-y-3 p-4">
                <div className="flex flex-wrap items-start gap-3">
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="font-semibold">
                      {w.name} <span className="font-mono text-xs text-muted-foreground">{w.publicId}</span>
                      <span className="ml-2 text-xs font-normal text-muted-foreground">KYC {w.kycStatus}</span>
                    </div>
                    <div className="font-display text-lg font-extrabold">
                      Rs {(w.amountPkr ?? 0).toLocaleString()} <span className="text-sm font-semibold text-muted-foreground">· {w.coins.toLocaleString()} coins</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-2 text-sm">
                      <span className="font-semibold">{METHOD_LABEL[w.method]}</span>
                      <span className="font-mono">{w.accountNumber}</span>
                      <button type="button" aria-label="Copy account number" onClick={() => copy(w.accountNumber)} className="text-muted-foreground hover:text-foreground">
                        <Copy className="size-3.5" />
                      </button>
                      <span className="text-muted-foreground">· {w.accountHolder}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {w.id} · requested {fmtDate(w.createdAt)}
                      {w.updatedAt && String(w.updatedAt) !== String(w.createdAt) && ` · updated ${fmtDate(w.updatedAt)}`}
                      {w.paymentReference && ` · Payment ref ${w.paymentReference}`}
                      {w.adminNote && ` · Note: ${w.adminNote}`}
                    </div>
                  </div>
                  <StatusBadge status={w.status} />
                </div>
                {!done && (
                  <div className="flex flex-wrap gap-2">
                    {w.status !== 'pending' && (
                      <Input className="h-8 w-48" placeholder="Payment transaction ID" value={f(w.id).ref} onChange={(e) => setForm({ ...form, [w.id]: { ...f(w.id), ref: e.target.value } })} />
                    )}
                    <Input className="h-8 w-60" placeholder="Note / rejection reason" value={f(w.id).note} onChange={(e) => setForm({ ...form, [w.id]: { ...f(w.id), note: e.target.value } })} />
                    {w.status === 'pending' && (
                      <Button size="sm" variant="secondary" disabled={pending} onClick={() => update(w, 'approved')}>
                        Approve
                      </Button>
                    )}
                    {w.status === 'approved' && (
                      <Button size="sm" variant="secondary" disabled={pending} onClick={() => update(w, 'processing')}>
                        Mark processing
                      </Button>
                    )}
                    {w.status !== 'pending' && (
                      <Button size="sm" disabled={pending || !f(w.id).ref.trim()} onClick={() => update(w, 'paid')}>
                        Mark paid
                      </Button>
                    )}
                    <Button size="sm" variant="destructive" disabled={pending || !f(w.id).note.trim()} onClick={() => update(w, 'rejected')}>
                      Reject & refund
                    </Button>
                  </div>
                )}
              </li>
            )
          })}
        </ul>
      </Panel>
    </div>
  )
}
