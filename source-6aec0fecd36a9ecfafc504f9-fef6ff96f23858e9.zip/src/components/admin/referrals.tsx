import { useState } from 'react'
import { AlertTriangle } from 'lucide-react'

import { Coins, Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { adminListReferrals, adminResolveReferral } from '@/server/admin.functions'
import { Empty, Filter } from './common'

export function ReferralsSection() {
  const [status, setStatus] = useState('all')
  const { data, reload } = useServer(() => adminListReferrals({ data: { status } }), [status])
  const { pending, run } = useAction()
  const act = async (id: number, action: 'approve' | 'reject') => {
    if (await run(() => adminResolveReferral({ data: { id, action } }), action === 'approve' ? 'Reward paid' : 'Referral rejected')) void reload()
  }
  const rows = data?.rows ?? []
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Panel className="p-4">
          <div className="text-xs text-muted-foreground">Referrals listed</div>
          <div className="font-display text-2xl font-extrabold">{rows.length}</div>
        </Panel>
        <Panel className="p-4">
          <div className="text-xs text-muted-foreground">Rewarded</div>
          <div className="font-display text-2xl font-extrabold">{rows.filter((r) => r.status === 'rewarded').length}</div>
        </Panel>
        <Panel className="p-4">
          <div className="text-xs text-muted-foreground">Flagged (fraud check)</div>
          <div className="font-display text-2xl font-extrabold text-ludo-red">{rows.filter((r) => r.status === 'flagged').length}</div>
        </Panel>
        <Panel className="p-4">
          <div className="text-xs text-muted-foreground">Total referral earnings paid</div>
          <Coins value={data?.totalPaid ?? 0} className="text-2xl text-primary" />
        </Panel>
      </div>
      <p className="text-xs text-muted-foreground">Enable/disable referrals and change reward amounts in Website settings → Referral programme.</p>
      <Filter
        value={status}
        onChange={setStatus}
        options={[
          ['all', 'All'],
          ['pending', 'Pending'],
          ['flagged', 'Flagged'],
          ['rewarded', 'Rewarded'],
          ['rejected', 'Rejected'],
        ]}
      />
      <Panel className="p-0">
        {rows.length === 0 && <Empty>No referrals.</Empty>}
        <ul className="divide-y divide-white/5">
          {rows.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center gap-3 p-4 text-sm">
              <div className="min-w-0 flex-1">
                <div className="font-semibold">
                  {r.referrer} <span className="font-mono text-xs text-muted-foreground">{r.referrerId}</span> → {r.referred}{' '}
                  <span className="font-mono text-xs text-muted-foreground">{r.referredId}</span>
                </div>
                <div className="text-xs text-muted-foreground">
                  Code {r.code} · {fmtDate(r.createdAt)} · {r.games} games played
                </div>
                {r.flags.length > 0 && (
                  <div className="mt-1 flex flex-wrap gap-1">
                    {r.flags.map((f) => (
                      <span key={f} className="flex items-center gap-1 rounded-full bg-ludo-red/15 px-2 text-[10px] font-bold text-ludo-red">
                        <AlertTriangle className="size-3" /> {f}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <StatusBadge status={r.status} />
              {(r.status === 'pending' || r.status === 'flagged') && (
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" disabled={pending} onClick={() => act(r.id, 'approve')}>
                    Approve & pay
                  </Button>
                  <Button size="sm" variant="destructive" disabled={pending} onClick={() => act(r.id, 'reject')}>
                    Reject as fraud
                  </Button>
                </div>
              )}
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  )
}
