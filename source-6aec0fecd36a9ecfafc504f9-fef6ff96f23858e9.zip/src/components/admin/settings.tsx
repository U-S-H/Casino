import { useState } from 'react'
import { Lock, Megaphone, Plus, Trash2 } from 'lucide-react'

import { Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAction, useServer } from '@/lib/client'
import { adminBroadcast, adminGetSettings, adminSaveSettings } from '@/server/admin.functions'
import { Empty } from './common'

type S = Awaited<ReturnType<typeof adminGetSettings>>

function Num({ label, value, onChange, min = 0 }: { label: string; value: number; onChange: (n: number) => void; min?: number }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Input type="number" min={min} value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </div>
  )
}

export function SettingsSection() {
  const { data, reload } = useServer(() => adminGetSettings())
  if (!data) return <Empty>Loading…</Empty>
  return <SettingsEditor key={JSON.stringify(data)} initial={data} reload={reload} />
}

function SettingsEditor({ initial, reload }: { initial: S; reload: () => Promise<void> }) {
  const [s, setS] = useState<S>(() => structuredClone(initial))
  const { pending, run } = useAction()
  const set = <K extends keyof S>(k: K, v: S[K]) => setS({ ...s, [k]: v })
  const save = async () => {
    const r = await run(() => adminSaveSettings({ data: s }), (x) => (x.changed.length ? `Saved: ${x.changed.join(', ')}` : 'No changes'))
    if (r) void reload()
  }

  return (
    <div className="space-y-6 pb-24">
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel className="space-y-3">
          <h2 className="font-bold">Branding</h2>
          <div className="space-y-1">
            <Label className="text-xs">Website name</Label>
            <Input value={s.siteName} onChange={(e) => set('siteName', e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Logo URL (optional, https)</Label>
            <Input value={s.logoUrl} onChange={(e) => set('logoUrl', e.target.value)} placeholder="https://…/logo.png" />
          </div>
        </Panel>

        <Panel className="space-y-3">
          <h2 className="flex items-center justify-between font-bold">
            Maintenance mode <Switch checked={s.maintenance.enabled} onCheckedChange={(v) => set('maintenance', { ...s.maintenance, enabled: v })} />
          </h2>
          <Textarea rows={2} value={s.maintenance.message} onChange={(e) => set('maintenance', { ...s.maintenance, message: e.target.value })} />
          <p className="text-xs text-muted-foreground">When on, players see the maintenance message and deposits/matches are blocked. Admins keep access.</p>
        </Panel>

        <Panel className="space-y-3 lg:col-span-2">
          <h2 className="font-bold">Payment numbers</h2>
          {s.paymentMethods.map((m, i) => (
            <div key={m.id} className="grid items-end gap-2 sm:grid-cols-[8rem_1fr_1fr_auto]">
              <div className="pb-2 font-semibold">{m.name}</div>
              <div className="space-y-1">
                <Label className="text-xs">Account number</Label>
                <Input value={m.account} onChange={(e) => set('paymentMethods', s.paymentMethods.map((x, j) => (j === i ? { ...x, account: e.target.value } : x)))} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Account title</Label>
                <Input value={m.accountTitle} onChange={(e) => set('paymentMethods', s.paymentMethods.map((x, j) => (j === i ? { ...x, accountTitle: e.target.value } : x)))} />
              </div>
              <label className="flex items-center gap-2 pb-2 text-xs">
                <Switch checked={m.enabled} onCheckedChange={(v) => set('paymentMethods', s.paymentMethods.map((x, j) => (j === i ? { ...x, enabled: v } : x)))} /> Enabled
              </label>
            </div>
          ))}
        </Panel>

        <Panel className="space-y-3 lg:col-span-2">
          <h2 className="flex items-center justify-between font-bold">
            Coin packages
            <Button
              size="sm"
              variant="secondary"
              onClick={() => set('coinPackages', [...s.coinPackages, { id: `pk-${Date.now().toString(36)}`, name: 'New', coins: 1000, bonus: 0, price: 200, tag: null, active: false }])}
            >
              <Plus /> Add
            </Button>
          </h2>
          {s.coinPackages.map((p, i) => {
            const up = (patch: Partial<typeof p>) => set('coinPackages', s.coinPackages.map((x, j) => (j === i ? { ...x, ...patch } : x)))
            return (
              <div key={p.id} className="grid items-end gap-2 sm:grid-cols-[1fr_6rem_6rem_6rem_7rem_auto_auto]">
                <div className="space-y-1">
                  <Label className="text-xs">Name</Label>
                  <Input value={p.name} onChange={(e) => up({ name: e.target.value })} />
                </div>
                <Num label="Coins" value={p.coins} min={1} onChange={(n) => up({ coins: n })} />
                <Num label="Bonus" value={p.bonus} onChange={(n) => up({ bonus: n })} />
                <Num label="Price Rs" value={p.price} min={1} onChange={(n) => up({ price: n })} />
                <div className="space-y-1">
                  <Label className="text-xs">Tag</Label>
                  <Input value={p.tag ?? ''} onChange={(e) => up({ tag: e.target.value || null })} />
                </div>
                <label className="flex items-center gap-2 pb-2 text-xs">
                  <Switch checked={p.active} onCheckedChange={(v) => up({ active: v })} /> Active
                </label>
                <Button size="icon" variant="ghost" aria-label="Remove package" onClick={() => set('coinPackages', s.coinPackages.filter((_, j) => j !== i))}>
                  <Trash2 />
                </Button>
              </div>
            )
          })}
        </Panel>

        <Panel className="space-y-3">
          <h2 className="flex items-center justify-between font-bold">
            Referral programme <Switch checked={s.referral.enabled} onCheckedChange={(v) => set('referral', { ...s.referral, enabled: v })} />
          </h2>
          <div className="space-y-1">
            <Label className="text-xs">Campaign name</Label>
            <Input value={s.referral.campaignName} onChange={(e) => set('referral', { ...s.referral, campaignName: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Num label="Referrer reward" value={s.referral.referrerReward} onChange={(n) => set('referral', { ...s.referral, referrerReward: n })} />
            <Num label="New player reward" value={s.referral.refereeReward} onChange={(n) => set('referral', { ...s.referral, refereeReward: n })} />
            <Num label="Games to qualify" value={s.referral.qualifyGames} onChange={(n) => set('referral', { ...s.referral, qualifyGames: n })} />
            <Num label="Daily cap per referrer" value={s.referral.dailyCapPerReferrer} min={1} onChange={(n) => set('referral', { ...s.referral, dailyCapPerReferrer: n })} />
          </div>
        </Panel>

        <Panel className="space-y-3">
          <h2 className="font-bold">Rewards</h2>
          <Num label="Welcome bonus (coins)" value={s.welcomeBonus} onChange={(n) => set('welcomeBonus', n)} />
          <Label className="text-xs">Daily rewards (day 1 → 7)</Label>
          <div className="grid grid-cols-7 gap-1">
            {s.dailyRewards.map((r, i) => (
              <Input key={i} type="number" min={0} value={r} className="px-1 text-center" onChange={(e) => set('dailyRewards', s.dailyRewards.map((x, j) => (j === i ? Number(e.target.value) : x)))} />
            ))}
          </div>
        </Panel>

        <Panel className="space-y-3">
          <h2 className="font-bold">Deposit & withdrawal limits</h2>
          <div className="grid grid-cols-2 gap-2">
            <Num label="Min deposit Rs" value={s.limits.depositMinPkr} min={1} onChange={(n) => set('limits', { ...s.limits, depositMinPkr: n })} />
            <Num label="Max deposit Rs" value={s.limits.depositMaxPkr} min={1} onChange={(n) => set('limits', { ...s.limits, depositMaxPkr: n })} />
            <Num label="Daily max Rs / user" value={s.limits.depositDailyMaxPkr} min={1} onChange={(n) => set('limits', { ...s.limits, depositDailyMaxPkr: n })} />
            <Num label="Deposit requests / day" value={s.limits.depositsPerDay} min={1} onChange={(n) => set('limits', { ...s.limits, depositsPerDay: n })} />
            <Num label="Min withdrawal coins" value={s.limits.withdrawMinCoins} min={1} onChange={(n) => set('limits', { ...s.limits, withdrawMinCoins: n })} />
            <Num label="Max withdrawal coins" value={s.limits.withdrawMaxCoins} min={1} onChange={(n) => set('limits', { ...s.limits, withdrawMaxCoins: n })} />
            <Num label="Payout rate (coins per Rs 1)" value={s.limits.withdrawCoinsPerPkr} min={1} onChange={(n) => set('limits', { ...s.limits, withdrawCoinsPerPkr: n })} />
          </div>
          <p className="flex gap-2 rounded-lg bg-primary/10 p-2 text-xs">
            <Lock className="size-4 shrink-0 text-primary" /> Withdrawals are open. The payout rate applies to new requests; existing requests keep the rupee amount fixed when they were made. Wagering stays locked off in code.
          </p>
        </Panel>

        <Panel className="space-y-3">
          <h2 className="font-bold">Game, jurisdiction & support</h2>
          <div className="grid grid-cols-2 gap-2">
            <Num label="Turn timer (seconds)" value={s.game.turnSeconds} min={10} onChange={(n) => set('game', { ...s.game, turnSeconds: n })} />
            <Num label="Bot fill after (seconds)" value={s.game.botFillSeconds} min={5} onChange={(n) => set('game', { ...s.game, botFillSeconds: n })} />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Blocked countries for deposits (ISO codes, comma-separated)</Label>
            <Input
              value={s.blockedCountries.join(', ')}
              onChange={(e) =>
                set(
                  'blockedCountries',
                  e.target.value
                    .split(',')
                    .map((c) => c.trim().toUpperCase())
                    .filter((c) => c.length === 2),
                )
              }
              placeholder="e.g. IN, US"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Support email</Label>
              <Input value={s.support.email} onChange={(e) => set('support', { ...s.support, email: e.target.value })} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Support WhatsApp</Label>
              <Input value={s.support.whatsapp} onChange={(e) => set('support', { ...s.support, whatsapp: e.target.value })} />
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Support hours</Label>
            <Input value={s.support.hours} onChange={(e) => set('support', { ...s.support, hours: e.target.value })} />
          </div>
        </Panel>

        <Panel className="space-y-3 lg:col-span-2">
          <h2 className="flex items-center justify-between font-bold">
            Promotional banners
            <Button size="sm" variant="secondary" disabled={s.banners.length >= 10} onClick={() => set('banners', [...s.banners, { id: `b${Date.now().toString(36)}`, title: '', body: '', active: true }])}>
              <Plus /> Add
            </Button>
          </h2>
          {s.banners.map((b, i) => {
            const up = (patch: Partial<typeof b>) => set('banners', s.banners.map((x, j) => (j === i ? { ...x, ...patch } : x)))
            return (
              <div key={b.id} className="grid items-center gap-2 sm:grid-cols-[1fr_2fr_auto_auto]">
                <Input value={b.title} onChange={(e) => up({ title: e.target.value })} placeholder="Title" />
                <Input value={b.body} onChange={(e) => up({ body: e.target.value })} placeholder="Text" />
                <Switch checked={b.active} onCheckedChange={(v) => up({ active: v })} />
                <Button size="icon" variant="ghost" aria-label="Remove banner" onClick={() => set('banners', s.banners.filter((_, j) => j !== i))}>
                  <Trash2 />
                </Button>
              </div>
            )
          })}
        </Panel>
      </div>

      <Broadcast />

      <div className="fixed right-4 bottom-4 z-40">
        <Button size="lg" className="rounded-full font-bold shadow-2xl" disabled={pending} onClick={save}>
          Save all settings
        </Button>
      </div>
    </div>
  )
}

function Broadcast() {
  const { pending, run } = useAction()
  return (
    <Panel>
      <h2 className="mb-3 flex items-center gap-2 font-bold">
        <Megaphone className="size-4 text-primary" /> Send notification to all players
      </h2>
      <form
        className="grid gap-2 sm:grid-cols-[1fr_2fr_auto]"
        onSubmit={async (e) => {
          e.preventDefault()
          const form = e.currentTarget
          const fd = new FormData(form)
          if (await run(() => adminBroadcast({ data: { title: String(fd.get('title')), body: String(fd.get('body')) } }), 'Notification sent')) form.reset()
        }}
      >
        <Input name="title" required minLength={3} maxLength={80} placeholder="Title" />
        <Input name="body" required minLength={3} maxLength={300} placeholder="Message" />
        <Button type="submit" disabled={pending}>
          Send
        </Button>
      </form>
    </Panel>
  )
}
