import { useState } from 'react'
import { AlertTriangle, Plus } from 'lucide-react'

import { Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { adminCancelTournament, adminCloseRoom, adminCreateTournament, adminEndTournament, adminGames, adminTournaments } from '@/server/admin.functions'
import { Empty, selectCls } from './common'

export function GamesSection() {
  const games = useServer(() => adminGames(), [], 15_000)
  const tours = useServer(() => adminTournaments())
  const { pending, run } = useAction()
  const [announce, setAnnounce] = useState(true)
  return (
    <Tabs defaultValue="rooms">
      <TabsList className="flex-wrap">
        <TabsTrigger value="rooms">Active rooms ({games.data?.rooms.length ?? 0})</TabsTrigger>
        <TabsTrigger value="history">Match history</TabsTrigger>
        <TabsTrigger value="cheat">Anti-cheat reports</TabsTrigger>
        <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
      </TabsList>

      <TabsContent value="rooms" className="mt-4">
        <Panel className="p-0">
          {games.data?.rooms.length === 0 && <Empty>No active rooms.</Empty>}
          <ul className="divide-y divide-white/5 text-sm">
            {games.data?.rooms.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="flex-1">
                  <div className="font-semibold">
                    #{r.code} · {r.mode} {r.isPrivate ? '· private' : '· public'}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {r.seats.join(', ')} · updated {fmtDate(r.updatedAt)}
                  </div>
                </div>
                <StatusBadge status={r.status} />
                <Button size="sm" variant="destructive" disabled={pending} onClick={async () => confirm('Close this room?') && (await run(() => adminCloseRoom({ data: { id: r.id } }), 'Room closed')) && games.reload()}>
                  Close
                </Button>
              </li>
            ))}
          </ul>
        </Panel>
      </TabsContent>

      <TabsContent value="history" className="mt-4">
        <Panel className="p-0">
          {games.data?.history.length === 0 && <Empty>No finished matches yet.</Empty>}
          <ul className="divide-y divide-white/5 text-sm">
            {games.data?.history.map((g) => (
              <li key={g.id} className="p-4">
                <div className="flex justify-between gap-2">
                  <span className="font-semibold">
                    {g.mode} · {g.turns} turns
                  </span>
                  <span className="text-xs text-muted-foreground">{fmtDate(g.endedAt)}</span>
                </div>
                <div className="text-xs text-muted-foreground">
                  {g.players.map((p) => `${p.name}${p.won ? ' 🏆' : ''} (${p.finished}/4)`).join(' · ')}
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      </TabsContent>

      <TabsContent value="cheat" className="mt-4 space-y-3">
        <p className="text-sm text-muted-foreground">
          Dice are generated server-side with a cryptographic RNG and every move is validated by the rules engine, so clients cannot inject rolls or illegal moves. This report lists statistically unusual players (≥10 games, &gt;80% win rate) for manual review.
        </p>
        <Panel className="p-0">
          {games.data?.flagged.length === 0 && <Empty>No suspicious players.</Empty>}
          <ul className="divide-y divide-white/5 text-sm">
            {games.data?.flagged.map((f) => (
              <li key={f.publicId} className="flex items-center gap-3 p-4">
                <AlertTriangle className="size-4 text-ludo-red" />
                <span className="flex-1 font-semibold">
                  {f.name} <span className="font-mono text-xs text-muted-foreground">{f.publicId}</span>
                </span>
                <span className="text-xs">
                  {f.won}/{f.played} wins · {f.winRate}%
                </span>
              </li>
            ))}
          </ul>
        </Panel>
      </TabsContent>

      <TabsContent value="tournaments" className="mt-4 space-y-4">
        <Panel>
          <h2 className="mb-3 flex items-center gap-2 font-bold">
            <Plus className="size-4 text-primary" /> Create tournament
          </h2>
          <form
            className="grid gap-2 sm:grid-cols-3"
            onSubmit={async (e) => {
              e.preventDefault()
              const form = e.currentTarget
              const fd = new FormData(form)
              const r = await run(
                () =>
                  adminCreateTournament({
                    data: {
                      name: String(fd.get('name')),
                      kind: fd.get('kind') as 'daily' | 'weekly' | 'private',
                      mode: fd.get('mode') as '1v1' | '2v2' | '4p',
                      prizeCoins: Number(fd.get('prize')),
                      capacity: Number(fd.get('capacity')),
                      startsAt: new Date(String(fd.get('start'))).toISOString(),
                      hours: Number(fd.get('hours')),
                      announce,
                    },
                  }),
                'Tournament created',
              )
              if (r) {
                form.reset()
                void tours.reload()
              }
            }}
          >
            <Input name="name" required minLength={3} placeholder="Name" className="sm:col-span-3" />
            <select name="kind" className={selectCls}>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="private">Private (invite code)</option>
            </select>
            <select name="mode" className={selectCls}>
              <option value="4p">4 players</option>
              <option value="2v2">2 vs 2</option>
              <option value="1v1">1 vs 1</option>
            </select>
            <Input name="start" type="datetime-local" required />
            <Input name="hours" type="number" min={1} defaultValue={24} required title="Duration (hours)" placeholder="Hours" />
            <Input name="prize" type="number" min={0} defaultValue={1000} required title="Prize pool (bonus coins)" placeholder="Prize (bonus coins)" />
            <Input name="capacity" type="number" min={2} defaultValue={128} required title="Capacity" placeholder="Capacity" />
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={announce} onCheckedChange={setAnnounce} /> Announce to all players
            </label>
            <Button type="submit" disabled={pending} className="sm:col-span-2">
              Create
            </Button>
          </form>
          <p className="mt-2 text-xs text-muted-foreground">Entry is always free; prizes are promotional bonus coins (50/30/20% to the top 3). Daily and weekly free tournaments are also scheduled automatically.</p>
        </Panel>
        <Panel className="p-0">
          {tours.data?.length === 0 && <Empty>No tournaments.</Empty>}
          <ul className="divide-y divide-white/5 text-sm">
            {tours.data?.map((t) => (
              <li key={t.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="flex-1">
                  <div className="font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {t.kind} · {t.mode} · {t.players}/{t.capacity} players · {t.prizeCoins} prize · {fmtDate(t.startsAt)} → {fmtDate(t.endsAt)}
                    {t.inviteCode && ` · code ${t.inviteCode}`}
                  </div>
                </div>
                <StatusBadge status={t.status} />
                {(t.status === 'live' || t.status === 'upcoming') && (
                  <div className="flex gap-2">
                    <Button size="sm" variant="secondary" disabled={pending} onClick={async () => confirm('End now and pay prizes?') && (await run(() => adminEndTournament({ data: { id: t.id } }), 'Settled')) && tours.reload()}>
                      End & settle
                    </Button>
                    <Button size="sm" variant="destructive" disabled={pending} onClick={async () => confirm('Cancel tournament? No prizes will be paid.') && (await run(() => adminCancelTournament({ data: { id: t.id } }), 'Cancelled')) && tours.reload()}>
                      Cancel
                    </Button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </Panel>
      </TabsContent>
    </Tabs>
  )
}
