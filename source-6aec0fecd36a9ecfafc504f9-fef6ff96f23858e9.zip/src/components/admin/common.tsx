import { Panel } from '@/components/brand'
import { cn } from '@/lib/utils'

export function Stat({ label, value, icon: Icon, hint, onClick }: { label: string; value: React.ReactNode; icon: React.ComponentType<{ className?: string }>; hint?: string; onClick?: () => void }) {
  return (
    <Panel className={cn('p-4', onClick && 'cursor-pointer transition hover:bg-white/10')}>
      <div onClick={onClick}>
        <div className="flex items-center justify-between text-xs font-semibold text-muted-foreground">
          {label}
          <Icon className="size-4" />
        </div>
        <div className="mt-2 font-display text-2xl font-extrabold">{value}</div>
        {hint && <div className="mt-0.5 text-xs text-muted-foreground">{hint}</div>}
      </div>
    </Panel>
  )
}

export function Filter({ value, options, onChange }: { value: string; options: [string, string][]; onChange: (v: string) => void }) {
  return (
    <div className="flex gap-1 overflow-x-auto rounded-full bg-white/5 p-1 ring-1 ring-white/10">
      {options.map(([id, label]) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={cn('shrink-0 rounded-full px-3 py-1 text-xs font-semibold', value === id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground')}
        >
          {label}
        </button>
      ))}
    </div>
  )
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <p className="py-8 text-center text-sm text-muted-foreground">{children}</p>
}

export const selectCls = 'h-9 w-full rounded-md border bg-transparent px-3 text-sm'
