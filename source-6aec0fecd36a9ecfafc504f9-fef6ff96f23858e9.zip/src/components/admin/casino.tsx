import { useEffect, useState } from 'react'
import { Activity, AlertTriangle, Gauge, Layers, ShieldCheck, Users } from 'lucide-react'

import { Coins, Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { card, CASINO_INFO, fmtX, type AviatorConfig, type CasinoKey, type DragonTigerConfig } from '@/lib/games/casino'
import { cn } from '@/lib/utils'
import {
  adminCasinoAudit,
  adminCasinoBets,
  adminCasinoDisputes,
  adminCasinoLedger,
  adminCasinoOverview,
  adminCasinoRounds,
  adminGetCasino,
  adminResolveCasinoDispute,
  adminSaveCasino,
} from '@/server/casino-admin.functions'
import { Empty, Filter, Stat } from './common'

/**
 * Admin section for Dragon Tiger or Aviator. Everything here is either
 * configuration (applies to future rounds/bets) or read-only. There is no
 * control that sets or changes a round result.
 */
export function CasinoSection({ game }: { game: CasinoKey }) {
  return (
    <Tabs defaultValue="overview" className="space-y-4">
      <TabsList className="flex h-auto flex-wrap justify-start">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="settings">Settings</TabsTrigger>
        <TabsTrigger value="rounds">Rounds</TabsTrigger>
        <TabsTrigger value="bets">Player bets</TabsTrigger>
        <TabsTrigger value="ledger">Wallet transactions</TabsTrigger>
        <TabsTrigger value="disputes">Disputes</TabsTrigger>
        <TabsTrigger value="audit">Audit log</TabsTrigger>
      </TabsList>
      <TabsContent value="overview"><OverviewTab game={game} /></TabsContent>
      <TabsContent value="settings"><SettingsTab game={game} /></TabsContent>
      <TabsContent value="rounds"><RoundsTab game={game} /></TabsContent>
      <TabsContent value="bets"><BetsTab game={game} /></TabsContent>
      <TabsContent value="ledger"><LedgerTab game={game} /></TabsContent>
      <TabsContent value="disputes"><DisputesTab game={game} /></TabsContent>
      <TabsContent value="audit"><AuditTab game={game} /></TabsContent>
    </Tabs>
  )
}

const n = (v: number) => v.toLocaleString()

function resultText(r: { game: string; dt: { dragon: number; tiger: number; winner: string } | null; crashX100: number | null }) {
  if (r.game === 'dragon_tiger')
    return r.dt ? `${card(r.dt.dragon).rank}${card(r.dt.dragon).suit} vs ${card(r.dt.tiger).rank}${card(r.dt.tiger).suit} · ${r.dt.winner}` : 'hidden until reveal'
  return r.crashX100 != null ? fmtX(r.crashX100) : 'hidden until crash'
}

function OverviewTab({ game }: { game: CasinoKey }) {
  const { data } = useServer(() => adminCasinoOverview({ data: { game } }), [game], 5000)
  if (!data) return <Panel>Loading…</Panel>
  const periods = [
    ['Last 24 h', data.today],
    ['Last 7 days', data.week],
    ['All time', data.all],
  ] as const
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Open bets (liability)" value={n(data.liability.openBets)} icon={Layers} hint={`${n(data.liability.openStake)} coins staked`} />
        <Stat label="Max possible payout" value={<Coins value={data.liability.maxPayout} />} icon={AlertTriangle} hint="Worst case of all unsettled bets" />
        <Stat label="Settled rounds" value={n(data.rounds)} icon={Activity} />
        <Stat label="Open disputes" value={n(data.openDisputes)} icon={ShieldCheck} />
      </div>
      <Panel className="overflow-x-auto p-0">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">Performance</th>
              <th className="p-3 text-right">Bets</th>
              <th className="p-3 text-right">Players</th>
              <th className="p-3 text-right">Staked</th>
              <th className="p-3 text-right">Paid out</th>
              <th className="p-3 text-right">Fees</th>
              <th className="p-3 text-right">Platform net</th>
              <th className="p-3 text-right">RTP</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {periods.map(([label, s]) => (
              <tr key={label}>
                <td className="p-3 font-semibold">{label}</td>
                <td className="p-3 text-right tabular-nums">{n(s.bets)}</td>
                <td className="p-3 text-right tabular-nums">{n(s.players)}</td>
                <td className="p-3 text-right tabular-nums">{n(s.stake)}</td>
                <td className="p-3 text-right tabular-nums">{n(s.payout)}</td>
                <td className="p-3 text-right tabular-nums">{n(s.fees)}</td>
                <td className={cn('p-3 text-right font-bold tabular-nums', s.net >= 0 ? 'text-ludo-green' : 'text-ludo-red')}>{s.net >= 0 ? '+' : ''}{n(s.net)}</td>
                <td className="p-3 text-right tabular-nums">{s.rtp == null ? '—' : `${s.rtp}%`}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
      <Panel>
        <h3 className="mb-2 flex items-center gap-2 font-bold"><Gauge className="size-4 text-primary" /> Active rounds</h3>
        {!data.active.length && <Empty>No active round. The next round opens when a player loads the game.</Empty>}
        <ul className="divide-y divide-white/5 text-sm">
          {data.active.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span className="font-mono font-bold">{r.id}</span>
              <span className="capitalize">{r.phase}</span>
              <span>{r.openBets} bets · {n(r.openStake)} coins</span>
              <span className="text-xs text-muted-foreground">{resultText(r)}</span>
              <span className="w-full truncate font-mono text-[10px] text-muted-foreground">seed hash {r.seedHash}</span>
            </li>
          ))}
        </ul>
        <p className="mt-2 text-xs text-muted-foreground">Results are fixed by the seed committed when the round opens. Unsettled seeds are never shown here and cannot be edited.</p>
      </Panel>
    </div>
  )
}

function Num({ label, value, onChange, step, hint }: { label: string; value: number; onChange: (v: number) => void; step?: number; hint?: string }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      <Input type="number" step={step ?? 1} value={Number.isFinite(value) ? value : ''} onChange={(e) => onChange(Number(e.target.value))} />
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  )
}

function SettingsTab({ game }: { game: CasinoKey }) {
  const { data, reload } = useServer(() => adminGetCasino(), [])
  const [cfg, setCfg] = useState<DragonTigerConfig | AviatorConfig | null>(null)
  const [presets, setPresets] = useState('')
  const { pending, run } = useAction()
  useEffect(() => {
    if (data) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- load the saved config into the form
      setCfg(data[game])
      setPresets(data[game].presets.join(', '))
    }
  }, [data, game])
  if (!cfg) return <Panel>Loading…</Panel>
  const set = (patch: Partial<DragonTigerConfig & AviatorConfig>) => setCfg((c) => (c ? ({ ...c, ...patch } as typeof c) : c))
  const dt = game === 'dragon_tiger' ? (cfg as DragonTigerConfig) : null
  const av = game === 'aviator' ? (cfg as AviatorConfig) : null

  const save = async () => {
    const p = presets.split(/[,\s]+/).map(Number).filter((x) => Number.isInteger(x) && x > 0)
    const config = { ...cfg, presets: p.length ? p : [cfg.minBet] }
    const r = await run(
      () => (game === 'dragon_tiger' ? adminSaveCasino({ data: { game, config: config as DragonTigerConfig } }) : adminSaveCasino({ data: { game, config: config as AviatorConfig } })),
      'Settings saved and logged',
    )
    if (r) void reload()
  }

  return (
    <div className="space-y-4">
      <Panel className="space-y-4">
        <h3 className="font-bold">Availability</h3>
        <div className="flex flex-wrap gap-6">
          <label className="flex items-center gap-2 text-sm font-semibold">
            <Switch checked={cfg.enabled} onCheckedChange={(v) => set({ enabled: v })} /> Game enabled
          </label>
          <label className="flex items-center gap-2 text-sm font-semibold">
            <Switch checked={cfg.paused} onCheckedChange={(v) => set({ paused: v })} /> Paused for maintenance
          </label>
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Maintenance message shown to players</Label>
          <Input value={cfg.pauseMessage} maxLength={200} onChange={(e) => set({ pauseMessage: e.target.value })} />
        </div>
        <p className="text-xs text-muted-foreground">Disabling or pausing stops new bets and new rounds. Rounds that already have bets always finish and settle normally.</p>
      </Panel>

      <Panel className="space-y-4">
        <h3 className="font-bold">Bet limits & exposure</h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Num label="Minimum bet" value={cfg.minBet} onChange={(v) => set({ minBet: v })} />
          <Num label="Maximum bet" value={cfg.maxBet} onChange={(v) => set({ maxBet: v })} />
          <Num label="Max payout per bet" value={cfg.maxPayoutPerBet} onChange={(v) => set({ maxPayoutPerBet: v })} hint="Total return incl. stake" />
          <Num label="Max exposure per round" value={cfg.maxRoundExposure} onChange={(v) => set({ maxRoundExposure: v })} hint="New bets are refused above this" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Quick-pick amounts (comma separated)</Label>
          <Input value={presets} onChange={(e) => setPresets(e.target.value)} />
        </div>
      </Panel>

      {dt && (
        <Panel className="space-y-4">
          <h3 className="font-bold">Published odds & fees</h3>
          <div className="grid gap-3 sm:grid-cols-3">
            <Num label="Dragon odds (N:1 net profit)" step={0.05} value={dt.odds.dragon} onChange={(v) => set({ odds: { ...dt.odds, dragon: v } })} />
            <Num label="Tiger odds (N:1 net profit)" step={0.05} value={dt.odds.tiger} onChange={(v) => set({ odds: { ...dt.odds, tiger: v } })} />
            <Num label="Tie odds (N:1 net profit)" step={0.5} value={dt.odds.tie} onChange={(v) => set({ odds: { ...dt.odds, tie: v } })} />
            <Num label="Tie refund on Dragon/Tiger bets %" value={dt.tieRefundPercent} onChange={(v) => set({ tieRefundPercent: v })} />
            <Num label="Commission on winnings %" value={dt.feePercent} onChange={(v) => set({ feePercent: v })} hint="Taken from profit only" />
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Num label="Betting window (seconds)" value={dt.bettingSeconds} onChange={(v) => set({ bettingSeconds: v })} />
            <Num label="Reveal time (seconds)" value={dt.revealSeconds} onChange={(v) => set({ revealSeconds: v })} />
          </div>
        </Panel>
      )}
      {av && (
        <Panel className="space-y-4">
          <h3 className="font-bold">Published odds & fees</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Num label="House edge %" step={0.5} value={av.houseEdgePercent} onChange={(v) => set({ houseEdgePercent: v })} hint={`Expected return ${(100 - av.houseEdgePercent).toFixed(1)}%`} />
            <Num label="Max multiplier (x)" value={av.maxMultiplier} onChange={(v) => set({ maxMultiplier: v })} />
            <Num label="Betting window (seconds)" value={av.bettingSeconds} onChange={(v) => set({ bettingSeconds: v })} />
            <Num label="Pause after crash (seconds)" value={av.pauseSeconds} onChange={(v) => set({ pauseSeconds: v })} />
          </div>
        </Panel>
      )}
      <div className="flex flex-wrap items-center gap-3">
        <Button onClick={() => void save()} disabled={pending} className="font-bold">Save settings</Button>
        <p className="text-xs text-muted-foreground">Changes apply to the next round and new bets. Bets already placed keep the odds they were accepted with. Every change is written to the audit log and shown to players on the game page.</p>
      </div>
    </div>
  )
}

function RoundsTab({ game }: { game: CasinoKey }) {
  const [filter, setFilter] = useState<'active' | 'completed'>('completed')
  const [q, setQ] = useState('')
  const { data } = useServer(() => adminCasinoRounds({ data: { game, filter, q } }), [game, filter, q], 10_000)
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3">
        <Filter value={filter} onChange={(v) => setFilter(v as typeof filter)} options={[['completed', 'Completed'], ['active', 'Active']]} />
        <Input value={q} onChange={(e) => setQ(e.target.value.toUpperCase())} placeholder="Round ID" className="ml-auto w-full font-mono sm:w-52" />
      </div>
      <Panel className="overflow-x-auto p-0">
        {data?.length === 0 && <Empty>No rounds.</Empty>}
        <table className="w-full min-w-[760px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">Round</th>
              <th className="p-3">Result</th>
              <th className="p-3 text-right">Bets</th>
              <th className="p-3 text-right">Staked</th>
              <th className="p-3 text-right">Paid</th>
              <th className="p-3">Seed (revealed after settlement)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data?.map((r) => (
              <tr key={r.id}>
                <td className="p-3 font-mono text-xs">
                  {r.id}
                  <div className="text-[10px] text-muted-foreground">{fmtDate(r.closesAt)}</div>
                </td>
                <td className="p-3 capitalize">{resultText(r)}</td>
                <td className="p-3 text-right tabular-nums">{r.betCount}</td>
                <td className="p-3 text-right tabular-nums">{n(r.totalStake)}</td>
                <td className="p-3 text-right tabular-nums">{n(r.totalPayout)}</td>
                <td className="max-w-[18rem] p-3 font-mono text-[10px] break-all text-muted-foreground">
                  hash {r.seedHash}
                  {r.serverSeed && <div className="text-foreground">seed {r.serverSeed}</div>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  )
}

function BetsTab({ game }: { game: CasinoKey }) {
  const [status, setStatus] = useState<'all' | 'active' | 'won' | 'lost' | 'push' | 'cancelled'>('all')
  const [q, setQ] = useState('')
  const [query, setQuery] = useState('')
  const { data } = useServer(() => adminCasinoBets({ data: { game, status, q: query } }), [game, status, query], 10_000)
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3">
        <Filter value={status} onChange={(v) => setStatus(v as typeof status)} options={[['all', 'All'], ['active', 'Open'], ['won', 'Won'], ['lost', 'Lost'], ...(game === 'dragon_tiger' ? [['push', 'Tie refund'] as [string, string]] : []), ['cancelled', 'Cancelled']]} />
        <form className="ml-auto w-full sm:w-72" onSubmit={(e) => { e.preventDefault(); setQuery(q) }}>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Bet / round ID, LKA-ID, name, email" />
        </form>
      </div>
      <Panel className="overflow-x-auto p-0">
        {data?.length === 0 && <Empty>No bets.</Empty>}
        <table className="w-full min-w-[820px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">Bet</th>
              <th className="p-3">Player</th>
              <th className="p-3">{game === 'aviator' ? 'Slot / auto' : 'Side'}</th>
              <th className="p-3 text-right">Stake</th>
              <th className="p-3">Status</th>
              <th className="p-3 text-right">Return</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data?.map((b) => (
              <tr key={b.id}>
                <td className="p-3 font-mono text-xs">
                  {b.id}
                  <div className="text-[10px] text-muted-foreground">{b.roundId} · {fmtDate(b.createdAt)}</div>
                </td>
                <td className="p-3">
                  {b.name}
                  <div className="font-mono text-[10px] text-muted-foreground">{b.publicId}</div>
                </td>
                <td className="p-3 capitalize">
                  {game === 'aviator' ? `Slot ${b.choice}${b.autoX100 ? ` · auto ${fmtX(b.autoX100)}` : ''}` : `${b.choice} · ${Number(b.terms.oddsX100) / 100}:1`}
                </td>
                <td className="p-3 text-right tabular-nums">{n(b.stake)}</td>
                <td className="p-3">
                  <StatusBadge status={b.status === 'push' ? 'tie refund' : b.status} />
                  {b.cashoutX100 && <span className="ml-1 text-xs">@ {fmtX(b.cashoutX100)}</span>}
                </td>
                <td className="p-3 text-right font-bold tabular-nums">
                  {n(b.payout)}
                  {b.fee > 0 && <div className="text-[10px] font-normal text-muted-foreground">fee {n(b.fee)}</div>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  )
}

function LedgerTab({ game }: { game: CasinoKey }) {
  const [type, setType] = useState<'all' | 'casino_bet' | 'casino_win' | 'casino_loss' | 'casino_refund'>('all')
  const { data } = useServer(() => adminCasinoLedger({ data: { game, type } }), [game, type], 15_000)
  return (
    <div className="space-y-3">
      <Filter value={type} onChange={(v) => setType(v as typeof type)} options={[['all', 'All'], ['casino_bet', 'Stakes'], ['casino_win', 'Wins / payouts'], ['casino_loss', 'Losses'], ['casino_refund', 'Refunds']]} />
      <Panel className="overflow-x-auto p-0">
        {data?.length === 0 && <Empty>No wallet transactions yet.</Empty>}
        <table className="w-full min-w-[760px] text-sm">
          <thead className="text-left text-xs text-muted-foreground">
            <tr>
              <th className="p-3">Transaction</th>
              <th className="p-3">Player</th>
              <th className="p-3">Description</th>
              <th className="p-3 text-right">Amount</th>
              <th className="p-3 text-right">Balance after</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {data?.map((t) => (
              <tr key={t.id}>
                <td className="p-3 font-mono text-xs">
                  {t.id}
                  <div className="text-[10px] text-muted-foreground">{fmtDate(t.createdAt)}</div>
                </td>
                <td className="p-3">
                  {t.name}
                  <div className="font-mono text-[10px] text-muted-foreground">{t.publicId}</div>
                </td>
                <td className="p-3">
                  {t.label}
                  <div className="text-[10px] text-muted-foreground capitalize">{t.type.replace('casino_', '')} · {t.bucket} · {t.refId}</div>
                </td>
                <td className={cn('p-3 text-right font-bold tabular-nums', t.amount > 0 ? 'text-ludo-green' : t.amount < 0 ? 'text-ludo-red' : 'text-muted-foreground')}>
                  {t.amount > 0 ? '+' : ''}{n(t.amount)}
                </td>
                <td className="p-3 text-right tabular-nums">{n(t.balanceAfter)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  )
}

function DisputesTab({ game }: { game: CasinoKey }) {
  const [status, setStatus] = useState<'open' | 'resolved' | 'dismissed' | 'all'>('open')
  const { data, reload } = useServer(() => adminCasinoDisputes({ data: { game, status } }), [game, status], 30_000)
  const [answer, setAnswer] = useState<Record<number, string>>({})
  const { pending, run } = useAction()
  const close = async (id: number, s: 'resolved' | 'dismissed') => {
    const r = await run(() => adminResolveCasinoDispute({ data: { id, status: s, resolution: answer[id] ?? '' } }), 'Dispute closed and player notified')
    if (r) void reload()
  }
  return (
    <div className="space-y-3">
      <Filter value={status} onChange={(v) => setStatus(v as typeof status)} options={[['open', 'Open'], ['resolved', 'Resolved'], ['dismissed', 'Dismissed'], ['all', 'All']]} />
      {data?.length === 0 && <Panel><Empty>No disputes.</Empty></Panel>}
      {data?.map((d) => (
        <Panel key={d.id} className="space-y-2 text-sm">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-semibold">{d.name} <span className="font-mono text-xs text-muted-foreground">{d.publicId}</span></span>
            <StatusBadge status={d.status} />
          </div>
          <div className="font-mono text-xs text-muted-foreground">
            Bet {d.betId} · round {d.roundId} · {d.choice} · stake {n(d.stake ?? 0)} · {d.betStatus} · returned {n(d.payout ?? 0)} · {fmtDate(d.createdAt)}
          </div>
          <p className="rounded-lg bg-white/5 p-2">{d.reason}</p>
          {d.status === 'open' ? (
            <>
              <Textarea placeholder="Answer to the player (min 5 characters)" value={answer[d.id] ?? ''} onChange={(e) => setAnswer((a) => ({ ...a, [d.id]: e.target.value }))} />
              <div className="flex gap-2">
                <Button size="sm" disabled={pending || (answer[d.id] ?? '').trim().length < 5} onClick={() => void close(d.id, 'resolved')}>Resolve</Button>
                <Button size="sm" variant="outline" disabled={pending || (answer[d.id] ?? '').trim().length < 5} onClick={() => void close(d.id, 'dismissed')}>Dismiss</Button>
              </div>
              <p className="text-[11px] text-muted-foreground">Closing a dispute never changes the round or the bet. If a goodwill credit is justified, use Users → Details → wallet adjustment (separately audit-logged).</p>
            </>
          ) : (
            d.resolution && <p className="text-xs text-muted-foreground">Answer: {d.resolution}</p>
          )}
        </Panel>
      ))}
    </div>
  )
}

function AuditTab({ game }: { game: CasinoKey }) {
  const { data } = useServer(() => adminCasinoAudit({ data: { game } }), [game], 30_000)
  return (
    <Panel>
      {data?.length === 0 && <Empty>No admin activity for {CASINO_INFO[game].name} yet.</Empty>}
      <ul className="divide-y divide-white/5 text-sm">
        {data?.map((a) => (
          <li key={a.id} className="py-2.5">
            <div className="flex flex-wrap justify-between gap-2">
              <span className="font-semibold">{a.action}</span>
              <span className="text-xs text-muted-foreground">{fmtDate(a.createdAt)}</span>
            </div>
            <div className="text-xs text-muted-foreground">{a.actorEmail}</div>
            {a.details && <code className="mt-1 block text-[11px] break-all text-muted-foreground">{a.details}</code>}
          </li>
        ))}
      </ul>
      <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground"><Users className="size-3" /> Every bet, cash-out and payout is also listed in the Player bets and Wallet transactions tabs.</p>
    </Panel>
  )
}
