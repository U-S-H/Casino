import { describe, expect, it } from 'vitest'

import { FINISH, TRACK, applyMove, createGame, movableTokens, nextTurn, tokenPoint } from './ludo'

describe('ludo engine', () => {
  it('has a 52-cell track with unique cells', () => {
    expect(TRACK).toHaveLength(52)
    expect(new Set(TRACK.map(([r, c]) => `${r},${c}`)).size).toBe(52)
  })

  it('needs a six to leave the yard', () => {
    const g = createGame('4p')
    expect(movableTokens(g.players[0], 5)).toEqual([])
    expect(movableTokens(g.players[0], 6)).toEqual([0, 1, 2, 3])
  })

  it('captures an opponent on a non-safe cell and grants an extra turn', () => {
    const g = createGame('1v1')
    // red at progress 2 (abs 2); yellow token sitting on abs 5 = yellow progress 31.
    g.players[0].tokens[0] = 2
    g.players[1].tokens[0] = 31
    const res = applyMove({ ...g, dice: 3 }, 0)
    expect(res.captured).toBe(true)
    expect(res.extraTurn).toBe(true)
    expect(res.state.players[1].tokens[0]).toBe(-1)
  })

  it('does not capture teammates in 2v2', () => {
    const g = createGame('2v2')
    const yellow = g.players.find((p) => p.color === 'yellow')!
    g.players[0].tokens[0] = 2
    yellow.tokens[0] = 31
    const res = applyMove({ ...g, dice: 3 }, 0)
    expect(res.captured).toBe(false)
  })

  it('requires an exact roll to finish and declares a winner', () => {
    const g = createGame('1v1')
    g.players[0].tokens = [FINISH, FINISH, FINISH, 54]
    expect(movableTokens(g.players[0], 3)).toEqual([])
    const res = applyMove({ ...g, dice: 2 }, 3)
    expect(res.state.winnerTeam).toBe(g.players[0].team)
  })

  it('passes the turn and maps positions onto the board', () => {
    const g = createGame('4p')
    expect(nextTurn(g, false).turn).toBe(1)
    expect(tokenPoint('red', 0, 0)).toEqual([6.5, 1.5])
  })
})
