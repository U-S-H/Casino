import { getRouteApi, useRouter } from '@tanstack/react-router'
import { useCallback, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'

/** Pulls a readable message out of a server-function error. */
export function errMsg(e: unknown): string {
  if (e && typeof e === 'object') {
    const m = (e as { message?: unknown }).message
    if (typeof m === 'string' && m) {
      // zod errors arrive as a JSON array string
      if (m.startsWith('[')) {
        try {
          const parsed = JSON.parse(m) as { message?: string }[]
          if (parsed[0]?.message) return parsed[0].message
        } catch {
          /* fall through */
        }
      }
      return m
    }
  }
  return 'Something went wrong. Please try again.'
}

/**
 * Minimal data hook for server functions: loads on mount, optional polling,
 * manual reload. Keeps the previous data while refreshing.
 */
export function useServer<T>(fn: () => Promise<T>, deps: unknown[] = [], pollMs?: number) {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const fnRef = useRef(fn)
  useEffect(() => {
    fnRef.current = fn
  })
  const reload = useCallback(async () => {
    try {
      const d = await fnRef.current()
      setData(d)
      setError(null)
    } catch (e) {
      setError(errMsg(e))
    } finally {
      setLoading(false)
    }
  }, [])
  useEffect(() => {
    void reload()
    if (!pollMs) return
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') void reload()
    }, pollMs)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
  return { data, error, loading, reload, setData }
}

/** Wraps a mutation with pending state + toasts. */
export function useAction() {
  const [pending, setPending] = useState(false)
  const run = useCallback(async <T,>(fn: () => Promise<T>, success?: string | ((r: T) => string)) => {
    setPending(true)
    try {
      const r = await fn()
      if (success) toast.success(typeof success === 'function' ? success(r) : success)
      return r
    } catch (e) {
      toast.error(errMsg(e))
      return undefined
    } finally {
      setPending(false)
    }
  }, [])
  return { pending, run }
}

const appApi = getRouteApi('/app')

/** Session data loaded by the /app layout guard (always signed in there). */
export function useApp() {
  const ctx = appApi.useRouteContext()
  const router = useRouter()
  return { ...ctx.session, refresh: () => router.invalidate() }
}

export function fmtDate(d: Date | string | null | undefined, withTime = true) {
  if (!d) return '—'
  const date = typeof d === 'string' ? new Date(d) : d
  return date.toLocaleString(undefined, withTime ? { dateStyle: 'medium', timeStyle: 'short' } : { dateStyle: 'medium' })
}

export function timeAgo(d: Date | string) {
  const date = typeof d === 'string' ? new Date(d) : d
  const s = Math.max(1, Math.round((Date.now() - date.getTime()) / 1000))
  if (s < 60) return `${s}s`
  if (s < 3600) return `${Math.round(s / 60)}m`
  if (s < 86400) return `${Math.round(s / 3600)}h`
  return `${Math.round(s / 86400)}d`
}

export function setReferralCookie(code: string) {
  const clean = code.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 20)
  if (!clean) return
  document.cookie = `lka_ref=${clean}; path=/; max-age=${60 * 60 * 24 * 30}; samesite=lax; secure`
}
export function getReferralCookie() {
  if (typeof document === 'undefined') return ''
  return document.cookie.match(/(?:^|; )lka_ref=([^;]+)/)?.[1] ?? ''
}

export const initialsOf = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join('') || '?'

export const METHOD_LABEL: Record<string, string> = { easypaisa: 'EasyPaisa', jazzcash: 'JazzCash', sadapay: 'SadaPay' }
export const METHOD_COLOR: Record<string, string> = {
  easypaisa: 'oklch(0.68 0.18 150)',
  jazzcash: 'oklch(0.63 0.22 25)',
  sadapay: 'oklch(0.72 0.14 200)',
}

export const todayKey = () => new Date().toISOString().slice(0, 10)
