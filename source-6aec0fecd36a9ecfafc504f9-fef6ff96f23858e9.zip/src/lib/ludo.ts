/**
 * Pure Ludo rules engine. No React, no I/O — the same functions can later run
 * server-side to validate moves in live multiplayer matches (see PLAN.md).
 *
 * Token progress is relative to each colour's start cell:
 *   -1        → in the yard
 *   0..50     → on the shared 52-cell track
 *   51..55    → in the colour's home column
 *   56        → finished
 */

export type Color = 'red' | 'green' | 'yellow' | 'blue'
export type Mode = '1v1' | '2v2' | '4p'

export const COLORS: Color[] = ['red', 'green', 'yellow', 'blue']
export const START_INDEX: Record<Color, number> = {
  red: 0,
  green: 13,
  yellow: 26,
  blue: 39,
}
export const FINISH = 56
const LAST_TRACK = 50

/** Absolute track cells where captures are not allowed (starts + stars). */
export const SAFE_CELLS = new Set([0, 8, 13, 21, 26, 34, 39, 47])

/** [row, col] on a 15×15 grid for each of the 52 shared track cells. */
export const TRACK: [number, number][] = (() => {
  const t: [number, number][] = []
  for (let c = 1; c <= 5; c++) t.push([6, c])
  for (let r = 5; r >= 0; r--) t.push([r, 6])
  t.push([0, 7])
  for (let r = 0; r <= 5; r++) t.push([r, 8])
  for (let c = 9; c <= 14; c++) t.push([6, c])
  t.push([7, 14])
  for (let c = 14; c >= 9; c--) t.push([8, c])
  for (let r = 9; r <= 14; r++) t.push([r, 8])
  t.push([14, 7])
  for (let r = 14; r >= 9; r--) t.push([r, 6])
  for (let c = 5; c >= 0; c--) t.push([8, c])
  t.push([7, 0])
  t.push([6, 0])
  return t
})()

export const HOME_COLUMN: Record<Color, [number, number][]> = {
  red: [1, 2, 3, 4, 5].map((c) => [7, c] as [number, number]),
  green: [1, 2, 3, 4, 5].map((r) => [r, 7] as [number, number]),
  yellow: [13, 12, 11, 10, 9].map((c) => [7, c] as [number, number]),
  blue: [13, 12, 11, 10, 9].map((r) => [r, 7] as [number, number]),
}

const YARD_ORIGIN: Record<Color, [number, number]> = {
  red: [0, 0],
  green: [0, 9],
  yellow: [9, 9],
  blue: [9, 0],
}

const FINISH_POS: Record<Color, [number, number]> = {
  red: [7.5, 6.55],
  green: [6.55, 7.5],
  yellow: [7.5, 8.45],
  blue: [8.45, 7.5],
}

export function absoluteCell(color: Color, progress: number): number | null {
  if (progress < 0 || progress > LAST_TRACK) return null
  return (START_INDEX[color] + progress) % 52
}

/** Centre point of a token in grid units (0..15), for absolute positioning. */
export function tokenPoint(
  color: Color,
  progress: number,
  tokenIndex: number,
): [number, number] {
  if (progress < 0) {
    const [r0, c0] = YARD_ORIGIN[color]
    const dr = tokenIndex < 2 ? 2 : 4
    const dc = tokenIndex % 2 === 0 ? 2 : 4
    return [r0 + dr, c0 + dc]
  }
  if (progress >= FINISH) return FINISH_POS[color]
  if (progress > LAST_TRACK) {
    const [r, c] = HOME_COLUMN[color][progress - LAST_TRACK - 1]
    return [r + 0.5, c + 0.5]
  }
  const [r, c] = TRACK[absoluteCell(color, progress)!]
  return [r + 0.5, c + 0.5]
}

export interface Player {
  color: Color
  name: string
  isBot: boolean
  team: number
  tokens: number[]
}

export interface GameState {
  mode: Mode
  players: Player[]
  turn: number
  dice: number | null
  sixStreak: number
  winnerTeam: number | null
  finishOrder: Color[]
  log: string[]
}

export function createGame(mode: Mode, humanName = 'You'): GameState {
  const colors: Color[] = mode === '1v1' ? ['red', 'yellow'] : COLORS
  const botNames = ['Zara', 'Bilal', 'Hina', 'Omar']
  return {
    mode,
    players: colors.map((color, i) => ({
      color,
      name: i === 0 ? humanName : botNames[i],
      isBot: i !== 0,
      // 2v2: red+yellow vs green+blue (partners sit opposite).
      team: mode === '2v2' ? (color === 'red' || color === 'yellow' ? 0 : 1) : i,
      tokens: [-1, -1, -1, -1],
    })),
    turn: 0,
    dice: null,
    sixStreak: 0,
    winnerTeam: null,
    finishOrder: [],
    log: ['Match started. Roll a 6 to bring a token out.'],
  }
}

export function movableTokens(player: Player, dice: number): number[] {
  return player.tokens
    .map((p, i) => ({ p, i }))
    .filter(({ p }) => (p < 0 ? dice === 6 : p + dice <= FINISH))
    .map(({ i }) => i)
}

export interface MoveResult {
  state: GameState
  captured: boolean
  finished: boolean
  extraTurn: boolean
}

/** Applies a full move (token jumps straight to its target). */
export function applyMove(
  state: GameState,
  tokenIndex: number,
): MoveResult {
  const dice = state.dice!
  const players = state.players.map((p) => ({ ...p, tokens: [...p.tokens] }))
  const me = players[state.turn]
  const from = me.tokens[tokenIndex]
  const to = from < 0 ? 0 : from + dice
  me.tokens[tokenIndex] = to
  const log = [...state.log]

  let captured = false
  const cell = absoluteCell(me.color, to)
  if (cell !== null && !SAFE_CELLS.has(cell)) {
    for (const other of players) {
      if (other.team === me.team) continue
      other.tokens = other.tokens.map((p) => {
        if (absoluteCell(other.color, p) === cell) {
          captured = true
          log.push(`${me.name} captured ${other.name}'s token!`)
          return -1
        }
        return p
      })
    }
  }

  const finished = to === FINISH
  if (finished) log.push(`${me.name} brought a token home.`)

  const finishOrder = [...state.finishOrder]
  if (me.tokens.every((p) => p === FINISH) && !finishOrder.includes(me.color))
    finishOrder.push(me.color)

  let winnerTeam: number | null = null
  for (const team of new Set(players.map((p) => p.team))) {
    const members = players.filter((p) => p.team === team)
    if (members.every((m) => m.tokens.every((t) => t === FINISH))) {
      winnerTeam = team
      break
    }
  }

  const extraTurn = winnerTeam === null && (dice === 6 || captured || finished)
  return {
    state: {
      ...state,
      players,
      log: log.slice(-30),
      finishOrder,
      winnerTeam,
    },
    captured,
    finished,
    extraTurn,
  }
}

export function nextTurn(state: GameState, keepTurn: boolean): GameState {
  if (keepTurn) return { ...state, dice: null }
  let t = state.turn
  do {
    t = (t + 1) % state.players.length
  } while (
    state.players[t].tokens.every((p) => p === FINISH) &&
    t !== state.turn
  )
  return { ...state, turn: t, dice: null, sixStreak: 0 }
}

/** Simple heuristic bot: capture > finish > leave yard > safe > furthest. */
export function chooseBotMove(state: GameState, options: number[]): number {
  const me = state.players[state.turn]
  const dice = state.dice!
  let best = options[0]
  let bestScore = -Infinity
  for (const i of options) {
    const from = me.tokens[i]
    const to = from < 0 ? 0 : from + dice
    let score = to
    const cell = absoluteCell(me.color, to)
    if (to === FINISH) score += 80
    if (from < 0) score += 40
    if (cell !== null && SAFE_CELLS.has(cell)) score += 15
    if (cell !== null && !SAFE_CELLS.has(cell)) {
      for (const o of state.players) {
        if (o.team === me.team) continue
        if (o.tokens.some((p) => absoluteCell(o.color, p) === cell)) score += 100
      }
    }
    if (score > bestScore) {
      bestScore = score
      best = i
    }
  }
  return best
}

export function rollDie(): number {
  return 1 + Math.floor(Math.random() * 6)
}
