/**
 * Shared contract for the turn-based arena games (8 Ball Pool, Carrom, Chess).
 *
 * Every engine is pure and deterministic: no I/O, no Date.now(), no
 * Math.random() inside `apply`/`timeout`. The same module runs on the server
 * (authoritative — it decides results and payouts) and in the browser (to
 * preview aim lines and replay shot animations). State must be plain JSON.
 */

export type ArenaGameId = 'pool' | 'carrom' | 'chess'

/** Thrown for illegal actions. The server shows `message` to the player. */
export class GameRuleError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'GameRuleError'
  }
}

export interface StepResult<S> {
  state: S
  /** True once the match is over. */
  done: boolean
  /** Winning seat (0 or 1) when done; null when done as a draw. Ignored if !done. */
  winner: number | null
  /** Short human-readable reason, e.g. "Checkmate", "Potted the 8 ball". */
  reason?: string
}

export interface ArenaEngine<S = unknown, A = unknown> {
  id: ArenaGameId
  name: string
  /** Seconds a player gets for each turn before `timeout` is applied. */
  turnSeconds: number
  /** Builds the opening state. `rand` returns [0,1) and is crypto-backed on the server. */
  init(names: [string, string], rand: () => number): S
  /** Validates untrusted client input into a typed action. Throws GameRuleError. */
  parseAction(raw: unknown): A
  /** Applies an action by `seat`. Must check whose turn it is itself. Throws GameRuleError. */
  apply(state: S, seat: number, action: A): StepResult<S>
  /** Called when `seat` lets its turn clock run out. */
  timeout(state: S, seat: number): StepResult<S>
  /** Seat whose turn it is (0 or 1). */
  current(state: S): number
}

/** Props every board component accepts. */
export interface BoardProps<S, A> {
  state: S
  /** Seat this viewer controls (0/1), or -1 for a spectator. Orients the board. */
  mySeat: number
  /** True when the viewer may act now (their turn, not waiting on the server). */
  canAct: boolean
  onAction: (action: A) => void
  /** Display names for seat 0 and seat 1. */
  names: [string, string]
}
