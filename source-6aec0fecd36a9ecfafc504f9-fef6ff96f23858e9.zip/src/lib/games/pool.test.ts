import { describe, expect, it } from 'vitest'

import {
  BALL_R,
  HEAD_X,
  TABLE_H,
  TABLE_W,
  isValidCuePlacement,
  poolEngine,
  simulate,
  type PoolBall,
  type PoolState,
} from './pool'
import { GameRuleError } from './types'

const seeded = (seed: number) => () => {
  seed = (seed * 1664525 + 1013904223) % 4294967296
  return seed / 4294967296
}

const fresh = () => poolEngine.init(['Ann', 'Bob'], seeded(42))

/** Mid-game state with custom balls (open table unless groups given). */
const mid = (balls: PoolBall[], over: Partial<PoolState> = {}): PoolState => ({
  ...fresh(),
  balls,
  breakShot: false,
  kitchen: false,
  ballInHand: false,
  ...over,
})

// Cue at (300,300) shooting up-left at an object ball on the diagonal into the top-left corner.
const D = Math.SQRT1_2
const diag = (id: number, extra: PoolBall[] = []): PoolBall[] => [
  { id: 0, x: 300, y: 300 },
  { id, x: 150, y: 150 },
  ...extra,
]
const diagShot = { type: 'shot' as const, dx: -D, dy: -D, power: 0.5 }

describe('pool physics', () => {
  it('is deterministic', () => {
    const s = fresh()
    const shot = { dx: 1, dy: 0.01, power: 1 }
    const a = simulate(s.balls, shot, { frames: true })
    const b = simulate(s.balls, shot, { frames: true })
    expect(JSON.stringify(a)).toBe(JSON.stringify(b))
  })

  it('terminates and keeps balls on the table', () => {
    const s = fresh()
    for (const [dx, dy] of [
      [1, 0],
      [1, 0.05],
      [0.3, 1],
      [-1, 0.2],
    ]) {
      const r = simulate(s.balls, { dx: dx!, dy: dy!, power: 1 })
      expect(r.steps).toBeLessThanOrEqual(20 * 480)
      expect(r.balls.length + r.pots.length).toBe(16)
      for (const b of r.balls) {
        expect(b.x).toBeGreaterThanOrEqual(BALL_R - 1)
        expect(b.x).toBeLessThanOrEqual(TABLE_W - BALL_R + 1)
        expect(b.y).toBeGreaterThanOrEqual(BALL_R - 1)
        expect(b.y).toBeLessThanOrEqual(TABLE_H - BALL_R + 1)
      }
    }
  })

  it('pots an object ball into a corner pocket with a straight shot', () => {
    const r = simulate(diag(3), diagShot)
    expect(r.first).toBe(3)
    expect(r.pots).toEqual([{ id: 3, pocket: 0 }])
    expect(r.scratch).toBe(false)
  })
})

describe('pool rules', () => {
  it('racks 16 balls with the 8 in the centre and seat 0 to break', () => {
    const s = fresh()
    expect(s.balls).toHaveLength(16)
    expect(s.turn).toBe(0)
    expect(s.ballInHand).toBe(true)
    expect(s.kitchen).toBe(true)
    expect(isValidCuePlacement(s.balls, HEAD_X + 50, 250, true)).toBe(false)
    expect(isValidCuePlacement(s.balls, HEAD_X - 50, 250, true)).toBe(true)
  })

  it('plays a full break without throwing', () => {
    const s = fresh()
    const res = poolEngine.apply(s, 0, poolEngine.parseAction({ type: 'shot', dx: 1, dy: 0, power: 1, cueX: 200, cueY: 250 }))
    expect(res.state.breakShot).toBe(false)
    expect(res.state.lastShot?.n).toBe(1)
    expect(res.state.balls.some((b) => b.id === 0)).toBe(true)
  })

  it('scratch gives the opponent ball in hand', () => {
    // Cue ball shot straight into the top-left corner after grazing nothing... hit a rail ball then scratch.
    const s = mid([
      { id: 0, x: 150, y: 150 },
      { id: 5, x: 600, y: 400 },
    ])
    const res = poolEngine.apply(s, 0, { type: 'shot', dx: -D, dy: -D, power: 0.5 })
    expect(res.done).toBe(false)
    expect(res.state.turn).toBe(1)
    expect(res.state.ballInHand).toBe(true)
    expect(res.state.foul).toMatch(/Scratch/)
    expect(res.state.balls.some((b) => b.id === 0)).toBe(true)
  })

  it('assigns groups on the first legal pot and keeps the turn', () => {
    const s = mid(diag(3, [{ id: 12, x: 800, y: 400 }, { id: 8, x: 900, y: 100 }]), { turn: 1 })
    const res = poolEngine.apply(s, 1, diagShot)
    expect(res.state.groups).toEqual(['stripes', 'solids'])
    expect(res.state.turn).toBe(1)
    expect(res.state.foul).toBeNull()
  })

  it('potting own ball keeps the turn; missing passes it', () => {
    const groups: PoolState['groups'] = ['stripes', 'solids']
    const s = mid(diag(11, [{ id: 2, x: 800, y: 400 }, { id: 8, x: 900, y: 100 }]), { groups })
    const res = poolEngine.apply(s, 0, diagShot)
    expect(res.state.turn).toBe(0)
    const miss = poolEngine.apply(s, 0, { ...diagShot, power: 0.08 })
    expect(miss.state.turn).toBe(1)
  })

  it('hitting the wrong group first is a foul', () => {
    const groups: PoolState['groups'] = ['stripes', 'solids']
    const s = mid(diag(2, [{ id: 11, x: 800, y: 400 }, { id: 8, x: 900, y: 100 }]), { groups })
    const res = poolEngine.apply(s, 0, diagShot)
    expect(res.state.turn).toBe(1)
    expect(res.state.ballInHand).toBe(true)
  })

  it('potting the 8 early loses', () => {
    const groups: PoolState['groups'] = ['solids', 'stripes']
    const s = mid(diag(8, [{ id: 1, x: 800, y: 400 }]), { groups })
    const res = poolEngine.apply(s, 0, diagShot)
    expect(res.done).toBe(true)
    expect(res.winner).toBe(1)
    expect(res.state.over).toBe(true)
  })

  it('potting the 8 after clearing the group wins', () => {
    const groups: PoolState['groups'] = ['solids', 'stripes']
    const s = mid(diag(8, [{ id: 9, x: 800, y: 400 }]), { groups })
    const res = poolEngine.apply(s, 0, diagShot)
    expect(res.done).toBe(true)
    expect(res.winner).toBe(0)
  })

  it('rejects the wrong seat and invalid actions', () => {
    const s = fresh()
    expect(() => poolEngine.apply(s, 1, { type: 'shot', dx: 1, dy: 0, power: 1 })).toThrow(GameRuleError)
    expect(() => poolEngine.parseAction({ type: 'shot', dx: 0, dy: 0, power: 1 })).toThrow(GameRuleError)
    expect(() => poolEngine.parseAction({ type: 'shot', dx: NaN, dy: 1, power: 1 })).toThrow(GameRuleError)
    expect(() => poolEngine.parseAction({ type: 'move', dx: 1, dy: 0, power: 1 })).toThrow(GameRuleError)
    expect(() => poolEngine.parseAction(null)).toThrow(GameRuleError)
    const a = poolEngine.parseAction({ type: 'shot', dx: 3, dy: 4, power: 7 })
    expect(a).toEqual({ type: 'shot', dx: 0.6, dy: 0.8, power: 1 })
    // Cue ball in the rack / beyond the head string is rejected on the break.
    expect(() => poolEngine.apply(s, 0, { type: 'shot', dx: 1, dy: 0, power: 1, cueX: 600, cueY: 250 })).toThrow(GameRuleError)
  })

  it('timeout passes the turn with ball in hand', () => {
    const s = mid(diag(3))
    const res = poolEngine.timeout(s, 0)
    expect(res.state.turn).toBe(1)
    expect(res.state.ballInHand).toBe(true)
    expect(res.state.n).toBe(s.n + 1)
  })
})
