/**
 * 8 Ball Pool engine: deterministic physics + standard 8-ball rules.
 *
 * The physics (`simulate`) only uses + - * / Math.sqrt Math.abs Math.min
 * Math.max with a fixed timestep and a hard step cap, so the server
 * (authoritative) and every browser (replaying `lastShot`) compute identical
 * results. Final positions are rounded to 1e-3 so they survive JSON storage.
 *
 * Table: playfield TABLE_W x TABLE_H (1000 x 500 abstract units, i.e. a 9 ft
 * table where 1 unit = 0.1 inch). x grows to the right (head string on the
 * left, rack on the right), y grows downwards.
 *
 * Rule simplifications (documented for the integrator):
 * - No spin / english; balls slide with constant friction + light drag.
 * - Break: the only fouls are a scratch or missing every ball. No "4 balls to
 *   a rail" requirement. Balls potted on the break never assign groups.
 * - 8 potted on the break is re-spotted on the foot spot (nearest free spot);
 *   it is neither a win nor a loss.
 * - Every foul (including a scratch on the break and a timeout) gives the
 *   opponent ball in hand ANYWHERE on the table. Only the opening break is
 *   restricted to behind the head string ("kitchen").
 * - Groups are assigned by the first object ball legally potted on an open
 *   table after the break (if a shot pots both a solid and a stripe, the
 *   first one to drop decides).
 * - No call-pocket: any legal pot of the 8 after clearing your group wins.
 * - The cue ball always stays in `balls` (re-spotted after a scratch) so the
 *   shooter with ball in hand can drag it from a valid default spot.
 */
import { GameRuleError, type ArenaEngine, type StepResult } from './types'

// ---------------------------------------------------------------- geometry

export const TABLE_W = 1000
export const TABLE_H = 500
export const BALL_R = 11.25
/** Visual rail width used by the board renderer (outside the playfield). */
export const RAIL = 48
/** Head string: ball in hand on the break must have x <= HEAD_X. */
export const HEAD_X = TABLE_W / 4
export const HEAD_SPOT = { x: HEAD_X, y: TABLE_H / 2 }
export const FOOT_SPOT = { x: (TABLE_W * 3) / 4, y: TABLE_H / 2 }

export interface Pocket {
  x: number
  y: number
  /** A ball is potted once its centre comes within `r` of (x, y). */
  r: number
  side: boolean
}

const CORNER_OFF = 3
const CORNER_R = 26
const SIDE_OFF = 6
const SIDE_R = 22
/** Within these distances of a pocket along a rail, the cushion is open. */
const CORNER_MOUTH = 20
const SIDE_MOUTH = 16

export const POCKETS: Pocket[] = [
  { x: -CORNER_OFF, y: -CORNER_OFF, r: CORNER_R, side: false },
  { x: TABLE_W / 2, y: -SIDE_OFF, r: SIDE_R, side: true },
  { x: TABLE_W + CORNER_OFF, y: -CORNER_OFF, r: CORNER_R, side: false },
  { x: -CORNER_OFF, y: TABLE_H + CORNER_OFF, r: CORNER_R, side: false },
  { x: TABLE_W / 2, y: TABLE_H + SIDE_OFF, r: SIDE_R, side: true },
  { x: TABLE_W + CORNER_OFF, y: TABLE_H + CORNER_OFF, r: CORNER_R, side: false },
]

// ---------------------------------------------------------------- physics constants

/** Cue ball speed (units/s) at power 1. */
export const MAX_SPEED = 2600
const MIN_POWER = 0.03
const DT = 1 / 480
/** Steps between recorded frames: 8 * (1/480 s) = one frame at 60 fps. */
export const FRAME_EVERY = 8
const MAX_STEPS = 20 * 480
const DECEL = 150
const DRAG = 0.35
const STOP_SPEED = 3
const BALL_E = 0.95
const RAIL_E = 0.75
const RAIL_TANGENT = 0.97

// ---------------------------------------------------------------- types

export interface PoolBall {
  /** 0 = cue ball, 1-7 solids, 8 = eight ball, 9-15 stripes. */
  id: number
  x: number
  y: number
}

export type PoolGroup = 'solids' | 'stripes'

export interface PoolShot {
  /** Unit direction vector. */
  dx: number
  dy: number
  /** 0..1 */
  power: number
}

export interface PoolAction extends PoolShot {
  type: 'shot'
  /** Cue ball placement; only honoured when the shooter has ball in hand. */
  cueX?: number
  cueY?: number
}

export interface PoolPot {
  id: number
  pocket: number
}

export interface SimResult {
  balls: PoolBall[]
  /** First ball the cue ball touched, or null. */
  first: number | null
  pots: PoolPot[]
  /** Ids of balls that touched a cushion after the first contact (unique, in order). */
  rails: number[]
  scratch: boolean
  steps: number
  /** On-table positions every `frameEvery` steps (first frame = start). Only with `opts.frames`. */
  frames?: PoolBall[][]
}

export interface PoolLastShot {
  n: number
  seat: number
  /** Ball positions right before the shot (cue ball already placed). */
  before: PoolBall[]
  shot: { dx: number; dy: number; power: number; cueX?: number; cueY?: number }
}

export interface PoolState {
  names: [string, string]
  /** Balls still on the table. The cue ball (id 0) is always present. */
  balls: PoolBall[]
  turn: number
  groups: [PoolGroup | null, PoolGroup | null]
  ballInHand: boolean
  /** Ball in hand restricted to behind the head string (opening break only). */
  kitchen: boolean
  breakShot: boolean
  /** Foul message of the last shot / timeout, or null. */
  foul: string | null
  log: string[]
  lastShot: PoolLastShot | null
  /** Monotonic counter, bumped on every shot and timeout. */
  n: number
  over: boolean
  winner: number | null
  reason: string | null
}

// ---------------------------------------------------------------- helpers

export const isSolid = (id: number) => id >= 1 && id <= 7
export const isStripe = (id: number) => id >= 9 && id <= 15
export const groupOf = (id: number): PoolGroup | null => (isSolid(id) ? 'solids' : isStripe(id) ? 'stripes' : null)
export const groupIds = (g: PoolGroup) => (g === 'solids' ? [1, 2, 3, 4, 5, 6, 7] : [9, 10, 11, 12, 13, 14, 15])

/** Object balls of `seat`'s group still on the table (empty when the group is unassigned). */
export function remainingFor(state: PoolState, seat: number): number[] {
  const g = state.groups[seat]
  if (!g) return []
  return state.balls.map((b) => b.id).filter((id) => groupOf(id) === g).sort((a, b) => a - b)
}

/** True when `seat` has a group and every ball of it is potted (next target: the 8). */
export function onEight(state: PoolState, seat: number): boolean {
  return state.groups[seat] !== null && remainingFor(state, seat).length === 0
}

const round3 = (v: number) => Math.round(v * 1000) / 1000

/**
 * Whether the cue ball may be placed at (x, y): fully on the playfield, not
 * overlapping another ball, not in a pocket, and behind the head string when
 * `kitchen` is set.
 */
export function isValidCuePlacement(balls: PoolBall[], x: number, y: number, kitchen: boolean): boolean {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return false
  if (x < BALL_R || x > TABLE_W - BALL_R || y < BALL_R || y > TABLE_H - BALL_R) return false
  if (kitchen && x > HEAD_X) return false
  for (const p of POCKETS) {
    const dx = x - p.x
    const dy = y - p.y
    if (dx * dx + dy * dy < (p.r + BALL_R) * (p.r + BALL_R)) return false
  }
  for (const b of balls) {
    if (b.id === 0) continue
    const dx = x - b.x
    const dy = y - b.y
    if (dx * dx + dy * dy < 4 * BALL_R * BALL_R) return false
  }
  return true
}

/** Nearest free spot to (x, y) found by a deterministic spiral search. */
function freeSpot(balls: PoolBall[], x: number, y: number, kitchen: boolean, ignoreId: number): { x: number; y: number } {
  const others = balls.filter((b) => b.id !== ignoreId)
  const ok = (px: number, py: number) =>
    isValidCuePlacement(
      others.map((b) => (b.id === 0 ? { ...b, id: -1 } : b)),
      px,
      py,
      kitchen,
    )
  if (ok(x, y)) return { x, y }
  for (let ring = 1; ring < 60; ring++) {
    const d = ring * BALL_R
    for (let k = -ring; k <= ring; k++) {
      const cands = [
        [x + k * BALL_R, y - d],
        [x + k * BALL_R, y + d],
        [x - d, y + k * BALL_R],
        [x + d, y + k * BALL_R],
      ]
      for (const [px, py] of cands) if (ok(px!, py!)) return { x: px!, y: py! }
    }
  }
  return { x, y }
}

// ---------------------------------------------------------------- simulation

interface Body {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  on: boolean
}

/**
 * Runs a shot to rest. `balls` must contain the cue ball (id 0). Pure and
 * deterministic: same input gives bit-identical output.
 */
export function simulate(
  balls: PoolBall[],
  shot: PoolShot,
  opts: { frames?: boolean; frameEvery?: number } = {},
): SimResult {
  const bodies: Body[] = balls.map((b) => ({ id: b.id, x: b.x, y: b.y, vx: 0, vy: 0, on: true }))
  const cue = bodies.find((b) => b.id === 0)
  const pots: PoolPot[] = []
  const rails: number[] = []
  let first: number | null = null
  const frameEvery = Math.max(1, opts.frameEvery ?? FRAME_EVERY)
  const frames: PoolBall[][] | undefined = opts.frames ? [] : undefined
  const snap = () => bodies.filter((b) => b.on).map((b) => ({ id: b.id, x: b.x, y: b.y }))

  if (cue) {
    const len = Math.sqrt(shot.dx * shot.dx + shot.dy * shot.dy)
    const p = Math.max(0, Math.min(1, shot.power))
    if (len > 0) {
      cue.vx = (shot.dx / len) * p * MAX_SPEED
      cue.vy = (shot.dy / len) * p * MAX_SPEED
    }
  }
  frames?.push(snap())

  const railHit = (b: Body) => {
    if (first !== null && !rails.includes(b.id)) rails.push(b.id)
  }
  const pot = (b: Body, pocket: number) => {
    b.on = false
    b.vx = 0
    b.vy = 0
    pots.push({ id: b.id, pocket })
  }

  let steps = 0
  while (steps < MAX_STEPS) {
    steps++
    let moving = false

    // Integrate + friction.
    for (const b of bodies) {
      if (!b.on) continue
      const s2 = b.vx * b.vx + b.vy * b.vy
      if (s2 === 0) continue
      b.x += b.vx * DT
      b.y += b.vy * DT
      const s = Math.sqrt(s2)
      const ns = s - (DECEL + DRAG * s) * DT
      if (ns < STOP_SPEED) {
        b.vx = 0
        b.vy = 0
      } else {
        const k = ns / s
        b.vx *= k
        b.vy *= k
        moving = true
      }
    }

    // Pockets, then cushions (cushions are open near pocket mouths).
    for (const b of bodies) {
      if (!b.on) continue
      let potted = false
      for (let i = 0; i < POCKETS.length; i++) {
        const p = POCKETS[i]!
        const dx = b.x - p.x
        const dy = b.y - p.y
        if (dx * dx + dy * dy < p.r * p.r) {
          pot(b, i)
          potted = true
          break
        }
      }
      if (potted) continue
      // Safety net: anything that escaped the playfield drops into the nearest pocket.
      if (b.x < -3 * BALL_R || b.x > TABLE_W + 3 * BALL_R || b.y < -3 * BALL_R || b.y > TABLE_H + 3 * BALL_R) {
        let best = 0
        let bd = Infinity
        for (let i = 0; i < POCKETS.length; i++) {
          const dx = b.x - POCKETS[i]!.x
          const dy = b.y - POCKETS[i]!.y
          const d = dx * dx + dy * dy
          if (d < bd) {
            bd = d
            best = i
          }
        }
        pot(b, best)
        continue
      }
      const nearCornerX = b.x < CORNER_MOUTH || b.x > TABLE_W - CORNER_MOUTH
      const nearSideX = Math.abs(b.x - TABLE_W / 2) < SIDE_MOUTH
      const nearCornerY = b.y < CORNER_MOUTH || b.y > TABLE_H - CORNER_MOUTH
      if (!nearCornerX && !nearSideX) {
        if (b.y < BALL_R) {
          b.y = BALL_R + (BALL_R - b.y) * RAIL_E
          if (b.vy < 0) b.vy = -b.vy * RAIL_E
          b.vx *= RAIL_TANGENT
          railHit(b)
        } else if (b.y > TABLE_H - BALL_R) {
          b.y = TABLE_H - BALL_R - (b.y - (TABLE_H - BALL_R)) * RAIL_E
          if (b.vy > 0) b.vy = -b.vy * RAIL_E
          b.vx *= RAIL_TANGENT
          railHit(b)
        }
      }
      if (!nearCornerY) {
        if (b.x < BALL_R) {
          b.x = BALL_R + (BALL_R - b.x) * RAIL_E
          if (b.vx < 0) b.vx = -b.vx * RAIL_E
          b.vy *= RAIL_TANGENT
          railHit(b)
        } else if (b.x > TABLE_W - BALL_R) {
          b.x = TABLE_W - BALL_R - (b.x - (TABLE_W - BALL_R)) * RAIL_E
          if (b.vx > 0) b.vx = -b.vx * RAIL_E
          b.vy *= RAIL_TANGENT
          railHit(b)
        }
      }
    }

    // Ball-ball collisions (equal mass, slight restitution loss).
    const min2 = 4 * BALL_R * BALL_R
    for (let i = 0; i < bodies.length; i++) {
      const a = bodies[i]!
      if (!a.on) continue
      for (let j = i + 1; j < bodies.length; j++) {
        const c = bodies[j]!
        if (!c.on) continue
        const dx = c.x - a.x
        const dy = c.y - a.y
        const d2 = dx * dx + dy * dy
        if (d2 >= min2 || d2 === 0) continue
        const d = Math.sqrt(d2)
        const nx = dx / d
        const ny = dy / d
        // Separate overlapping balls.
        const push = (2 * BALL_R - d) / 2
        a.x -= nx * push
        a.y -= ny * push
        c.x += nx * push
        c.y += ny * push
        const vn = (a.vx - c.vx) * nx + (a.vy - c.vy) * ny
        if (vn <= 0) continue
        const imp = ((1 + BALL_E) / 2) * vn
        a.vx -= imp * nx
        a.vy -= imp * ny
        c.vx += imp * nx
        c.vy += imp * ny
        moving = true
        if (first === null) {
          if (a.id === 0) first = c.id
          else if (c.id === 0) first = a.id
        }
      }
    }

    if (frames && steps % frameEvery === 0) frames.push(snap())
    if (!moving) break
  }

  const out = bodies.filter((b) => b.on).map((b) => ({ id: b.id, x: round3(b.x), y: round3(b.y) }))
  if (frames) frames.push(out)
  return {
    balls: out,
    first,
    pots,
    rails,
    scratch: pots.some((p) => p.id === 0),
    steps,
    frames,
  }
}

/**
 * Aim preview (UI helper, no trig): casts the cue ball along (dx, dy) and
 * returns where it first touches a ball (ghost ball centre) or a cushion,
 * plus the object ball's departure direction.
 */
export function aimPreview(
  balls: PoolBall[],
  cx: number,
  cy: number,
  dx: number,
  dy: number,
): { hit: number | null; ghost: { x: number; y: number }; objDir: { x: number; y: number } | null } {
  const len = Math.sqrt(dx * dx + dy * dy) || 1
  const ux = dx / len
  const uy = dy / len
  let best = Infinity
  let hit: PoolBall | null = null
  for (const b of balls) {
    if (b.id === 0) continue
    const ox = b.x - cx
    const oy = b.y - cy
    const t = ox * ux + oy * uy
    if (t <= 0) continue
    const perp2 = ox * ox + oy * oy - t * t
    const r2 = 4 * BALL_R * BALL_R
    if (perp2 >= r2) continue
    const tt = t - Math.sqrt(r2 - perp2)
    if (tt < best) {
      best = tt
      hit = b
    }
  }
  // Cushion distance.
  let wall = Infinity
  if (ux > 0) wall = Math.min(wall, (TABLE_W - BALL_R - cx) / ux)
  if (ux < 0) wall = Math.min(wall, (BALL_R - cx) / ux)
  if (uy > 0) wall = Math.min(wall, (TABLE_H - BALL_R - cy) / uy)
  if (uy < 0) wall = Math.min(wall, (BALL_R - cy) / uy)
  if (hit && best <= wall) {
    const gx = cx + ux * best
    const gy = cy + uy * best
    const nx = (hit.x - gx) / (2 * BALL_R)
    const ny = (hit.y - gy) / (2 * BALL_R)
    return { hit: hit.id, ghost: { x: gx, y: gy }, objDir: { x: nx, y: ny } }
  }
  const w = Math.max(0, wall)
  return { hit: null, ghost: { x: cx + ux * w, y: cy + uy * w }, objDir: null }
}

// ---------------------------------------------------------------- rack

function rack(rand: () => number): PoolBall[] {
  const gap = 0.05
  const colStep = (2 * BALL_R + gap) * (Math.sqrt(3) / 2)
  const rowStep = 2 * BALL_R + gap
  const slots: { x: number; y: number }[] = []
  for (let k = 0; k < 5; k++)
    for (let j = 0; j <= k; j++)
      slots.push({ x: FOOT_SPOT.x + k * colStep, y: FOOT_SPOT.y + (j - k / 2) * rowStep })
  // Slot indices: row k starts at k(k+1)/2. 8 = row 2 middle (4); back corners = 10 and 14.
  const shuffle = <T>(arr: T[]) => {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1))
      ;[arr[i], arr[j]] = [arr[j]!, arr[i]!]
    }
    return arr
  }
  const solids = shuffle([1, 2, 3, 4, 5, 6, 7])
  const stripes = shuffle([9, 10, 11, 12, 13, 14, 15])
  const ids: number[] = new Array(15).fill(0)
  ids[4] = 8
  const solidLeft = rand() < 0.5
  ids[10] = solidLeft ? solids.pop()! : stripes.pop()!
  ids[14] = solidLeft ? stripes.pop()! : solids.pop()!
  const rest = shuffle([...solids, ...stripes])
  for (let i = 0; i < 15; i++) if (ids[i] === 0) ids[i] = rest.pop()!
  const out: PoolBall[] = [{ id: 0, x: HEAD_SPOT.x, y: HEAD_SPOT.y }]
  slots.forEach((s, i) => out.push({ id: ids[i]!, x: round3(s.x), y: round3(s.y) }))
  return out
}

// ---------------------------------------------------------------- engine

const pushLog = (log: string[], ...lines: string[]) => [...log, ...lines].slice(-20)
const ballList = (ids: number[]) => ids.join(', ')

function respotCue(balls: PoolBall[]): PoolBall[] {
  const rest = balls.filter((b) => b.id !== 0)
  const spot = freeSpot(rest, HEAD_SPOT.x, HEAD_SPOT.y, false, 0)
  return [{ id: 0, x: round3(spot.x), y: round3(spot.y) }, ...rest]
}

function finish(state: PoolState, winner: number, reason: string): StepResult<PoolState> {
  const s: PoolState = { ...state, over: true, winner, reason, log: pushLog(state.log, reason) }
  return { state: s, done: true, winner, reason }
}

export const poolEngine: ArenaEngine<PoolState, PoolAction> = {
  id: 'pool',
  name: '8 Ball Pool',
  turnSeconds: 45,

  init(names, rand) {
    return {
      names: [names[0], names[1]],
      balls: rack(rand),
      turn: 0,
      groups: [null, null],
      ballInHand: true,
      kitchen: true,
      breakShot: true,
      foul: null,
      log: [`${names[0]} breaks`],
      lastShot: null,
      n: 0,
      over: false,
      winner: null,
      reason: null,
    }
  },

  parseAction(raw) {
    if (!raw || typeof raw !== 'object') throw new GameRuleError('Invalid shot')
    const r = raw as Record<string, unknown>
    if (r.type !== 'shot') throw new GameRuleError('Invalid shot')
    const num = (v: unknown) => typeof v === 'number' && Number.isFinite(v)
    if (!num(r.dx) || !num(r.dy) || !num(r.power)) throw new GameRuleError('Invalid shot')
    const dx = r.dx as number
    const dy = r.dy as number
    const len = Math.sqrt(dx * dx + dy * dy)
    if (!(len > 1e-9)) throw new GameRuleError('Pick an aim direction')
    const q = (v: number) => Math.round(v * 1e6) / 1e6
    const a: PoolAction = {
      type: 'shot',
      dx: q(dx / len),
      dy: q(dy / len),
      power: q(Math.max(MIN_POWER, Math.min(1, r.power as number))),
    }
    if (a.dx === 0 && a.dy === 0) throw new GameRuleError('Pick an aim direction')
    if (r.cueX !== undefined || r.cueY !== undefined) {
      if (!num(r.cueX) || !num(r.cueY)) throw new GameRuleError('Invalid cue ball position')
      a.cueX = round3(r.cueX as number)
      a.cueY = round3(r.cueY as number)
    }
    return a
  },

  current: (state) => state.turn,

  apply(state, seat, action) {
    if (state.over) throw new GameRuleError('The game is over')
    if (seat !== state.turn) throw new GameRuleError('Not your turn')
    const opp = 1 - seat
    const name = state.names[seat]

    // Place the cue ball.
    let before = state.balls
    const shotInfo: PoolLastShot['shot'] = { dx: action.dx, dy: action.dy, power: action.power }
    if (action.cueX !== undefined && action.cueY !== undefined) {
      if (!state.ballInHand) throw new GameRuleError('You do not have ball in hand')
      if (!isValidCuePlacement(state.balls, action.cueX, action.cueY, state.kitchen))
        throw new GameRuleError(state.kitchen ? 'Place the cue ball behind the head string' : 'Cue ball cannot go there')
      before = [{ id: 0, x: action.cueX, y: action.cueY }, ...state.balls.filter((b) => b.id !== 0)]
      shotInfo.cueX = action.cueX
      shotInfo.cueY = action.cueY
    }

    const sim = simulate(before, action)
    const n = state.n + 1
    const lastShot: PoolLastShot = { n, seat, before, shot: shotInfo }
    const objPots = sim.pots.filter((p) => p.id !== 0)
    const pottedIds = objPots.map((p) => p.id)
    const eightPotted = pottedIds.includes(8)
    const group = state.groups[seat]
    const wasOnEight = onEight(state, seat)

    let log = state.log
    if (pottedIds.length) log = pushLog(log, `${name} potted ${ballList(pottedIds)}`)

    const base: PoolState = { ...state, balls: sim.balls, lastShot, n, log, breakShot: false, kitchen: false }

    // ---- fouls
    let foul: string | null = null
    if (sim.scratch) foul = 'Scratch: the cue ball was potted'
    else if (sim.first === null) foul = 'No ball was hit'
    else if (!state.breakShot) {
      if (group) {
        const legalFirst = wasOnEight ? sim.first === 8 : groupOf(sim.first) === group
        if (!legalFirst) foul = wasOnEight ? 'Must hit the 8 ball first' : `Must hit ${group} first`
      } else if (sim.first === 8) foul = 'Cannot hit the 8 ball first on an open table'
      if (!foul && objPots.length === 0 && sim.rails.length === 0) foul = 'No ball reached a rail after contact'
    }

    // ---- 8 ball
    if (eightPotted) {
      if (state.breakShot) {
        const others = base.balls.filter((b) => b.id !== 8)
        const spot = freeSpot(others.map((b) => (b.id === 0 ? { ...b, id: -1 } : b)), FOOT_SPOT.x, FOOT_SPOT.y, false, 8)
        base.balls = [...others, { id: 8, x: round3(spot.x), y: round3(spot.y) }]
        base.log = pushLog(base.log, '8 ball potted on the break: re-spotted')
      } else if (wasOnEight && !foul) {
        return finish(base, seat, `${name} potted the 8 ball`)
      } else {
        const why = sim.scratch ? 'scratched on the 8 ball' : wasOnEight ? 'fouled on the 8 ball' : 'potted the 8 ball early'
        return finish(base, opp, `${name} ${why}`)
      }
    }

    if (sim.scratch) base.balls = respotCue(base.balls)

    if (foul) {
      return {
        state: {
          ...base,
          turn: opp,
          ballInHand: true,
          foul,
          log: pushLog(base.log, `Foul: ${foul}. ${state.names[opp]} has ball in hand`),
        },
        done: false,
        winner: null,
      }
    }

    // ---- groups
    let groups = state.groups
    if (!group && !state.breakShot) {
      const firstObj = objPots.find((p) => groupOf(p.id) !== null)
      if (firstObj) {
        const g = groupOf(firstObj.id)!
        const other: PoolGroup = g === 'solids' ? 'stripes' : 'solids'
        groups = seat === 0 ? [g, other] : [other, g]
        base.log = pushLog(base.log, `${name} is ${g}`)
      }
    }
    const myGroup = groups[seat]
    const keep = state.breakShot
      ? objPots.length > 0
      : objPots.some((p) => myGroup !== null && groupOf(p.id) === myGroup)

    return {
      state: {
        ...base,
        groups,
        turn: keep ? seat : opp,
        ballInHand: false,
        foul: null,
      },
      done: false,
      winner: null,
    }
  },

  timeout(state, seat) {
    if (state.over || seat !== state.turn) return { state, done: state.over, winner: state.winner }
    const opp = 1 - seat
    return {
      state: {
        ...state,
        turn: opp,
        ballInHand: true,
        // A missed break passes the break (still from behind the head string).
        kitchen: state.breakShot,
        n: state.n + 1,
        foul: `${state.names[seat]} ran out of time`,
        log: pushLog(state.log, `${state.names[seat]} ran out of time. ${state.names[opp]} has ball in hand`),
      },
      done: false,
      winner: null,
    }
  },
}
