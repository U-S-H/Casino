import { describe, expect, it } from 'vitest'

import {
  BOARD,
  COIN_R,
  POCKETS,
  carromEngine,
  resolveStrike,
  simulate,
  strikerPos,
} from './carrom'
import type { CarromAction, CarromState, Coin, SimResult } from './carrom'
import { GameRuleError } from './types'

const fresh = () => carromEngine.init(['Ana', 'Ben'], () => 0.5)

/** Coin lined up between the seat-0 striker at x=0.5 and the top-left pocket. */
function pocketShot(k: Coin['k'] = 'w') {
  const s = strikerPos(0, 0.5)
  const P = POCKETS[0]
  const dx = P.x - s.x
  const dy = P.y - s.y
  const L = Math.sqrt(dx * dx + dy * dy)
  const coin: Coin = { id: k === 'w' ? 1 : k === 'b' ? 10 : 0, k, x: P.x - (dx / L) * 120, y: P.y - (dy / L) * 120 }
  return { coin, action: { type: 'strike', x: 0.5, dx: dx / L, dy: dy / L, power: 0.3 } as CarromAction }
}

const outcome = (state: CarromState, pocketIds: number[], strikerPocketed = false): SimResult => ({
  coins: state.coins.filter((c) => !pocketIds.includes(c.id)),
  pocketed: state.coins.filter((c) => pocketIds.includes(c.id)),
  strikerPocketed,
  striker: strikerPocketed ? null : { x: 370, y: 370 },
  steps: 1,
})
const act: CarromAction = { type: 'strike', x: 0.5, dx: 0, dy: -1, power: 0.5 }
const count = (s: CarromState, k: Coin['k']) => s.coins.filter((c) => c.k === k).length

describe('carrom engine', () => {
  it('sets up 19 non-overlapping coins', () => {
    const s = fresh()
    expect(s.coins).toHaveLength(19)
    expect(count(s, 'w')).toBe(9)
    expect(count(s, 'b')).toBe(9)
    expect(count(s, 'q')).toBe(1)
    for (let i = 0; i < s.coins.length; i++)
      for (let j = i + 1; j < s.coins.length; j++) {
        const a = s.coins[i]
        const b = s.coins[j]
        expect(Math.hypot(a.x - b.x, a.y - b.y)).toBeGreaterThanOrEqual(2 * COIN_R)
      }
  })

  it('is deterministic, terminates and keeps pieces on the board', () => {
    const s = fresh()
    const strike = { seat: 0, x: 0.37, dx: 0.21, dy: -0.97, power: 1 }
    const a = simulate(s.coins, strike, { frames: true })
    const b = simulate(JSON.parse(JSON.stringify(s.coins)), strike, { frames: true })
    expect(JSON.stringify(a)).toBe(JSON.stringify(b))
    expect(a.steps).toBeLessThan(3000)
    expect(a.frames!.length).toBeGreaterThan(2)
    for (const c of a.coins) {
      expect(c.x).toBeGreaterThanOrEqual(COIN_R - 1e-6)
      expect(c.x).toBeLessThanOrEqual(BOARD - COIN_R + 1e-6)
      expect(c.y).toBeGreaterThanOrEqual(COIN_R - 1e-6)
      expect(c.y).toBeLessThanOrEqual(BOARD - COIN_R + 1e-6)
    }
    expect(a.coins.length + a.pocketed.length).toBe(19)
  })

  it('pockets a coin with a straight shot', () => {
    const { coin, action } = pocketShot()
    const r = simulate([coin], { seat: 0, ...action })
    expect(r.pocketed.map((c) => c.id)).toEqual([1])
    expect(r.strikerPocketed).toBe(false)
  })

  it('keeps the turn after pocketing an own coin (end to end)', () => {
    const { coin, action } = pocketShot('w')
    const s: CarromState = { ...fresh(), coins: [coin, { id: 2, k: 'w', x: 370, y: 370 }, { id: 10, k: 'b', x: 500, y: 300 }] }
    const r = carromEngine.apply(s, 0, carromEngine.parseAction(action))
    expect(r.state.turn).toBe(0)
    expect(r.state.pocketed[0]).toBe(8) // 7 already off the board + 1
    expect(r.state.n).toBe(1)
    expect(r.state.lastStrike?.before.coins).toHaveLength(3)
    // replay reproduces the authoritative result
    const replay = simulate(r.state.lastStrike!.before.coins, { seat: 0, ...r.state.lastStrike!.strike })
    expect(replay.coins).toEqual(r.state.coins)
  })

  it('passes the turn after pocketing only opponent coins', () => {
    const s = fresh()
    const r = resolveStrike(s, 0, act, outcome(s, [10]))
    expect(r.state.turn).toBe(1)
    expect(r.state.pocketed).toEqual([0, 1])
  })

  it('passes the turn when nothing is pocketed', () => {
    const s = fresh()
    expect(resolveStrike(s, 0, act, outcome(s, [])).state.turn).toBe(1)
  })

  it('penalises a striker foul', () => {
    const s0 = fresh()
    const s = { ...s0, coins: s0.coins.filter((c) => c.id !== 1 && c.id !== 2) } // white already pocketed 2
    const r = resolveStrike(s, 0, act, outcome(s, [3, 10], true))
    expect(r.state.turn).toBe(1)
    expect(r.state.foul).toMatch(/striker/)
    // coin 3 returned, plus one penalty coin: 7 + 1 + 1 = 9 - 1
    expect(count(r.state, 'w')).toBe(8)
    expect(count(r.state, 'b')).toBe(8) // opponent coin stays pocketed
    for (let i = 0; i < r.state.coins.length; i++)
      for (let j = i + 1; j < r.state.coins.length; j++) {
        const a = r.state.coins[i]
        const b = r.state.coins[j]
        expect(Math.hypot(a.x - b.x, a.y - b.y)).toBeGreaterThanOrEqual(2 * COIN_R)
      }
  })

  it('returns the queen if pocketed before any own coin', () => {
    const s = fresh()
    const r = resolveStrike(s, 0, act, outcome(s, [0]))
    expect(count(r.state, 'q')).toBe(1)
    expect(r.state.queen).toEqual({ s: 'board' })
    expect(r.state.turn).toBe(1)
  })

  it('requires the queen to be covered on the next strike', () => {
    const s0 = fresh()
    const s = { ...s0, coins: s0.coins.filter((c) => c.id !== 1) }
    const a = resolveStrike(s, 0, act, outcome(s, [0])).state
    expect(a.queen).toEqual({ s: 'pending', seat: 0 })
    expect(a.turn).toBe(0)
    const covered = resolveStrike(a, 0, act, outcome(a, [2])).state
    expect(covered.queen).toEqual({ s: 'covered', seat: 0 })
    expect(covered.turn).toBe(0)
    const missed = resolveStrike(a, 0, act, outcome(a, [])).state
    expect(missed.queen).toEqual({ s: 'board' })
    expect(count(missed, 'q')).toBe(1)
    expect(missed.turn).toBe(1)
  })

  it('forbids pocketing the last coin before the queen is covered', () => {
    const s0 = fresh()
    const s = { ...s0, coins: s0.coins.filter((c) => c.k !== 'w' || c.id === 9) }
    const r = resolveStrike(s, 0, act, outcome(s, [9]))
    expect(r.done).toBe(false)
    expect(count(r.state, 'w')).toBe(1)
    expect(r.state.foul).toBeTruthy()
    expect(r.state.turn).toBe(1)
  })

  it('detects a win and scores points', () => {
    const s0 = fresh()
    const s: CarromState = {
      ...s0,
      queen: { s: 'covered', seat: 0 },
      coins: s0.coins.filter((c) => c.k === 'b' || c.id === 9),
    }
    const r = resolveStrike(s, 0, act, outcome(s, [9]))
    expect(r.done).toBe(true)
    expect(r.winner).toBe(0)
    expect(r.state.points).toBe(9 + 3)
    expect(() => carromEngine.apply(r.state, 1, act)).toThrow(GameRuleError)
  })

  it('rejects a strike out of turn', () => {
    expect(() => carromEngine.apply(fresh(), 1, { ...act, dy: 1 })).toThrow(/not your turn/)
  })

  it('rejects a backward shot', () => {
    expect(() => carromEngine.apply(fresh(), 0, { ...act, dx: 0, dy: 1 })).toThrow(/backwards/)
    // sideways is fine
    expect(() => carromEngine.apply(fresh(), 0, { ...act, dx: 1, dy: 0 })).not.toThrow()
  })

  it('rejects a bad striker position', () => {
    expect(() => carromEngine.apply(fresh(), 0, { ...act, x: 1.2 })).toThrow(GameRuleError)
    const p = strikerPos(0, 0.5)
    const s = { ...fresh(), coins: [{ id: 1, k: 'w' as const, x: p.x + 10, y: p.y }] }
    expect(() => carromEngine.apply(s, 0, act)).toThrow(/overlaps/)
  })

  it('validates raw actions', () => {
    expect(() => carromEngine.parseAction({ type: 'strike', x: 0.5, dx: NaN, dy: 1, power: 1 })).toThrow(GameRuleError)
    expect(() => carromEngine.parseAction({ type: 'strike', x: 0.5, dx: 0, dy: 0, power: 1 })).toThrow(GameRuleError)
    const a = carromEngine.parseAction({ type: 'strike', x: 0.5, dx: 3, dy: -4, power: 7 })
    expect(a).toEqual({ type: 'strike', x: 0.5, dx: 0.6, dy: -0.8, power: 1 })
  })

  it('passes the turn on timeout and returns a pending queen', () => {
    const s: CarromState = { ...fresh(), queen: { s: 'pending', seat: 0 } }
    s.coins = s.coins.filter((c) => c.k !== 'q')
    const r = carromEngine.timeout(s, 0)
    expect(r.state.turn).toBe(1)
    expect(r.state.queen).toEqual({ s: 'board' })
    expect(count(r.state, 'q')).toBe(1)
  })
})
