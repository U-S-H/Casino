/**
 * Pure chess rules engine implementing the shared ArenaEngine contract.
 *
 * Seat 0 = White, seat 1 = Black. Board is a 64-length array indexed
 * `rank * 8 + file` with a1 = 0, h1 = 7, a8 = 56, h8 = 63. Each cell is ''
 * (empty) or a FEN piece letter: uppercase = White, lowercase = Black.
 *
 * Draw offers: either player may offer at any time while the game is live.
 * The offer stays open until the opponent accepts/declines it or makes a
 * move (a move by the recipient is an implicit decline). The offerer making
 * their own move does not withdraw it. After a decline, the offerer may not
 * offer again until they have made another move. Offering while the opponent
 * already has an offer pending counts as accepting it.
 */
import { GameRuleError, type ArenaEngine, type StepResult } from './types'

export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k'
export type Promotion = 'q' | 'r' | 'b' | 'n'

export interface ChessMove {
  from: string
  to: string
  promotion?: Promotion
  /** Captured piece letter (FEN case), if any. */
  captured?: string
  /** 'k' / 'q' for king-side / queen-side castling. */
  castle?: 'k' | 'q'
  enPassant?: boolean
}

export interface ChessState {
  board: string[]
  /** Side to move: 0 = White, 1 = Black. */
  turn: number
  /** Subset of 'KQkq', '' when none. */
  castling: string
  /** En-passant target square (e.g. 'e3') or null. */
  ep: string | null
  halfmove: number
  fullmove: number
  /** Position keys since the last irreversible move (threefold repetition). */
  history: string[]
  lastMove: { from: string; to: string; san?: string } | null
  /** SAN move list (last 200 plies). */
  moves: string[]
  /** Pieces captured BY each seat (FEN letters of the victim). */
  captured: [string[], string[]]
  /** Seat that has an open draw offer, or null. */
  drawOffer: number | null
  /** Seat barred from offering again until it makes a move (after a decline). */
  offerBlocked: number | null
  result: { winner: number | null; reason: string } | null
  names: [string, string]
  /** Monotonic action counter. */
  n: number
}

export type ChessAction =
  | { type: 'move'; from: string; to: string; promotion?: Promotion }
  | { type: 'resign' }
  | { type: 'offerDraw' }
  | { type: 'acceptDraw' }
  | { type: 'declineDraw' }

export const START_FEN =
  'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
const FILES = 'abcdefgh'
const PROMOS: Promotion[] = ['q', 'r', 'b', 'n']

// ---------------------------------------------------------------- squares

export function squareName(i: number): string {
  return FILES[i % 8] + String((i >> 3) + 1)
}

export function squareIndex(s: string): number {
  if (typeof s !== 'string' || !/^[a-h][1-8]$/.test(s)) return -1
  return (s.charCodeAt(1) - 49) * 8 + (s.charCodeAt(0) - 97)
}

const isWhite = (p: string) => p !== '' && p === p.toUpperCase()
/** Seat owning a piece letter: 0 white, 1 black. */
export const pieceSeat = (p: string) => (isWhite(p) ? 0 : 1)
const typeOf = (p: string) => p.toLowerCase() as PieceType

export function pieceAt(state: ChessState, square: string): string {
  const i = squareIndex(square)
  return i < 0 ? '' : state.board[i]
}

// ---------------------------------------------------------------- attacks

const KNIGHT = [
  [1, 2],
  [2, 1],
  [2, -1],
  [1, -2],
  [-1, -2],
  [-2, -1],
  [-2, 1],
  [-1, 2],
]
const KING = [
  [1, 0],
  [1, 1],
  [0, 1],
  [-1, 1],
  [-1, 0],
  [-1, -1],
  [0, -1],
  [1, -1],
]
const ROOK_DIRS = [
  [1, 0],
  [-1, 0],
  [0, 1],
  [0, -1],
]
const BISHOP_DIRS = [
  [1, 1],
  [1, -1],
  [-1, 1],
  [-1, -1],
]

const at = (f: number, r: number) =>
  f < 0 || f > 7 || r < 0 || r > 7 ? -1 : r * 8 + f

/** Is square `sq` attacked by pieces of `bySeat`? */
function attacked(board: string[], sq: number, bySeat: number): boolean {
  const f = sq % 8
  const r = sq >> 3
  const own = (p: string) => p !== '' && pieceSeat(p) === bySeat
  // pawns
  const pr = bySeat === 0 ? r - 1 : r + 1
  for (const df of [-1, 1]) {
    const i = at(f + df, pr)
    if (i >= 0 && own(board[i]) && typeOf(board[i]) === 'p') return true
  }
  for (const [df, dr] of KNIGHT) {
    const i = at(f + df, r + dr)
    if (i >= 0 && own(board[i]) && typeOf(board[i]) === 'n') return true
  }
  for (const [df, dr] of KING) {
    const i = at(f + df, r + dr)
    if (i >= 0 && own(board[i]) && typeOf(board[i]) === 'k') return true
  }
  const ray = (dirs: number[][], types: PieceType[]) => {
    for (const [df, dr] of dirs) {
      let cf = f + df
      let cr = r + dr
      for (let i = at(cf, cr); i >= 0; cf += df, cr += dr, i = at(cf, cr)) {
        const p = board[i]
        if (p === '') continue
        if (own(p) && types.includes(typeOf(p))) return true
        break
      }
    }
    return false
  }
  return ray(ROOK_DIRS, ['r', 'q']) || ray(BISHOP_DIRS, ['b', 'q'])
}

function kingSquare(board: string[], seat: number): number {
  const k = seat === 0 ? 'K' : 'k'
  return board.indexOf(k)
}

function boardInCheck(board: string[], seat: number): boolean {
  const k = kingSquare(board, seat)
  return k >= 0 && attacked(board, k, 1 - seat)
}

/** Is the side to move (or `seat`) currently in check? */
export function inCheck(state: ChessState, seat: number = state.turn): boolean {
  return boardInCheck(state.board, seat)
}

// ---------------------------------------------------------------- move generation

interface Pos {
  board: string[]
  turn: number
  castling: string
  ep: string | null
}

function pseudoMoves(pos: Pos, from: number): ChessMove[] {
  const { board, turn } = pos
  const p = board[from]
  if (p === '' || pieceSeat(p) !== turn) return []
  const f = from % 8
  const r = from >> 3
  const out: ChessMove[] = []
  const fromS = squareName(from)
  const enemy = (i: number) => board[i] !== '' && pieceSeat(board[i]) !== turn
  const push = (to: number, extra: Partial<ChessMove> = {}) => {
    const cap = board[to]
    out.push({
      from: fromS,
      to: squareName(to),
      ...(cap ? { captured: cap } : {}),
      ...extra,
    })
  }
  const pushPawn = (to: number, extra: Partial<ChessMove> = {}) => {
    const tr = to >> 3
    if (tr === 7 || tr === 0) {
      for (const promotion of PROMOS) push(to, { ...extra, promotion })
    } else push(to, extra)
  }
  const t = typeOf(p)
  if (t === 'p') {
    const dir = turn === 0 ? 1 : -1
    const one = at(f, r + dir)
    if (one >= 0 && board[one] === '') {
      pushPawn(one)
      const startRank = turn === 0 ? 1 : 6
      const two = at(f, r + 2 * dir)
      if (r === startRank && board[two] === '') push(two)
    }
    for (const df of [-1, 1]) {
      const c = at(f + df, r + dir)
      if (c < 0) continue
      if (enemy(c)) pushPawn(c)
      else if (pos.ep && squareName(c) === pos.ep && board[c] === '') {
        out.push({
          from: fromS,
          to: squareName(c),
          enPassant: true,
          captured: turn === 0 ? 'p' : 'P',
        })
      }
    }
    return out
  }
  if (t === 'n' || t === 'k') {
    for (const [df, dr] of t === 'n' ? KNIGHT : KING) {
      const i = at(f + df, r + dr)
      if (i >= 0 && (board[i] === '' || enemy(i))) push(i)
    }
    if (t === 'k') {
      const home = turn === 0 ? 4 : 60
      const opp = 1 - turn
      const [kc, qc, rook] = turn === 0 ? ['K', 'Q', 'R'] : ['k', 'q', 'r']
      if (from === home && !attacked(board, home, opp)) {
        if (
          pos.castling.includes(kc) &&
          board[home + 3] === rook &&
          board[home + 1] === '' &&
          board[home + 2] === '' &&
          !attacked(board, home + 1, opp) &&
          !attacked(board, home + 2, opp)
        )
          out.push({ from: fromS, to: squareName(home + 2), castle: 'k' })
        if (
          pos.castling.includes(qc) &&
          board[home - 4] === rook &&
          board[home - 1] === '' &&
          board[home - 2] === '' &&
          board[home - 3] === '' &&
          !attacked(board, home - 1, opp) &&
          !attacked(board, home - 2, opp)
        )
          out.push({ from: fromS, to: squareName(home - 2), castle: 'q' })
      }
    }
    return out
  }
  const dirs =
    t === 'r'
      ? ROOK_DIRS
      : t === 'b'
        ? BISHOP_DIRS
        : [...ROOK_DIRS, ...BISHOP_DIRS]
  for (const [df, dr] of dirs) {
    let cf = f + df
    let cr = r + dr
    for (let i = at(cf, cr); i >= 0; cf += df, cr += dr, i = at(cf, cr)) {
      if (board[i] === '') push(i)
      else {
        if (enemy(i)) push(i)
        break
      }
    }
  }
  return out
}

interface Applied {
  board: string[]
  castling: string
  ep: string | null
}

function makeMove(pos: Pos, m: ChessMove): Applied {
  const board = pos.board.slice()
  const from = squareIndex(m.from)
  const to = squareIndex(m.to)
  const p = board[from]
  const white = pos.turn === 0
  board[from] = ''
  board[to] = m.promotion
    ? white
      ? m.promotion.toUpperCase()
      : m.promotion
    : p
  if (m.enPassant) board[to + (white ? -8 : 8)] = ''
  if (m.castle) {
    const home = white ? 4 : 60
    if (m.castle === 'k') {
      board[home + 1] = board[home + 3]
      board[home + 3] = ''
    } else {
      board[home - 1] = board[home - 4]
      board[home - 4] = ''
    }
  }
  let castling = pos.castling
  const strip = (chars: string) => {
    for (const c of chars) castling = castling.replace(c, '')
  }
  if (p === 'K') strip('KQ')
  if (p === 'k') strip('kq')
  for (const sq of [from, to]) {
    if (sq === 0) strip('Q')
    if (sq === 7) strip('K')
    if (sq === 56) strip('q')
    if (sq === 63) strip('k')
  }
  let ep: string | null = null
  if (typeOf(p) === 'p' && Math.abs(to - from) === 16)
    ep = squareName((from + to) / 2)
  return { board, castling, ep }
}

function legalFrom(pos: Pos, from: number): ChessMove[] {
  return pseudoMoves(pos, from).filter(
    (m) => !boardInCheck(makeMove(pos, m).board, pos.turn),
  )
}

function allLegal(pos: Pos): ChessMove[] {
  const out: ChessMove[] = []
  for (let i = 0; i < 64; i++) {
    const p = pos.board[i]
    if (p !== '' && pieceSeat(p) === pos.turn) out.push(...legalFrom(pos, i))
  }
  return out
}

/** Legal moves for the piece on `fromSquare` (empty when not side to move or game over). */
export function legalMoves(state: ChessState, fromSquare: string): ChessMove[] {
  const i = squareIndex(fromSquare)
  if (i < 0 || state.result) return []
  return legalFrom(state, i)
}

/** Every legal move for the side to move. */
export function allLegalMoves(state: ChessState): ChessMove[] {
  return state.result ? [] : allLegal(state)
}

// ---------------------------------------------------------------- draws & keys

function placement(board: string[]): string {
  const rows: string[] = []
  for (let r = 7; r >= 0; r--) {
    let row = ''
    let empty = 0
    for (let f = 0; f < 8; f++) {
      const p = board[r * 8 + f]
      if (p === '') empty++
      else {
        if (empty) row += empty
        empty = 0
        row += p
      }
    }
    if (empty) row += empty
    rows.push(row)
  }
  return rows.join('/')
}

/** Repetition key: placement, side, castling, and ep only when an ep capture is legal. */
function positionKey(pos: Pos): string {
  let ep = '-'
  if (pos.ep && allLegal(pos).some((m) => m.enPassant)) ep = pos.ep
  return `${placement(pos.board)} ${pos.turn === 0 ? 'w' : 'b'} ${pos.castling || '-'} ${ep}`
}

/** True when neither side can possibly mate (K v K, K+minor v K, bishops all on one colour). */
export function insufficientMaterial(board: string[]): boolean {
  const others: { t: PieceType; sq: number }[] = []
  for (let i = 0; i < 64; i++) {
    const p = board[i]
    if (p !== '' && typeOf(p) !== 'k') others.push({ t: typeOf(p), sq: i })
  }
  if (others.length === 0) return true
  if (others.length === 1 && (others[0].t === 'n' || others[0].t === 'b'))
    return true
  if (others.every((o) => o.t === 'b')) {
    const colour = (sq: number) => ((sq % 8) + (sq >> 3)) % 2
    const c0 = colour(others[0].sq)
    return others.every((o) => colour(o.sq) === c0)
  }
  return false
}

/** Can `seat` alone ever deliver mate? False for a bare king or king + single minor. */
function hasMatingMaterial(board: string[], seat: number): boolean {
  const mine = board.filter(
    (p) => p !== '' && pieceSeat(p) === seat && typeOf(p) !== 'k',
  )
  if (mine.length === 0) return false
  if (mine.length === 1 && (typeOf(mine[0]) === 'n' || typeOf(mine[0]) === 'b'))
    return false
  return true
}

// ---------------------------------------------------------------- FEN

export function fromFen(
  fen: string,
  names: [string, string] = ['White', 'Black'],
): ChessState {
  const parts = fen.trim().split(/\s+/)
  const rows = (parts[0] ?? '').split('/')
  if (rows.length !== 8) throw new GameRuleError('Invalid FEN')
  const board: string[] = Array(64).fill('')
  rows.forEach((row, ri) => {
    const r = 7 - ri
    let f = 0
    for (const ch of row) {
      if (/[1-8]/.test(ch)) f += Number(ch)
      else if (/[pnbrqkPNBRQK]/.test(ch)) board[r * 8 + f++] = ch
      else throw new GameRuleError('Invalid FEN')
    }
    if (f !== 8) throw new GameRuleError('Invalid FEN')
  })
  const turn = parts[1] === 'b' ? 1 : 0
  const castling =
    parts[2] && parts[2] !== '-' ? parts[2].replace(/[^KQkq]/g, '') : ''
  const ep = parts[3] && squareIndex(parts[3]) >= 0 ? parts[3] : null
  const halfmove = Number(parts[4] ?? 0) || 0
  const fullmove = Number(parts[5] ?? 1) || 1
  const pos: Pos = { board, turn, castling, ep }
  return {
    board,
    turn,
    castling,
    ep,
    halfmove,
    fullmove,
    history: [positionKey(pos)],
    lastMove: null,
    moves: [],
    captured: [[], []],
    drawOffer: null,
    offerBlocked: null,
    result: null,
    names,
    n: 0,
  }
}

export function toFen(state: ChessState): string {
  return [
    placement(state.board),
    state.turn === 0 ? 'w' : 'b',
    state.castling || '-',
    state.ep ?? '-',
    state.halfmove,
    state.fullmove,
  ].join(' ')
}

// ---------------------------------------------------------------- SAN

function toSan(pos: Pos, m: ChessMove, legal: ChessMove[], after: Pos): string {
  let san: string
  if (m.castle) san = m.castle === 'k' ? 'O-O' : 'O-O-O'
  else {
    const p = pos.board[squareIndex(m.from)]
    const t = typeOf(p)
    const cap = !!m.captured
    if (t === 'p') {
      san =
        (cap ? m.from[0] + 'x' : '') +
        m.to +
        (m.promotion ? '=' + m.promotion.toUpperCase() : '')
    } else {
      const rivals = legal.filter(
        (o) =>
          o.to === m.to &&
          o.from !== m.from &&
          pos.board[squareIndex(o.from)] === p,
      )
      let dis = ''
      if (rivals.length) {
        if (!rivals.some((o) => o.from[0] === m.from[0])) dis = m.from[0]
        else if (!rivals.some((o) => o.from[1] === m.from[1])) dis = m.from[1]
        else dis = m.from
      }
      san = t.toUpperCase() + dis + (cap ? 'x' : '') + m.to
    }
  }
  if (boardInCheck(after.board, after.turn))
    san += allLegal(after).length ? '+' : '#'
  return san
}

// ---------------------------------------------------------------- engine

const PROMO_SET = new Set<string>(PROMOS)

function parseAction(raw: unknown): ChessAction {
  if (!raw || typeof raw !== 'object') throw new GameRuleError('Invalid action')
  const a = raw as Record<string, unknown>
  switch (a.type) {
    case 'move': {
      const from = typeof a.from === 'string' ? a.from.toLowerCase() : ''
      const to = typeof a.to === 'string' ? a.to.toLowerCase() : ''
      if (squareIndex(from) < 0 || squareIndex(to) < 0)
        throw new GameRuleError('Invalid square')
      if (a.promotion === undefined || a.promotion === null)
        return { type: 'move', from, to }
      const promotion =
        typeof a.promotion === 'string' ? a.promotion.toLowerCase() : ''
      if (!PROMO_SET.has(promotion))
        throw new GameRuleError(
          'Promotion must be a queen, rook, bishop or knight',
        )
      return { type: 'move', from, to, promotion: promotion as Promotion }
    }
    case 'resign':
    case 'offerDraw':
    case 'acceptDraw':
    case 'declineDraw':
      return { type: a.type }
    default:
      throw new GameRuleError('Unknown action')
  }
}

const live = (state: ChessState): StepResult<ChessState> => ({
  state,
  done: false,
  winner: null,
})
const finish = (
  state: ChessState,
  winner: number | null,
  reason: string,
): StepResult<ChessState> => ({
  state: { ...state, result: { winner, reason }, drawOffer: null },
  done: true,
  winner,
  reason,
})

function applyMove(
  state: ChessState,
  seat: number,
  action: { from: string; to: string; promotion?: Promotion },
): StepResult<ChessState> {
  if (seat !== state.turn) throw new GameRuleError("It's not your turn")
  const from = squareIndex(action.from)
  const piece = state.board[from]
  if (!piece) throw new GameRuleError('There is no piece on that square')
  if (pieceSeat(piece) !== seat)
    throw new GameRuleError("That's not your piece")
  const pos: Pos = state
  const legal = allLegal(pos)
  const candidates = legal.filter(
    (m) => m.from === action.from && m.to === action.to,
  )
  if (!candidates.length) {
    throw new GameRuleError(
      boardInCheck(state.board, seat)
        ? 'Illegal move — your king is in check'
        : 'Illegal move',
    )
  }
  let move = candidates[0]
  if (candidates[0].promotion) {
    if (!action.promotion)
      throw new GameRuleError('Choose a piece to promote to')
    move =
      candidates.find((m) => m.promotion === action.promotion) ?? candidates[0]
  }
  const applied = makeMove(pos, move)
  const nextTurn = 1 - seat
  const after: Pos = { ...applied, turn: nextTurn }
  const san = toSan(pos, move, legal, after)
  const irreversible = typeOf(piece) === 'p' || !!move.captured
  const key = positionKey(after)
  const history = irreversible ? [key] : [...state.history, key]
  const captured: [string[], string[]] = [
    state.captured[0].slice(),
    state.captured[1].slice(),
  ]
  if (move.captured) captured[seat].push(move.captured)
  const next: ChessState = {
    ...state,
    ...after,
    halfmove: irreversible ? 0 : state.halfmove + 1,
    fullmove: seat === 1 ? state.fullmove + 1 : state.fullmove,
    history,
    lastMove: { from: move.from, to: move.to, san },
    moves: [...state.moves, san].slice(-200),
    captured,
    // A move by the recipient declines an open offer; the offerer's own move keeps it.
    drawOffer: state.drawOffer === seat ? seat : null,
    offerBlocked: state.offerBlocked === seat ? null : state.offerBlocked,
    n: state.n + 1,
  }
  if (!allLegal(after).length) {
    return boardInCheck(after.board, nextTurn)
      ? finish(next, seat, 'Checkmate')
      : finish(next, null, 'Stalemate')
  }
  if (insufficientMaterial(after.board))
    return finish(next, null, 'Insufficient material')
  if (next.halfmove >= 100) return finish(next, null, '50-move rule')
  if (history.filter((k) => k === key).length >= 3)
    return finish(next, null, 'Threefold repetition')
  return live(next)
}

function apply(
  state: ChessState,
  seat: number,
  action: ChessAction,
): StepResult<ChessState> {
  if (state.result) throw new GameRuleError('The game is already over')
  if (seat !== 0 && seat !== 1)
    throw new GameRuleError('You are not playing in this game')
  const other = 1 - seat
  const bump = (s: Partial<ChessState>): ChessState => ({
    ...state,
    ...s,
    n: state.n + 1,
  })
  switch (action.type) {
    case 'move':
      return applyMove(state, seat, action)
    case 'resign':
      return finish(bump({}), other, 'Resignation')
    case 'offerDraw':
      if (state.drawOffer === other)
        return finish(bump({}), null, 'Draw agreed')
      if (state.drawOffer === seat)
        throw new GameRuleError('You already offered a draw')
      if (state.offerBlocked === seat)
        throw new GameRuleError('Make a move before offering another draw')
      return live(bump({ drawOffer: seat }))
    case 'acceptDraw':
      if (state.drawOffer !== other)
        throw new GameRuleError('There is no draw offer to accept')
      return finish(bump({}), null, 'Draw agreed')
    case 'declineDraw':
      if (state.drawOffer !== other)
        throw new GameRuleError('There is no draw offer to decline')
      return live(bump({ drawOffer: null, offerBlocked: other }))
  }
}

function timeout(state: ChessState, seat: number): StepResult<ChessState> {
  if (state.result)
    return {
      state,
      done: true,
      winner: state.result.winner,
      reason: state.result.reason,
    }
  const winner = 1 - seat
  const s = { ...state, n: state.n + 1 }
  if (!hasMatingMaterial(state.board, winner))
    return finish(s, null, 'Time out vs insufficient material')
  return finish(s, winner, 'Ran out of time')
}

export const chessEngine: ArenaEngine<ChessState, ChessAction> = {
  id: 'chess',
  name: 'Chess',
  turnSeconds: 120,
  init: (names) => fromFen(START_FEN, names),
  parseAction,
  apply,
  timeout,
  current: (state) => state.turn,
}
