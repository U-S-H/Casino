import { describe, expect, it } from 'vitest'

import {
  allLegalMoves,
  chessEngine,
  fromFen,
  inCheck,
  insufficientMaterial,
  legalMoves,
  pieceAt,
  toFen,
  type ChessState,
} from './chess'
import { GameRuleError, type StepResult } from './types'

const init = () => chessEngine.init(['A', 'B'], () => 0)

function run(state: ChessState, moves: string[]) {
  let s = state
  let res: StepResult<ChessState> = { state: s, done: false, winner: null }
  for (const mv of moves) {
    const action = chessEngine.parseAction({
      type: 'move',
      from: mv.slice(0, 2),
      to: mv.slice(2, 4),
      promotion: mv[4],
    })
    const r = chessEngine.apply(s, s.turn, action)
    res = r
    s = r.state
  }
  return res
}
describe('chess engine', () => {
  it('has 20 opening moves and white to move', () => {
    const s = init()
    expect(allLegalMoves(s)).toHaveLength(20)
    expect(chessEngine.current(s)).toBe(0)
    expect(
      legalMoves(s, 'g1')
        .map((m) => m.to)
        .sort(),
    ).toEqual(['f3', 'h3'])
    expect(toFen(s)).toBe(
      'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
    )
  })

  it("detects fool's mate", () => {
    const r = run(init(), ['f2f3', 'e7e5', 'g2g4', 'd8h4'])
    expect(r.done).toBe(true)
    expect(r.winner).toBe(1)
    expect(r.reason).toBe('Checkmate')
    expect(r.state.moves).toEqual(['f3', 'e5', 'g4', 'Qh4#'])
    expect(r.state.result).toEqual({ winner: 1, reason: 'Checkmate' })
  })

  it('detects stalemate', () => {
    const s = fromFen('7k/8/6Q1/8/8/8/8/K7 w - - 0 1')
    const r = run(s, ['g6f7'])
    expect(r.done).toBe(true)
    expect(r.winner).toBeNull()
    expect(r.reason).toBe('Stalemate')
  })

  it('allows castling and moves the rook', () => {
    const s = fromFen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1')
    const tos = legalMoves(s, 'e1').map((m) => m.to)
    expect(tos).toContain('g1')
    expect(tos).toContain('c1')
    const r = run(s, ['e1g1'])
    expect(pieceAt(r.state, 'g1')).toBe('K')
    expect(pieceAt(r.state, 'f1')).toBe('R')
    expect(pieceAt(r.state, 'h1')).toBe('')
    expect(r.state.castling).toBe('kq')
    expect(r.state.moves).toEqual(['O-O'])
    const q = run(r.state, ['e8c8'])
    expect(pieceAt(q.state, 'd8')).toBe('r')
    expect(q.state.moves[1]).toBe('O-O-O')
  })

  it('blocks castling out of, through, or into check', () => {
    // in check from e-file rook
    const inChk = fromFen('4r1k1/8/8/8/8/8/8/R3K2R w KQ - 0 1')
    expect(inCheck(inChk)).toBe(true)
    expect(legalMoves(inChk, 'e1').map((m) => m.to)).not.toContain('g1')
    expect(legalMoves(inChk, 'e1').map((m) => m.to)).not.toContain('c1')
    // f1 attacked: no king-side; queen-side still fine
    const through = fromFen('5rk1/8/8/8/8/8/8/R3K2R w KQ - 0 1')
    const t = legalMoves(through, 'e1').map((m) => m.to)
    expect(t).not.toContain('g1')
    expect(t).toContain('c1')
    // g1 attacked: no king-side
    const into = fromFen('6rk/8/8/8/8/8/8/R3K2R w KQ - 0 1')
    expect(legalMoves(into, 'e1').map((m) => m.to)).not.toContain('g1')
    // blocked by a piece / missing rights
    const blocked = fromFen('4k3/8/8/8/8/8/8/RN2K1NR w KQ - 0 1')
    expect(legalMoves(blocked, 'e1').map((m) => m.to)).not.toContain('g1')
    expect(legalMoves(blocked, 'e1').map((m) => m.to)).not.toContain('c1')
    const noRights = fromFen('4k3/8/8/8/8/8/8/R3K2R w - - 0 1')
    expect(legalMoves(noRights, 'e1').map((m) => m.to)).not.toContain('g1')
  })

  it('supports en passant', () => {
    const r = run(init(), ['e2e4', 'a7a6', 'e4e5', 'd7d5'])
    expect(r.state.ep).toBe('d6')
    const ep = legalMoves(r.state, 'e5').find((m) => m.to === 'd6')
    expect(ep?.enPassant).toBe(true)
    const r2 = run(r.state, ['e5d6'])
    expect(pieceAt(r2.state, 'd5')).toBe('')
    expect(pieceAt(r2.state, 'd6')).toBe('P')
    expect(r2.state.captured[0]).toEqual(['p'])
    expect(r2.state.moves.at(-1)).toBe('exd6')
    // the right expires after one move
    const r3 = run(init(), ['e2e4', 'a7a6', 'e4e5', 'd7d5', 'h2h3', 'h7h6'])
    expect(legalMoves(r3.state, 'e5').map((m) => m.to)).not.toContain('d6')
  })

  it('handles promotion and requires a piece choice', () => {
    const s = fromFen('8/P6k/8/8/8/8/8/K7 w - - 0 1')
    expect(() =>
      chessEngine.apply(
        s,
        0,
        chessEngine.parseAction({ type: 'move', from: 'a7', to: 'a8' }),
      ),
    ).toThrow(GameRuleError)
    expect(() =>
      chessEngine.parseAction({
        type: 'move',
        from: 'a7',
        to: 'a8',
        promotion: 'k',
      }),
    ).toThrow(GameRuleError)
    const r = run(s, ['a7a8n'])
    expect(pieceAt(r.state, 'a8')).toBe('N')
    expect(r.state.moves).toEqual(['a8=N'])
    const q = run(s, ['a7a8q'])
    expect(pieceAt(q.state, 'a8')).toBe('Q')
  })

  it('rejects illegal moves', () => {
    const s = init()
    expect(() => run(s, ['e2e5'])).toThrow(GameRuleError)
    expect(() => run(s, ['e1e2'])).toThrow(GameRuleError)
    expect(() =>
      chessEngine.apply(s, 0, { type: 'move', from: 'e7', to: 'e5' }),
    ).toThrow("That's not your piece")
    // pinned piece cannot move
    const pinned = fromFen('4r1k1/8/8/8/8/8/4N3/4K3 w - - 0 1')
    expect(legalMoves(pinned, 'e2')).toHaveLength(0)
    expect(() =>
      chessEngine.parseAction({ type: 'move', from: 'z9', to: 'e4' }),
    ).toThrow(GameRuleError)
    expect(() => chessEngine.parseAction('nope')).toThrow(GameRuleError)
    expect(() => chessEngine.parseAction({ type: 'hack' })).toThrow(
      GameRuleError,
    )
  })

  it('rejects moves out of turn and after the game ends', () => {
    const s = init()
    expect(() =>
      chessEngine.apply(s, 1, { type: 'move', from: 'e7', to: 'e5' }),
    ).toThrow("It's not your turn")
    const over = chessEngine.apply(s, 0, { type: 'resign' }).state
    expect(() =>
      chessEngine.apply(over, 0, { type: 'move', from: 'e2', to: 'e4' }),
    ).toThrow(GameRuleError)
  })

  it('handles resignation by either seat at any time', () => {
    const s = init()
    const r = chessEngine.apply(s, 1, { type: 'resign' })
    expect(r).toMatchObject({ done: true, winner: 0, reason: 'Resignation' })
    expect(r.state.n).toBe(1)
  })

  it('handles draw offers', () => {
    let s = init()
    expect(() => chessEngine.apply(s, 1, { type: 'acceptDraw' })).toThrow(
      GameRuleError,
    )
    s = chessEngine.apply(s, 0, { type: 'offerDraw' }).state
    expect(s.drawOffer).toBe(0)
    expect(() => chessEngine.apply(s, 0, { type: 'acceptDraw' })).toThrow(
      GameRuleError,
    )
    // offerer's own move keeps it, recipient's move clears it
    s = run(s, ['e2e4']).state
    expect(s.drawOffer).toBe(0)
    const declinedByMove = run(s, ['e7e5']).state
    expect(declinedByMove.drawOffer).toBeNull()
    // explicit decline blocks re-offering until a move
    const declined = chessEngine.apply(s, 1, { type: 'declineDraw' }).state
    expect(declined.drawOffer).toBeNull()
    expect(() => chessEngine.apply(declined, 0, { type: 'offerDraw' })).toThrow(
      GameRuleError,
    )
    // accept
    const r = chessEngine.apply(s, 1, { type: 'acceptDraw' })
    expect(r).toMatchObject({ done: true, winner: null, reason: 'Draw agreed' })
  })

  it('detects insufficient material', () => {
    expect(
      insufficientMaterial(fromFen('4k3/8/8/8/8/8/8/4K3 w - - 0 1').board),
    ).toBe(true)
    expect(
      insufficientMaterial(fromFen('4k3/8/8/8/8/8/8/4KN2 w - - 0 1').board),
    ).toBe(true)
    // bishops on same colour (c1 and f8 are both dark)
    expect(
      insufficientMaterial(fromFen('5bk1/8/8/8/8/8/8/2B1K3 w - - 0 1').board),
    ).toBe(true)
    // opposite colours (g8 is light)
    expect(
      insufficientMaterial(fromFen('4k1b1/8/8/8/8/8/8/2B1K3 w - - 0 1').board),
    ).toBe(false)
    expect(
      insufficientMaterial(fromFen('4k3/8/8/8/8/8/8/R3K3 w - - 0 1').board),
    ).toBe(false)
    // capturing the last piece ends the game
    const r = run(fromFen('4k3/8/8/8/8/8/3r4/4K3 w - - 0 1'), ['e1d2'])
    expect(r).toMatchObject({
      done: true,
      winner: null,
      reason: 'Insufficient material',
    })
  })

  it('detects threefold repetition', () => {
    const r = run(init(), [
      'g1f3',
      'g8f6',
      'f3g1',
      'f6g8',
      'g1f3',
      'g8f6',
      'f3g1',
      'f6g8',
    ])
    expect(r).toMatchObject({
      done: true,
      winner: null,
      reason: 'Threefold repetition',
    })
  })

  it('applies the 50-move rule', () => {
    const r = run(fromFen('4k3/8/8/8/8/8/8/R3K3 w - - 99 80'), ['a1a2'])
    expect(r).toMatchObject({
      done: true,
      winner: null,
      reason: '50-move rule',
    })
  })

  it('handles timeouts', () => {
    const s = init()
    expect(chessEngine.timeout(s, 0)).toMatchObject({
      done: true,
      winner: 1,
      reason: 'Ran out of time',
    })
    const bare = fromFen('4k3/8/8/8/8/8/8/R3K3 b - - 0 1')
    expect(chessEngine.timeout(bare, 0)).toMatchObject({
      done: true,
      winner: null,
    })
    expect(chessEngine.timeout(bare, 1)).toMatchObject({
      done: true,
      winner: 0,
    })
  })

  it('keeps state as plain JSON', () => {
    const r = run(init(), ['e2e4', 'e7e5'])
    expect(JSON.parse(JSON.stringify(r.state))).toEqual(r.state)
    expect(r.state.n).toBe(2)
    expect(r.state.lastMove).toEqual({ from: 'e7', to: 'e5', san: 'e5' })
  })
})
