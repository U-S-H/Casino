/**
 * Carrom Board engine — pure, deterministic, JSON state.
 *
 * Units are millimetres on an ICF-sized playing surface (740 × 740), origin at
 * the top-left corner, y pointing down. Seat 0 plays White and shoots from the
 * bottom baseline; seat 1 plays Black from the top baseline. The UI rotates the
 * view 180° for seat 1.
 *
 * The physics simulation (`simulate`) uses only + - * / Math.sqrt Math.abs
 * Math.min Math.max Math.ceil with a fixed timestep and a hard step cap, so the
 * server and every browser produce bit-identical results for the same input.
 *
 * Rules (simplified ICF):
 * - Pocket at least one own coin → strike again. Otherwise the turn passes.
 * - Opponent coins you pocket stay pocketed and count for the opponent.
 * - Striker pocketed (foul): turn passes; own coins and the queen pocketed on
 *   that strike go back to the centre, and one of the fouler's previously
 *   pocketed coins (if any) is returned as a penalty. No "debt" is carried when
 *   the fouler has nothing to return.
 * - Queen: may only be pocketed once the player has pocketed at least one own
 *   coin (pocketing an own coin on the same strike also counts). Pocketed with
 *   an own coin on the same strike → covered immediately. Otherwise it is
 *   pending and must be covered by pocketing an own coin on the immediately
 *   following strike, else it returns to the centre.
 * - You cannot pocket your last coin while the queen is uncovered, nor the
 *   opponent's last coin at any time: foul, one such coin is returned, turn passes.
 * - Win: pocket all 9 own coins with the queen covered (by either player).
 *   Points = opponent coins left on the board + 3 if the winner covered the queen.
 * - Timeout: turn passes with no coin penalty; a pending queen is returned.
 */
import { GameRuleError } from './types'
import type { ArenaEngine, StepResult } from './types'

// ---------------------------------------------------------------- geometry
export const BOARD = 740
export const FRAME = 70
export const COIN_R = 15.9
export const STRIKER_R = 20.6
export const POCKET_R = 22.25
export const COIN_MASS = 5.5
export const STRIKER_MASS = 15
/** Distance from the cushion to the baseline centre line (between the two lines). */
export const BASE_OFFSET = 86.1
export const BASE_INNER = 70.2
export const BASE_OUTER = 102
export const BASE_LEN = 470
export const BASE_MIN = (BOARD - BASE_LEN) / 2 + COIN_R
export const BASE_MAX = BOARD - (BOARD - BASE_LEN) / 2 - COIN_R
export const CENTER = BOARD / 2
export const CENTER_CIRCLE_R = 85
export const POCKETS: ReadonlyArray<{ x: number; y: number }> = [
  { x: POCKET_R, y: POCKET_R },
  { x: BOARD - POCKET_R, y: POCKET_R },
  { x: POCKET_R, y: BOARD - POCKET_R },
  { x: BOARD - POCKET_R, y: BOARD - POCKET_R },
]

// ---------------------------------------------------------------- physics constants
export const MAX_SPEED = 4500 // mm/s at power 1
const MIN_SPEED_FRAC = 0.04
const FRICTION = 1600 // mm/s² deceleration
const E_COIN = 0.92
const E_WALL = 0.72
const DT = 1 / 120
const MAX_STEPS = 120 * 25
const MAX_SUBSTEPS = 16
const FRAME_EVERY = 2
/** Seconds between recorded animation frames. */
export const SIM_FRAME_SECONDS = DT * FRAME_EVERY

// ---------------------------------------------------------------- types
export type CoinKind = 'w' | 'b' | 'q'
export interface Coin {
  id: number
  k: CoinKind
  x: number
  y: number
}
export interface CarromAction {
  type: 'strike'
  /** Striker position along the baseline, 0..1 from BASE_MIN to BASE_MAX (board x). */
  x: number
  /** Unit direction in board coordinates. */
  dx: number
  dy: number
  /** 0..1 */
  power: number
}
export type QueenStatus = { s: 'board' } | { s: 'pending'; seat: number } | { s: 'covered'; seat: number }
export interface LastStrike {
  n: number
  seat: number
  before: { coins: Coin[]; striker: { x: number; y: number } }
  strike: CarromAction
}
export interface CarromState {
  v: 1
  names: [string, string]
  /** Coins currently on the board. */
  coins: Coin[]
  /** Own coins pocketed: [white (seat 0), black (seat 1)]. */
  pocketed: [number, number]
  queen: QueenStatus
  turn: number
  /** Strike counter (monotonic). */
  n: number
  lastStrike: LastStrike | null
  log: string[]
  /** Foul from the most recent strike, or null. */
  foul: string | null
  over: boolean
  winner: number | null
  points: number | null
}
export interface StrikeInput {
  seat: number
  x: number
  dx: number
  dy: number
  power: number
}
/** Positions of [...input coins, striker]; null once pocketed. */
export type SimFrame = Array<{ x: number; y: number } | null>
export interface SimResult {
  /** Coins still on the board (input order) at their resting positions. */
  coins: Coin[]
  /** Coins pocketed, in pocketing order. */
  pocketed: Coin[]
  strikerPocketed: boolean
  striker: { x: number; y: number } | null
  steps: number
  frames?: SimFrame[]
}

// ---------------------------------------------------------------- helpers
export function strikerBaseline(seat: number) {
  return { y: seat === 0 ? BOARD - BASE_OFFSET : BASE_OFFSET, xMin: BASE_MIN, xMax: BASE_MAX }
}
export function strikerPos(seat: number, x: number) {
  return { x: BASE_MIN + x * (BASE_MAX - BASE_MIN), y: strikerBaseline(seat).y }
}
export const ownKind = (seat: number): CoinKind => (seat === 0 ? 'w' : 'b')
const countKind = (coins: readonly Coin[], k: CoinKind) => coins.filter((c) => c.k === k).length

/** Returns a reason string when the striker cannot be placed at `x`, else null. */
export function strikerPlacementError(coins: readonly Coin[], seat: number, x: number): string | null {
  if (!Number.isFinite(x) || x < 0 || x > 1) return 'Striker must be placed on your baseline'
  const p = strikerPos(seat, x)
  for (const c of coins) {
    const ddx = c.x - p.x
    const ddy = c.y - p.y
    if (ddx * ddx + ddy * ddy < (STRIKER_R + COIN_R) * (STRIKER_R + COIN_R) - 1e-6) return 'Striker overlaps a coin'
  }
  return null
}

/** True when (dx,dy) is forward or sideways for `seat`. */
export function isForward(seat: number, dy: number) {
  return seat === 0 ? dy <= 1e-9 : dy >= -1e-9
}

function initialCoins(): Coin[] {
  const coins: Coin[] = [{ id: 0, k: 'q', x: CENTER, y: CENTER }]
  const d = 2 * COIN_R + 0.1
  const s3 = Math.sqrt(3) / 2
  // unit vectors at 0°,60°,…,300° and 30°,90°,…,330° (no trig)
  const hex: Array<[number, number]> = [
    [1, 0], [0.5, s3], [-0.5, s3], [-1, 0], [-0.5, -s3], [0.5, -s3],
  ]
  const mid: Array<[number, number]> = [
    [s3, 0.5], [0, 1], [-s3, 0.5], [-s3, -0.5], [0, -1], [s3, -0.5],
  ]
  let w = 1
  let b = 10
  const add = (k: 'w' | 'b', x: number, y: number) => coins.push({ id: k === 'w' ? w++ : b++, k, x, y })
  hex.forEach(([ux, uy], i) => add(i % 2 === 0 ? 'w' : 'b', CENTER + ux * d, CENTER + uy * d))
  hex.forEach(([ux, uy], i) => add(i % 2 === 0 ? 'w' : 'b', CENTER + ux * 2 * d, CENTER + uy * 2 * d))
  mid.forEach(([ux, uy], i) => add(i % 2 === 0 ? 'b' : 'w', CENTER + ux * Math.sqrt(3) * d, CENTER + uy * Math.sqrt(3) * d))
  return coins
}

/** Nearest free spot to the centre (deterministic square-spiral grid search). */
export function freeSpotNear(coins: readonly Coin[], cx = CENTER, cy = CENTER): { x: number; y: number } {
  const step = 2
  const min2 = (2 * COIN_R + 0.1) * (2 * COIN_R + 0.1)
  const free = (x: number, y: number) =>
    x >= COIN_R && x <= BOARD - COIN_R && y >= COIN_R && y <= BOARD - COIN_R &&
    coins.every((c) => (c.x - x) * (c.x - x) + (c.y - y) * (c.y - y) >= min2)
  for (let k = 0; k < 160; k++) {
    let best: { x: number; y: number; d: number } | null = null
    for (let i = -k; i <= k; i++) {
      for (let j = -k; j <= k; j++) {
        if (Math.max(Math.abs(i), Math.abs(j)) !== k) continue
        const x = cx + i * step
        const y = cy + j * step
        const d = i * i + j * j
        if ((!best || d < best.d) && free(x, y)) best = { x, y, d }
      }
    }
    if (best) return { x: best.x, y: best.y }
  }
  return { x: cx, y: cy }
}

// ---------------------------------------------------------------- simulation
interface Body {
  x: number
  y: number
  vx: number
  vy: number
  r: number
  m: number
  on: boolean
}

export function simulate(coins: readonly Coin[], strike: StrikeInput, opts?: { frames?: boolean }): SimResult {
  const sp = strikerPos(strike.seat, strike.x)
  const len = Math.sqrt(strike.dx * strike.dx + strike.dy * strike.dy) || 1
  const power = Math.min(1, Math.max(0, strike.power))
  const speed = MAX_SPEED * (MIN_SPEED_FRAC + (1 - MIN_SPEED_FRAC) * power)
  const bodies: Body[] = coins.map((c) => ({ x: c.x, y: c.y, vx: 0, vy: 0, r: COIN_R, m: COIN_MASS, on: true }))
  bodies.push({
    x: sp.x, y: sp.y, vx: (strike.dx / len) * speed, vy: (strike.dy / len) * speed,
    r: STRIKER_R, m: STRIKER_MASS, on: true,
  })
  const si = bodies.length - 1
  const pocketedIdx: number[] = []
  const frames: SimFrame[] | undefined = opts?.frames ? [] : undefined
  const snap = () => frames?.push(bodies.map((b) => (b.on ? { x: b.x, y: b.y } : null)))
  snap()
  const pr2 = POCKET_R * POCKET_R
  let steps = 0
  for (; steps < MAX_STEPS; steps++) {
    let maxV = 0
    for (const b of bodies) if (b.on) maxV = Math.max(maxV, Math.abs(b.vx) + Math.abs(b.vy))
    if (maxV === 0) break
    const subs = Math.min(MAX_SUBSTEPS, Math.max(1, Math.ceil((maxV * DT) / (COIN_R * 0.35))))
    const h = DT / subs
    const dv = FRICTION * h
    for (let s = 0; s < subs; s++) {
      // integrate + friction
      for (const b of bodies) {
        if (!b.on || (b.vx === 0 && b.vy === 0)) continue
        b.x += b.vx * h
        b.y += b.vy * h
        const v = Math.sqrt(b.vx * b.vx + b.vy * b.vy)
        if (v <= dv) {
          b.vx = 0
          b.vy = 0
        } else {
          const f = (v - dv) / v
          b.vx *= f
          b.vy *= f
        }
      }
      // pockets
      for (let i = 0; i < bodies.length; i++) {
        const b = bodies[i]
        if (!b.on) continue
        for (const p of POCKETS) {
          const ddx = b.x - p.x
          const ddy = b.y - p.y
          if (ddx * ddx + ddy * ddy <= pr2) {
            b.on = false
            b.vx = 0
            b.vy = 0
            pocketedIdx.push(i)
            break
          }
        }
      }
      // body collisions
      for (let i = 0; i < bodies.length; i++) {
        const a = bodies[i]
        if (!a.on) continue
        for (let j = i + 1; j < bodies.length; j++) {
          const c = bodies[j]
          if (!c.on) continue
          const nx0 = c.x - a.x
          const ny0 = c.y - a.y
          const rr = a.r + c.r
          const d2 = nx0 * nx0 + ny0 * ny0
          if (d2 >= rr * rr) continue
          const d = Math.sqrt(d2)
          const nx = d > 1e-9 ? nx0 / d : 1
          const ny = d > 1e-9 ? ny0 / d : 0
          const ia = 1 / a.m
          const ic = 1 / c.m
          const overlap = rr - d
          const corr = overlap / (ia + ic)
          a.x -= nx * corr * ia
          a.y -= ny * corr * ia
          c.x += nx * corr * ic
          c.y += ny * corr * ic
          const vrel = (a.vx - c.vx) * nx + (a.vy - c.vy) * ny
          if (vrel > 0) {
            const J = ((1 + E_COIN) * vrel) / (ia + ic)
            a.vx -= J * ia * nx
            a.vy -= J * ia * ny
            c.vx += J * ic * nx
            c.vy += J * ic * ny
          }
        }
      }
      // cushions
      for (const b of bodies) {
        if (!b.on) continue
        if (b.x < b.r) {
          b.x = b.r
          if (b.vx < 0) b.vx = -b.vx * E_WALL
        } else if (b.x > BOARD - b.r) {
          b.x = BOARD - b.r
          if (b.vx > 0) b.vx = -b.vx * E_WALL
        }
        if (b.y < b.r) {
          b.y = b.r
          if (b.vy < 0) b.vy = -b.vy * E_WALL
        } else if (b.y > BOARD - b.r) {
          b.y = BOARD - b.r
          if (b.vy > 0) b.vy = -b.vy * E_WALL
        }
      }
    }
    if (frames && steps % FRAME_EVERY === FRAME_EVERY - 1) snap()
  }
  snap()
  const out: Coin[] = []
  coins.forEach((c, i) => {
    if (bodies[i].on) out.push({ id: c.id, k: c.k, x: bodies[i].x, y: bodies[i].y })
  })
  const pocketed = pocketedIdx.filter((i) => i !== si).map((i) => ({ ...coins[i], x: bodies[i].x, y: bodies[i].y }))
  const st = bodies[si]
  return {
    coins: out,
    pocketed,
    strikerPocketed: !st.on,
    striker: st.on ? { x: st.x, y: st.y } : null,
    steps,
    frames,
  }
}

// ---------------------------------------------------------------- rules
const KIND_IDS: Record<CoinKind, number[]> = {
  q: [0],
  w: [1, 2, 3, 4, 5, 6, 7, 8, 9],
  b: [10, 11, 12, 13, 14, 15, 16, 17, 18],
}
const kindName = (k: CoinKind) => (k === 'w' ? 'white' : k === 'b' ? 'black' : 'queen')

function returnToCentre(coins: Coin[], k: CoinKind) {
  const id = KIND_IDS[k].find((i) => !coins.some((c) => c.id === i))
  if (id === undefined) return
  const p = freeSpotNear(coins)
  coins.push({ id, k, x: p.x, y: p.y })
}

const pushLog = (log: string[], ...lines: string[]) => [...log, ...lines].slice(-20)

/** Applies carrom rules to a simulation outcome. Exported for tests. */
export function resolveStrike(state: CarromState, seat: number, action: CarromAction, sim: SimResult): StepResult<CarromState> {
  const own = ownKind(seat)
  const opp = ownKind(1 - seat)
  const name = state.names[seat]
  const coins = sim.coins.map((c) => ({ ...c }))
  const ownP = sim.pocketed.filter((c) => c.k === own).length
  const oppP = sim.pocketed.filter((c) => c.k === opp).length
  const queenP = sim.pocketed.some((c) => c.k === 'q')
  const priorOwn = 9 - countKind(state.coins, own)
  let queen: QueenStatus = state.queen
  let keep = false
  let foul: string | null = null
  const msgs: string[] = []
  const bits: string[] = []
  if (ownP) bits.push(`${ownP} ${kindName(own)}`)
  if (oppP) bits.push(`${oppP} ${kindName(opp)}`)
  if (queenP) bits.push('the queen')
  msgs.push(bits.length ? `${name} pocketed ${bits.join(', ')}` : `${name} pocketed nothing`)

  if (sim.strikerPocketed) {
    foul = `${name} pocketed the striker`
    for (let i = 0; i < ownP; i++) returnToCentre(coins, own)
    if (queenP) returnToCentre(coins, 'q')
    if (queen.s === 'pending' && queen.seat === seat) {
      returnToCentre(coins, 'q')
      queen = { s: 'board' }
    }
    if (priorOwn > 0) {
      returnToCentre(coins, own)
      msgs.push(`Foul: striker pocketed — one ${kindName(own)} coin returned`)
    } else {
      msgs.push('Foul: striker pocketed')
    }
  } else {
    if (queen.s === 'pending' && queen.seat === seat) {
      if (ownP > 0) {
        queen = { s: 'covered', seat }
        msgs.push(`${name} covered the queen`)
      } else {
        returnToCentre(coins, 'q')
        queen = { s: 'board' }
        msgs.push('Queen not covered — returned to the centre')
      }
    }
    if (queenP) {
      if (priorOwn === 0 && ownP === 0) {
        returnToCentre(coins, 'q')
        msgs.push('Queen returned: pocket one of your own coins first')
      } else if (ownP > 0) {
        queen = { s: 'covered', seat }
        msgs.push(`${name} pocketed and covered the queen`)
      } else {
        queen = { s: 'pending', seat }
        keep = true
        msgs.push(`${name} must cover the queen on the next strike`)
      }
    }
    if (ownP > 0) keep = true
  }

  const ownLeft = countKind(coins, own)
  const oppLeft = countKind(coins, opp)
  let winner: number | null = null
  if (ownLeft === 0 && queen.s === 'covered') {
    winner = seat
  } else {
    if (oppLeft === 0) {
      foul ??= `${name} pocketed the opponent's last coin`
      returnToCentre(coins, opp)
      keep = false
      msgs.push(`Foul: opponent's last coin returned`)
    }
    if (ownLeft === 0) {
      foul ??= `${name} pocketed their last coin before the queen was covered`
      returnToCentre(coins, own)
      keep = false
      msgs.push('Foul: last coin returned — the queen must be covered first')
    }
  }
  if (winner === null && !keep && queen.s === 'pending') {
    returnToCentre(coins, 'q')
    queen = { s: 'board' }
  }

  const n = state.n + 1
  const next: CarromState = {
    ...state,
    coins,
    pocketed: [9 - countKind(coins, 'w'), 9 - countKind(coins, 'b')],
    queen,
    turn: winner !== null ? seat : keep ? seat : 1 - seat,
    n,
    lastStrike: {
      n,
      seat,
      before: { coins: state.coins.map((c) => ({ ...c })), striker: strikerPos(seat, action.x) },
      strike: { ...action },
    },
    foul,
    log: state.log,
    over: winner !== null,
    winner,
    points: null,
  }
  if (winner !== null) {
    const points = oppLeft + (queen.s === 'covered' && queen.seat === seat ? 3 : 0)
    next.points = points
    msgs.push(`${name} wins with ${points} point${points === 1 ? '' : 's'}`)
    next.log = pushLog(state.log, ...msgs)
    return { state: next, done: true, winner, reason: `${name} pocketed all their coins` }
  }
  if (keep) msgs.push(`${name} strikes again`)
  next.log = pushLog(state.log, ...msgs)
  return { state: next, done: false, winner: null }
}

// ---------------------------------------------------------------- engine
export const carromEngine: ArenaEngine<CarromState, CarromAction> = {
  id: 'carrom',
  name: 'Carrom Board',
  turnSeconds: 30,
  init(names) {
    return {
      v: 1,
      names: [names[0], names[1]],
      coins: initialCoins(),
      pocketed: [0, 0],
      queen: { s: 'board' },
      turn: 0,
      n: 0,
      lastStrike: null,
      log: [`${names[0]} (White) breaks`],
      foul: null,
      over: false,
      winner: null,
      points: null,
    }
  },
  parseAction(raw) {
    if (!raw || typeof raw !== 'object') throw new GameRuleError('Invalid action')
    const a = raw as Record<string, unknown>
    if (a.type !== 'strike') throw new GameRuleError('Unknown action')
    const nums = [a.x, a.dx, a.dy, a.power]
    if (!nums.every((v) => typeof v === 'number' && Number.isFinite(v))) throw new GameRuleError('Invalid strike')
    const [x, dx, dy, power] = nums as number[]
    const len = Math.sqrt(dx * dx + dy * dy)
    if (!(len > 1e-9)) throw new GameRuleError('Aim direction is missing')
    return { type: 'strike', x, dx: dx / len, dy: dy / len, power: Math.min(1, Math.max(0, power)) }
  },
  apply(state, seat, action) {
    if (state.over) throw new GameRuleError('The game is over')
    if (seat !== state.turn) throw new GameRuleError("It's not your turn")
    const err = strikerPlacementError(state.coins, seat, action.x)
    if (err) throw new GameRuleError(err)
    if (!isForward(seat, action.dy)) throw new GameRuleError('You cannot strike backwards')
    const sim = simulate(state.coins, { seat, ...action })
    return resolveStrike(state, seat, action, sim)
  },
  timeout(state, seat) {
    if (state.over || seat !== state.turn) return { state, done: false, winner: null }
    const coins = state.coins.map((c) => ({ ...c }))
    let queen = state.queen
    const msgs = [`${state.names[seat]} ran out of time`]
    if (queen.s === 'pending' && queen.seat === seat) {
      returnToCentre(coins, 'q')
      queen = { s: 'board' }
      msgs.push('Queen not covered — returned to the centre')
    }
    return {
      state: { ...state, coins, queen, turn: 1 - seat, foul: null, log: pushLog(state.log, ...msgs) },
      done: false,
      winner: null,
    }
  },
  current(state) {
    return state.turn
  },
}
