/**
 * Dragon Tiger and Aviator: rules, payout maths and the provably-fair
 * derivations. Pure code shared by the server (which decides every result)
 * and the browser (which only displays results and re-verifies revealed seeds).
 *
 * Provably fair protocol (both games)
 *   1. When a round is created the server draws `serverSeed` = 32 random bytes
 *      (crypto.randomBytes, hex) and publishes `seedHash = SHA-256(serverSeed)`
 *      before any bet is accepted.
 *   2. The result is fixed by `digest = HMAC-SHA256(key = serverSeed, message = roundId)`.
 *      Nothing else (bets, balances, players) is an input.
 *   3. After the round settles the server reveals `serverSeed`. Anyone can check
 *      SHA-256(serverSeed) === seedHash and recompute the result from the digest.
 */

export type CasinoKey = 'dragon_tiger' | 'aviator'
export const CASINO_KEYS: CasinoKey[] = ['dragon_tiger', 'aviator']

export const CASINO_INFO: Record<CasinoKey, { name: string; tagline: string; path: '/app/dragon-tiger' | '/app/aviator'; prefix: string }> = {
  dragon_tiger: { name: 'Dragon Tiger', tagline: 'One card each · highest wins', path: '/app/dragon-tiger', prefix: 'DT' },
  aviator: { name: 'Aviator', tagline: 'Cash out before the plane flies away', path: '/app/aviator', prefix: 'AV' },
}

// ───────────────────────────── configuration ─────────────────────────────

interface CommonConfig {
  /** Shown in the lobby and playable. */
  enabled: boolean
  /** Maintenance pause: no new bets; open rounds still settle normally. */
  paused: boolean
  pauseMessage: string
  minBet: number
  maxBet: number
  presets: number[]
  /** Largest total return (stake + profit) one bet can receive. */
  maxPayoutPerBet: number
  /** Largest total potential return of all bets in one round. */
  maxRoundExposure: number
}

export interface DragonTigerConfig extends CommonConfig {
  /** Net-profit odds "N to 1": a winning bet returns stake + stake × N. */
  odds: { dragon: number; tiger: number; tie: number }
  /** On a tie, Dragon and Tiger bets get this % of their stake back. */
  tieRefundPercent: number
  /** Commission taken from the profit of winning bets (not from the stake). */
  feePercent: number
  bettingSeconds: number
  revealSeconds: number
}

export interface AviatorConfig extends CommonConfig {
  /** Built into the crash distribution: expected return = 100% − edge, for every cash-out target. */
  houseEdgePercent: number
  /** The plane never flies past this multiplier. */
  maxMultiplier: number
  bettingSeconds: number
  pauseSeconds: number
}

export interface CasinoConfig {
  dragon_tiger: DragonTigerConfig
  aviator: AviatorConfig
}

const PRESETS = [200, 500, 1000, 2000, 5000, 10000]
const common: CommonConfig = {
  enabled: true,
  paused: false,
  pauseMessage: 'This game is paused for maintenance. Open bets are settled normally.',
  minBet: 200,
  maxBet: 10000,
  presets: PRESETS,
  maxPayoutPerBet: 100000,
  maxRoundExposure: 2000000,
}

export const DEFAULT_CASINO: CasinoConfig = {
  dragon_tiger: { ...common, odds: { dragon: 1, tiger: 1, tie: 8 }, tieRefundPercent: 50, feePercent: 0, bettingSeconds: 15, revealSeconds: 8 },
  aviator: { ...common, houseEdgePercent: 3, maxMultiplier: 100, bettingSeconds: 8, pauseSeconds: 4 },
}

export function mergeCasino(stored: unknown): CasinoConfig {
  const s = (stored && typeof stored === 'object' ? stored : {}) as Partial<{ dragon_tiger: Partial<DragonTigerConfig>; aviator: Partial<AviatorConfig> }>
  const dt = s.dragon_tiger ?? {}
  const av = s.aviator ?? {}
  return {
    dragon_tiger: {
      ...DEFAULT_CASINO.dragon_tiger,
      ...dt,
      odds: { ...DEFAULT_CASINO.dragon_tiger.odds, ...dt.odds },
      presets: Array.isArray(dt.presets) && dt.presets.length ? dt.presets : PRESETS,
    },
    aviator: { ...DEFAULT_CASINO.aviator, ...av, presets: Array.isArray(av.presets) && av.presets.length ? av.presets : PRESETS },
  }
}

/** Returns an error message, or null when `amount` is an allowed bet. */
export function betError(cfg: CommonConfig, amount: number): string | null {
  if (!Number.isInteger(amount) || amount <= 0) return 'Bet must be a whole number of coins.'
  if (amount < cfg.minBet) return `Minimum bet is ${cfg.minBet.toLocaleString()} coins.`
  if (amount > cfg.maxBet) return `Maximum bet is ${cfg.maxBet.toLocaleString()} coins.`
  return null
}

// ───────────────────────────── shared fairness helpers ─────────────────────────────

/** Reads 4-byte unsigned words from a hex digest. */
function words(hex: string) {
  const out: number[] = []
  for (let i = 0; i + 8 <= hex.length; i += 8) out.push(parseInt(hex.slice(i, i + 8), 16))
  return out
}

/** Unbiased pick in [0, n) from the digest words (rejection sampling; falls back to modulo). */
function pick(ws: number[], start: number, n: number): [number, number] {
  const limit = Math.floor(0x1_0000_0000 / n) * n
  for (let i = start; i < ws.length; i++) if (ws[i]! < limit) return [ws[i]! % n, i + 1]
  return [ws[start % ws.length]! % n, start + 1]
}

// ───────────────────────────── Dragon Tiger ─────────────────────────────

export type DtSide = 'dragon' | 'tiger' | 'tie'
export const DT_SIDES: DtSide[] = ['dragon', 'tiger', 'tie']
export const SUITS = ['♠', '♥', '♦', '♣'] as const
export const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'] as const

/** A card is 0–51: suit = floor(c / 13), rank value = c % 13 + 1 (Ace = 1 low … King = 13 high). */
export interface Card {
  index: number
  rank: (typeof RANKS)[number]
  suit: (typeof SUITS)[number]
  value: number
  red: boolean
}
export function card(index: number): Card {
  const s = Math.floor(index / 13)
  return { index, rank: RANKS[index % 13]!, suit: SUITS[s]!, value: (index % 13) + 1, red: s === 1 || s === 2 }
}

export interface DtResult {
  dragon: number
  tiger: number
  winner: DtSide
}

/**
 * Deals from a freshly shuffled single 52-card deck: Dragon gets one card, Tiger
 * the next card from the remaining 51. Only rank decides (suits are ignored);
 * Ace is the lowest card and King the highest. Equal ranks are a Tie.
 */
export function dtDeal(digestHex: string): DtResult {
  const ws = words(digestHex)
  const [d, next] = pick(ws, 0, 52)
  const [t0] = pick(ws, next, 51)
  const t = t0 >= d ? t0 + 1 : t0
  const dv = (d % 13) + 1
  const tv = (t % 13) + 1
  return { dragon: d, tiger: t, winner: dv > tv ? 'dragon' : tv > dv ? 'tiger' : 'tie' }
}

export interface DtBetTerms {
  oddsX100: number
  tieRefundPercent: number
  feePercent: number
}

/**
 * Settles one Dragon Tiger bet. Odds are net profit ("1:1" pays 1 coin profit
 * per coin staked, so the total return is 2× the stake; "8:1" returns 9×).
 * The commission is taken from the profit only, rounded down in the player's favour.
 */
export function dtSettle(side: DtSide, stake: number, terms: DtBetTerms, winner: DtSide) {
  if (side === winner) {
    const profit = Math.floor((stake * terms.oddsX100) / 100)
    const fee = Math.floor((profit * terms.feePercent) / 100)
    return { status: 'won' as const, payout: stake + profit - fee, fee }
  }
  if (winner === 'tie' && side !== 'tie') return { status: 'push' as const, payout: Math.floor((stake * terms.tieRefundPercent) / 100), fee: 0 }
  return { status: 'lost' as const, payout: 0, fee: 0 }
}

/** Largest return a Dragon Tiger bet could receive (used for limits/exposure). */
export const dtMaxReturn = (stake: number, terms: DtBetTerms) => dtSettle('dragon', stake, terms, 'dragon').payout

// ───────────────────────────── Aviator ─────────────────────────────

/** Multiplier growth: m(t) = e^(RATE · seconds). 2× after ≈10 s, 10× after ≈33 s. */
export const AV_RATE = 0.07

/** Multiplier ×100 (floored) after `ms` of flight. */
export function avMultAt(ms: number) {
  return Math.max(100, Math.floor(100 * Math.exp((AV_RATE * Math.max(0, ms)) / 1000) + 1e-9))
}

/** Flight time (ms) until the multiplier reaches `x100`. */
export const avTimeTo = (x100: number) => Math.ceil((Math.log(Math.max(100, x100) / 100) / AV_RATE) * 1000)

/**
 * Crash point ×100 from the digest. U = (2^52 − h) / 2^52 with h = the first
 * 52 bits, so U is uniform in (0, 1]. crash = floor(100 × (1 − edge) / U) / 100,
 * which gives P(crash ≥ m) = (1 − edge) / m: every cash-out target has the same
 * expected return of (100 − edge)%. Results below 1.00× become 1.00× (an instant
 * crash) and the result is capped at the round's maximum multiplier.
 */
export function avCrash(digestHex: string, edgeBps: number, maxX100: number) {
  const E = 2n ** 52n
  const h = BigInt('0x' + digestHex.slice(0, 13))
  const x = (100n * BigInt(10000 - edgeBps) * E) / ((E - h) * 10000n)
  return Math.max(100, Math.min(maxX100, Number(x)))
}

/** Total return of an Aviator cash-out (rounded down), capped by the per-bet max payout. */
export const avPayout = (stake: number, x100: number, maxPayout: number) => Math.min(maxPayout, Math.floor((stake * x100) / 100))

/** The bet is cashed out automatically at the lowest of: the player's target, the max multiplier, the max-payout point. */
export function avEffectiveAuto(stake: number, userAutoX100: number | null, maxX100: number, maxPayout: number) {
  const payoutCap = Math.max(101, Math.floor((maxPayout * 100) / stake))
  return Math.min(userAutoX100 ?? Infinity, maxX100, payoutCap)
}

export const fmtX = (x100: number) => `${(x100 / 100).toFixed(2)}x`

// ───────────────────────────── verification (browser + server) ─────────────────────────────

const hex = (b: ArrayBuffer) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join('')

/** Recomputes SHA-256(seed) and HMAC-SHA256(seed, roundId) with Web Crypto. */
export async function fairDigests(serverSeed: string, roundId: string) {
  const enc = new TextEncoder()
  const subtle = globalThis.crypto.subtle
  const seedHash = hex(await subtle.digest('SHA-256', enc.encode(serverSeed)))
  const key = await subtle.importKey('raw', enc.encode(serverSeed), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  const digest = hex(await subtle.sign('HMAC', key, enc.encode(roundId)))
  return { seedHash, digest }
}
