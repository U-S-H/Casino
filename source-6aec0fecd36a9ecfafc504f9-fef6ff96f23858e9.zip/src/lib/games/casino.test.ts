import { createHash, createHmac, randomBytes } from 'node:crypto'
import { describe, expect, it } from 'vitest'

import { avCrash, avEffectiveAuto, avMultAt, avPayout, avTimeTo, betError, card, DEFAULT_CASINO, dtDeal, dtSettle, fairDigests, mergeCasino } from './casino'

const digest = (seed: string, id: string) => createHmac('sha256', seed).update(id).digest('hex')
const terms = (odds: number, tie = 50, fee = 0) => ({ oddsX100: odds * 100, tieRefundPercent: tie, feePercent: fee })

describe('Dragon Tiger', () => {
  it('ranks cards Ace low → King high and ignores suits', () => {
    expect(card(0)).toMatchObject({ rank: 'A', value: 1, suit: '♠' })
    expect(card(12)).toMatchObject({ rank: 'K', value: 13 })
    expect(card(13)).toMatchObject({ rank: 'A', suit: '♥', red: true })
  })

  it('deals two different cards and decides the winner by rank', () => {
    const counts = { dragon: 0, tiger: 0, tie: 0 }
    for (let i = 0; i < 20000; i++) {
      const r = dtDeal(digest(randomBytes(32).toString('hex'), `DT-${i}`))
      expect(r.dragon).not.toBe(r.tiger)
      expect(r.dragon).toBeGreaterThanOrEqual(0)
      expect(r.tiger).toBeLessThan(52)
      const d = card(r.dragon).value
      const t = card(r.tiger).value
      expect(r.winner).toBe(d > t ? 'dragon' : t > d ? 'tiger' : 'tie')
      counts[r.winner]++
    }
    // Single deck: P(tie) = 3/51 ≈ 5.9%, Dragon ≈ Tiger ≈ 47%.
    expect(counts.tie / 20000).toBeGreaterThan(0.045)
    expect(counts.tie / 20000).toBeLessThan(0.073)
    expect(Math.abs(counts.dragon - counts.tiger) / 20000).toBeLessThan(0.03)
  })

  it('is deterministic for a seed + round', () => {
    const d = digest('abc', 'DT-0000001')
    expect(dtDeal(d)).toEqual(dtDeal(d))
  })

  it('pays published odds as net profit (stake + profit)', () => {
    expect(dtSettle('dragon', 1000, terms(1), 'dragon')).toEqual({ status: 'won', payout: 2000, fee: 0 })
    expect(dtSettle('tiger', 1000, terms(1), 'tiger')).toEqual({ status: 'won', payout: 2000, fee: 0 })
    expect(dtSettle('tie', 1000, terms(8), 'tie')).toEqual({ status: 'won', payout: 9000, fee: 0 })
    expect(dtSettle('dragon', 1000, terms(1), 'tiger')).toEqual({ status: 'lost', payout: 0, fee: 0 })
    expect(dtSettle('tie', 1000, terms(8), 'dragon')).toEqual({ status: 'lost', payout: 0, fee: 0 })
  })

  it('returns the configured share on a tie and takes commission from profit only', () => {
    expect(dtSettle('dragon', 1000, terms(1, 50), 'tie')).toEqual({ status: 'push', payout: 500, fee: 0 })
    expect(dtSettle('tiger', 999, terms(1, 50), 'tie').payout).toBe(499)
    expect(dtSettle('dragon', 1000, terms(1, 0), 'tie').payout).toBe(0)
    expect(dtSettle('dragon', 1000, terms(1, 50, 5), 'dragon')).toEqual({ status: 'won', payout: 1950, fee: 50 })
  })
})

describe('Aviator', () => {
  it('multiplier starts at 1.00x and grows monotonically', () => {
    expect(avMultAt(0)).toBe(100)
    let prev = 100
    for (let t = 0; t < 60000; t += 37) {
      const m = avMultAt(t)
      expect(m).toBeGreaterThanOrEqual(prev)
      prev = m
    }
    expect(avMultAt(avTimeTo(250))).toBeGreaterThanOrEqual(250)
    expect(avMultAt(avTimeTo(250) - 20)).toBeLessThan(250)
  })

  it('crash distribution matches P(crash ≥ m) = (1 − edge)/m', () => {
    const N = 40000
    const xs = Array.from({ length: N }, (_, i) => avCrash(digest(randomBytes(32).toString('hex'), `AV-${i}`), 300, 10000))
    for (const m of [2, 5, 10]) {
      const p = xs.filter((x) => x >= m * 100).length / N
      expect(Math.abs(p - 0.97 / m)).toBeLessThan(0.012)
    }
    expect(Math.min(...xs)).toBe(100)
    expect(Math.max(...xs)).toBeLessThanOrEqual(10000)
  })

  it('crash points honour the cap and are deterministic', () => {
    const d = 'f'.repeat(13) + '0'.repeat(51) // h ≈ 2^52 → huge multiplier
    expect(avCrash(d, 300, 10000)).toBe(10000)
    expect(avCrash('0'.repeat(64), 300, 10000)).toBe(100) // 0.97x → instant crash
    const x = digest('seed', 'AV-0000009')
    expect(avCrash(x, 300, 10000)).toBe(avCrash(x, 300, 10000))
  })

  it('payout = stake × multiplier rounded down, capped by max payout', () => {
    expect(avPayout(1000, 215, 100000)).toBe(2150)
    expect(avPayout(333, 150, 100000)).toBe(499)
    expect(avPayout(10000, 5000, 100000)).toBe(100000)
    expect(avEffectiveAuto(10000, null, 10000, 100000)).toBe(1000)
    expect(avEffectiveAuto(200, 250, 10000, 100000)).toBe(250)
    expect(avEffectiveAuto(200, null, 10000, 100000)).toBe(10000)
  })
})

describe('config & limits', () => {
  it('defaults publish 200–10,000 bets and 1:1 / 1:1 / 8:1 odds', () => {
    expect(DEFAULT_CASINO.dragon_tiger.odds).toEqual({ dragon: 1, tiger: 1, tie: 8 })
    expect(betError(DEFAULT_CASINO.aviator, 199)).toMatch(/Minimum/)
    expect(betError(DEFAULT_CASINO.aviator, 10001)).toMatch(/Maximum/)
    expect(betError(DEFAULT_CASINO.aviator, 1234)).toBeNull()
    expect(betError(DEFAULT_CASINO.aviator, 12.5)).toMatch(/whole/)
    expect(mergeCasino({ aviator: { minBet: 500 } }).aviator.minBet).toBe(500)
    expect(mergeCasino(null).dragon_tiger.odds.tie).toBe(8)
  })

  it('browser verifier reproduces the server hash and digest', async () => {
    const seed = randomBytes(32).toString('hex')
    const r = await fairDigests(seed, 'AV-0000042')
    expect(r.seedHash).toBe(createHash('sha256').update(seed).digest('hex'))
    expect(r.digest).toBe(digest(seed, 'AV-0000042'))
  })
})
