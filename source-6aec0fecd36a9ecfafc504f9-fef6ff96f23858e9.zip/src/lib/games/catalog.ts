/**
 * Game catalogue shared by the browser and the server: names, match types and
 * the default coin-entry configuration. Admins override the config at runtime
 * (stored in the `settings` table under key `arena`).
 */

export type GameKey = 'ludo' | 'pool' | 'carrom' | 'chess'
export const GAME_KEYS: GameKey[] = ['ludo', 'pool', 'carrom', 'chess']

export interface MatchType {
  id: string
  label: string
  sub: string
  players: number
  /** Seconds per turn (arena games). Ludo uses the global turn timer. */
  turnSeconds?: number
  enabled: boolean
}

export interface GameConfig {
  enabled: boolean
  /** Coin-entry matches allowed for this game (free matches stay available). */
  entryEnabled: boolean
  /** Players may type any amount between min and max (otherwise presets only). */
  customAmounts: boolean
  minEntry: number
  maxEntry: number
  presets: number[]
  /** Platform fee, % of the total prize pool (0–50). */
  feePercent: number
  /** % of the net prize per finishing place, for matches with more than two sides (Ludo 4 players). */
  prizeSplit: number[]
  matchTypes: MatchType[]
}

export type ArenaConfig = Record<GameKey, GameConfig>

export const GAME_INFO: Record<GameKey, { name: string; tagline: string; accent: string }> = {
  ludo: { name: 'Ludo', tagline: 'Classic dice race · 2–4 players', accent: 'var(--ludo-red)' },
  pool: { name: '8 Ball Pool', tagline: 'Real cue physics · 1 vs 1', accent: 'var(--ludo-green)' },
  carrom: { name: 'Carrom Board', tagline: 'Flick, pocket, cover the queen', accent: 'var(--ludo-yellow)' },
  chess: { name: 'Chess', tagline: 'Full rules · checkmate to win', accent: 'var(--ludo-blue)' },
}

const PRESETS = [200, 500, 1000, 2000, 5000, 10000]
const base = { enabled: true, entryEnabled: true, customAmounts: true, minEntry: 200, maxEntry: 10000, presets: PRESETS, feePercent: 10, prizeSplit: [100] }

export const DEFAULT_ARENA: ArenaConfig = {
  ludo: {
    ...base,
    matchTypes: [
      { id: '1v1', label: '1 vs 1', sub: 'Head-to-head duel', players: 2, enabled: true },
      { id: '2v2', label: '2 vs 2', sub: 'Partner sits opposite', players: 4, enabled: true },
      { id: '4p', label: '4 Players', sub: 'Classic free-for-all', players: 4, enabled: true },
    ],
  },
  pool: {
    ...base,
    matchTypes: [
      { id: 'classic', label: 'Classic', sub: '45 s shot clock', players: 2, turnSeconds: 45, enabled: true },
      { id: 'quick', label: 'Quick fire', sub: '20 s shot clock', players: 2, turnSeconds: 20, enabled: true },
    ],
  },
  carrom: {
    ...base,
    matchTypes: [
      { id: 'classic', label: 'Classic', sub: '30 s per strike', players: 2, turnSeconds: 30, enabled: true },
      { id: 'quick', label: 'Quick fire', sub: '15 s per strike', players: 2, turnSeconds: 15, enabled: true },
    ],
  },
  chess: {
    ...base,
    matchTypes: [
      { id: 'rapid', label: 'Rapid', sub: '2 min per move', players: 2, turnSeconds: 120, enabled: true },
      { id: 'blitz', label: 'Blitz', sub: '30 s per move', players: 2, turnSeconds: 30, enabled: true },
    ],
  },
}

/** Merges a stored (possibly partial / older) config over the defaults. */
export function mergeArena(stored: unknown): ArenaConfig {
  const s = (stored && typeof stored === 'object' ? stored : {}) as Partial<Record<GameKey, Partial<GameConfig>>>
  const out = {} as ArenaConfig
  for (const k of GAME_KEYS) {
    const d = DEFAULT_ARENA[k]
    const v = s[k] ?? {}
    out[k] = {
      ...d,
      ...v,
      presets: Array.isArray(v.presets) && v.presets.length ? v.presets : d.presets,
      prizeSplit: Array.isArray(v.prizeSplit) && v.prizeSplit.length ? v.prizeSplit : d.prizeSplit,
      // Match types are fixed per game; only labels/enabled/turn seconds are configurable.
      matchTypes: d.matchTypes.map((mt) => ({ ...mt, ...(v.matchTypes ?? []).find((x) => x.id === mt.id), id: mt.id, players: mt.players })),
    }
  }
  return out
}

/** Prize maths shared by UI and server. Fee is rounded down so players never pay more than the stated %. */
export function prizeMath(entry: number, players: number, feePercent: number) {
  const pool = entry * players
  const fee = Math.floor((pool * feePercent) / 100)
  return { pool, fee, prize: pool - fee }
}

/** Returns an error message, or null when `amount` is an allowed entry for this game. 0 = free match. */
export function entryError(cfg: GameConfig, amount: number): string | null {
  if (!Number.isInteger(amount) || amount < 0) return 'Entry must be a whole number of coins.'
  if (amount === 0) return null
  if (!cfg.entryEnabled) return 'Coin-entry matches are turned off for this game right now.'
  if (amount < cfg.minEntry) return `Minimum entry is ${cfg.minEntry.toLocaleString()} coins.`
  if (amount > cfg.maxEntry) return `Maximum entry is ${cfg.maxEntry.toLocaleString()} coins.`
  if (!cfg.customAmounts && !cfg.presets.includes(amount)) return 'Pick one of the listed entry amounts.'
  return null
}

/**
 * Splits the net prize across ranked places. `places` is the number of
 * eligible sides in finishing order; unused percentages roll to 1st place so
 * the full prize is always paid out.
 */
export function splitPrize(prize: number, split: number[], places: number) {
  const pct = split.slice(0, Math.max(1, places))
  const total = pct.reduce((a, b) => a + b, 0) || 100
  const shares = pct.map((p) => Math.floor((prize * p) / total))
  shares[0] += prize - shares.reduce((a, b) => a + b, 0)
  return shares
}
