import { createFileRoute } from '@tanstack/react-router'
import { Headset, Mail, MessageCircle } from 'lucide-react'

import { PageHeader, Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { fmtDate, useAction, useApp, useServer } from '@/lib/client'
import { createTicket, listMyTickets } from '@/server/social.functions'

export const Route = createFileRoute('/app/support')({
  head: () => ({ meta: [{ title: 'Support · Ludo King Arena' }] }),
  component: Support,
})

const CATS = ['deposit', 'withdrawal', 'game', 'account', 'referral', 'general'] as const

function Support() {
  const { settings } = useApp()
  const tickets = useServer(() => listMyTickets())
  const { pending, run } = useAction()
  return (
    <div className="space-y-6">
      <PageHeader title="Customer support" subtitle={`We usually reply within a few hours · ${settings.support.hours}`} />
      <div className="grid gap-6 lg:grid-cols-[1fr_20rem]">
        <Panel>
          <h2 className="mb-3 flex items-center gap-2 font-bold">
            <Headset className="size-5 text-primary" /> Open a ticket
          </h2>
          <form
            className="space-y-3"
            onSubmit={async (e) => {
              e.preventDefault()
              const form = e.currentTarget
              const fd = new FormData(form)
              const r = await run(
                () =>
                  createTicket({
                    data: { subject: String(fd.get('subject')), message: String(fd.get('message')), category: fd.get('category') as (typeof CATS)[number] },
                  }),
                (x) => `Ticket ${x.id} created`,
              )
              if (r) {
                form.reset()
                void tickets.reload()
              }
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="category">Topic</Label>
              <select id="category" name="category" className="h-9 w-full rounded-md border bg-transparent px-3 text-sm capitalize">
                {CATS.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="subject">Subject</Label>
              <Input id="subject" name="subject" required minLength={4} maxLength={120} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" name="message" required minLength={10} maxLength={2000} rows={5} placeholder="Include deposit IDs or TIDs if relevant." />
            </div>
            <Button type="submit" disabled={pending}>
              Submit ticket
            </Button>
          </form>
        </Panel>
        <div className="space-y-4">
          <Panel>
            <h3 className="font-bold">Other ways to reach us</h3>
            <ul className="mt-2 space-y-2 text-sm">
              {settings.support.email && (
                <li className="flex items-center gap-2">
                  <Mail className="size-4 text-primary" />
                  <a href={`mailto:${settings.support.email}`} className="hover:underline">
                    {settings.support.email}
                  </a>
                </li>
              )}
              {settings.support.whatsapp && (
                <li className="flex items-center gap-2">
                  <MessageCircle className="size-4 text-ludo-green" />
                  <a href={`https://wa.me/${settings.support.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noreferrer" className="hover:underline">
                    WhatsApp {settings.support.whatsapp}
                  </a>
                </li>
              )}
            </ul>
          </Panel>
        </div>
      </div>
      <Panel>
        <h2 className="mb-2 font-bold">My tickets</h2>
        {tickets.data?.length === 0 && <p className="text-sm text-muted-foreground">No tickets yet.</p>}
        <ul className="divide-y divide-white/5 text-sm">
          {tickets.data?.map((t) => (
            <li key={t.id} className="py-3">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold">
                  {t.subject} <span className="text-xs text-muted-foreground">· {t.id}</span>
                </span>
                <StatusBadge status={t.status} />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">{t.message}</p>
              {t.adminReply && <p className="mt-2 rounded-lg bg-primary/10 p-2 text-xs">Support: {t.adminReply}</p>}
              <p className="mt-1 text-[11px] text-muted-foreground">{fmtDate(t.createdAt)}</p>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  )
}
