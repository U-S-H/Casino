import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowDownLeft, ArrowUpRight, Gift, ShieldCheck, UserPlus } from 'lucide-react'

import { Coins, PageHeader, Panel } from '@/components/brand'
import { StatusBadge, TxList } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { fmtDate, METHOD_LABEL, useApp, useServer } from '@/lib/client'
import { getWallet } from '@/server/account.functions'
import { listMyDeposits, listMyWithdrawals, listTransactions } from '@/server/wallet.functions'

export const Route = createFileRoute('/app/wallet')({
  head: () => ({ meta: [{ title: 'Wallet · Ludo King Arena' }] }),
  component: WalletScreen,
})

function WalletScreen() {
  const app = useApp()
  const live = useServer(() => getWallet(), [], 20_000)
  const wallet = live.data ?? app.wallet
  const coinPackages = app.settings.coinPackages
  const txs = useServer(() => listTransactions({ data: { limit: 8 } }))
  const deps = useServer(() => listMyDeposits(), [], 30_000)
  const wds = useServer(() => listMyWithdrawals())
  return (
    <div className="space-y-6">
      <PageHeader title="Wallet" subtitle="Your coins, packages and rewards in one place." />

      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent/70 via-card to-primary/30 p-6 ring-1 ring-white/10 md:p-8">
        <div className="absolute -top-10 -right-10 size-48 rounded-full bg-primary/20 blur-3xl" />
        <div className="text-sm font-semibold text-muted-foreground">Available coins</div>
        <div className="mt-1 font-display text-5xl font-extrabold">
          <Coins value={wallet.available} />
        </div>
        <div className="mt-6 grid grid-cols-3 gap-3 text-sm">
          {[
            ['Purchased', wallet.purchased],
            ['Bonus', wallet.bonus],
            ['Winnings', wallet.winnings],
          ].map(([l, v]) => (
            <div key={l} className="rounded-xl bg-black/20 p-3">
              <div className="text-xs text-muted-foreground">{l}</div>
              <div className="mt-0.5 font-bold tabular-nums">{(v as number).toLocaleString()}</div>
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild className="rounded-full font-bold">
            <Link to="/app/deposit">
              <ArrowDownLeft /> Buy coins
            </Link>
          </Button>
          <Button asChild variant="outline" className="rounded-full font-bold">
            <Link to="/app/withdraw">
              <ArrowUpRight /> Withdraw
            </Link>
          </Button>
        </div>
      </div>

      <section>
        <h2 className="mb-3 text-lg font-bold">Coin packages</h2>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          {coinPackages.map((p) => (
            <Link
              key={p.id}
              to="/app/deposit"
              search={{ pkg: p.id }}
              className="glass relative rounded-2xl p-4 text-center transition hover:-translate-y-1 hover:ring-1 hover:ring-primary/50"
            >
              {p.tag && (
                <span className="absolute -top-2 left-1/2 -translate-x-1/2 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-primary-foreground">
                  {p.tag}
                </span>
              )}
              <span className="coin mt-2 text-4xl" />
              <div className="mt-2 font-display text-xl font-extrabold">{p.coins.toLocaleString()}</div>
              {p.bonus > 0 && <div className="text-xs font-semibold text-ludo-green">+{p.bonus} bonus</div>}
              <div className="mt-3 rounded-lg bg-white/5 py-1.5 text-sm font-bold">Rs {p.price}</div>
            </Link>
          ))}
        </div>
      </section>

      <Panel>
        <Tabs defaultValue="deposits">
          <TabsList>
            <TabsTrigger value="deposits">Deposit history</TabsTrigger>
            <TabsTrigger value="withdrawals">Withdrawal history</TabsTrigger>
          </TabsList>
          <TabsContent value="deposits" className="mt-3">
            {deps.data?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No deposit requests yet.</p>}
            <ul className="divide-y divide-white/5">
              {deps.data?.map((d) => (
                <li key={d.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold">
                      {d.packageName} · Rs {d.amountPkr} via {METHOD_LABEL[d.method]}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {d.id} · TID {d.tid} · {fmtDate(d.createdAt)}
                    </div>
                    {d.adminNote && <div className="mt-0.5 text-xs text-muted-foreground">Note: {d.adminNote}</div>}
                  </div>
                  <Coins value={d.coins + d.bonusCoins} />
                  <StatusBadge status={d.status} />
                </li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent value="withdrawals" className="mt-3">
            {wds.data?.length === 0 && <p className="py-4 text-sm text-muted-foreground">No withdrawal requests yet.</p>}
            <ul className="divide-y divide-white/5">
              {wds.data?.map((w) => (
                <li key={w.id} className="flex items-center gap-3 py-3 text-sm">
                  <div className="flex-1">
                    <div className="font-semibold">
                      {w.coins} coins → {METHOD_LABEL[w.method]} {w.accountNumber}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {w.id} · {fmtDate(w.createdAt)}
                      {w.paymentReference && ` · Ref ${w.paymentReference}`}
                    </div>
                  </div>
                  <StatusBadge status={w.status} />
                </li>
              ))}
            </ul>
          </TabsContent>
        </Tabs>
      </Panel>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-lg font-bold">Recent activity</h2>
            <Link to="/app/transactions" className="text-xs font-semibold text-primary">
              Full history
            </Link>
          </div>
          <TxList items={txs.data ?? []} />
        </Panel>
        <div className="space-y-4">
          <Panel>
            <Gift className="size-6 text-primary" />
            <h3 className="mt-2 font-bold">Daily rewards</h3>
            <p className="text-sm text-muted-foreground">{app.me.dailyStreak ? `Day ${app.me.dailyStreak} streak — ` : ''}keep logging in for bigger rewards.</p>
            <Button asChild variant="secondary" size="sm" className="mt-3">
              <Link to="/app">Claim today</Link>
            </Button>
          </Panel>
          <Panel>
            <UserPlus className="size-6 text-primary" />
            <h3 className="mt-2 font-bold">Invite & earn</h3>
            <p className="text-sm text-muted-foreground">{app.settings.referral.enabled ? `Get ${app.settings.referral.referrerReward} coins for every friend who plays ${app.settings.referral.qualifyGames} games.` : 'Referral rewards are paused right now.'}</p>
            <Button asChild variant="secondary" size="sm" className="mt-3">
              <Link to="/app/referrals">
                Your referral link
              </Link>
            </Button>
          </Panel>
          <div className="flex gap-3 rounded-2xl bg-ludo-green/10 p-4 text-xs text-muted-foreground ring-1 ring-ludo-green/30">
            <ShieldCheck className="size-5 shrink-0 text-ludo-green" />
            Balances are calculated on our servers. Every credit has a unique transaction ID and is checked against duplicates.
          </div>
        </div>
      </div>
    </div>
  )
}
