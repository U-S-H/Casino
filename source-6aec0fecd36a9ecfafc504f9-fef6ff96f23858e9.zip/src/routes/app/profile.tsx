import { updateUser } from '@netlify/identity'
import { createFileRoute } from '@tanstack/react-router'
import { useRef, useState } from 'react'
import { BadgeCheck, Camera, Copy, IdCard, KeyRound, LogOut, Monitor, Settings, ShieldCheck, Timer, Trophy } from 'lucide-react'
import { toast } from 'sonner'

import { authErrorMessage, signOut } from '@/components/auth/auth-helpers'
import { Avatar, PageHeader, Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { errMsg, fmtDate, initialsOf, useAction, useApp, useServer } from '@/lib/client'
import { cn } from '@/lib/utils'
import { getLoginHistory, markPasswordChanged, setResponsibleGaming, submitKyc, updateProfile, uploadAvatar } from '@/server/account.functions'
import { getGameHistory } from '@/server/social.functions'
import { myTournamentHistory } from '@/server/tournament.functions'

export const Route = createFileRoute('/app/profile')({
  head: () => ({ meta: [{ title: 'Profile · Ludo King Arena' }] }),
  component: Profile,
})

function Profile() {
  const { me, refresh } = useApp()
  const logins = useServer(() => getLoginHistory())
  const games = useServer(() => getGameHistory())
  const tours = useServer(() => myTournamentHistory())
  const [uploading, setUploading] = useState(false)
  const winRate = me.gamesPlayed ? Math.round((me.gamesWon / me.gamesPlayed) * 100) : 0

  return (
    <div className="space-y-6">
      <PageHeader title="Profile" />

      <Panel className="flex flex-col items-center gap-5 sm:flex-row">
        <label className={cn('group relative cursor-pointer', uploading && 'opacity-60')}>
          <Avatar initials={initialsOf(me.displayName)} src={me.avatarUrl} className="size-24 font-display text-3xl ring-4 ring-primary" />
          <span className="absolute right-0 bottom-0 grid size-8 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg">
            <Camera className="size-4" />
          </span>
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="sr-only"
            disabled={uploading}
            onChange={async (e) => {
              const f = e.target.files?.[0]
              if (!f) return
              if (f.size > 2 * 1024 * 1024) return toast.error('Image must be under 2 MB')
              const fd = new FormData()
              fd.set('file', f)
              setUploading(true)
              try {
                await uploadAvatar({ data: fd })
                toast.success('Profile picture updated')
                await refresh()
              } catch (err) {
                toast.error(errMsg(err))
              } finally {
                setUploading(false)
              }
            }}
          />
        </label>
        <div className="flex-1 text-center sm:text-left">
          <h2 className="flex items-center justify-center gap-2 text-2xl font-extrabold sm:justify-start">
            {me.displayName}
            {me.kycStatus === 'verified' && <BadgeCheck className="size-5 text-ludo-blue" />}
          </h2>
          <p className="text-sm text-muted-foreground">{me.email}</p>
          <button
            onClick={() => {
              void navigator.clipboard?.writeText(me.publicId)
              toast.success('Player ID copied')
            }}
            className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 font-mono text-xs ring-1 ring-white/10"
          >
            ID {me.publicId} <Copy className="size-3" />
          </button>
        </div>
        <div className="text-center">
          <div className="font-display text-3xl font-extrabold text-primary">{me.rating}</div>
          <div className="text-xs text-muted-foreground">Rating · joined {fmtDate(me.createdAt, false)}</div>
        </div>
      </Panel>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          ['Games', me.gamesPlayed],
          ['Wins', me.gamesWon],
          ['Win rate', `${winRate}%`],
          ['Daily streak', me.dailyStreak],
        ].map(([l, v]) => (
          <Panel key={l} className="p-4 text-center">
            <div className="font-display text-2xl font-extrabold">{v}</div>
            <div className="text-xs text-muted-foreground">{l}</div>
          </Panel>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <AccountSettings />
        <PasswordPanel />
        <KycPanel />
        <ResponsiblePanel />

        <Panel>
          <h2 className="mb-2 font-bold">Game history</h2>
          {games.data?.length === 0 && <p className="text-sm text-muted-foreground">No online games yet.</p>}
          <ul className="max-h-72 divide-y divide-white/5 overflow-y-auto text-sm">
            {games.data?.map((g) => (
              <li key={g.id} className="flex justify-between py-2">
                <span>
                  {g.mode} · <span className={g.won ? 'text-ludo-green' : 'text-ludo-red'}>{g.won ? 'Won' : 'Lost'}</span>
                  <span className="block text-xs text-muted-foreground">vs {g.opponents || '—'}</span>
                </span>
                <span className="text-right text-xs text-muted-foreground">
                  {g.ratingDelta > 0 ? '+' : ''}
                  {g.ratingDelta} RP
                  <span className="block">{fmtDate(g.endedAt)}</span>
                </span>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel>
          <h2 className="mb-2 flex items-center gap-2 font-bold">
            <Trophy className="size-5 text-primary" /> Tournament history
          </h2>
          {tours.data?.length === 0 && <p className="text-sm text-muted-foreground">You haven’t joined a tournament yet.</p>}
          <ul className="max-h-72 divide-y divide-white/5 overflow-y-auto text-sm">
            {tours.data?.map((t) => (
              <li key={t.id} className="flex justify-between py-2">
                <span>
                  {t.name}
                  <span className="block text-xs text-muted-foreground">
                    {t.points} pts · {t.wins}/{t.games} wins · {t.status}
                  </span>
                </span>
                <span className="text-right text-xs">
                  {t.rank ? `#${t.rank}` : '—'}
                  {t.prize > 0 && <span className="block text-primary">+{t.prize}</span>}
                </span>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel className="lg:col-span-2">
          <h2 className="flex items-center gap-2 font-bold">
            <ShieldCheck className="size-5 text-primary" /> Sessions & login history
          </h2>
          <ul className="mt-3 grid gap-3 text-sm sm:grid-cols-2">
            {logins.data?.map((l, i) => (
              <li key={l.id} className="flex items-center gap-3">
                <Monitor className="size-4 shrink-0 text-muted-foreground" />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold">
                    {describeAgent(l.userAgent)} {i === 0 && <span className="ml-1 rounded bg-primary/20 px-1.5 text-[10px] text-primary">Latest</span>}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {[l.city, l.country].filter(Boolean).join(', ') || 'Unknown location'} · {fmtDate(l.createdAt)}
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <Button variant="outline" className="mt-4" onClick={signOut}>
            <LogOut /> Sign out of this device
          </Button>
          <p className="mt-2 text-xs text-muted-foreground">Changing your password signs out sessions on other devices when their tokens next refresh.</p>
        </Panel>
      </div>
    </div>
  )
}

function describeAgent(ua: string | null) {
  if (!ua) return 'Unknown device'
  const browser = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : 'Browser'
  const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : ''
  return `${browser}${os ? ` · ${os}` : ''}`
}

function AccountSettings() {
  const { me, refresh } = useApp()
  const { pending, run } = useAction()
  return (
    <Panel>
      <h2 className="flex items-center gap-2 font-bold">
        <Settings className="size-5 text-primary" /> Account settings
      </h2>
      <form
        className="mt-3 space-y-3"
        onSubmit={async (e) => {
          e.preventDefault()
          const fd = new FormData(e.currentTarget)
          const dob = String(fd.get('dob') || '')
          const r = await run(() => updateProfile({ data: { displayName: String(fd.get('name')), dateOfBirth: dob || undefined } }), 'Profile saved')
          if (r) await refresh()
        }}
      >
        <div className="space-y-1.5">
          <Label htmlFor="name">Username</Label>
          <Input id="name" name="name" defaultValue={me.displayName} minLength={3} maxLength={24} required />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="dob">Date of birth (age verification, 18+)</Label>
          <Input id="dob" name="dob" type="date" defaultValue={me.dateOfBirth ?? ''} disabled={!!me.dateOfBirth} />
          {me.ageConfirmed && <p className="text-xs text-ludo-green">Age confirmed</p>}
        </div>
        <Button type="submit" disabled={pending} size="sm">
          Save
        </Button>
      </form>
    </Panel>
  )
}

function PasswordPanel() {
  const { me } = useApp()
  const [pending, setPending] = useState(false)
  const form = useRef<HTMLFormElement>(null)
  return (
    <Panel>
      <h2 className="flex items-center gap-2 font-bold">
        <KeyRound className="size-5 text-primary" /> Change password
      </h2>
      {me.isAdmin && !me.passwordChangedAt && (
        <p className="mt-2 rounded-lg bg-ludo-yellow/10 p-2 text-xs text-ludo-yellow">First admin login: please set a new password now.</p>
      )}
      <form
        ref={form}
        className="mt-3 space-y-3"
        onSubmit={async (e) => {
          e.preventDefault()
          const fd = new FormData(e.currentTarget)
          const pw = String(fd.get('pw'))
          if (pw !== String(fd.get('pw2'))) return toast.error('Passwords do not match.')
          setPending(true)
          try {
            await updateUser({ password: pw })
            await markPasswordChanged()
            toast.success('Password updated')
            form.current?.reset()
          } catch (err) {
            toast.error(authErrorMessage(err))
          } finally {
            setPending(false)
          }
        }}
      >
        <Input name="pw" type="password" minLength={8} required placeholder="New password" autoComplete="new-password" />
        <Input name="pw2" type="password" minLength={8} required placeholder="Confirm new password" autoComplete="new-password" />
        <Button type="submit" size="sm" disabled={pending}>
          Update password
        </Button>
      </form>
      <p className="mt-2 text-xs text-muted-foreground">Signed in with Google? Use “Forgot password” on the login page to add a password.</p>
    </Panel>
  )
}

function KycPanel() {
  const { me, refresh } = useApp()
  const [pending, setPending] = useState(false)
  return (
    <Panel>
      <h2 className="flex items-center justify-between gap-2 font-bold">
        <span className="flex items-center gap-2">
          <IdCard className="size-5 text-primary" /> Identity verification (KYC)
        </span>
        <StatusBadge status={me.kycStatus.replace('not_started', 'not started')} />
      </h2>
      {me.kycStatus === 'verified' || me.kycStatus === 'pending' ? (
        <p className="mt-3 text-sm text-muted-foreground">
          {me.kycStatus === 'verified' ? 'Your identity is verified.' : 'Your documents are being reviewed (usually within 24 hours).'}
        </p>
      ) : (
        <form
          className="mt-3 space-y-3"
          onSubmit={async (e) => {
            e.preventDefault()
            setPending(true)
            try {
              await submitKyc({ data: new FormData(e.currentTarget) })
              toast.success('KYC submitted for review')
              await refresh()
            } catch (err) {
              toast.error(errMsg(err))
            } finally {
              setPending(false)
            }
          }}
        >
          <Input name="fullName" required minLength={3} placeholder="Full name as on CNIC" />
          <Input name="cnic" required placeholder="CNIC 12345-1234567-1" />
          <Input name="file" type="file" required accept="image/png,image/jpeg,image/webp" />
          <Button type="submit" size="sm" disabled={pending}>
            Submit for review
          </Button>
          <p className="text-xs text-muted-foreground">Documents are stored privately and only visible to administrators. Required before your first withdrawal.</p>
        </form>
      )}
    </Panel>
  )
}

function ResponsiblePanel() {
  const { me, refresh } = useApp()
  const { pending, run } = useAction()
  const excluded = me.selfExcludedUntil && new Date(me.selfExcludedUntil) > new Date()
  return (
    <Panel>
      <h2 className="flex items-center gap-2 font-bold">
        <Timer className="size-5 text-primary" /> Responsible play
      </h2>
      <form
        className="mt-3 space-y-3 text-sm"
        onSubmit={async (e) => {
          e.preventDefault()
          const fd = new FormData(e.currentTarget)
          const limit = Number(fd.get('limit') || 0)
          const days = Number(fd.get('days') || 0)
          if (days && !confirm(`Pause deposits and play for ${days} days? This cannot be undone early.`)) return
          const r = await run(() => setResponsibleGaming({ data: { dailyDepositLimitPkr: limit || null, selfExcludeDays: days || undefined } }), 'Saved')
          if (r) await refresh()
        }}
      >
        <div className="space-y-1.5">
          <Label htmlFor="limit">Personal daily deposit limit (Rs, 0 = none)</Label>
          <Input id="limit" name="limit" type="number" min={0} defaultValue={me.dailyDepositLimitPkr ?? 0} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="days">Take a break (self-exclusion)</Label>
          <select id="days" name="days" className="h-9 w-full rounded-md border bg-transparent px-3 text-sm" defaultValue="0">
            <option value="0">No break</option>
            <option value="1">24 hours</option>
            <option value="7">7 days</option>
            <option value="30">30 days</option>
            <option value="180">6 months</option>
          </select>
          {excluded && <p className="text-xs text-ludo-yellow">Self-excluded until {fmtDate(me.selfExcludedUntil)}</p>}
        </div>
        <Button type="submit" size="sm" disabled={pending}>
          Save limits
        </Button>
      </form>
    </Panel>
  )
}
