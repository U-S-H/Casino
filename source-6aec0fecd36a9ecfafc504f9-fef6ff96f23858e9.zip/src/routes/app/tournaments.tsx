import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { CalendarDays, Copy, KeyRound, Lock, Medal, Plus, Timer, Trophy, Users } from 'lucide-react'
import { toast } from 'sonner'

import { Coins, PageHeader, Panel } from '@/components/brand'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { fmtDate, useAction, useServer } from '@/lib/client'
import { cn } from '@/lib/utils'
import { createPrivateTournament, getStandings, joinTournament, listTournaments, myTournamentHistory } from '@/server/tournament.functions'

export const Route = createFileRoute('/app/tournaments')({
  head: () => ({ meta: [{ title: 'Tournaments · Ludo King Arena' }] }),
  component: Tournaments,
})

type Kind = 'daily' | 'weekly' | 'private'
type T = Awaited<ReturnType<typeof listTournaments>>[number]

function TournamentCard({ t, onJoin, onView, busy }: { t: T; onJoin: () => void; onView: () => void; busy: boolean }) {
  const full = t.players >= t.capacity
  return (
    <Panel className="flex flex-col">
      <div className="flex items-start justify-between">
        <div className="grid size-11 place-items-center rounded-xl bg-primary/15">
          {t.kind === 'private' ? <Lock className="size-5 text-primary" /> : <Trophy className="size-5 text-primary" />}
        </div>
        {t.status === 'live' ? (
          <Badge className="bg-ludo-red text-white">● Live</Badge>
        ) : (
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Timer className="size-3" /> {fmtDate(t.startsAt)}
          </span>
        )}
      </div>
      <h3 className="mt-3 text-lg font-bold">{t.name}</h3>
      <div className="mt-1 flex flex-wrap gap-3 text-xs text-muted-foreground">
        <span>{t.mode === '4p' ? '4-player' : t.mode}</span>
        <span className="flex items-center gap-1">
          <Users className="size-3" /> {t.players}/{t.capacity}
        </span>
        <span>Ends {fmtDate(t.endsAt)}</span>
      </div>
      <Progress value={(t.players / t.capacity) * 100} className="mt-3 h-1.5" />
      <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
        <div className="rounded-lg bg-white/5 p-2">
          <div className="text-[11px] text-muted-foreground">Prize pool (bonus coins)</div>
          <Coins value={t.prizeCoins} className="text-primary" />
        </div>
        <div className="rounded-lg bg-white/5 p-2">
          <div className="text-[11px] text-muted-foreground">Entry</div>
          <span className="font-bold text-ludo-green">Free</span>
        </div>
      </div>
      {t.inviteCode && (
        <button
          onClick={() => {
            void navigator.clipboard?.writeText(t.inviteCode!)
            toast.success('Invite code copied')
          }}
          className="mt-3 flex items-center justify-center gap-2 rounded-lg bg-white/5 py-2 font-mono text-sm"
        >
          Invite code {t.inviteCode} <Copy className="size-3" />
        </button>
      )}
      <div className="mt-4 grid grid-cols-2 gap-2">
        <Button className="font-bold" variant={t.joined ? 'secondary' : 'default'} disabled={t.joined || full || busy} onClick={onJoin}>
          {t.joined ? 'Joined ✓' : full ? 'Full' : 'Join'}
        </Button>
        <Button variant="outline" onClick={onView}>
          Standings
        </Button>
      </div>
    </Panel>
  )
}

function Tournaments() {
  const list = useServer(() => listTournaments(), [], 60_000)
  const history = useServer(() => myTournamentHistory())
  const { pending, run } = useAction()
  const [view, setView] = useState<string | null>(null)
  const [create, setCreate] = useState(false)

  const viewId = view ?? list.data?.find((t) => t.joined)?.id ?? list.data?.[0]?.id ?? null

  const join = async (id: string, name: string) => {
    const r = await run(() => joinTournament({ data: { id } }), `Joined ${name}. Play online ${'matches'} to earn points!`)
    if (r) void list.reload()
  }

  const grid = (kind: Kind) => {
    const items = list.data?.filter((t) => t.kind === kind) ?? []
    return (
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.loading && !list.data && <p className="text-sm text-muted-foreground">Loading…</p>}
        {items.map((t) => (
          <TournamentCard key={t.id} t={t} busy={pending} onJoin={() => join(t.id, t.name)} onView={() => setView(t.id)} />
        ))}
        {kind === 'private' && (
          <>
            <button
              onClick={() => setCreate(true)}
              className="grid min-h-64 place-items-center rounded-2xl border-2 border-dashed border-white/15 text-muted-foreground hover:border-primary/50 hover:text-foreground"
            >
              <span className="flex flex-col items-center gap-2 font-semibold">
                <Plus className="size-8" /> Create private tournament
              </span>
            </button>
            <Panel>
              <h3 className="flex items-center gap-2 font-bold">
                <KeyRound className="size-4 text-primary" /> Join with invite code
              </h3>
              <form
                className="mt-3 flex gap-2"
                onSubmit={async (e) => {
                  e.preventDefault()
                  const code = String(new FormData(e.currentTarget).get('code'))
                  const r = await run(() => joinTournament({ data: { inviteCode: code } }), (x) => `Joined ${x.name}`)
                  if (r) void list.reload()
                }}
              >
                <Input name="code" required minLength={4} placeholder="CODE" className="uppercase" />
                <Button type="submit" disabled={pending}>
                  Join
                </Button>
              </form>
            </Panel>
          </>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Tournaments"
        subtitle="Free-play competitions. Every online match you play in a joined tournament's mode scores points (win 3, play 1). Results settle automatically."
      />
      <Tabs defaultValue="daily">
        <TabsList>
          <TabsTrigger value="daily">
            <CalendarDays className="size-4" /> Daily
          </TabsTrigger>
          <TabsTrigger value="weekly">
            <Trophy className="size-4" /> Weekly
          </TabsTrigger>
          <TabsTrigger value="private">
            <Lock className="size-4" /> Private
          </TabsTrigger>
        </TabsList>
        <TabsContent value="daily" className="mt-4">
          {grid('daily')}
        </TabsContent>
        <TabsContent value="weekly" className="mt-4">
          {grid('weekly')}
        </TabsContent>
        <TabsContent value="private" className="mt-4">
          {grid('private')}
        </TabsContent>
      </Tabs>

      <div className="grid gap-6 lg:grid-cols-2">
        {viewId ? <Standings id={viewId} /> : <Panel>No tournaments yet.</Panel>}
        <Panel>
          <h2 className="mb-3 font-bold">Your tournament history</h2>
          {history.data?.length === 0 && <p className="text-sm text-muted-foreground">Join a tournament above to start ranking.</p>}
          <ul className="divide-y divide-white/5 text-sm">
            {history.data?.map((h) => (
              <li key={h.id} className="flex items-center justify-between py-2.5">
                <div>
                  <div className="font-semibold">{h.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {h.points} pts · {h.status} {h.rank ? `· #${h.rank}` : ''}
                  </div>
                </div>
                {h.prize ? <Coins value={h.prize} className="text-ludo-green" /> : <span className="text-muted-foreground">—</span>}
              </li>
            ))}
          </ul>
          <Button asChild variant="secondary" className="mt-3 w-full">
            <Link to="/app/play">Play a match</Link>
          </Button>
        </Panel>
      </div>

      <CreateDialog
        open={create}
        onOpenChange={setCreate}
        onCreated={() => {
          setCreate(false)
          void list.reload()
        }}
      />
    </div>
  )
}

function Standings({ id }: { id: string }) {
  const { data } = useServer(() => getStandings({ data: { id } }), [id], 30_000)
  return (
    <Panel>
      <h2 className="mb-3 flex items-center gap-2 font-bold">
        <Medal className="size-5 text-primary" /> {data?.name ?? 'Standings'}
      </h2>
      {data?.rows.length === 0 && <p className="text-sm text-muted-foreground">No players yet.</p>}
      <ol className="max-h-80 divide-y divide-white/5 overflow-y-auto text-sm">
        {data?.rows.map((p) => (
          <li key={p.userId} className={cn('flex items-center gap-3 py-2.5', p.me && 'text-primary')}>
            <span className="w-6 text-center font-display font-extrabold text-muted-foreground">{p.rank}</span>
            <span className="flex-1 font-semibold">{p.name}</span>
            <span className="text-xs text-muted-foreground">
              {p.wins}W/{p.games}
            </span>
            <span className="tabular-nums">{p.points} pts</span>
          </li>
        ))}
      </ol>
    </Panel>
  )
}

function CreateDialog({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: () => void }) {
  const { pending, run } = useAction()
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a private tournament</DialogTitle>
        </DialogHeader>
        <form
          className="space-y-3"
          onSubmit={async (e) => {
            e.preventDefault()
            const fd = new FormData(e.currentTarget)
            const r = await run(
              () => createPrivateTournament({ data: { name: String(fd.get('name')), mode: fd.get('mode') as '1v1' | '2v2' | '4p', hours: Number(fd.get('hours')) } }),
              (x) => `Created! Invite code ${x.inviteCode}`,
            )
            if (r) onCreated()
          }}
        >
          <Input name="name" required minLength={3} maxLength={40} placeholder="Tournament name" />
          <select name="mode" className="h-9 w-full rounded-md border bg-transparent px-3 text-sm">
            <option value="4p">4 players</option>
            <option value="2v2">2 vs 2</option>
            <option value="1v1">1 vs 1</option>
          </select>
          <select name="hours" className="h-9 w-full rounded-md border bg-transparent px-3 text-sm" defaultValue="24">
            <option value="3">3 hours</option>
            <option value="24">24 hours</option>
            <option value="72">3 days</option>
            <option value="168">7 days</option>
          </select>
          <Button type="submit" disabled={pending} className="w-full">
            Create
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
