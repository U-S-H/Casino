import { Link, createFileRoute } from '@tanstack/react-router'
import { Check, Crown, Gift, Headset, Lock, Megaphone, Swords, Trophy, Users } from 'lucide-react'

import { Avatar, Coins, Panel } from '@/components/brand'
import { GameCards } from '@/components/game/game-cards'
import { Button } from '@/components/ui/button'
import { fmtDate, initialsOf, todayKey, useAction, useApp, useServer } from '@/lib/client'
import { cn } from '@/lib/utils'
import { getCasinoLobby } from '@/server/casino.functions'
import { getGamesConfig } from '@/server/game.functions'
import { claimDailyReward } from '@/server/wallet.functions'
import { getGameHistory, getReferralSummary, listFriends } from '@/server/social.functions'
import { listTournaments } from '@/server/tournament.functions'

export const Route = createFileRoute('/app/')({
  head: () => ({ meta: [{ title: 'Home · Ludo King Arena' }] }),
  component: HomeDashboard,
})

const quickModes = [
  { mode: '1v1', title: '1 vs 1', sub: 'Quick duel', icon: Swords, from: 'from-ludo-red/80' },
  { mode: '2v2', title: '2 vs 2', sub: 'Team battle', icon: Users, from: 'from-ludo-green/80' },
  { mode: '4p', title: '4 Players', sub: 'Classic', icon: Crown, from: 'from-ludo-yellow/80' },
] as const

function greeting() {
  const h = new Date().getHours()
  return h < 12 ? 'Good morning,' : h < 18 ? 'Good afternoon,' : 'Good evening,'
}

function HomeDashboard() {
  const { me, wallet, settings, refresh } = useApp()
  const games = useServer(() => getGameHistory())
  const friends = useServer(() => listFriends())
  const tours = useServer(() => listTournaments())
  const refs = useServer(() => getReferralSummary())
  const gameCfg = useServer(() => getGamesConfig())
  const casinoCfg = useServer(() => getCasinoLobby())
  const { pending, run } = useAction()

  const claimedToday = me.lastDailyClaim === todayKey()
  // eslint-disable-next-line react-hooks/purity
  const yesterday = new Date(Date.now() - 864e5).toISOString().slice(0, 10)
  const streakAlive = me.lastDailyClaim === yesterday || claimedToday
  const len = settings.dailyRewards.length
  const nextDay = claimedToday ? me.dailyStreak : streakAlive ? (me.dailyStreak % len) + 1 : 1
  const winRate = me.gamesPlayed ? Math.round((me.gamesWon / me.gamesPlayed) * 100) : 0

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Avatar initials={initialsOf(me.displayName)} src={me.avatarUrl} className="size-14 text-lg" />
          <div>
            <p className="text-sm text-muted-foreground">{greeting()}</p>
            <h1 className="text-3xl font-extrabold">{me.displayName} 👋</h1>
            <p className="font-mono text-xs text-muted-foreground">ID {me.publicId}</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <Stat label="Rating" value={me.rating} />
          <Stat label="Played" value={me.gamesPlayed} />
          <Stat label="Win rate" value={`${winRate}%`} />
        </div>
      </div>

      {settings.banners.map((b) => (
        <div key={b.id} className="flex items-start gap-3 rounded-2xl bg-gradient-to-r from-primary/20 to-transparent p-4 ring-1 ring-primary/30">
          <Megaphone className="mt-0.5 size-5 shrink-0 text-primary" />
          <div>
            <div className="font-bold">{b.title}</div>
            <div className="text-sm text-muted-foreground">{b.body}</div>
          </div>
        </div>
      ))}

      <div className="grid gap-4 sm:grid-cols-4">
        <WalletTile label="Total coins" value={wallet.available} highlight />
        <WalletTile label="Purchased" value={wallet.purchased} />
        <WalletTile label="Bonus" value={wallet.bonus} />
        <WalletTile label="Referral earnings" value={refs.data?.earned ?? 0} />
      </div>

      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold">Games</h2>
          <Link to="/app/games" className="text-xs font-semibold text-primary hover:underline">All games →</Link>
        </div>
        <GameCards config={gameCfg.data} casino={casinoCfg.data} />
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {quickModes.map((m) => (
          <Link
            key={m.mode}
            to="/app/play"
            search={{ mode: m.mode }}
            className={cn('group relative overflow-hidden rounded-2xl bg-gradient-to-br to-card p-5 ring-1 ring-white/10 transition hover:-translate-y-1', m.from)}
          >
            <m.icon className="absolute -right-3 -bottom-3 size-24 opacity-15 transition group-hover:scale-110" />
            <div className="text-xs font-bold tracking-wider uppercase opacity-80">{m.sub}</div>
            <div className="mt-1 font-display text-2xl font-extrabold">{m.title}</div>
            <div className="mt-6 flex items-center justify-between text-sm">
              <span className="rounded-full bg-black/25 px-3 py-1 font-semibold">Free play</span>
              <span className="font-bold">Play →</span>
            </div>
          </Link>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <Gift className="size-5 text-primary" /> Daily rewards
            </h2>
            <span className="text-xs text-muted-foreground">{streakAlive ? `Day ${me.dailyStreak} streak` : 'Start your streak'}</span>
          </div>
          <div className="grid grid-cols-7 gap-2">
            {settings.dailyRewards.map((r, i) => {
              const day = i + 1
              const done = claimedToday ? day <= me.dailyStreak : day < nextDay
              const isToday = !claimedToday && day === nextDay
              return (
                <div
                  key={day}
                  className={cn(
                    'flex flex-col items-center gap-1 rounded-xl py-3 text-center ring-1 ring-white/10',
                    done && 'bg-ludo-green/15 ring-ludo-green/40',
                    isToday && 'bg-primary/15 ring-2 ring-primary',
                  )}
                >
                  <span className="text-[10px] font-bold text-muted-foreground uppercase">Day {day}</span>
                  {done ? <Check className="size-5 text-ludo-green" /> : <span className="coin text-xl" />}
                  <span className="text-xs font-bold">{r}</span>
                </div>
              )
            })}
          </div>
          <Button
            className="mt-4 w-full rounded-xl font-bold"
            disabled={claimedToday || pending}
            onClick={() => run(() => claimDailyReward(), (r) => `+${r.amount} bonus coins claimed!`).then((r) => r && refresh())}
          >
            {claimedToday ? 'Come back tomorrow' : `Claim ${settings.dailyRewards[nextDay - 1]} coins`}
          </Button>
        </Panel>

        <Panel>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-bold">Friends</h2>
            <Link to="/app/friends" className="text-xs font-semibold text-primary">
              See all
            </Link>
          </div>
          {friends.data && friends.data.friends.length === 0 && (
            <p className="text-sm text-muted-foreground">No friends yet. Search players by name or ID on the Friends page.</p>
          )}
          <ul className="space-y-3">
            {friends.data?.friends.slice(0, 5).map((f) => (
              <li key={f.id} className="flex items-center gap-3">
                <Avatar initials={initialsOf(f.name)} src={f.avatarUrl} status={f.online ? 'online' : 'offline'} className="size-9" />
                <div className="flex-1 text-sm">
                  <div className="font-semibold">{f.name}</div>
                  <div className="text-xs text-muted-foreground">{f.online ? 'Online' : `Rating ${f.rating}`}</div>
                </div>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-bold">
              <Trophy className="size-5 text-primary" /> Tournaments
            </h2>
            <Link to="/app/tournaments" className="text-xs font-semibold text-primary">
              All
            </Link>
          </div>
          <ul className="divide-y divide-white/5">
            {tours.data?.slice(0, 4).map((t) => (
              <li key={t.id} className="flex items-center justify-between py-3 text-sm">
                <div>
                  <div className="font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {t.mode} · {t.status === 'live' ? `ends ${fmtDate(t.endsAt)}` : `starts ${fmtDate(t.startsAt)}`}
                  </div>
                </div>
                <Coins value={t.prizeCoins} className="text-primary" />
              </li>
            ))}
          </ul>
        </Panel>
        <Panel>
          <h2 className="mb-3 text-lg font-bold">Recent games</h2>
          {games.data?.length === 0 && <p className="text-sm text-muted-foreground">No online games yet — jump into a match!</p>}
          <ul className="divide-y divide-white/5">
            {games.data?.slice(0, 5).map((g) => (
              <li key={g.id} className="flex items-center justify-between py-3 text-sm">
                <div>
                  <div className="font-semibold">
                    {g.mode} · <span className={g.won ? 'text-ludo-green' : 'text-ludo-red'}>{g.won ? 'won' : 'lost'}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">vs {g.opponents || '—'}</div>
                </div>
                <div className="text-right">
                  <div className={cn('font-bold tabular-nums', g.ratingDelta > 0 ? 'text-ludo-green' : 'text-ludo-red')}>
                    {g.ratingDelta > 0 ? '+' : ''}
                    {g.ratingDelta} RP
                  </div>
                  <div className="text-xs text-muted-foreground">{fmtDate(g.endedAt)}</div>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Link to="/app/play" search={{ room: 'private' }} className="flex items-center justify-center gap-2 rounded-xl bg-white/5 py-2.5 text-sm font-semibold hover:bg-white/10">
              <Lock className="size-4" /> Private room
            </Link>
            <Link to="/app/support" className="flex items-center justify-center gap-2 rounded-xl bg-white/5 py-2.5 text-sm font-semibold hover:bg-white/10">
              <Headset className="size-4" /> Support
            </Link>
          </div>
        </Panel>
      </div>
    </div>
  )
}

function Stat({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="glass rounded-xl px-4 py-2">
      <div className="font-display text-lg font-extrabold">{value}</div>
      <div className="text-muted-foreground">{label}</div>
    </div>
  )
}

function WalletTile({ label, value, highlight }: { label: string; value: number; highlight?: boolean }) {
  return (
    <Link to="/app/wallet" className={cn('glass rounded-2xl p-4 transition hover:bg-white/10', highlight && 'ring-1 ring-primary/40')}>
      <div className="text-xs font-semibold text-muted-foreground">{label}</div>
      <Coins value={value} className={cn('mt-1 text-xl', highlight && 'text-primary')} />
    </Link>
  )
}
