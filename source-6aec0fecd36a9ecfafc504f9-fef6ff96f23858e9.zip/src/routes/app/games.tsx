import { createFileRoute } from '@tanstack/react-router'
import { ShieldCheck } from 'lucide-react'

import { PageHeader, Panel } from '@/components/brand'
import { GameCards } from '@/components/game/game-cards'
import { useServer } from '@/lib/client'
import { getCasinoLobby } from '@/server/casino.functions'
import { getGamesConfig } from '@/server/game.functions'

export const Route = createFileRoute('/app/games')({
  head: () => ({ meta: [{ title: 'Games · Ludo King Arena' }] }),
  component: Games,
})

function Games() {
  const cfg = useServer(() => getGamesConfig())
  const casinoCfg = useServer(() => getCasinoLobby())
  return (
    <div className="space-y-6">
      <PageHeader title="Games" subtitle="Four live multiplayer games — play free, or pick a coin entry and win the prize pool — plus Dragon Tiger and Aviator live rounds." />
      <GameCards config={cfg.data} casino={casinoCfg.data} />
      <Panel className="flex items-start gap-3 text-sm text-muted-foreground">
        <ShieldCheck className="mt-0.5 size-5 shrink-0 text-primary" />
        <p>
          Every match runs on our servers. Dice, moves and physics are checked server-side, and entries are deducted once, only when the match starts. The prize is paid automatically to the verified winner. If a match is cancelled before it starts, nothing is charged. Coins are virtual and cannot be exchanged for cash.
        </p>
      </Panel>
    </div>
  )
}
