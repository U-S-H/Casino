import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Check, Search, Share2, UserMinus, UserPlus, X } from 'lucide-react'
import { toast } from 'sonner'

import { Avatar, PageHeader, Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { errMsg, initialsOf, timeAgo, useApp, useServer } from '@/lib/client'
import { listFriends, removeFriend, respondFriendRequest, searchPlayers, sendFriendRequest } from '@/server/social.functions'

export const Route = createFileRoute('/app/friends')({
  head: () => ({ meta: [{ title: 'Friends · Ludo King Arena' }] }),
  component: Friends,
})

type Found = Awaited<ReturnType<typeof searchPlayers>>

function Friends() {
  const { me } = useApp()
  const { data, reload } = useServer(() => listFriends(), [], 30_000)
  const [q, setQ] = useState('')
  const [found, setFound] = useState<Found | null>(null)
  const act = async (fn: () => Promise<unknown>, msg: string) => {
    try {
      await fn()
      toast.success(msg)
      void reload()
    } catch (e) {
      toast.error(errMsg(e))
    }
  }
  const friendIds = new Set([...(data?.friends ?? []), ...(data?.outgoing ?? []), ...(data?.incoming ?? [])].map((f) => f.id))
  const online = data?.friends.filter((f) => f.online).length ?? 0

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        <PageHeader title="Friends" subtitle={`${online} online now`} />
        <form
          className="relative"
          onSubmit={async (e) => {
            e.preventDefault()
            if (q.trim().length < 2) return
            try {
              setFound(await searchPlayers({ data: { q: q.trim() } }))
            } catch (err) {
              toast.error(errMsg(err))
            }
          }}
        >
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find players by name or ID (LKA-…)" className="h-11 pl-9" />
        </form>
        {found && (
          <Panel>
            <div className="mb-2 flex items-center justify-between">
              <h2 className="font-bold">Search results</h2>
              <button className="text-xs text-muted-foreground" onClick={() => setFound(null)}>
                Clear
              </button>
            </div>
            {found.length === 0 && <p className="text-sm text-muted-foreground">No players found.</p>}
            <ul className="divide-y divide-white/5">
              {found.map((p) => (
                <li key={p.id} className="flex items-center gap-3 py-3">
                  <Avatar initials={initialsOf(p.name)} src={p.avatarUrl} />
                  <div className="flex-1">
                    <div className="font-semibold">{p.name}</div>
                    <div className="font-mono text-xs text-muted-foreground">
                      {p.publicId} · {p.rating}
                    </div>
                  </div>
                  <Button size="sm" variant="secondary" disabled={friendIds.has(p.id)} onClick={() => act(() => sendFriendRequest({ data: { userId: p.id } }), `Request sent to ${p.name}`)}>
                    <UserPlus /> {friendIds.has(p.id) ? 'Added' : 'Add'}
                  </Button>
                </li>
              ))}
            </ul>
          </Panel>
        )}
        <Panel>
          <h2 className="mb-2 font-bold">My friends</h2>
          {data?.friends.length === 0 && <p className="py-4 text-sm text-muted-foreground">No friends yet. Search above or share your invite link.</p>}
          <ul className="divide-y divide-white/5">
            {data?.friends.map((f) => (
              <li key={f.id} className="flex items-center gap-3 py-3">
                <Avatar initials={initialsOf(f.name)} src={f.avatarUrl} status={f.online ? 'online' : 'offline'} />
                <div className="flex-1">
                  <div className="font-semibold">{f.name}</div>
                  <div className="text-xs text-muted-foreground">
                    Rating {f.rating} · {f.online ? 'Online' : `Seen ${timeAgo(f.lastSeenAt)} ago`}
                  </div>
                </div>
                <Button size="icon" variant="ghost" aria-label="Remove friend" onClick={() => confirm(`Remove ${f.name}?`) && act(() => removeFriend({ data: { userId: f.id } }), 'Friend removed')}>
                  <UserMinus />
                </Button>
              </li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-muted-foreground">To play together, create a private room on the Play page and invite friends from the room.</p>
        </Panel>
      </div>
      <div className="space-y-4">
        <Panel>
          <h2 className="mb-3 font-bold">Requests ({data?.incoming.length ?? 0})</h2>
          {data?.incoming.length === 0 && <p className="text-sm text-muted-foreground">No pending requests.</p>}
          <ul className="space-y-3">
            {data?.incoming.map((r) => (
              <li key={r.id} className="flex items-center gap-3">
                <Avatar initials={initialsOf(r.name)} src={r.avatarUrl} className="size-9" />
                <span className="flex-1 text-sm font-semibold">{r.name}</span>
                <Button size="icon" className="size-8" aria-label="Accept" onClick={() => act(() => respondFriendRequest({ data: { userId: r.id, accept: true } }), `You and ${r.name} are now friends`)}>
                  <Check />
                </Button>
                <Button size="icon" variant="secondary" className="size-8" aria-label="Decline" onClick={() => act(() => respondFriendRequest({ data: { userId: r.id, accept: false } }), 'Request declined')}>
                  <X />
                </Button>
              </li>
            ))}
          </ul>
          {!!data?.outgoing.length && <p className="mt-3 text-xs text-muted-foreground">Sent: {data.outgoing.map((o) => o.name).join(', ')}</p>}
        </Panel>
        <Panel>
          <h2 className="font-bold">Invite to the arena</h2>
          <p className="mt-1 text-sm text-muted-foreground">Share your referral link and earn bonus coins.</p>
          <Button
            className="mt-3 w-full"
            variant="secondary"
            onClick={() => {
              void navigator.clipboard?.writeText(`${window.location.origin}/?ref=${me.referralCode}`)
              toast.success('Invite link copied')
            }}
          >
            <Share2 /> Copy invite link
          </Button>
        </Panel>
      </div>
    </div>
  )
}
