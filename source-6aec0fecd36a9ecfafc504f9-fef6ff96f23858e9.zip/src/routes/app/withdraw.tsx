import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Clock, ShieldAlert, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'

import { Coins, PageHeader, Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { StatusBadge } from '@/components/brand/tx-list'
import { errMsg, fmtDate, METHOD_LABEL, useApp, useServer } from '@/lib/client'
import { listMyWithdrawals, requestWithdrawal } from '@/server/wallet.functions'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/app/withdraw')({
  head: () => ({ meta: [{ title: 'Withdraw · Ludo King Arena' }] }),
  component: Withdraw,
})

const STEPS = ['pending', 'approved', 'processing', 'paid'] as const

function Withdraw() {
  const { me, wallet, settings, refresh } = useApp()
  // Display flag only — the server enforces its own switch (src/server/lib/settings.ts).
  const CASHOUT_ENABLED = settings.cashoutEnabled
  const paymentMethods = settings.paymentMethods
  const { withdrawMinCoins: min, withdrawMaxCoins: max } = settings.limits
  const rate = settings.limits.withdrawCoinsPerPkr || 5
  const history = useServer(() => listMyWithdrawals(), [], 30_000)
  const [methodId, setMethodId] = useState<'easypaisa' | 'jazzcash' | 'sadapay'>(paymentMethods[0]?.id ?? 'easypaisa')
  const [amount, setAmount] = useState('')
  const [pending, setPending] = useState(false)
  // One key per submission attempt: retries of the same click are deduplicated server-side.
  const [key, setKey] = useState(() => crypto.randomUUID())
  const kycOk = me.kycStatus === 'verified'
  const open = history.data?.find((w) => w.status === 'pending' || w.status === 'approved' || w.status === 'processing')
  const coins = Number(amount) || 0
  const eligible = Math.min(wallet.winnings, max)
  const canSubmit = CASHOUT_ENABLED && kycOk && !open && !pending && eligible >= min
  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title="Withdraw" subtitle="Request a payout of your winnings to a mobile wallet." />

      <div className="grid gap-4 sm:grid-cols-3">
        <Panel>
          <div className="text-xs text-muted-foreground">Withdrawable winnings</div>
          <div className="mt-1 font-display text-3xl font-extrabold">
            <Coins value={wallet.winnings} />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">≈ Rs {coinsToPkr(wallet.winnings, rate).toLocaleString()}. Bonus and purchased coins can’t be withdrawn.</p>
        </Panel>
        <Panel>
          <div className="text-xs text-muted-foreground">Reserved for payouts</div>
          <div className="mt-1 font-display text-3xl font-extrabold">
            <Coins value={wallet.reserved} />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">Held while a request is reviewed. Returned if it is rejected.</p>
        </Panel>
        <Panel>
          <div className="text-xs text-muted-foreground">Identity check (KYC)</div>
          <div className="mt-1 flex items-center gap-2 font-bold">
            {kycOk ? <ShieldCheck className="size-5 text-ludo-green" /> : <ShieldAlert className="size-5 text-primary" />}
            {kycOk ? 'Verified' : me.kycStatus === 'pending' ? 'Under review' : 'Required before first withdrawal'}
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            CNIC photo, reviewed within 24 hours.{' '}
            {!kycOk && me.kycStatus !== 'pending' && (
              <Link to="/app/profile" className="font-semibold text-primary">
                Submit KYC
              </Link>
            )}
          </p>
        </Panel>
      </div>

      <Panel>
        <h2 className="mb-1 font-bold">Payout details</h2>
        <p className="mb-4 text-xs text-muted-foreground">
          Payout rate: {rate.toLocaleString()} coins = Rs 1 · Limits {min.toLocaleString()}–{max.toLocaleString()} coins per request · One open request at a time.
        </p>
        {open && (
          <div className="mb-4 flex gap-2 rounded-xl bg-ludo-yellow/10 p-3 text-sm ring-1 ring-ludo-yellow/30">
            <Clock className="size-4 shrink-0 text-ludo-yellow" />
            Request {open.id} is {open.status}. You can submit a new one once it is paid or rejected.
          </div>
        )}
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault()
            const form = e.currentTarget
            const fd = new FormData(form)
            setPending(true)
            try {
              const r = await requestWithdrawal({
                data: {
                  method: methodId,
                  accountHolder: String(fd.get('holder')),
                  accountNumber: String(fd.get('acc')),
                  coins,
                  idempotencyKey: key,
                },
              })
              toast.success(`Withdrawal ${r.id} submitted for review`)
              setKey(crypto.randomUUID())
              setAmount('')
              form.reset()
              await refresh()
              void history.reload()
            } catch (err) {
              toast.error(errMsg(err))
            } finally {
              setPending(false)
            }
          }}
        >
          <div className="grid gap-2 sm:grid-cols-3">
            {paymentMethods.map((m) => (
              <button
                type="button"
                key={m.id}
                onClick={() => setMethodId(m.id)}
                className={cn(
                  'rounded-xl p-3 text-sm font-semibold ring-1 ring-white/10',
                  methodId === m.id ? 'bg-primary/10 ring-2 ring-primary' : 'bg-white/5',
                )}
              >
                {m.name}
              </button>
            ))}
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="acc">Your {METHOD_LABEL[methodId]} account number</Label>
              <Input id="acc" name="acc" required inputMode="numeric" placeholder="03XXXXXXXXX" pattern="03\d{9}" title="11 digits starting with 03" className="h-11" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="holder">Account holder name</Label>
              <Input id="holder" name="holder" required minLength={3} maxLength={60} placeholder="As on your CNIC" className="h-11" />
            </div>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-end justify-between">
              <Label htmlFor="amt">Coins to withdraw</Label>
              <button type="button" className="text-xs font-semibold text-primary disabled:opacity-50" disabled={eligible < min} onClick={() => setAmount(String(eligible))}>
                Max {eligible.toLocaleString()}
              </button>
            </div>
            <Input
              id="amt"
              name="amt"
              required
              type="number"
              min={min}
              max={Math.max(min, eligible)}
              step={1}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={`Minimum ${min.toLocaleString()}`}
              className="h-11"
            />
            <p className="text-xs text-muted-foreground">
              {coins > 0 ? <>You receive <span className="font-bold text-foreground">Rs {coinsToPkr(coins, rate).toLocaleString()}</span>. </> : null}
              {eligible < min && `You need at least ${min.toLocaleString()} coins of winnings to withdraw.`}
            </p>
          </div>
          <Button type="submit" disabled={!canSubmit} className="h-11 w-full rounded-xl font-bold">
            {pending ? 'Submitting…' : !kycOk ? 'Verify KYC to withdraw' : open ? 'Request already open' : 'Request withdrawal'}
          </Button>
        </form>
      </Panel>

      <Panel>
        <h2 className="mb-2 font-bold">Withdrawal status & history</h2>
        {!history.data?.length && <p className="py-6 text-center text-sm text-muted-foreground">No withdrawal requests yet.</p>}
        <ul className="divide-y divide-white/5">
          {history.data?.map((w) => {
            const at = STEPS.indexOf(w.status as (typeof STEPS)[number])
            return (
              <li key={w.id} className="space-y-2 py-3 text-sm">
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="font-semibold">
                      {w.coins.toLocaleString()} coins{w.amountPkr != null && ` · Rs ${w.amountPkr.toLocaleString()}`} → {METHOD_LABEL[w.method]} {w.accountNumber}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {w.id} · {w.accountHolder} · {fmtDate(w.createdAt)}
                      {w.paymentReference && ` · Payment ref ${w.paymentReference}`}
                    </div>
                  </div>
                  <StatusBadge status={w.status} />
                </div>
                {w.status === 'rejected' ? (
                  <p className="rounded-lg bg-ludo-red/10 p-2 text-xs">
                    Rejected{w.adminNote ? `: ${w.adminNote}` : ''}. {w.coins.toLocaleString()} coins were returned to your winnings.
                  </p>
                ) : (
                  <div className="flex gap-1">
                    {STEPS.map((st, i) => (
                      <div key={st} className="flex-1">
                        <div className={cn('h-1 rounded-full', i <= at ? 'bg-primary' : 'bg-white/10')} />
                        <div className={cn('mt-1 text-[10px] capitalize', i <= at ? 'text-foreground' : 'text-muted-foreground')}>{st}</div>
                      </div>
                    ))}
                  </div>
                )}
                {w.status !== 'rejected' && w.adminNote && <p className="text-xs text-muted-foreground">Note: {w.adminNote}</p>}
              </li>
            )
          })}
        </ul>
      </Panel>
    </div>
  )
}

const coinsToPkr = (coins: number, rate: number) => Math.floor(coins / Math.max(rate, 0.01))
