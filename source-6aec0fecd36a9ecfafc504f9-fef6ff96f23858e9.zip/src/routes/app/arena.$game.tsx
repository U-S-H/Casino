import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, KeyRound, Lock, RotateCcw, Search, UserPlus, Users } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Panel } from '@/components/brand'
import { ArenaMatch, BOARDS } from '@/components/game/arena-match'
import { EntryPicker, entryOk, JoinConfirmDialog, type RoomPreview } from '@/components/game/entry-picker'
import { GameArt } from '@/components/game/game-cards'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { errMsg, useServer } from '@/lib/client'
import { GAME_INFO } from '@/lib/games/catalog'
import { carromEngine } from '@/lib/games/carrom'
import { chessEngine } from '@/lib/games/chess'
import { poolEngine } from '@/lib/games/pool'
import { GameRuleError, type ArenaEngine } from '@/lib/games/types'
import { cn } from '@/lib/utils'
import { createRoom, getActiveRoom, getLobby, joinRoomByCode, previewRoom, quickMatch, type RoomView } from '@/server/game.functions'

type ArenaId = 'pool' | 'carrom' | 'chess'
const ENGINES: Record<ArenaId, ArenaEngine> = {
  pool: poolEngine as unknown as ArenaEngine,
  carrom: carromEngine as unknown as ArenaEngine,
  chess: chessEngine as unknown as ArenaEngine,
}
const RULES: Record<ArenaId, string[]> = {
  pool: [
    'Break, then pot your group (solids 1–7 or stripes 9–15). The first legal pot decides the groups.',
    'Pot one of your own balls to shoot again. Scratches, missing your group or no rail after contact are fouls: your opponent gets ball in hand.',
    'Clear your group, then pot the 8 to win. Potting the 8 early or scratching on it loses.',
  ],
  carrom: [
    'Place the striker on your baseline, aim forward and flick. White plays first from the bottom.',
    'Pocket your own coin to strike again. Pocketing the striker is a foul: one of your coins goes back.',
    'Pocket the red queen after one of your own coins, then cover it with another of your coins on the next strike. First to clear all 9 coins wins.',
  ],
  chess: [
    'Full FIDE rules: castling, en passant, promotion, check and checkmate.',
    'Draws by stalemate, agreement, insufficient material, threefold repetition and the 50-move rule.',
    'Each move has a clock. Running out of time loses the game.',
  ],
}

export const Route = createFileRoute('/app/arena/$game')({
  head: ({ params }) => ({ meta: [{ title: `${GAME_INFO[params.game as ArenaId]?.name ?? 'Game'} · Ludo King Arena` }] }),
  validateSearch: (s: Record<string, unknown>): { code?: string } => ({
    code: typeof s.code === 'string' || typeof s.code === 'number' ? String(s.code).slice(0, 6) : undefined,
  }),
  component: ArenaRoute,
})

function ArenaRoute() {
  const { game } = Route.useParams()
  if (!['pool', 'carrom', 'chess'].includes(game))
    return (
      <Panel className="mx-auto max-w-md text-center">
        <h2 className="text-xl font-bold">Game not found</h2>
        <Link to="/app/games" className="mt-3 inline-block text-sm font-semibold text-primary">Back to games</Link>
      </Panel>
    )
  return <ArenaLobby key={game} game={game as ArenaId} />
}

function ArenaLobby({ game }: { game: ArenaId }) {
  const search = Route.useSearch()
  const navigate = useNavigate()
  const info = GAME_INFO[game]
  const lobby = useServer(() => getLobby({ data: { game } }), [game], 20_000)
  const cfg = lobby.data?.config
  const types = cfg?.matchTypes.filter((m) => m.enabled) ?? []
  const [mode, setMode] = useState<string>('')
  const mt = types.find((t) => t.id === mode) ?? types[0]
  const [entry, setEntry] = useState(0)
  const [room, setRoom] = useState<RoomView | null>(null)
  const [practice, setPractice] = useState(false)
  const [checked, setChecked] = useState(false)
  const [busy, setBusy] = useState(false)
  const [preview, setPreview] = useState<(RoomPreview & { password: string }) | null>(null)
  const balance = lobby.data?.balance ?? 0
  const canGo = entryOk(cfg, entry, balance) && !!mt
  const entryLabel = entry > 0 ? `${entry.toLocaleString()} coins` : 'free'

  useEffect(() => {
    getActiveRoom({ data: { game } })
      .then((r) => r && setRoom(r))
      .catch(() => undefined)
      .finally(() => setChecked(true))
  }, [game])

  const go = async (fn: () => Promise<RoomView>) => {
    setBusy(true)
    try {
      setRoom(await fn())
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  const exit = () => {
    setRoom(null)
    setPractice(false)
    void lobby.reload()
    void navigate({ to: '/app/arena/$game', params: { game }, search: {} })
  }

  if (room) return <ArenaMatch key={room.id} initial={room} onExit={exit} />
  if (practice) return <Practice game={game} onExit={exit} />

  const openHere = (lobby.data?.openTables ?? []).filter((t) => t.mode === mt?.id)

  return (
    <div>
      <Link to="/app/games" className="mb-3 inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-3" /> All games
      </Link>
      <PageHeader title={info.name} subtitle={`${info.tagline}. Live 1-vs-1 multiplayer — play free or choose a virtual-coin entry.`} />
      {lobby.loading && !cfg && <Panel className="text-sm text-muted-foreground">Loading lobby…</Panel>}
      {lobby.error && <Panel className="text-sm text-ludo-red">{lobby.error}</Panel>}
      {cfg && !cfg.enabled && <Panel className="mb-4 text-sm text-ludo-yellow">{info.name} is temporarily disabled by the admins.</Panel>}

      {cfg && (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
          <div className="space-y-6">
            <Panel>
              <div className="mb-3 text-sm font-bold">Match type</div>
              <div className="grid gap-3 sm:grid-cols-2">
                {types.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setMode(t.id)}
                    className={cn('rounded-2xl bg-white/5 p-4 text-left ring-1 ring-white/10 transition hover:bg-white/10', mt?.id === t.id && 'ring-2 ring-primary')}
                  >
                    <div className="font-display text-lg font-extrabold">{t.label}</div>
                    <div className="text-xs text-muted-foreground">{t.sub}</div>
                    <div className="mt-2 flex items-center gap-1 text-xs font-semibold text-ludo-green"><Users className="size-3.5" /> {t.players} players</div>
                  </button>
                ))}
              </div>
            </Panel>
            <Panel>
              <EntryPicker cfg={cfg} balance={balance} players={mt?.players ?? 2} value={entry} onChange={setEntry} />
            </Panel>

            <Tabs defaultValue={search.code ? 'private' : 'random'}>
              <TabsList className="w-full sm:w-auto">
                <TabsTrigger value="random"><Search className="size-4" /> Matchmaking</TabsTrigger>
                <TabsTrigger value="private"><Lock className="size-4" /> Private room</TabsTrigger>
              </TabsList>
              <TabsContent value="random" className="mt-4">
                <Panel className="flex flex-col items-center gap-4 py-8 text-center">
                  <GameArt game={game} className="size-16" />
                  <p className="max-w-md text-sm text-muted-foreground">
                    You are paired with a real player who picked the same match type and the same entry ({entryLabel}).
                    {openHere.length > 0 && ` ${openHere.reduce((a, t) => a + t.n, 0)} open table(s) waiting right now.`}
                  </p>
                  <Button size="lg" disabled={busy || !checked || !canGo} className="h-12 rounded-full px-10 text-base font-bold" onClick={() => go(() => quickMatch({ data: { game, mode: mt!.id, entry } }))}>
                    {busy ? 'Matching…' : `Find match · ${entryLabel}`}
                  </Button>
                </Panel>
              </TabsContent>
              <TabsContent value="private" className="mt-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Panel>
                    <h2 className="flex items-center gap-2 text-lg font-bold"><Lock className="size-5 text-primary" /> Create a room</h2>
                    <p className="mt-2 text-sm text-muted-foreground">Share the 6-digit code. The entry you picked is locked for the room.</p>
                    <form
                      className="mt-4 space-y-3"
                      onSubmit={(e) => {
                        e.preventDefault()
                        const password = String(new FormData(e.currentTarget).get('password') ?? '')
                        void go(() => createRoom({ data: { game, mode: mt!.id, entry, password } }))
                      }}
                    >
                      <Input name="password" maxLength={32} placeholder="Room password (optional)" />
                      <Button type="submit" disabled={busy || !canGo} className="w-full font-bold"><UserPlus /> Create room · {entryLabel}</Button>
                    </form>
                  </Panel>
                  <Panel>
                    <h2 className="flex items-center gap-2 text-lg font-bold"><KeyRound className="size-5 text-primary" /> Join a room</h2>
                    <form
                      className="mt-4 space-y-3"
                      onSubmit={(e) => {
                        e.preventDefault()
                        const fd = new FormData(e.currentTarget)
                        const code = String(fd.get('code')).trim()
                        const password = String(fd.get('password') ?? '')
                        setBusy(true)
                        previewRoom({ data: { code } })
                          .then((p) => {
                            if (p.game !== game) throw new Error(`That code is for ${GAME_INFO[p.game].name}. Open it from the Games page.`)
                            setPreview({ ...p, password })
                          })
                          .catch((err) => toast.error(errMsg(err)))
                          .finally(() => setBusy(false))
                      }}
                    >
                      <div className="space-y-1.5">
                        <Label htmlFor="acode">Room code</Label>
                        <Input id="acode" name="code" required inputMode="numeric" pattern="\d{6}" defaultValue={search.code} placeholder="6 digits" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="apass">Password (if set)</Label>
                        <Input id="apass" name="password" maxLength={32} />
                      </div>
                      <Button type="submit" disabled={busy} variant="secondary" className="w-full font-bold">Review entry & join</Button>
                    </form>
                  </Panel>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <aside className="space-y-4">
            <Panel>
              <h3 className="font-bold">How to play</h3>
              <ul className="mt-2 list-disc space-y-1.5 pl-4 text-sm text-muted-foreground">
                {RULES[game].map((r) => <li key={r}>{r}</li>)}
              </ul>
            </Panel>
            <Panel className="text-center">
              <h3 className="font-bold">Practice on this device</h3>
              <p className="mt-1 text-xs text-muted-foreground">Pass-and-play for two people on one screen. No coins, no rating.</p>
              <Button variant="secondary" className="mt-3 rounded-full px-6 font-bold" onClick={() => setPractice(true)}>Start practice</Button>
            </Panel>
          </aside>
        </div>
      )}
      <JoinConfirmDialog
        preview={preview}
        busy={busy}
        onClose={() => setPreview(null)}
        onConfirm={(p) =>
          void go(async () => {
            const r = await joinRoomByCode({ data: { code: p.code, password: preview?.password ?? '', acceptEntry: p.stake.entryFee } })
            setPreview(null)
            return r
          })
        }
      />
    </div>
  )
}

/** Local pass-and-play using the same rules engine the server runs. */
function Practice({ game, onExit }: { game: ArenaId; onExit: () => void }) {
  const eng = ENGINES[game]
  const names: [string, string] = ['Player 1', 'Player 2']
  const fresh = () => ({ state: eng.init(names, Math.random) as Record<string, unknown>, done: false, winner: null as number | null, reason: '' })
  const [g, setG] = useState(fresh)
  const Board = BOARDS[game]
  const seat = useMemo(() => eng.current(g.state), [eng, g.state])
  const act = (a: unknown) => {
    try {
      const r = eng.apply(g.state, seat, eng.parseAction(a))
      setG({ state: r.state as Record<string, unknown>, done: r.done, winner: r.winner, reason: r.reason ?? '' })
    } catch (e) {
      toast.error(e instanceof GameRuleError ? e.message : errMsg(e))
    }
  }
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button onClick={onExit} className="inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" /> Lobby</button>
        <span className="text-sm font-bold">Practice · {GAME_INFO[game].name} · {g.done ? 'Game over' : `${names[seat]} to play`}</span>
        <Button size="sm" variant="secondary" onClick={() => setG(fresh())}><RotateCcw /> Restart</Button>
      </div>
      <div className="mx-auto max-w-4xl">
        <Board state={g.state as never} mySeat={seat} canAct={!g.done} onAction={act as never} names={names} />
      </div>
      {g.done && (
        <Panel className="text-center">
          <div className="font-display text-2xl font-extrabold">{g.winner === null ? 'Draw' : `${names[g.winner]} wins`}</div>
          <p className="text-sm text-muted-foreground">{g.reason}</p>
          <Button className="mt-3 rounded-full" onClick={() => setG(fresh())}>Play again</Button>
        </Panel>
      )}
    </div>
  )
}
