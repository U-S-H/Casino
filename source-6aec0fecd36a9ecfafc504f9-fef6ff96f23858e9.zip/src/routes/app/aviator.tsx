import { Link, createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, Info, PauseCircle, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'

import { AmountPicker, BalancePill, MyBets, newKey, OfflineBanner, RoundTag, useCasino, useNow, useWalletRefresh, VerifyDialog } from '@/components/casino/common'
import { Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { errMsg } from '@/lib/client'
import { AV_RATE, avMultAt, avPayout, betError, fmtX, type AviatorConfig } from '@/lib/games/casino'
import { cn } from '@/lib/utils'
import { cancelCasinoBet, cashOutCasinoBet, placeCasinoBet, type CasinoState } from '@/server/casino.functions'

export const Route = createFileRoute('/app/aviator')({
  head: () => ({ meta: [{ title: 'Aviator · Ludo King Arena' }] }),
  component: Aviator,
})

type Bet = CasinoState['myBets'][number]
type View = { phase: 'idle' | 'betting' | 'flying' | 'crashed'; elapsed: number; x100: number; crashX100: number | null; sinceCrash: number }

function viewOf(round: CasinoState['round'], now: number): View {
  if (!round) return { phase: 'idle', elapsed: 0, x100: 100, crashX100: null, sinceCrash: 0 }
  const closes = new Date(round.closesAt).getTime()
  if (round.crashX100 != null) {
    const at = round.resultAt ? new Date(round.resultAt).getTime() : now
    return { phase: 'crashed', elapsed: at - closes, x100: round.crashX100, crashX100: round.crashX100, sinceCrash: Math.max(0, now - at) }
  }
  if (now < closes) return { phase: 'betting', elapsed: now - closes, x100: 100, crashX100: null, sinceCrash: 0 }
  return { phase: 'flying', elapsed: now - closes, x100: avMultAt(now - closes), crashX100: null, sinceCrash: 0 }
}

const chipTone = (x: number) => (x >= 1000 ? 'bg-primary/20 text-primary ring-primary/40' : x >= 200 ? 'bg-accent/25 text-[oklch(0.8_0.15_300)] ring-accent/40' : 'bg-ludo-blue/20 text-ludo-blue ring-ludo-blue/40')

function Aviator() {
  const { state, setState, offline, skew, reload } = useCasino('aviator', 500, 1200)
  const now = useNow(skew, 50)
  const refreshWallet = useWalletRefresh()
  const [verifyOpen, setVerifyOpen] = useState(false)
  const [verifyId, setVerifyId] = useState<string | undefined>()
  const [version, setVersion] = useState(0)
  const settledSeen = useRef<string | null>(null)

  const round = state?.round ?? null
  const v = viewOf(round, now)

  useEffect(() => {
    if (round?.settled && settledSeen.current !== round.id) {
      settledSeen.current = round.id
      refreshWallet()
      setVersion((x) => x + 1)
    }
  }, [round?.id, round?.settled, refreshWallet])

  if (!state)
    return (
      <Shell>
        <Panel className="grid h-80 place-items-center text-muted-foreground">Fuelling the plane…</Panel>
      </Shell>
    )
  const cfg = state.config as AviatorConfig
  const apply = (r: { bet: Bet; balance: number }) => {
    setState((s) => (s ? { ...s, balance: r.balance, myBets: [r.bet, ...s.myBets.filter((b) => b.id !== r.bet.id)] } : s))
    refreshWallet()
    void reload()
  }

  return (
    <Shell balance={state.balance}>
      <OfflineBanner show={offline} />
      {(cfg.paused || !cfg.enabled) && (
        <div className="flex items-center gap-2 rounded-xl bg-ludo-yellow/10 p-3 text-sm text-ludo-yellow ring-1 ring-ludo-yellow/30">
          <PauseCircle className="size-4 shrink-0" /> {cfg.enabled ? cfg.pauseMessage : 'Aviator is currently unavailable.'}
        </div>
      )}

      {/* crash history bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {state.history.slice(0, 30).map((r) => (
          <button
            key={r.id}
            type="button"
            onClick={() => {
              setVerifyId(r.id)
              setVerifyOpen(true)
            }}
            className={cn('shrink-0 rounded-full px-2.5 py-1 font-mono text-xs font-bold ring-1', chipTone(r.crashX100 ?? 100))}
            title={`${r.id} · tap to verify`}
          >
            {fmtX(r.crashX100 ?? 100)}
          </button>
        ))}
        {!state.history.length && <span className="text-xs text-muted-foreground">Crash history appears here.</span>}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_19rem]">
        <div className="space-y-4">
          <div className="relative overflow-hidden rounded-3xl ring-1 ring-white/10" style={{ background: 'radial-gradient(120% 100% at 0% 100%, oklch(0.27 0.09 300), oklch(0.14 0.04 285) 70%)' }}>
            <div className="absolute top-3 left-4 z-10">
              <RoundTag id={round?.id} hash={round?.seedHash} />
            </div>
            <FlightCanvas view={v} />
            <div className="pointer-events-none absolute inset-0 grid place-items-center">
              {v.phase === 'betting' && round ? (
                <div className="w-64 text-center">
                  <div className="text-xs font-bold tracking-widest text-muted-foreground uppercase">Next flight in</div>
                  <div className="font-display text-5xl font-extrabold tabular-nums">{(Math.max(0, -v.elapsed) / 1000).toFixed(1)}s</div>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-ludo-red" style={{ width: `${Math.max(0, Math.min(100, (-v.elapsed / (cfg.bettingSeconds * 1000)) * 100))}%` }} />
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">Place your bets</div>
                </div>
              ) : v.phase === 'flying' ? (
                <div className="font-display text-6xl font-extrabold tabular-nums drop-shadow-[0_4px_24px_rgba(0,0,0,.6)] sm:text-8xl">{fmtX(v.x100)}</div>
              ) : v.phase === 'crashed' ? (
                <div className="text-center">
                  <div className="text-sm font-extrabold tracking-[0.3em] text-ludo-red uppercase">Flew away!</div>
                  <div className="font-display text-6xl font-extrabold text-ludo-red tabular-nums sm:text-8xl">{fmtX(v.x100)}</div>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">{cfg.paused ? 'Paused' : 'Waiting for the next round…'}</div>
              )}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {(['1', '2'] as const).map((slot) => (
              <BetSlot key={slot} slot={slot} state={state} view={v} onApplied={apply} offline={offline} />
            ))}
          </div>

          <Panel>
            <h2 className="mb-2 font-bold">My bets</h2>
            <MyBets game="aviator" version={version} />
          </Panel>
        </div>

        <aside className="space-y-4">
          <Panel>
            <h2 className="mb-2 flex items-center justify-between text-sm font-bold">
              Live bets <span className="text-xs font-normal text-muted-foreground">{state.totals.players} players</span>
            </h2>
            {!state.live.length && <p className="text-xs text-muted-foreground">No bets in this round yet.</p>}
            <ul className="max-h-72 space-y-1 overflow-y-auto text-xs">
              {state.live.map((b, i) => (
                <li key={i} className={cn('grid grid-cols-[1fr_auto_auto] items-center gap-2 rounded-lg px-2 py-1', b.me && 'bg-primary/10', b.status === 'won' && 'bg-ludo-green/10')}>
                  <span className="truncate font-semibold">{b.name}</span>
                  <span className="tabular-nums">{b.stake.toLocaleString()}</span>
                  <span className={cn('w-20 text-right font-bold tabular-nums', b.status === 'won' ? 'text-ludo-green' : b.status === 'lost' ? 'text-ludo-red' : 'text-muted-foreground')}>
                    {b.status === 'won' && b.cashoutX100 ? `${fmtX(b.cashoutX100)} +${b.payout.toLocaleString()}` : b.status === 'lost' ? 'lost' : '…'}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel className="space-y-2 text-xs text-muted-foreground">
            <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
              <Info className="size-4 text-primary" /> How it works
            </h2>
            <ul className="list-disc space-y-1 pl-4">
              <li>Bet during the countdown ({cfg.minBet.toLocaleString()}–{cfg.maxBet.toLocaleString()} coins, up to two bets per round). The stake is deducted when the bet is accepted.</li>
              <li>The multiplier starts at 1.00x and grows until the plane flies away. Cash out before that to win stake × multiplier (total return, rounded down).</li>
              <li>Auto cash-out pays you automatically at your chosen multiplier if the plane reaches it.</li>
              <li>The server’s clock decides: a cash-out counts only if it reaches the server before the crash time. If you lose connection, auto cash-out still works; a bet without one is lost if the plane flies away.</li>
              <li>Max multiplier {cfg.maxMultiplier}x. Max return per bet {cfg.maxPayoutPerBet.toLocaleString()} coins; bets are cashed out automatically when they reach it.</li>
              <li>House edge {cfg.houseEdgePercent}%: on average every cash-out target returns {(100 - cfg.houseEdgePercent).toFixed(1)}% of stakes. No other fees.</li>
            </ul>
          </Panel>

          <Panel className="space-y-2 text-xs text-muted-foreground">
            <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
              <ShieldCheck className="size-4 text-ludo-green" /> Provably fair
            </h2>
            <p>Before betting opens the server publishes SHA-256 of a random 256-bit seed. The crash point is fixed by that seed alone: no bet, player or balance can change it.</p>
            <p className="font-mono text-[11px] text-foreground">
              d = HMAC-SHA256(seed, roundId)
              <br />h = first 52 bits of d
              <br />crash = ⌊(100 − edge) · 2⁵² / (2⁵² − h)⌋ / 100
              <br />(min 1.00x, max {cfg.maxMultiplier}x)
            </p>
            <p>The seed is revealed when the round settles. Tap any multiplier in the history bar to recompute it in your browser.</p>
            <Button size="sm" variant="secondary" className="w-full" onClick={() => setVerifyOpen(true)}>
              Verify a round
            </Button>
          </Panel>
        </aside>
      </div>
      <VerifyDialog open={verifyOpen} onOpenChange={setVerifyOpen} game="aviator" initialId={verifyId} />
    </Shell>
  )
}

function Shell({ children, balance }: { children: React.ReactNode; balance?: number }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link to="/app/games" className="grid size-9 place-items-center rounded-xl bg-white/5 hover:bg-white/10" aria-label="Back to games">
            <ArrowLeft className="size-4" />
          </Link>
          <div>
            <h1 className="font-display text-2xl font-extrabold sm:text-3xl">
              Aviator<span className="text-ludo-red">.</span>
            </h1>
            <p className="text-xs text-muted-foreground">Cash out before the plane flies away</p>
          </div>
        </div>
        {balance != null && <BalancePill value={balance} />}
      </div>
      {children}
    </div>
  )
}

function BetSlot({ slot, state, view, onApplied, offline }: { slot: '1' | '2'; state: CasinoState; view: View; onApplied: (r: { bet: Bet; balance: number }) => void; offline: boolean }) {
  const cfg = state.config as AviatorConfig
  const round = state.round
  const [amount, setAmount] = useState(slot === '1' ? 500 : 1000)
  const [autoOn, setAutoOn] = useState(false)
  const [autoVal, setAutoVal] = useState('2.00')
  const [queued, setQueued] = useState(false)
  const [busy, setBusy] = useState(false)
  const bet = round ? state.myBets.find((b) => b.roundId === round.id && b.choice === slot) : undefined
  const autoX100 = autoOn ? Math.round(parseFloat(autoVal || '0') * 100) : null
  const autoErr = autoOn && (!autoX100 || autoX100 < 101 || autoX100 > cfg.maxMultiplier * 100) ? `Auto cash-out must be 1.01x–${cfg.maxMultiplier}x` : null
  const open = view.phase === 'betting' && cfg.enabled && !cfg.paused

  const place = async () => {
    if (!round) return
    const err = betError(cfg, amount) ?? autoErr
    if (err) return toast.error(err)
    if (amount > state.balance) return toast.error('Not enough coins in your wallet.')
    setBusy(true)
    try {
      const r = await placeCasinoBet({ data: { game: 'aviator', roundId: round.id, choice: slot, amount, autoX100, clientKey: newKey() } })
      toast.success(`Bet ${slot} placed: ${amount.toLocaleString()} coins`)
      onApplied(r)
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  // "Bet next round": submit automatically when the next betting window opens.
  const roundId = round?.id
  const placeRef = useRef(place)
  useEffect(() => {
    placeRef.current = place
  })
  useEffect(() => {
    if (queued && open && roundId && !bet && !busy) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- reacts to the server opening a new betting window
      setQueued(false)
      void placeRef.current()
    }
  }, [queued, open, roundId, bet, busy])

  const cancel = async () => {
    if (!bet) return
    setBusy(true)
    try {
      const r = await cancelCasinoBet({ data: { betId: bet.id } })
      toast.success('Bet cancelled, coins returned')
      onApplied({ bet: r.bet, balance: r.balance })
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(false)
    }
  }
  const cashOut = async () => {
    if (!bet) return
    setBusy(true)
    try {
      const r = await cashOutCasinoBet({ data: { betId: bet.id } })
      toast.success(`Cashed out at ${fmtX(r.bet.cashoutX100 ?? 100)}: +${r.bet.payout.toLocaleString()} coins`)
      onApplied(r)
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  const maxPayout = Number(bet?.terms.maxPayout ?? cfg.maxPayoutPerBet)
  const live = bet ? avPayout(bet.stake, Math.min(view.x100, bet.autoX100 ?? Infinity), maxPayout) : 0
  const autoHit = !!bet && bet.status === 'active' && view.phase === 'flying' && !!bet.autoX100 && view.x100 >= bet.autoX100
  const potential = autoX100 ? avPayout(amount, autoX100, cfg.maxPayoutPerBet) : null

  let action: React.ReactNode
  if (bet?.status === 'active' && view.phase === 'betting')
    action = (
      <Button disabled={busy} onClick={() => void cancel()} className="h-16 w-full rounded-2xl bg-ludo-red text-lg font-extrabold text-white hover:bg-ludo-red/90">
        Cancel
        <span className="block text-xs font-semibold opacity-80">Waiting for take-off</span>
      </Button>
    )
  else if (bet?.status === 'active' && view.phase === 'flying')
    action = (
      <Button disabled={busy || autoHit || offline} onClick={() => void cashOut()} className="h-16 w-full flex-col gap-0 rounded-2xl bg-primary text-lg font-extrabold text-primary-foreground shadow-[0_0_30px] shadow-primary/40 hover:bg-primary/90">
        {autoHit ? `Auto cash-out ${fmtX(bet.autoX100!)}…` : 'Cash out'}
        <span className="text-sm tabular-nums">{live.toLocaleString()} coins</span>
      </Button>
    )
  else if (bet && bet.status === 'won')
    action = (
      <div className="flex h-16 flex-col items-center justify-center rounded-2xl bg-ludo-green/15 text-ludo-green ring-1 ring-ludo-green/40">
        <span className="font-extrabold">Cashed out {fmtX(bet.cashoutX100 ?? 100)}</span>
        <span className="text-sm font-bold tabular-nums">+{bet.payout.toLocaleString()} coins</span>
      </div>
    )
  else if (bet && (bet.status === 'lost' || (bet.status === 'active' && view.phase === 'crashed')))
    action = (
      <div className="flex h-16 flex-col items-center justify-center rounded-2xl bg-ludo-red/10 text-ludo-red ring-1 ring-ludo-red/30">
        <span className="font-extrabold">Flew away</span>
        <span className="text-xs">−{bet.stake.toLocaleString()} coins</span>
      </div>
    )
  else if (open)
    action = (
      <Button disabled={busy || offline || !!betError(cfg, amount) || !!autoErr || amount > state.balance} onClick={() => void place()} className="h-16 w-full flex-col gap-0 rounded-2xl bg-ludo-green text-lg font-extrabold text-white hover:bg-ludo-green/90">
        Bet
        <span className="text-sm tabular-nums">{amount.toLocaleString()} coins</span>
      </Button>
    )
  else
    action = (
      <Button
        variant="secondary"
        disabled={!cfg.enabled || cfg.paused}
        onClick={() => setQueued((q) => !q)}
        className={cn('h-16 w-full flex-col gap-0 rounded-2xl text-base font-extrabold', queued && 'ring-2 ring-ludo-green')}
      >
        {queued ? 'Cancel queued bet' : 'Bet next round'}
        <span className="text-xs font-semibold text-muted-foreground tabular-nums">{queued ? 'Placed when betting opens' : `${amount.toLocaleString()} coins`}</span>
      </Button>
    )

  const locked = !!bet && bet.status === 'active'
  return (
    <Panel className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold tracking-wider text-muted-foreground uppercase">Bet {slot}</span>
        {potential != null && !locked && <span className="text-[11px] text-muted-foreground">Auto return {potential.toLocaleString()}</span>}
        {locked && bet.autoX100 && <span className="text-[11px] text-muted-foreground">Auto at {fmtX(bet.autoX100)}</span>}
      </div>
      <AmountPicker id={`av-amount-${slot}`} cfg={cfg} value={amount} onChange={setAmount} balance={state.balance} disabled={locked || queued} compact />
      <div className="flex items-center gap-3">
        <label className="flex items-center gap-2 text-xs font-semibold">
          <Switch checked={autoOn} onCheckedChange={setAutoOn} disabled={locked || queued} aria-label="Auto cash-out" /> Auto cash-out
        </label>
        <div className="relative w-24">
          <Input
            aria-label="Auto cash-out multiplier"
            value={autoVal}
            disabled={!autoOn || locked || queued}
            inputMode="decimal"
            onChange={(e) => setAutoVal(e.target.value.replace(/[^\d.]/g, '').slice(0, 7))}
            className="h-8 pr-5 text-right font-mono text-sm"
          />
          <span className="absolute top-1/2 right-2 -translate-y-1/2 text-xs text-muted-foreground">x</span>
        </div>
      </div>
      {autoErr && <p className="text-[11px] font-semibold text-ludo-red">{autoErr}</p>}
      {action}
    </Panel>
  )
}

/** HTML5 canvas: grid, the exponential curve, the plane and the fly-away. */
function FlightCanvas({ view }: { view: View }) {
  const ref = useRef<HTMLCanvasElement>(null)
  const viewRef = useRef(view)
  useEffect(() => {
    viewRef.current = view
  }, [view])
  useEffect(() => {
    const cv = ref.current
    if (!cv) return
    const ctx = cv.getContext('2d')
    if (!ctx) return
    let raf = 0
    const draw = () => {
      raf = requestAnimationFrame(draw)
      const dpr = Math.min(2, window.devicePixelRatio || 1)
      const W = cv.clientWidth
      const H = cv.clientHeight
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) {
        cv.width = Math.round(W * dpr)
        cv.height = Math.round(H * dpr)
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, W, H)
      const v = viewRef.current
      const pad = { l: 36, b: 28, r: 24, t: 48 }
      const gw = W - pad.l - pad.r
      const gh = H - pad.t - pad.b
      const t = Math.max(0, v.elapsed / 1000)
      const m = v.x100 / 100
      const maxT = Math.max(8, t * 1.18)
      const maxM = Math.max(2, m * 1.2)
      const X = (s: number) => pad.l + (s / maxT) * gw
      const Y = (mm: number) => pad.t + gh - ((mm - 1) / (maxM - 1)) * gh

      // grid + axes
      ctx.strokeStyle = 'rgba(255,255,255,0.06)'
      ctx.lineWidth = 1
      ctx.fillStyle = 'rgba(255,255,255,0.35)'
      ctx.font = '600 10px Manrope, system-ui'
      const stepM = maxM > 20 ? 10 : maxM > 6 ? 2 : maxM > 3 ? 1 : 0.5
      for (let mm = 1; mm <= maxM; mm += stepM) {
        const y = Y(mm)
        ctx.beginPath()
        ctx.moveTo(pad.l, y)
        ctx.lineTo(W - pad.r, y)
        ctx.stroke()
        ctx.fillText(`${mm.toFixed(mm % 1 ? 1 : 0)}x`, 4, y + 3)
      }
      const stepT = maxT > 40 ? 10 : maxT > 16 ? 5 : 2
      for (let s = 0; s <= maxT; s += stepT) {
        const x = X(s)
        ctx.beginPath()
        ctx.moveTo(x, pad.t)
        ctx.lineTo(x, pad.t + gh)
        ctx.stroke()
        ctx.fillText(`${s}s`, x - 6, H - 8)
      }

      const plane = (x: number, y: number, ang: number, alpha: number, wobble: number) => {
        ctx.save()
        ctx.globalAlpha = alpha
        ctx.translate(x, y)
        ctx.rotate(ang)
        ctx.fillStyle = '#e8384f'
        ctx.strokeStyle = 'rgba(0,0,0,0.35)'
        ctx.lineWidth = 1
        // fuselage
        ctx.beginPath()
        ctx.moveTo(18, 0)
        ctx.quadraticCurveTo(12, -6, -16, -4)
        ctx.lineTo(-22, -11)
        ctx.lineTo(-26, -11)
        ctx.lineTo(-22, 2)
        ctx.quadraticCurveTo(0, 6, 18, 0)
        ctx.fill()
        ctx.stroke()
        // wing
        ctx.fillStyle = '#b91c33'
        ctx.beginPath()
        ctx.moveTo(4, 1)
        ctx.lineTo(-8, 14 + wobble)
        ctx.lineTo(-13, 14 + wobble)
        ctx.lineTo(-6, 1)
        ctx.fill()
        // cockpit
        ctx.fillStyle = 'rgba(255,255,255,0.85)'
        ctx.beginPath()
        ctx.ellipse(7, -3, 4, 2, -0.2, 0, Math.PI * 2)
        ctx.fill()
        // propeller
        ctx.fillStyle = 'rgba(255,255,255,0.7)'
        const p = Math.sin(performance.now() / 25) * 9
        ctx.fillRect(19, -Math.abs(p), 2, Math.abs(p) * 2)
        ctx.restore()
      }

      if (v.phase === 'betting' || v.phase === 'idle') {
        const bob = Math.sin(performance.now() / 300) * 3
        plane(pad.l + 26, pad.t + gh - 12 + bob, -0.05, 0.9, bob / 3)
        return
      }

      // curve
      const N = 80
      ctx.beginPath()
      ctx.moveTo(X(0), Y(1))
      for (let i = 1; i <= N; i++) {
        const s = (t * i) / N
        ctx.lineTo(X(s), Y(Math.exp(AV_RATE * s)))
      }
      const tipX = X(t)
      const tipY = Y(Math.exp(AV_RATE * t))
      const fill = ctx.createLinearGradient(0, pad.t, 0, pad.t + gh)
      fill.addColorStop(0, v.phase === 'crashed' ? 'rgba(232,56,79,0.18)' : 'rgba(232,56,79,0.45)')
      fill.addColorStop(1, 'rgba(232,56,79,0.02)')
      ctx.strokeStyle = v.phase === 'crashed' ? 'rgba(232,56,79,0.5)' : '#e8384f'
      ctx.lineWidth = 4
      ctx.lineCap = 'round'
      ctx.stroke()
      ctx.lineTo(tipX, pad.t + gh)
      ctx.lineTo(X(0), pad.t + gh)
      ctx.closePath()
      ctx.fillStyle = fill
      ctx.fill()

      const slope = Math.atan2(-(Y(Math.exp(AV_RATE * (t + 0.3))) - tipY), X(t + 0.3) - tipX)
      if (v.phase === 'flying') {
        plane(tipX, tipY - 6, -Math.min(0.9, slope), 1, Math.sin(performance.now() / 120))
      } else {
        // fly-away: the plane exits up and to the right, fading out
        const k = Math.min(1, v.sinceCrash / 900)
        plane(tipX + k * W * 0.6, tipY - 6 - k * H * 0.6, -0.6, 1 - k, 0)
      }
    }
    draw()
    return () => cancelAnimationFrame(raf)
  }, [])
  return <canvas ref={ref} className="block h-72 w-full sm:h-96" aria-label="Aviator flight chart" role="img" />
}
