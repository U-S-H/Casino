import { createFileRoute } from '@tanstack/react-router'
import { Crown } from 'lucide-react'

import { Avatar, PageHeader, Panel } from '@/components/brand'
import { initialsOf, useApp, useServer } from '@/lib/client'
import { cn } from '@/lib/utils'
import { getLeaderboard } from '@/server/social.functions'

export const Route = createFileRoute('/app/leaderboard')({
  head: () => ({ meta: [{ title: 'Leaderboard · Ludo King Arena' }] }),
  component: Leaderboard,
})

function Leaderboard() {
  const { me } = useApp()
  const { data, loading } = useServer(() => getLeaderboard(), [], 60_000)
  const top = data?.top ?? []
  const [first, second, third] = top
  const podium = [
    { p: second, h: 'h-24', ring: 'ring-zinc-300' },
    { p: first, h: 'h-32', ring: 'ring-primary' },
    { p: third, h: 'h-20', ring: 'ring-amber-700' },
  ].filter((x) => x.p)
  return (
    <div>
      <PageHeader title="Leaderboard" subtitle="All-time ranking by rating from server-verified online matches." />
      {!loading && top.length === 0 && <Panel className="text-center text-sm text-muted-foreground">No ranked players yet. Win an online match to claim #1!</Panel>}

      <div className="mx-auto mb-8 grid max-w-lg grid-cols-3 items-end gap-3">
        {podium.map(({ p, h, ring }) => (
          <div key={p!.id} className="flex flex-col items-center text-center">
            {p!.rank === 1 && <Crown className="mb-1 size-6 text-primary" />}
            <Avatar initials={initialsOf(p!.name)} src={p!.avatarUrl} className={cn('size-14 ring-4', ring)} />
            <div className="mt-2 w-full truncate text-sm font-bold">{p!.name}</div>
            <div className="text-xs text-muted-foreground">{p!.rating}</div>
            <div className={cn('mt-2 grid w-full place-items-center rounded-t-xl bg-gradient-to-b from-primary/30 to-transparent font-display text-3xl font-extrabold', h)}>
              {p!.rank}
            </div>
          </div>
        ))}
      </div>

      {top.length > 3 && (
        <Panel className="p-2">
          <ol className="divide-y divide-white/5">
            {top.slice(3).map((p) => (
              <li key={p.id} className={cn('flex items-center gap-3 p-3', p.me && 'text-primary')}>
                <span className="w-8 text-center font-display font-extrabold text-muted-foreground">{p.rank}</span>
                <Avatar initials={initialsOf(p.name)} src={p.avatarUrl} className="size-9" />
                <div className="flex-1">
                  <div className="font-semibold">{p.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {p.wins.toLocaleString()} wins / {p.played} games{p.country ? ` · ${p.country}` : ''}
                  </div>
                </div>
                <span className="font-bold tabular-nums">{p.rating}</span>
              </li>
            ))}
          </ol>
        </Panel>
      )}

      <div className="sticky bottom-24 mt-4 flex items-center gap-3 rounded-2xl bg-primary p-3 text-primary-foreground shadow-xl md:bottom-4">
        <span className="w-12 text-center font-display text-lg font-extrabold">{data?.me.rank ? `#${data.me.rank}` : '—'}</span>
        <Avatar initials={initialsOf(me.displayName)} src={me.avatarUrl} className="size-9" />
        <div className="flex-1 font-bold">
          You <span className="text-xs font-semibold opacity-80">· {data?.me.wins ?? 0} wins</span>
        </div>
        <span className="font-bold tabular-nums">{data?.me.rating ?? me.rating}</span>
      </div>
    </div>
  )
}
