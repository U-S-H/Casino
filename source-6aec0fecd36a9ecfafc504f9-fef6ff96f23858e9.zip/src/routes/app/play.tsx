import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Bot, Crown, Dices, KeyRound, Lock, Search, Swords, UserPlus, Users } from 'lucide-react'
import { toast } from 'sonner'

import { PageHeader, Panel } from '@/components/brand'
import { EntryPicker, entryOk, JoinConfirmDialog, type RoomPreview } from '@/components/game/entry-picker'
import { LudoGame } from '@/components/game/ludo-board'
import { OnlineGame } from '@/components/game/online-game'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { errMsg, useServer } from '@/lib/client'
import type { Mode } from '@/lib/ludo'
import { cn } from '@/lib/utils'
import { createRoom, getActiveRoom, getLobby, joinRoomByCode, previewRoom, quickMatch, type RoomView } from '@/server/game.functions'

type PlaySearch = { mode?: Mode; room?: 'private'; code?: string }

export const Route = createFileRoute('/app/play')({
  head: () => ({ meta: [{ title: 'Play · Ludo King Arena' }] }),
  validateSearch: (s: Record<string, unknown>): PlaySearch => ({
    mode: s.mode === '1v1' || s.mode === '2v2' || s.mode === '4p' ? s.mode : undefined,
    room: s.room === 'private' ? 'private' : undefined,
    code: typeof s.code === 'string' || typeof s.code === 'number' ? String(s.code).slice(0, 6) : undefined,
  }),
  component: Play,
})

const MODES: { id: Mode; title: string; sub: string; icon: typeof Swords; players: number }[] = [
  { id: '1v1', title: '1 vs 1', sub: 'Head-to-head duel', icon: Swords, players: 2 },
  { id: '2v2', title: '2 vs 2', sub: 'Partner sits opposite', icon: Users, players: 4 },
  { id: '4p', title: '4 Players', sub: 'Classic free-for-all', icon: Crown, players: 4 },
]

function Play() {
  const search = Route.useSearch()
  const navigate = useNavigate()
  const [mode, setMode] = useState<Mode>(search.mode ?? '4p')
  const [practice, setPractice] = useState(false)
  const [room, setRoom] = useState<RoomView | null>(null)
  const [checked, setChecked] = useState(false)
  const [busy, setBusy] = useState(false)
  const [entry, setEntry] = useState(0)
  const [preview, setPreview] = useState<(RoomPreview & { password: string }) | null>(null)
  const lobby = useServer(() => getLobby({ data: { game: 'ludo' } }), [], 20_000)
  const cfg = lobby.data?.config
  const modes = MODES.filter((m) => cfg?.matchTypes.find((t) => t.id === m.id)?.enabled ?? true)
  const selected = modes.find((m) => m.id === mode) ?? modes[0] ?? MODES[0]!
  const balance = lobby.data?.balance ?? 0
  const canGo = entryOk(cfg, entry, balance)
  const entryLabel = entry > 0 ? `${entry.toLocaleString()} coins` : 'free'

  // Resume an unfinished online game after refresh/reconnect.
  useEffect(() => {
    getActiveRoom({ data: { game: 'ludo' } })
      .then((r) => r && setRoom(r))
      .catch(() => undefined)
      .finally(() => setChecked(true))
  }, [])

  const go = async (fn: () => Promise<RoomView>) => {
    setBusy(true)
    try {
      setRoom(await fn())
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(false)
    }
  }

  const exit = () => {
    setRoom(null)
    setPractice(false)
    void lobby.reload()
    void navigate({ to: '/app/play', search: { mode } })
  }

  if (room) return <OnlineGame key={room.id} initial={room} onExit={exit} />
  if (practice) return <LudoGame key={mode} mode={mode} onExit={exit} />

  return (
    <div>
      <PageHeader title="Play Ludo" subtitle="Live multiplayer with server-rolled dice. Play free or pick a virtual-coin entry." />
      {cfg && !cfg.enabled && <Panel className="mb-4 text-sm text-ludo-yellow">Ludo is temporarily disabled by the admins.</Panel>}

      <div className="grid gap-4 sm:grid-cols-3">
        {modes.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={cn('glass rounded-2xl p-5 text-left transition hover:-translate-y-0.5', mode === m.id && 'ring-2 ring-primary')}
          >
            <m.icon className={cn('size-7', mode === m.id ? 'text-primary' : 'text-muted-foreground')} />
            <div className="mt-3 font-display text-xl font-extrabold">{m.title}</div>
            <div className="text-sm text-muted-foreground">{m.sub}</div>
            <div className={cn('mt-4 text-xs font-semibold', entry > 0 ? 'text-primary' : 'text-ludo-green')}>
              {entry > 0 ? `${entry.toLocaleString()} coin entry` : 'Free entry'} · {m.players} seats
            </div>
          </button>
        ))}
      </div>

      {cfg && (
        <Panel className="mt-6">
          <EntryPicker cfg={cfg} balance={balance} players={selected.players} value={entry} onChange={setEntry} />
        </Panel>
      )}

      <Tabs defaultValue={search.room === 'private' || search.code ? 'private' : 'random'} className="mt-8">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="random">
            <Search className="size-4" /> Random match
          </TabsTrigger>
          <TabsTrigger value="private">
            <Lock className="size-4" /> Friends / private room
          </TabsTrigger>
          <TabsTrigger value="practice">
            <Bot className="size-4" /> Practice
          </TabsTrigger>
        </TabsList>

        <TabsContent value="random" className="mt-4">
          <Panel className="flex flex-col items-center gap-5 py-10 text-center">
            <Dices className="size-14 text-primary" />
            <div>
              <h2 className="text-xl font-bold">{selected.title} · Random opponents</h2>
              <p className="text-sm text-muted-foreground">
                {entry > 0
                  ? `You are matched only with players who chose the same ${entry.toLocaleString()}-coin entry. Coin matches never use bots.`
                  : 'Join an open table with real players. Empty seats are filled by bots after ~25 seconds.'}
              </p>
            </div>
            <Button size="lg" disabled={busy || !checked || !canGo} className="h-12 rounded-full px-10 text-base font-bold" onClick={() => go(() => quickMatch({ data: { game: 'ludo', mode: selected.id, entry } }))}>
              {busy ? 'Matching…' : `Find match · ${entryLabel}`}
            </Button>
          </Panel>
        </TabsContent>

        <TabsContent value="private" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Panel>
              <h2 className="flex items-center gap-2 text-lg font-bold">
                <Lock className="size-5 text-primary" /> Create a room
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">Get a 6-digit room code to share. A password is optional.</p>
              <form
                className="mt-4 space-y-3"
                onSubmit={(e) => {
                  e.preventDefault()
                  const password = String(new FormData(e.currentTarget).get('password') ?? '')
                  void go(() => createRoom({ data: { game: 'ludo', mode: selected.id, entry, password } }))
                }}
              >
                <Input name="password" maxLength={32} placeholder="Room password (optional)" />
                <Button type="submit" disabled={busy || !canGo} className="w-full font-bold">
                  <UserPlus /> Create {selected.title} room · {entryLabel}
                </Button>
              </form>
            </Panel>
            <Panel>
              <h2 className="flex items-center gap-2 text-lg font-bold">
                <KeyRound className="size-5 text-primary" /> Join a room
              </h2>
              <form
                className="mt-4 space-y-3"
                onSubmit={(e) => {
                  e.preventDefault()
                  const fd = new FormData(e.currentTarget)
                  const code = String(fd.get('code')).trim()
                  const password = String(fd.get('password') ?? '')
                  setBusy(true)
                  previewRoom({ data: { code } })
                    .then((p) => {
                      if (p.game !== 'ludo') throw new Error('That code belongs to a different game. Open it from the Games page.')
                      setPreview({ ...p, password })
                    })
                    .catch((err) => toast.error(errMsg(err)))
                    .finally(() => setBusy(false))
                }}
              >
                <div className="space-y-1.5">
                  <Label htmlFor="rid">Room code</Label>
                  <Input id="rid" name="code" required inputMode="numeric" pattern="\d{6}" defaultValue={search.code} placeholder="6 digits" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="rpass">Password (if set)</Label>
                  <Input id="rpass" name="password" maxLength={32} />
                </div>
                <Button type="submit" disabled={busy} variant="secondary" className="w-full font-bold">
                  Review entry & join
                </Button>
              </form>
            </Panel>
          </div>
        </TabsContent>

        <TabsContent value="practice" className="mt-4">
          <Panel className="flex flex-col items-center gap-4 py-10 text-center">
            <Bot className="size-12 text-primary" />
            <div>
              <h2 className="text-xl font-bold">Practice vs bots</h2>
              <p className="text-sm text-muted-foreground">Offline training match on this device. Doesn’t affect rating or history.</p>
            </div>
            <Button variant="secondary" className="rounded-full px-8 font-bold" onClick={() => setPractice(true)}>
              Start practice
            </Button>
          </Panel>
        </TabsContent>
      </Tabs>
      <JoinConfirmDialog
        preview={preview}
        busy={busy}
        onClose={() => setPreview(null)}
        onConfirm={(p) =>
          void go(async () => {
            const r = await joinRoomByCode({ data: { code: p.code, password: preview?.password ?? '', acceptEntry: p.stake.entryFee } })
            setPreview(null)
            return r
          })
        }
      />
    </div>
  )
}
