import { createFileRoute } from '@tanstack/react-router'
import { Copy, Gift, Share2, ShieldCheck } from 'lucide-react'
import { toast } from 'sonner'

import { Coins, PageHeader, Panel } from '@/components/brand'
import { StatusBadge } from '@/components/brand/tx-list'
import { Button } from '@/components/ui/button'
import { fmtDate, useApp, useServer } from '@/lib/client'
import { getReferralSummary } from '@/server/social.functions'

export const Route = createFileRoute('/app/referrals')({
  head: () => ({ meta: [{ title: 'Referrals · Ludo King Arena' }] }),
  component: Referrals,
})

function Referrals() {
  const { me, settings } = useApp()
  const { data } = useServer(() => getReferralSummary())
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ludupro.netlify.app'
  const link = `${origin}/?ref=${me.referralCode}`
  const r = settings.referral
  const shareText = `Join me on Ludo King Arena and get ${r.refereeReward + settings.welcomeBonus} free coins! ${link}`

  return (
    <div className="space-y-6">
      <PageHeader title={r.campaignName || 'Invite & earn'} subtitle="Share your link. You both earn bonus coins when your friend plays." />
      {!r.enabled && <div className="rounded-xl bg-ludo-yellow/10 p-3 text-sm text-ludo-yellow ring-1 ring-ludo-yellow/30">Referral rewards are paused right now.</div>}

      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-ludo-green/40 via-card to-primary/30 p-6 ring-1 ring-white/10">
        <Gift className="absolute -right-6 -bottom-6 size-40 opacity-10" />
        <div className="text-sm text-muted-foreground">Your referral code</div>
        <div className="font-display text-4xl font-extrabold tracking-wider">{me.referralCode}</div>
        <div className="mt-4 flex flex-col gap-2 rounded-xl bg-black/25 p-3 sm:flex-row sm:items-center">
          <code className="flex-1 truncate text-sm">{link}</code>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                void navigator.clipboard?.writeText(link)
                toast.success('Referral link copied')
              }}
            >
              <Copy /> Copy link
            </Button>
            <Button size="sm" asChild className="bg-[#25D366] text-white hover:bg-[#1ebe5a]">
              <a href={`https://wa.me/?text=${encodeURIComponent(shareText)}`} target="_blank" rel="noreferrer">
                <Share2 /> WhatsApp
              </a>
            </Button>
          </div>
        </div>
        <p className="mt-3 text-sm">
          You get <b className="text-primary">{r.referrerReward}</b> coins, your friend gets <b className="text-primary">{r.refereeReward}</b> extra coins after they play{' '}
          {r.qualifyGames} online games.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          ['Joined', data?.joined ?? 0],
          ['Qualified', data?.qualified ?? 0],
          ['Pending', data?.pending ?? 0],
        ].map(([l, v]) => (
          <Panel key={l} className="p-4 text-center">
            <div className="font-display text-2xl font-extrabold">{v}</div>
            <div className="text-xs text-muted-foreground">{l}</div>
          </Panel>
        ))}
        <Panel className="p-4 text-center">
          <Coins value={data?.earned ?? 0} className="text-2xl text-primary" />
          <div className="text-xs text-muted-foreground">Earned</div>
        </Panel>
      </div>

      <Panel>
        <h2 className="mb-2 font-bold">Referral history</h2>
        {data?.history.length === 0 && <p className="py-4 text-sm text-muted-foreground">No referred friends yet — share your link to get started.</p>}
        <ul className="divide-y divide-white/5 text-sm">
          {data?.history.map((h) => (
            <li key={h.id} className="flex items-center justify-between gap-3 py-3">
              <div>
                <div className="font-semibold">{h.name}</div>
                <div className="text-xs text-muted-foreground">
                  Joined {fmtDate(h.createdAt, false)} · {h.games}/{r.qualifyGames} games
                </div>
              </div>
              <StatusBadge status={h.status === 'flagged' ? 'under_review' : h.status} />
            </li>
          ))}
        </ul>
        <p className="mt-3 flex gap-2 text-xs text-muted-foreground">
          <ShieldCheck className="size-4 shrink-0 text-ludo-green" /> Anti-fraud: sign-ups from the same network, alias emails or above the daily cap are reviewed manually before rewards are paid.
        </p>
      </Panel>
    </div>
  )
}
