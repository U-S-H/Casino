import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Check, Clock, Copy, ImagePlus, Info } from 'lucide-react'
import { toast } from 'sonner'

import { Coins, PageHeader, Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { errMsg, METHOD_COLOR, useApp } from '@/lib/client'
import { createDeposit } from '@/server/wallet.functions'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/app/deposit')({
  head: () => ({ meta: [{ title: 'Buy coins · Ludo King Arena' }] }),
  validateSearch: (s: Record<string, unknown>): { pkg?: string } => ({
    pkg: typeof s.pkg === 'string' ? s.pkg : undefined,
  }),
  component: Deposit,
})

function Step({ n, title, done, children }: { n: number; title: string; done: boolean; children: React.ReactNode }) {
  return (
    <Panel>
      <div className="mb-4 flex items-center gap-3">
        <span
          className={cn(
            'grid size-7 place-items-center rounded-full text-xs font-bold',
            done ? 'bg-ludo-green text-white' : 'bg-primary text-primary-foreground',
          )}
        >
          {done ? <Check className="size-4" /> : n}
        </span>
        <h2 className="font-bold">{title}</h2>
      </div>
      {children}
    </Panel>
  )
}

function Deposit() {
  const { pkg } = Route.useSearch()
  const { me, settings } = useApp()
  const coinPackages = settings.coinPackages
  const paymentMethods = settings.paymentMethods
  const [pkgId, setPkgId] = useState(pkg && coinPackages.some((x) => x.id === pkg) ? pkg : (coinPackages[2]?.id ?? coinPackages[0]?.id ?? ''))
  const [methodId, setMethodId] = useState<string>(paymentMethods[0]?.id ?? 'easypaisa')
  const [tid, setTid] = useState('')
  const [sender, setSender] = useState('')
  const [shot, setShot] = useState<{ name: string; url: string; file: File } | null>(null)
  const [adult, setAdult] = useState(false)
  const [pending, setPending] = useState(false)
  const [submitted, setSubmitted] = useState<string | null>(null)

  const p = coinPackages.find((x) => x.id === pkgId)
  const m = paymentMethods.find((x) => x.id === methodId)
  const ready = tid.trim().length >= 6 && /^03\d{9}$/.test(sender) && shot && adult && !pending

  if (!p || !m) {
    return (
      <Panel className="mx-auto max-w-lg text-center">
        <p className="text-sm text-muted-foreground">Deposits are temporarily unavailable. Please check back later.</p>
      </Panel>
    )
  }

  if (submitted) {
    return (
      <div className="mx-auto max-w-lg py-10 text-center">
        <div className="mx-auto grid size-20 place-items-center rounded-full bg-primary/15 ring-2 ring-primary">
          <Clock className="size-9 text-primary" />
        </div>
        <h1 className="mt-6 text-3xl font-extrabold">Request submitted</h1>
        <p className="mt-2 text-muted-foreground">
          Request <span className="font-bold text-foreground">{submitted}</span> is with our payments team. We check the TID with{' '}
          {m.name} and credit <Coins value={p.coins + p.bonus} className="text-primary" /> once it’s confirmed — you’ll get a notification.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Button asChild className="rounded-full font-bold">
            <Link to="/app/wallet">View deposit history</Link>
          </Button>
          <Button asChild variant="outline" className="rounded-full font-bold">
            <Link to="/app">Back home</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <PageHeader title="Buy coins" subtitle="Pay with your mobile wallet, then submit your transaction ID for verification." />

      <Step n={1} title="Choose a coin package" done>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
          {coinPackages.map((x) => (
            <button
              key={x.id}
              onClick={() => setPkgId(x.id)}
              className={cn(
                'rounded-xl p-3 text-center ring-1 ring-white/10 transition',
                pkgId === x.id ? 'bg-primary/15 ring-2 ring-primary' : 'bg-white/5 hover:bg-white/10',
              )}
            >
              <div className="font-display text-lg font-extrabold">{x.coins.toLocaleString()}</div>
              {x.bonus > 0 && <div className="text-[11px] font-semibold text-ludo-green">+{x.bonus}</div>}
              <div className="mt-1 text-xs font-bold text-muted-foreground">Rs {x.price}</div>
            </button>
          ))}
        </div>
      </Step>

      <Step n={2} title="Select payment method" done>
        <div className="grid gap-2 sm:grid-cols-3">
          {paymentMethods.map((x) => (
            <button
              key={x.id}
              onClick={() => setMethodId(x.id)}
              className={cn(
                'flex items-center gap-3 rounded-xl p-3 text-left ring-1 ring-white/10 transition',
                methodId === x.id ? 'bg-primary/10 ring-2 ring-primary' : 'bg-white/5 hover:bg-white/10',
              )}
            >
              <span className="grid size-9 place-items-center rounded-lg text-xs font-extrabold text-white" style={{ background: METHOD_COLOR[x.id] }}>
                {x.name.slice(0, 2)}
              </span>
              <span className="font-semibold">{x.name}</span>
            </button>
          ))}
        </div>
      </Step>

      <Step n={3} title={`Send Rs ${p.price} via ${m.name}`} done={false}>
        <div className="rounded-xl bg-white/5 p-4">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-xs text-muted-foreground">{m.name} account</div>
              <div className="font-display text-2xl font-extrabold tracking-wider">{m.account}</div>
              <div className="text-xs text-muted-foreground">Account title: {m.accountTitle}</div>
            </div>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                void navigator.clipboard?.writeText(m.account)
                toast.success('Account number copied')
              }}
            >
              <Copy /> Copy
            </Button>
          </div>
          <div className="mt-3 flex justify-between border-t border-white/10 pt-3 text-sm">
            <span className="text-muted-foreground">Amount to send</span>
            <span className="font-bold">Rs {p.price}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">You’ll receive</span>
            <Coins value={p.coins + p.bonus} className="text-primary" />
          </div>
        </div>
      </Step>

      <Step n={4} title="Confirm your payment" done={false}>
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault()
            if (!ready || !shot) return
            const fd = new FormData()
            fd.set('packageId', p.id)
            fd.set('method', m.id)
            fd.set('tid', tid.trim())
            fd.set('sender', sender.trim())
            fd.set('screenshot', shot.file)
            setPending(true)
            try {
              const r = await createDeposit({ data: fd })
              setSubmitted(r.id)
              toast.success('Deposit request submitted for review')
            } catch (err) {
              toast.error(errMsg(err))
            } finally {
              setPending(false)
            }
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="tid">Transaction ID (TID)</Label>
            <Input id="tid" value={tid} onChange={(e) => setTid(e.target.value)} placeholder="e.g. 8823991042" className="h-11 font-mono" />
            <p className="text-xs text-muted-foreground">Find it in your {m.name} SMS or app receipt. Each TID can only be used once.</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sender">Your {m.name} number (sender)</Label>
            <Input id="sender" value={sender} onChange={(e) => setSender(e.target.value.replace(/\D/g, '').slice(0, 11))} inputMode="numeric" placeholder="03XXXXXXXXX" className="h-11 font-mono" />
          </div>
          <div className="space-y-1.5">
            <Label>Payment screenshot</Label>
            <label className="flex cursor-pointer items-center gap-4 rounded-xl border-2 border-dashed border-white/15 p-4 hover:border-primary/50">
              {shot ? (
                <img src={shot.url} alt="Payment screenshot preview" className="size-16 rounded-lg object-cover" />
              ) : (
                <span className="grid size-16 place-items-center rounded-lg bg-white/5">
                  <ImagePlus className="size-6 text-muted-foreground" />
                </span>
              )}
              <span className="text-sm">
                <span className="font-semibold">{shot ? shot.name : 'Upload screenshot'}</span>
                <span className="block text-xs text-muted-foreground">PNG, JPG or WEBP, up to 5 MB</span>
              </span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                className="sr-only"
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (!f) return
                  if (f.size > 5 * 1024 * 1024) return toast.error('Screenshot must be under 5 MB')
                  setShot({ name: f.name, url: URL.createObjectURL(f), file: f })
                }}
              />
            </label>
          </div>
          <label className="flex items-start gap-3 text-xs text-muted-foreground">
            <Checkbox checked={adult} onCheckedChange={(v) => setAdult(v === true)} className="mt-0.5" />
            I am 18 or older and this payment was made from my own account.
          </label>
          <div className="flex gap-3 rounded-xl bg-white/5 p-3 text-xs text-muted-foreground">
            <Info className="size-4 shrink-0 text-primary" />
            Coins are credited only after our team confirms the payment with {m.name}. A screenshot alone is never enough to credit coins.
          </div>
          {!me.ageConfirmed && (
            <div className="rounded-xl bg-ludo-yellow/10 p-3 text-xs text-ludo-yellow ring-1 ring-ludo-yellow/30">
              Add your date of birth in <Link to="/app/profile" className="font-bold underline">Profile → Account settings</Link> to confirm you’re 18+ before depositing.
            </div>
          )}
          <Button type="submit" disabled={!ready} className="h-11 w-full rounded-xl font-bold">
            {pending ? 'Uploading…' : 'Submit deposit request'}
          </Button>
        </form>
      </Step>
    </div>
  )
}
