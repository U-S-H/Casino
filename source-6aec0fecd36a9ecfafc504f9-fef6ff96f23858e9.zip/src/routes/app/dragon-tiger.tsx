import { Link, createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, Info, PauseCircle, ShieldCheck, Undo2, Users } from 'lucide-react'
import { toast } from 'sonner'

import { AmountPicker, BalancePill, Countdown, MyBets, newKey, OfflineBanner, RoundTag, useCasino, useNow, useWalletRefresh, VerifyDialog } from '@/components/casino/common'
import { Coins, Panel } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { errMsg } from '@/lib/client'
import { betError, card, dtSettle, type DragonTigerConfig, type DtSide } from '@/lib/games/casino'
import { cn } from '@/lib/utils'
import { cancelCasinoBet, placeCasinoBet, type CasinoState } from '@/server/casino.functions'

export const Route = createFileRoute('/app/dragon-tiger')({
  head: () => ({ meta: [{ title: 'Dragon Tiger · Ludo King Arena' }] }),
  component: DragonTiger,
})

const SIDE: Record<DtSide, { name: string; color: string; ring: string; glyph: string }> = {
  dragon: { name: 'Dragon', color: 'var(--ludo-red)', ring: 'ring-ludo-red', glyph: '龍' },
  tiger: { name: 'Tiger', color: 'var(--ludo-blue)', ring: 'ring-ludo-blue', glyph: '虎' },
  tie: { name: 'Tie', color: 'var(--ludo-green)', ring: 'ring-ludo-green', glyph: '和' },
}

/** Reveal timeline (ms after betting closes). */
const T = { dealD: 0, flipD: 700, dealT: 1100, flipT: 1800, banner: 2500 }

function DragonTiger() {
  const { state, setState, offline, skew, reload } = useCasino('dragon_tiger', 900, 1500)
  const now = useNow(skew, 100)
  const refreshWallet = useWalletRefresh()
  const [amount, setAmount] = useState(500)
  const [busy, setBusy] = useState<string | null>(null)
  const [verify, setVerify] = useState<string | undefined>(undefined)
  const [verifyOpen, setVerifyOpen] = useState(false)
  const [version, setVersion] = useState(0)
  const announced = useRef<string | null>(null)

  const round = state?.round ?? null
  const cfg = state?.config as DragonTigerConfig | undefined
  const mine = state?.myBets.filter((b) => b.roundId === round?.id) ?? []

  // Announce my result once per round, then refresh wallet + history.
  useEffect(() => {
    if (!round?.settled || announced.current === round.id) return
    if (now - new Date(round.closesAt).getTime() < T.banner) return
    announced.current = round.id
    const bets = state?.myBets.filter((b) => b.roundId === round.id) ?? []
    if (!bets.length) return
    const ret = bets.reduce((s, b) => s + b.payout, 0)
    const staked = bets.reduce((s, b) => s + b.stake, 0)
    if (ret > staked) toast.success(`You won! +${ret.toLocaleString()} coins returned`)
    else if (ret > 0) toast(`Tie: ${ret.toLocaleString()} coins returned`)
    else toast(`No win this round (−${staked.toLocaleString()})`)
    refreshWallet()
    // eslint-disable-next-line react-hooks/set-state-in-effect -- one refresh per settled round from the server poll
    setVersion((v) => v + 1)
  }, [round, now, state?.myBets, refreshWallet])

  if (!state || !cfg)
    return (
      <Shell>
        <Panel className="grid h-80 place-items-center text-muted-foreground">Loading the table…</Panel>
      </Shell>
    )

  const closes = round ? new Date(round.closesAt).getTime() : 0
  const opens = round ? new Date(round.opensAt).getTime() : 0
  const betting = !!round && round.phase === 'betting' && now < closes && now >= opens
  const elapsed = round ? now - closes : -1
  const revealTotal = round?.endsAt ? new Date(round.endsAt).getTime() - closes : 8000
  const dt = round && !betting ? round.dt : null
  const canBet = betting && cfg.enabled && !cfg.paused && !offline

  const place = async (side: DtSide) => {
    if (!round) return
    const err = betError(cfg, amount)
    if (err) return toast.error(err)
    if (amount > state.balance) return toast.error('Not enough coins in your wallet.')
    setBusy(side)
    try {
      const r = await placeCasinoBet({ data: { game: 'dragon_tiger', roundId: round.id, choice: side, amount, clientKey: newKey() } })
      toast.success(`Bet placed: ${amount.toLocaleString()} on ${SIDE[side].name}`)
      setState((s) => (s ? { ...s, balance: r.balance, myBets: [r.bet, ...s.myBets.filter((b) => b.id !== r.bet.id)] } : s))
      refreshWallet()
      void reload()
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(null)
    }
  }
  const cancel = async (betId: string) => {
    setBusy(betId)
    try {
      const r = await cancelCasinoBet({ data: { betId } })
      toast.success('Bet cancelled, coins returned')
      setState((s) => (s ? { ...s, balance: r.balance, myBets: s.myBets.filter((b) => b.id !== betId) } : s))
      refreshWallet()
      void reload()
    } catch (e) {
      toast.error(errMsg(e))
    } finally {
      setBusy(null)
    }
  }

  const odds = cfg.odds
  return (
    <Shell balance={state.balance}>
      <OfflineBanner show={offline} />
      {(cfg.paused || !cfg.enabled) && (
        <div className="flex items-center gap-2 rounded-xl bg-ludo-yellow/10 p-3 text-sm text-ludo-yellow ring-1 ring-ludo-yellow/30">
          <PauseCircle className="size-4 shrink-0" /> {cfg.enabled ? cfg.pauseMessage : 'Dragon Tiger is currently unavailable.'}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-[1fr_20rem]">
        <div className="space-y-4">
          {/* ── Table ── */}
          <div className="relative overflow-hidden rounded-3xl p-4 ring-1 ring-primary/25 sm:p-6" style={{ background: 'radial-gradient(120% 90% at 50% 0%, oklch(0.32 0.1 300), oklch(0.18 0.05 285) 70%)' }}>
            <div className="pointer-events-none absolute inset-3 rounded-[1.4rem] ring-1 ring-primary/15" />
            <div className="relative flex flex-wrap items-center justify-between gap-3">
              <RoundTag id={round?.id} hash={round?.seedHash} />
              {round && betting ? (
                <Countdown ms={closes - now} total={closes - opens} label="Place your bets" />
              ) : round ? (
                <Countdown ms={Math.max(0, revealTotal - elapsed)} total={revealTotal} label={dt ? 'Next round in' : 'Dealing…'} tone="red" />
              ) : (
                <span className="text-sm text-muted-foreground">Waiting for the next round…</span>
              )}
            </div>

            <div className="relative mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-2 sm:gap-6">
              <Seat side="dragon" cardIndex={dt?.dragon} dealt={!betting && elapsed >= T.dealD} flipped={!!dt && elapsed >= T.flipD} win={!!dt && elapsed >= T.banner && dt.winner !== 'tiger'} lose={!!dt && elapsed >= T.banner && dt.winner === 'tiger'} />
              <div className="flex flex-col items-center gap-1">
                <span className="font-display text-2xl font-extrabold text-primary sm:text-4xl">VS</span>
                <div className="h-14 w-10 rounded-md bg-[repeating-linear-gradient(45deg,oklch(0.4_0.12_300),oklch(0.4_0.12_300)_4px,oklch(0.3_0.1_300)_4px,oklch(0.3_0.1_300)_8px)] shadow-lg ring-1 ring-primary/50" title="Shoe" />
                <span className="text-[10px] tracking-widest text-muted-foreground uppercase">Shoe</span>
              </div>
              <Seat side="tiger" cardIndex={dt?.tiger} dealt={!betting && elapsed >= T.dealT} flipped={!!dt && elapsed >= T.flipT} win={!!dt && elapsed >= T.banner && dt.winner !== 'dragon'} lose={!!dt && elapsed >= T.banner && dt.winner === 'dragon'} />
            </div>

            {dt && elapsed >= T.banner && (
              <div className="splash-in pointer-events-none absolute inset-x-0 top-1/2 z-10 mx-auto w-fit -translate-y-1/2 rounded-2xl px-6 py-3 text-center shadow-2xl ring-2" style={{ background: `color-mix(in oklch, ${SIDE[dt.winner].color} 85%, black)`, borderColor: SIDE[dt.winner].color }}>
                <div className="font-display text-2xl font-extrabold tracking-wide text-white uppercase sm:text-4xl">{dt.winner === 'tie' ? 'Tie!' : `${SIDE[dt.winner].name} wins`}</div>
                <div className="text-xs text-white/80">
                  {card(dt.dragon).rank} vs {card(dt.tiger).rank}
                </div>
              </div>
            )}

            {/* ── Bet zones ── */}
            <div className="relative mt-6 grid grid-cols-[1fr_0.8fr_1fr] gap-2 sm:gap-3">
              {(['dragon', 'tie', 'tiger'] as DtSide[]).map((side) => {
                const my = mine.filter((b) => b.choice === side)
                const win = !!dt && elapsed >= T.banner && dt.winner === side
                const terms = { oddsX100: Math.round(odds[side] * 100), tieRefundPercent: cfg.tieRefundPercent, feePercent: cfg.feePercent }
                const ret = dtSettle(side, amount || cfg.minBet, terms, side).payout
                return (
                  <button
                    key={side}
                    type="button"
                    disabled={!canBet || !!busy || my.length > 0}
                    onClick={() => void place(side)}
                    className={cn(
                      'group relative overflow-hidden rounded-2xl p-3 text-center ring-2 transition enabled:hover:-translate-y-0.5 disabled:cursor-not-allowed sm:p-4',
                      SIDE[side].ring,
                      win && 'animate-pulse shadow-[0_0_30px] shadow-primary/40',
                      !canBet && !my.length && 'opacity-70',
                    )}
                    style={{ background: `linear-gradient(180deg, color-mix(in oklch, ${SIDE[side].color} 35%, transparent), color-mix(in oklch, ${SIDE[side].color} 10%, transparent))` }}
                    aria-label={`Bet on ${SIDE[side].name}, pays ${odds[side]} to 1`}
                  >
                    <div className="font-display text-lg font-extrabold uppercase sm:text-2xl">{SIDE[side].name}</div>
                    <div className="text-xs font-bold text-primary">{odds[side]}:1</div>
                    <div className="mt-1 text-[10px] text-muted-foreground sm:text-[11px]">
                      Bet {(amount || cfg.minBet).toLocaleString()} → returns {ret.toLocaleString()}
                    </div>
                    <div className="mt-2 flex items-center justify-center gap-1 text-[10px] text-muted-foreground">
                      <Users className="size-3" /> {state.totals[side].toLocaleString()}
                    </div>
                    {my.map((b) => (
                      <div key={b.id} className="mt-2 rounded-full bg-black/40 px-2 py-1 text-xs font-bold text-primary">
                        Your bet <Coins value={b.stake} />
                      </div>
                    ))}
                    {busy === side && <div className="absolute inset-0 grid place-items-center bg-black/40 text-sm font-bold">Placing…</div>}
                  </button>
                )
              })}
            </div>
            {mine.length > 0 && betting && (
              <div className="relative mt-2 flex flex-wrap justify-center gap-2">
                {mine.map((b) => (
                  <Button key={b.id} size="sm" variant="ghost" disabled={!!busy} onClick={() => void cancel(b.id)} className="text-xs">
                    <Undo2 className="size-3" /> Cancel {SIDE[b.choice as DtSide].name} bet
                  </Button>
                ))}
              </div>
            )}
          </div>

          <Panel className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-bold">Bet amount</h2>
              <span className="text-xs text-muted-foreground">Pick an amount, then tap Dragon, Tie or Tiger. The stake is deducted when the bet is accepted.</span>
            </div>
            <AmountPicker id="dt-amount" cfg={cfg} value={amount} onChange={setAmount} balance={state.balance} disabled={!cfg.enabled || cfg.paused} />
          </Panel>

          <Panel>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-bold">Recent results</h2>
              <span className="text-xs text-muted-foreground">Newest first · tap to verify</span>
            </div>
            <div className="flex gap-1.5 overflow-x-auto pb-1">
              {state.history.slice(0, 24).map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => {
                    setVerify(r.id)
                    setVerifyOpen(true)
                  }}
                  title={`${r.id}: ${r.dt ? `${card(r.dt.dragon).rank}${card(r.dt.dragon).suit} vs ${card(r.dt.tiger).rank}${card(r.dt.tiger).suit}` : ''}`}
                  className="grid size-8 shrink-0 place-items-center rounded-full text-xs font-extrabold text-white"
                  style={{ background: r.dt ? SIDE[r.dt.winner].color : 'gray' }}
                >
                  {r.dt ? SIDE[r.dt.winner].name[0] : '?'}
                </button>
              ))}
              {!state.history.length && <span className="text-sm text-muted-foreground">No rounds yet.</span>}
            </div>
            <BeadRoad history={state.history} />
          </Panel>

          <Panel>
            <h2 className="mb-2 font-bold">My bets</h2>
            <MyBets game="dragon_tiger" version={version} />
          </Panel>
        </div>

        <aside className="space-y-4">
          <Panel className="space-y-3 text-sm">
            <h2 className="flex items-center gap-2 font-bold">
              <Info className="size-4 text-primary" /> Payouts & rules
            </h2>
            <table className="w-full text-xs">
              <thead className="text-muted-foreground">
                <tr>
                  <th className="py-1 text-left">Bet</th>
                  <th className="text-right">Odds</th>
                  <th className="text-right">1,000 returns</th>
                </tr>
              </thead>
              <tbody>
                {(['dragon', 'tiger', 'tie'] as DtSide[]).map((s) => (
                  <tr key={s} className="border-t border-white/5">
                    <td className="py-1.5 font-semibold">{SIDE[s].name}</td>
                    <td className="text-right">{odds[s]}:1</td>
                    <td className="text-right font-bold tabular-nums">{dtSettle(s, 1000, { oddsX100: Math.round(odds[s] * 100), tieRefundPercent: cfg.tieRefundPercent, feePercent: cfg.feePercent }, s).payout.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <ul className="list-disc space-y-1 pl-4 text-xs text-muted-foreground">
              <li>
                Odds are <b className="text-foreground">net profit</b>: 1:1 pays your stake back plus the same again (2× total); 8:1 pays stake + 8× (9× total).
              </li>
              <li>One card is dealt to Dragon and one to Tiger from a freshly shuffled 52-card deck. The higher card wins. Suits don’t count.</li>
              <li>Card order: A (lowest), 2, 3 … 10, J, Q, K (highest).</li>
              <li>Equal ranks are a Tie. On a Tie, Dragon and Tiger bets get {cfg.tieRefundPercent}% of the stake back.</li>
              <li>{cfg.feePercent > 0 ? `A ${cfg.feePercent}% commission is taken from the profit of winning bets (never from the stake).` : 'No commission is taken from winnings.'}</li>
              <li>
                Bets: {cfg.minBet.toLocaleString()}–{cfg.maxBet.toLocaleString()} coins, one bet per box per round, max return {cfg.maxPayoutPerBet.toLocaleString()} per bet. Betting closes when the timer ends; late bets are refused.
              </li>
              <li>Wins are credited to your winnings balance automatically, even if you leave the page.</li>
            </ul>
          </Panel>

          <Panel className="space-y-2 text-xs text-muted-foreground">
            <h2 className="flex items-center gap-2 text-sm font-bold text-foreground">
              <ShieldCheck className="size-4 text-ludo-green" /> Provably fair
            </h2>
            <p>Before betting opens, the server commits to a random 256-bit seed by publishing its SHA-256 hash (shown under the round ID).</p>
            <p>
              The cards come from <span className="font-mono text-foreground">HMAC-SHA256(seed, roundId)</span>. Dragon’s card is the first 32-bit word mod 52 (unbiased rejection sampling), Tiger’s the next word mod 51 from the remaining cards. Bets and balances are not inputs.
            </p>
            <p>After the round the seed is revealed. Anyone can check the hash and recompute the cards. Admins have no way to change them.</p>
            <Button size="sm" variant="secondary" className="w-full" onClick={() => setVerifyOpen(true)}>
              Verify a round
            </Button>
          </Panel>

          <Panel>
            <h2 className="mb-2 flex items-center justify-between text-sm font-bold">
              Live bets <span className="text-xs font-normal text-muted-foreground">{state.totals.players} players</span>
            </h2>
            <LiveList state={state} />
          </Panel>
        </aside>
      </div>
      <VerifyDialog open={verifyOpen} onOpenChange={setVerifyOpen} game="dragon_tiger" initialId={verify} />
    </Shell>
  )
}

function Shell({ children, balance }: { children: React.ReactNode; balance?: number }) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Link to="/app/games" className="grid size-9 place-items-center rounded-xl bg-white/5 hover:bg-white/10" aria-label="Back to games">
            <ArrowLeft className="size-4" />
          </Link>
          <div>
            <h1 className="font-display text-2xl font-extrabold sm:text-3xl">
              <span className="text-ludo-red">Dragon</span> <span className="text-muted-foreground">·</span> <span className="text-ludo-blue">Tiger</span>
            </h1>
            <p className="text-xs text-muted-foreground">Live rounds every few seconds · results decided on the server</p>
          </div>
        </div>
        {balance != null && <BalancePill value={balance} />}
      </div>
      {children}
    </div>
  )
}

function Seat({ side, cardIndex, dealt, flipped, win, lose }: { side: 'dragon' | 'tiger'; cardIndex?: number; dealt: boolean; flipped: boolean; win: boolean; lose: boolean }) {
  const s = SIDE[side]
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="flex items-center gap-2">
        <span className="font-display text-3xl font-black sm:text-5xl" style={{ color: s.color, textShadow: `0 0 24px ${s.color}` }} aria-hidden>
          {s.glyph}
        </span>
        <span className="font-display text-lg font-extrabold tracking-wider uppercase sm:text-2xl">{s.name}</span>
      </div>
      <div className={cn('relative aspect-[5/7] w-24 rounded-xl ring-2 ring-dashed ring-white/15 transition sm:w-32', win && 'ring-primary shadow-[0_0_40px] shadow-primary/50', lose && 'opacity-60')}>
        <PlayingCard index={cardIndex} dealt={dealt} flipped={flipped} from={side === 'dragon' ? 'right' : 'left'} />
      </div>
    </div>
  )
}

/** A card that slides in from the shoe face-down, then flips. Pure CSS transitions. */
function PlayingCard({ index, dealt, flipped, from }: { index?: number; dealt: boolean; flipped: boolean; from: 'left' | 'right' }) {
  const c = index != null ? card(index) : null
  return (
    <div
      className="absolute inset-0 [perspective:800px]"
      style={{
        transform: dealt ? 'translate(0,0) rotate(0)' : `translate(${from === 'right' ? '120%' : '-120%'}, -30%) rotate(${from === 'right' ? 25 : -25}deg)`,
        opacity: dealt ? 1 : 0,
        transition: 'transform 0.55s cubic-bezier(.2,.8,.3,1), opacity 0.3s',
      }}
    >
      <div className="relative h-full w-full transition-transform duration-500 [transform-style:preserve-3d]" style={{ transform: flipped && c ? 'rotateY(0deg)' : 'rotateY(180deg)' }}>
        <div className="absolute inset-0 flex flex-col justify-between rounded-xl bg-white p-2 shadow-2xl [backface-visibility:hidden]" style={{ color: c?.red ? '#d42a3a' : '#15151f' }}>
          {c && (
            <>
              <div className="text-left leading-none font-black">
                <div className="text-xl sm:text-2xl">{c.rank}</div>
                <div className="text-lg">{c.suit}</div>
              </div>
              <div className="text-center text-4xl sm:text-5xl">{c.suit}</div>
              <div className="rotate-180 text-left leading-none font-black">
                <div className="text-xl sm:text-2xl">{c.rank}</div>
                <div className="text-lg">{c.suit}</div>
              </div>
            </>
          )}
        </div>
        <div className="absolute inset-0 rounded-xl bg-[repeating-linear-gradient(45deg,oklch(0.45_0.14_300),oklch(0.45_0.14_300)_6px,oklch(0.33_0.11_300)_6px,oklch(0.33_0.11_300)_12px)] shadow-2xl ring-4 ring-white/90 [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <div className="grid h-full place-items-center">
            <span className="rotate-45 rounded-md bg-primary/90 p-1.5 shadow" />
          </div>
        </div>
      </div>
    </div>
  )
}

/** Classic bead road: results in columns of six, oldest on the left. */
function BeadRoad({ history }: { history: CasinoState['history'] }) {
  const items = [...history].reverse().slice(-36)
  const count = (w: DtSide) => history.filter((r) => r.dt?.winner === w).length
  return (
    <div className="mt-3 flex flex-wrap items-end gap-4">
      <div className="grid grid-flow-col grid-rows-6 gap-1 rounded-xl bg-white/5 p-2">
        {items.map((r) => (
          <span key={r.id} className="grid size-5 place-items-center rounded-full text-[9px] font-black text-white" style={{ background: r.dt ? SIDE[r.dt.winner].color : 'gray' }}>
            {r.dt ? SIDE[r.dt.winner].name[0] : ''}
          </span>
        ))}
      </div>
      <div className="space-y-1 text-xs">
        {(['dragon', 'tiger', 'tie'] as DtSide[]).map((w) => (
          <div key={w} className="flex items-center gap-2">
            <span className="size-3 rounded-full" style={{ background: SIDE[w].color }} />
            {SIDE[w].name} <b className="tabular-nums">{count(w)}</b>
          </div>
        ))}
        <div className="text-muted-foreground">last {history.length} rounds</div>
      </div>
    </div>
  )
}

function LiveList({ state }: { state: CasinoState }) {
  if (!state.live.length) return <p className="text-xs text-muted-foreground">No bets in this round yet.</p>
  return (
    <ul className="max-h-64 space-y-1 overflow-y-auto text-xs">
      {state.live.map((b, i) => (
        <li key={i} className={cn('flex items-center justify-between rounded-lg px-2 py-1', b.me && 'bg-primary/10')}>
          <span className="font-semibold">{b.name}</span>
          <span className="capitalize" style={{ color: SIDE[b.choice as DtSide]?.color }}>
            {b.choice}
          </span>
          <span className="tabular-nums">{b.stake.toLocaleString()}</span>
        </li>
      ))}
    </ul>
  )
}
