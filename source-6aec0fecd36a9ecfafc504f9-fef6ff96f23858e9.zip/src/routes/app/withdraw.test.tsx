import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import type { ComponentType } from 'react'
import { beforeEach, describe, expect, it, vi } from 'vitest'

const h = vi.hoisted(() => ({
  app: {} as Record<string, unknown>,
  history: [] as unknown[],
  request: vi.fn<(arg: unknown) => Promise<{ id: string; duplicate: boolean }>>(async () => ({ id: 'WR-ABC123', duplicate: false })),
}))

vi.mock('@tanstack/react-router', () => ({
  createFileRoute: () => (opts: object) => ({ options: opts }),
  getRouteApi: () => ({ useRouteContext: () => ({}) }),
  useRouter: () => ({ invalidate: vi.fn() }),
  Link: ({ children }: { children: React.ReactNode }) => <a>{children}</a>,
}))
vi.mock('@/server/wallet.functions', () => ({ listMyWithdrawals: vi.fn(), requestWithdrawal: h.request }))
vi.mock('@/lib/client', async (orig) => ({
  ...(await orig<typeof import('@/lib/client')>()),
  useApp: () => h.app,
  useServer: () => ({ data: h.history, reload: vi.fn() }),
}))
vi.mock('sonner', () => ({ toast: { success: vi.fn(), error: vi.fn() } }))

const settings = {
  cashoutEnabled: true,
  paymentMethods: [
    { id: 'easypaisa', name: 'EasyPaisa' },
    { id: 'jazzcash', name: 'JazzCash' },
    { id: 'sadapay', name: 'SadaPay' },
  ],
  limits: { withdrawMinCoins: 1000, withdrawMaxCoins: 50000, withdrawCoinsPerPkr: 5 },
}

async function page() {
  const { Route } = await import('./withdraw')
  const C = (Route as unknown as { options: { component: ComponentType } }).options.component
  return render(<C />)
}

describe('withdraw page', () => {
  beforeEach(() => {
    h.request.mockClear()
    h.history = []
    h.app = { me: { kycStatus: 'verified' }, wallet: { winnings: 4000, reserved: 0 }, settings, refresh: vi.fn() }
  })

  it('has no coming-soon lock and submits method, own account, holder and amount', async () => {
    await page()
    expect(screen.queryByText(/coming soon/i)).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: 'SadaPay' }))
    fireEvent.change(screen.getByLabelText(/account number/i), { target: { value: '03111234567' } })
    fireEvent.change(screen.getByLabelText(/holder/i), { target: { value: 'Ali Khan' } })
    fireEvent.change(screen.getByLabelText(/coins to withdraw/i), { target: { value: '2500' } })
    expect(screen.getByText('Rs 500')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Request withdrawal' }))
    await waitFor(() => expect(h.request).toHaveBeenCalledTimes(1))
    const { data } = h.request.mock.calls[0]![0] as { data: Record<string, unknown> }
    expect(data).toMatchObject({ method: 'sadapay', accountNumber: '03111234567', accountHolder: 'Ali Khan', coins: 2500 })
    expect(String(data.idempotencyKey)).toMatch(/^[0-9a-f-]{36}$/)
  })

  it('blocks submission without KYC and while a request is open, and shows status history', async () => {
    h.app = { ...h.app, me: { kycStatus: 'none' } }
    const { unmount } = await page()
    expect((screen.getByRole('button', { name: /verify kyc/i }) as HTMLButtonElement).disabled).toBe(true)
    unmount()

    h.app = { ...h.app, me: { kycStatus: 'verified' } }
    h.history = [
      { id: 'WR-OPEN01', method: 'jazzcash', accountNumber: '03001234567', accountHolder: 'Ali', coins: 1000, amountPkr: 200, status: 'processing', paymentReference: null, adminNote: null, createdAt: new Date() },
      { id: 'WR-REJ001', method: 'easypaisa', accountNumber: '03001234567', accountHolder: 'Ali', coins: 1500, amountPkr: 300, status: 'rejected', paymentReference: null, adminNote: 'Name mismatch', createdAt: new Date() },
    ]
    await page()
    expect((screen.getByRole('button', { name: /already open/i }) as HTMLButtonElement).disabled).toBe(true)
    expect(screen.getByText(/Rejected: Name mismatch/)).toBeTruthy()
    expect(screen.getAllByText('processing').length).toBeGreaterThan(0)
  })
})
