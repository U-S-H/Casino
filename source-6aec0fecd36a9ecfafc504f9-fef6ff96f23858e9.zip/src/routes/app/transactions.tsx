import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'

import { PageHeader, Panel } from '@/components/brand'
import { TxList } from '@/components/brand/tx-list'
import { useServer } from '@/lib/client'
import { listTransactions } from '@/server/wallet.functions'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/app/transactions')({
  head: () => ({ meta: [{ title: 'Transactions · Ludo King Arena' }] }),
  component: Transactions,
})

const FILTERS: { id: string; label: string; types?: string[] }[] = [
  { id: 'all', label: 'All' },
  { id: 'deposits', label: 'Deposits', types: ['deposit'] },
  { id: 'games', label: 'Games', types: ['game_win', 'tournament'] },
  { id: 'rewards', label: 'Rewards', types: ['daily_reward', 'referral', 'promo', 'welcome', 'adjustment'] },
  { id: 'withdrawals', label: 'Withdrawals', types: ['withdrawal'] },
]

function Transactions() {
  const [filter, setFilter] = useState('all')
  const { data, loading } = useServer(() => listTransactions({ data: { limit: 200 } }))
  const transactions = data ?? []
  const f = FILTERS.find((x) => x.id === filter)!
  const items = f.types ? transactions.filter((t) => f.types!.includes(t.type)) : transactions
  return (
    <div>
      <PageHeader title="Transaction history" subtitle="Every coin movement on your account, with its transaction ID." />
      <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((x) => (
          <button
            key={x.id}
            onClick={() => setFilter(x.id)}
            className={cn(
              'shrink-0 rounded-full px-4 py-1.5 text-sm font-semibold ring-1 ring-white/10',
              filter === x.id ? 'bg-primary text-primary-foreground' : 'bg-white/5 text-muted-foreground hover:text-foreground',
            )}
          >
            {x.label}
          </button>
        ))}
      </div>
      <Panel>
        {loading ? <p className="py-10 text-center text-sm text-muted-foreground">Loading…</p> : items.length ? <TxList items={items} /> : <p className="py-10 text-center text-sm text-muted-foreground">Nothing here yet.</p>}
      </Panel>
    </div>
  )
}
