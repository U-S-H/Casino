import { Link, Outlet, createFileRoute, redirect } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import {
  Bell,
  Gamepad2,
  Gift,
  Headset,
  Home,
  LogOut,
  Medal,
  Receipt,
  Shield,
  ShieldAlert,
  Trophy,
  User,
  Users,
  Wallet,
  Wrench,
} from 'lucide-react'

import { signOut } from '@/components/auth/auth-helpers'
import { Avatar, Coins, Logo } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { initialsOf, timeAgo, useApp, useServer } from '@/lib/client'
import { getSession, recordLogin } from '@/server/account.functions'
import { listNotifications, markNotificationsRead } from '@/server/social.functions'

export const Route = createFileRoute('/app')({
  beforeLoad: async () => {
    const session = await getSession()
    if (!session.me) throw redirect({ to: '/login' })
    return { session: { me: session.me, wallet: session.wallet!, settings: session.settings } }
  },
  component: AppLayout,
})

const nav = [
  { to: '/app', label: 'Home', icon: Home, exact: true },
  { to: '/app/games', label: 'Games', icon: Gamepad2 },
  { to: '/app/tournaments', label: 'Tournaments', icon: Trophy },
  { to: '/app/wallet', label: 'Wallet', icon: Wallet },
  { to: '/app/friends', label: 'Friends', icon: Users },
  { to: '/app/referrals', label: 'Referrals', icon: Gift },
  { to: '/app/leaderboard', label: 'Leaderboard', icon: Medal },
  { to: '/app/transactions', label: 'Transactions', icon: Receipt },
  { to: '/app/support', label: 'Support', icon: Headset },
  { to: '/app/profile', label: 'Profile', icon: User },
] as const

const mobileNav = [nav[0], nav[1], nav[2], nav[3], nav[9]]

function AppLayout() {
  const { me, wallet, settings } = useApp()

  useEffect(() => {
    if (sessionStorage.getItem('lka_login_recorded')) return
    sessionStorage.setItem('lka_login_recorded', '1')
    void recordLogin().catch(() => undefined)
  }, [])

  const restricted =
    me.status === 'blocked' || (me.status === 'suspended' && (!me.suspendedUntil || new Date(me.suspendedUntil) > new Date()))

  return (
    <div className="min-h-dvh md:grid md:grid-cols-[15rem_1fr]">
      <aside className="sticky top-0 hidden h-dvh flex-col gap-1 overflow-y-auto border-r border-white/5 bg-sidebar/60 p-4 md:flex">
        <Link to="/app" className="mb-6 px-2 py-2">
          <Logo size="sm" />
        </Link>
        {nav.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            activeOptions={{ exact: 'exact' in n }}
            className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground transition hover:bg-white/5 hover:text-foreground data-[status=active]:bg-primary/15 data-[status=active]:text-primary"
          >
            <n.icon className="size-4" />
            {n.label}
          </Link>
        ))}
        <div className="mt-auto space-y-1 pt-4">
          {me.isAdmin && (
            <Link
              to="/admin"
              className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-primary hover:bg-white/5"
            >
              <Shield className="size-4" /> Admin console
            </Link>
          )}
          <button
            onClick={signOut}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground hover:bg-white/5 hover:text-foreground"
          >
            <LogOut className="size-4" /> Log out
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-col pb-24 md:pb-0">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-white/5 bg-background/70 px-4 py-3 backdrop-blur-lg md:px-8">
          <Link to="/app" className="md:hidden">
            <Logo size="sm" />
          </Link>
          <div className="ml-auto flex items-center gap-2">
            {me.isAdmin && (
              <Link to="/admin" className="grid size-9 place-items-center rounded-full bg-primary/15 text-primary ring-1 ring-primary/30 md:hidden" aria-label="Admin console">
                <Shield className="size-4" />
              </Link>
            )}
            <Link to="/app/wallet" className="rounded-full bg-white/5 px-3 py-1.5 text-sm ring-1 ring-white/10 hover:bg-white/10">
              <Coins value={wallet.available} />
            </Link>
            <NotificationBell />
            <Link to="/app/profile" aria-label="Profile">
              <Avatar initials={initialsOf(me.displayName)} src={me.avatarUrl} className="size-9" />
            </Link>
          </div>
        </header>

        <main className="mx-auto w-full max-w-content flex-1 px-4 py-6 md:px-8 md:py-8">
          {restricted ? (
            <Gate icon={ShieldAlert} title={me.status === 'blocked' ? 'Account blocked' : 'Account suspended'}>
              {me.statusReason || 'Your account is restricted.'}{' '}
              {me.status === 'suspended' && me.suspendedUntil && <>Access returns on {new Date(me.suspendedUntil).toLocaleString()}.</>}
              <div className="mt-4">
                <a href={`mailto:${settings.support.email}`} className="font-semibold text-primary hover:underline">
                  Contact support
                </a>
              </div>
            </Gate>
          ) : settings.maintenance.enabled && !me.isAdmin ? (
            <Gate icon={Wrench} title="Maintenance in progress">
              {settings.maintenance.message}
            </Gate>
          ) : (
            <>
              {settings.maintenance.enabled && (
                <div className="mb-4 rounded-xl bg-ludo-yellow/15 px-4 py-2 text-sm font-semibold text-ludo-yellow ring-1 ring-ludo-yellow/30">
                  Maintenance mode is ON — players currently see the maintenance screen.
                </div>
              )}
              <Outlet />
            </>
          )}
        </main>
      </div>

      <nav className="fixed inset-x-3 bottom-3 z-40 grid grid-cols-5 rounded-2xl glass p-1.5 shadow-2xl md:hidden">
        {mobileNav.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            activeOptions={{ exact: 'exact' in n }}
            className="flex flex-col items-center gap-0.5 rounded-xl py-2 text-[11px] font-semibold text-muted-foreground data-[status=active]:bg-primary/15 data-[status=active]:text-primary"
          >
            <n.icon className="size-5" />
            {n.label}
          </Link>
        ))}
      </nav>
    </div>
  )
}

function Gate({ icon: Icon, title, children }: { icon: typeof Wrench; title: string; children: React.ReactNode }) {
  return (
    <div className="glass mx-auto mt-10 max-w-md rounded-2xl p-8 text-center">
      <Icon className="mx-auto size-12 text-primary" />
      <h1 className="mt-4 text-2xl font-extrabold">{title}</h1>
      <div className="mt-2 text-sm text-muted-foreground">{children}</div>
      <Button variant="outline" className="mt-6 rounded-full" onClick={signOut}>
        Log out
      </Button>
    </div>
  )
}

function NotificationBell() {
  const { data, reload } = useServer(() => listNotifications(), [], 30_000)
  const [open, setOpen] = useState(false)
  const unread = data?.unread ?? 0
  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o)
        if (!o && unread) void markNotificationsRead().then(reload)
      }}
    >
      <PopoverTrigger
        className="relative grid size-9 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 hover:bg-white/10"
        aria-label={`Notifications${unread ? ` (${unread} unread)` : ''}`}
      >
        <Bell className="size-4" />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 grid min-w-4 place-items-center rounded-full bg-ludo-red px-1 text-[10px] font-bold text-white">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b px-4 py-3 text-sm font-bold">
          Notifications
          {unread > 0 && (
            <button className="text-xs font-semibold text-primary" onClick={() => void markNotificationsRead().then(reload)}>
              Mark all read
            </button>
          )}
        </div>
        <div className="max-h-96 overflow-y-auto">
          {!data?.items.length && <p className="px-4 py-6 text-center text-sm text-muted-foreground">No notifications yet.</p>}
          {data?.items.map((n) => {
            const body = (
              <>
                <div className="flex justify-between gap-2 text-sm font-semibold">
                  <span className="flex items-center gap-1.5">
                    {n.unread && <span className="size-1.5 shrink-0 rounded-full bg-primary" />}
                    {n.title}
                  </span>
                  <span className="shrink-0 text-xs font-normal text-muted-foreground">{timeAgo(n.createdAt)}</span>
                </div>
                <p className="mt-0.5 text-xs text-muted-foreground">{n.body}</p>
              </>
            )
            return n.link ? (
              <a key={n.id} href={n.link} onClick={() => setOpen(false)} className="block border-b px-4 py-3 last:border-0 hover:bg-white/5">
                {body}
              </a>
            ) : (
              <div key={n.id} className="border-b px-4 py-3 last:border-0">
                {body}
              </div>
            )
          })}
        </div>
      </PopoverContent>
    </Popover>
  )
}
