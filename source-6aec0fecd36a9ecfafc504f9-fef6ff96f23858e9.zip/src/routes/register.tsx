import { signup } from '@netlify/identity'
import { Link, createFileRoute, redirect } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { MailCheck } from 'lucide-react'
import { toast } from 'sonner'

import { AuthShell, GoogleButton, OrDivider } from '@/components/brand/auth-shell'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { getReferralCookie, setReferralCookie } from '@/lib/client'
import { getSession } from '@/server/account.functions'
import { authErrorMessage, google } from '@/components/auth/auth-helpers'

export const Route = createFileRoute('/register')({
  head: () => ({ meta: [{ title: 'Create account · Ludo King Arena' }] }),
  beforeLoad: async () => {
    const s = await getSession()
    if (s.me) throw redirect({ to: '/app' })
    return { welcomeBonus: s.settings.welcomeBonus }
  },
  component: Register,
})

function Register() {
  const { welcomeBonus } = Route.useRouteContext()
  const [sent, setSent] = useState<{ email: string; password: string; name: string } | null>(null)
  const [agreed, setAgreed] = useState(false)
  const [pending, setPending] = useState(false)
  const [ref, setRef] = useState('')
  // Cookie is only readable in the browser, so read it after hydration.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => setRef(getReferralCookie()), [])

  const doSignup = async (email: string, password: string, name: string) => {
    const user = await signup(email, password, { full_name: name, age_confirmed: true })
    if (user.confirmedAt) {
      window.location.href = '/app'
      return
    }
    setSent({ email, password, name })
  }

  if (sent) {
    return (
      <AuthShell title="Check your inbox" subtitle={`We sent a verification link to ${sent.email}.`}>
        <div className="glass flex flex-col items-center gap-4 rounded-2xl p-8 text-center">
          <MailCheck className="size-12 text-primary" />
          <p className="text-sm text-muted-foreground">
            Click the link in the email to verify your account. You’ll be signed in automatically and your {welcomeBonus} welcome coins will be waiting.
          </p>
          <Button asChild className="w-full rounded-xl font-bold">
            <Link to="/login">I’ve verified — log in</Link>
          </Button>
          <button
            className="text-xs font-semibold text-primary hover:underline"
            onClick={async () => {
              try {
                await doSignup(sent.email, sent.password, sent.name)
                toast.success('Verification email re-sent.')
              } catch (e) {
                toast.error(authErrorMessage(e))
              }
            }}
          >
            Resend email
          </button>
        </div>
      </AuthShell>
    )
  }

  return (
    <AuthShell title="Join the arena" subtitle={`Create your account and claim ${welcomeBonus} welcome coins.`}>
      <GoogleButton
        onClick={() => {
          if (!agreed) return toast.error('Please confirm you are 18+ and accept the terms first.')
          if (ref) setReferralCookie(ref)
          google()
        }}
      />
      <OrDivider />
      <form
        className="space-y-4"
        onSubmit={async (e) => {
          e.preventDefault()
          if (!agreed) return toast.error('Please confirm you are 18+ and accept the terms.')
          const fd = new FormData(e.currentTarget)
          const email = String(fd.get('email')).trim()
          const password = String(fd.get('password'))
          const name = String(fd.get('name')).trim()
          if (ref) setReferralCookie(ref)
          setPending(true)
          try {
            await doSignup(email, password, name)
          } catch (err) {
            toast.error(authErrorMessage(err))
          } finally {
            setPending(false)
          }
        }}
      >
        <fieldset disabled={pending} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Display name</Label>
            <Input id="name" name="name" required minLength={3} maxLength={24} placeholder="e.g. DiceQueen" className="h-11" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" autoComplete="email" required placeholder="you@example.com" className="h-11" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" name="password" type="password" autoComplete="new-password" required minLength={8} placeholder="At least 8 characters" className="h-11" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ref">Referral code (optional)</Label>
            <Input id="ref" value={ref} onChange={(e) => setRef(e.target.value.toUpperCase())} placeholder="FRIEND123" className="h-11 uppercase" />
          </div>
          <label className="flex items-start gap-3 text-xs text-muted-foreground">
            <Checkbox checked={agreed} onCheckedChange={(v) => setAgreed(v === true)} className="mt-0.5" />
            I confirm I am 18 or older and accept the Terms and Fair Play policy.
          </label>
          <Button type="submit" className="h-11 w-full rounded-xl font-bold">
            {pending ? 'Creating account…' : 'Create account'}
          </Button>
        </fieldset>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        Already playing?{' '}
        <Link to="/login" className="font-semibold text-primary hover:underline">
          Log in
        </Link>
      </p>
    </AuthShell>
  )
}
