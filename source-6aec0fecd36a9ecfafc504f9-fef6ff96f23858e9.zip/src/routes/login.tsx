import { login, requestPasswordRecovery } from '@netlify/identity'
import { Link, createFileRoute, redirect } from '@tanstack/react-router'
import { useState } from 'react'
import { toast } from 'sonner'

import { AuthShell, GoogleButton, OrDivider } from '@/components/brand/auth-shell'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { authErrorMessage, goToDashboard, google } from '@/components/auth/auth-helpers'
import { getSession } from '@/server/account.functions'

export const Route = createFileRoute('/login')({
  head: () => ({ meta: [{ title: 'Log in · Ludo King Arena' }] }),
  beforeLoad: async () => {
    const s = await getSession()
    if (s.me) throw redirect({ to: s.me.isAdmin ? '/admin' : '/app' })
  },
  component: Login,
})

function Login() {
  const [forgotOpen, setForgotOpen] = useState(false)
  const [pending, setPending] = useState(false)

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (pending) return
    const fd = new FormData(e.currentTarget)
    setPending(true)
    try {
      await login(String(fd.get('email')).trim(), String(fd.get('password')))
      await goToDashboard()
    } catch (err) {
      toast.error(authErrorMessage(err))
      setPending(false)
    }
  }

  return (
    <AuthShell title="Welcome back" subtitle="Log in to continue your streak.">
      <GoogleButton onClick={google} />
      <OrDivider />
      <form className="space-y-4" onSubmit={submit}>
        <fieldset disabled={pending} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" autoComplete="email" required placeholder="you@example.com" className="h-11" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              <button type="button" onClick={() => setForgotOpen(true)} className="text-xs font-semibold text-primary hover:underline">
                Forgot password?
              </button>
            </div>
            <Input id="password" name="password" type="password" autoComplete="current-password" required className="h-11" />
          </div>
          <Button type="submit" className="h-11 w-full rounded-xl font-bold">
            {pending ? 'Signing in…' : 'Log in'}
          </Button>
        </fieldset>
      </form>
      <p className="mt-6 text-center text-sm text-muted-foreground">
        New here?{' '}
        <Link to="/register" className="font-semibold text-primary hover:underline">
          Create an account
        </Link>
      </p>
      <ForgotDialog open={forgotOpen} onOpenChange={setForgotOpen} />
    </AuthShell>
  )
}

function ForgotDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [pending, setPending] = useState(false)
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Reset your password</DialogTitle>
          <DialogDescription>We’ll email you a secure link to choose a new password.</DialogDescription>
        </DialogHeader>
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault()
            const email = String(new FormData(e.currentTarget).get('email')).trim()
            setPending(true)
            try {
              await requestPasswordRecovery(email)
            } catch {
              /* don't reveal whether the account exists */
            }
            setPending(false)
            onOpenChange(false)
            toast.success('If that email has an account, a reset link is on its way.')
          }}
        >
          <Input name="email" type="email" required placeholder="you@example.com" className="h-11" />
          <Button type="submit" disabled={pending} className="h-11 w-full rounded-xl font-bold">
            {pending ? 'Sending…' : 'Send reset link'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
