import { Link, createFileRoute, redirect } from '@tanstack/react-router'
import {
  Activity,
  ArrowDownLeft,
  ArrowUpRight,
  Plane,
  Spade,
  Gamepad2,
  Gift,
  Headphones,
  LayoutDashboard,
  LogOut,
  Settings2,
  ShieldCheck,
  Swords,
  Users,
  Wallet,
} from 'lucide-react'

import { CasinoSection } from '@/components/admin/casino'
import { DepositsSection } from '@/components/admin/deposits'
import { GamesSection } from '@/components/admin/games'
import { MatchesSection } from '@/components/admin/matches'
import { AuditSection, Overview } from '@/components/admin/overview'
import { ReferralsSection } from '@/components/admin/referrals'
import { SettingsSection } from '@/components/admin/settings'
import { SupportSection } from '@/components/admin/support'
import { UsersSection } from '@/components/admin/users'
import { WalletSection } from '@/components/admin/wallet'
import { WithdrawalsSection } from '@/components/admin/withdrawals'
import { signOut } from '@/components/auth/auth-helpers'
import { Logo } from '@/components/brand'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { getSession } from '@/server/account.functions'

const SECTIONS = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'users', label: 'Users', icon: Users },
  { id: 'deposits', label: 'Deposits', icon: ArrowDownLeft },
  { id: 'withdrawals', label: 'Payouts', icon: ArrowUpRight },
  { id: 'wallet', label: 'Wallets & ledger', icon: Wallet },
  { id: 'referrals', label: 'Referrals', icon: Gift },
  { id: 'matches', label: 'Matches & coin entry', icon: Swords },
  { id: 'dragon-tiger', label: 'Dragon Tiger', icon: Spade },
  { id: 'aviator', label: 'Aviator', icon: Plane },
  { id: 'games', label: 'Games & tournaments', icon: Gamepad2 },
  { id: 'settings', label: 'Website settings', icon: Settings2 },
  { id: 'support', label: 'Support', icon: Headphones },
  { id: 'audit', label: 'Audit log', icon: Activity },
] as const
export type Section = (typeof SECTIONS)[number]['id']

export const Route = createFileRoute('/admin')({
  head: () => ({ meta: [{ title: 'Admin console · Ludo King Arena' }, { name: 'robots', content: 'noindex' }] }),
  validateSearch: (s: Record<string, unknown>): { section?: Section } => ({
    section: SECTIONS.some((x) => x.id === s.section) ? (s.section as Section) : undefined,
  }),
  // UI guard only — every admin server function re-checks the admin role on the server.
  beforeLoad: async () => {
    const s = await getSession()
    if (!s.me) throw redirect({ to: '/login' })
    if (!s.me.isAdmin) throw redirect({ to: '/app' })
    return { me: s.me }
  },
  component: Admin,
})

function Admin() {
  const { section = 'overview' } = Route.useSearch()
  const { me } = Route.useRouteContext()
  const navigate = Route.useNavigate()
  const go = (s: Section) => void navigate({ search: { section: s } })
  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[16rem_1fr]">
      <aside className="border-b border-white/5 bg-sidebar/70 p-4 lg:sticky lg:top-0 lg:h-dvh lg:overflow-y-auto lg:border-r lg:border-b-0">
        <div className="flex items-center justify-between lg:block">
          <Link to="/app" className="block px-2 py-2">
            <Logo size="sm" />
          </Link>
          <Badge variant="secondary" className="lg:mt-2 lg:ml-2">
            <ShieldCheck className="size-3" /> Admin · {me.email}
          </Badge>
        </div>
        <nav className="mt-4 flex gap-1 overflow-x-auto lg:flex-col">
          {SECTIONS.map((s) => (
            <button
              key={s.id}
              onClick={() => go(s.id)}
              className={cn(
                'flex shrink-0 items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground transition hover:bg-white/5 hover:text-foreground',
                section === s.id && 'bg-primary/15 text-primary',
              )}
            >
              <s.icon className="size-4" />
              {s.label}
            </button>
          ))}
        </nav>
        <div className="mt-4 hidden space-y-2 px-3 lg:block">
          <Link to="/app" className="block text-xs font-semibold text-muted-foreground hover:text-foreground">
            ← Back to player app
          </Link>
          <button onClick={signOut} className="flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground">
            <LogOut className="size-3" /> Log out
          </button>
        </div>
      </aside>

      <main className="min-w-0 p-4 md:p-8">
        {!me.passwordChangedAt && (
          <div className="mb-4 rounded-xl bg-ludo-yellow/10 p-3 text-sm text-ludo-yellow ring-1 ring-ludo-yellow/30">
            Security: you haven’t changed the admin password yet.{' '}
            <Link to="/app/profile" className="font-bold underline">
              Change it now
            </Link>
          </div>
        )}
        <h1 className="mb-6 text-2xl font-extrabold md:text-3xl">{SECTIONS.find((s) => s.id === section)!.label}</h1>
        {section === 'overview' && <Overview go={go} />}
        {section === 'users' && <UsersSection />}
        {section === 'deposits' && <DepositsSection />}
        {section === 'withdrawals' && <WithdrawalsSection />}
        {section === 'wallet' && <WalletSection />}
        {section === 'referrals' && <ReferralsSection />}
        {section === 'matches' && <MatchesSection />}
        {section === 'dragon-tiger' && <CasinoSection key="dt" game="dragon_tiger" />}
        {section === 'aviator' && <CasinoSection key="av" game="aviator" />}
        {section === 'games' && <GamesSection />}
        {section === 'settings' && <SettingsSection />}
        {section === 'support' && <SupportSection />}
        {section === 'audit' && <AuditSection />}
      </main>
    </div>
  )
}
