import { createFileRoute } from '@tanstack/react-router'
import { eq } from 'drizzle-orm'

import { db } from '../../../db/index.js'
import { users } from '../../../db/schema.js'
import { readBlob } from '@/server/lib/files'

export const Route = createFileRoute('/api/avatar/$userId')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const [u] = await db.select({ key: users.avatarKey }).from(users).where(eq(users.id, params.userId))
        if (!u?.key) return new Response('Not found', { status: 404 })
        const blob = await readBlob('avatars', u.key)
        if (!blob) return new Response('Not found', { status: 404 })
        return new Response(blob.bytes, {
          headers: { 'Content-Type': blob.type, 'Cache-Control': 'public, max-age=86400', 'X-Content-Type-Options': 'nosniff' },
        })
      },
    },
  },
})
