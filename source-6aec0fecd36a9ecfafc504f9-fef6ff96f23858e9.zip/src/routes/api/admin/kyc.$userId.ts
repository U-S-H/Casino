import { createFileRoute } from '@tanstack/react-router'
import { eq } from 'drizzle-orm'

import { db } from '../../../../db/index.js'
import { users } from '../../../../db/schema.js'
import { getViewer } from '@/server/lib/auth'
import { readBlob } from '@/server/lib/files'

/** KYC documents are private: only administrators can view them. */
export const Route = createFileRoute('/api/admin/kyc/$userId')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const headers = { 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' }
        const v = await getViewer()
        if (!v?.isAdmin) return new Response('Forbidden', { status: 403, headers })
        const [u] = await db.select({ key: users.kycDocKey }).from(users).where(eq(users.id, params.userId))
        if (!u?.key) return new Response('Not found', { status: 404, headers })
        const blob = await readBlob('kyc-documents', u.key)
        if (!blob) return new Response('Not found', { status: 404, headers })
        return new Response(blob.bytes, { headers: { ...headers, 'Content-Type': blob.type } })
      },
    },
  },
})
