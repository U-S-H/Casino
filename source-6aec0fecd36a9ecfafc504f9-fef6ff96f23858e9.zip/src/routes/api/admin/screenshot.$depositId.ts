import { createFileRoute } from '@tanstack/react-router'
import { eq } from 'drizzle-orm'

import { db } from '../../../../db/index.js'
import { deposits } from '../../../../db/schema.js'
import { getViewer } from '@/server/lib/auth'
import { readBlob } from '@/server/lib/files'

/** Payment screenshots are private: only administrators can view them. */
export const Route = createFileRoute('/api/admin/screenshot/$depositId')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const headers = { 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' }
        const v = await getViewer()
        if (!v?.isAdmin) return new Response('Forbidden', { status: 403, headers })
        const [d] = await db.select({ key: deposits.screenshotKey }).from(deposits).where(eq(deposits.id, params.depositId))
        if (!d?.key) return new Response('Not found', { status: 404, headers })
        const blob = await readBlob('deposit-screenshots', d.key)
        if (!blob) return new Response('Not found', { status: 404, headers })
        return new Response(blob.bytes, { headers: { ...headers, 'Content-Type': blob.type } })
      },
    },
  },
})
