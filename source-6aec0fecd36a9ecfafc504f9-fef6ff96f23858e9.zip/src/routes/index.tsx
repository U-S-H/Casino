import { Link, createFileRoute } from '@tanstack/react-router'
import {
  ArrowRight,
  Crown,
  Dices,
  Gift,
  Lock,
  ShieldCheck,
  Swords,
  Trophy,
  Users,
  Zap,
} from 'lucide-react'

import { Logo, img } from '@/components/brand'
import { Button } from '@/components/ui/button'
import { getLandingData } from '@/server/public.functions'

export const Route = createFileRoute('/')({
  loader: () => getLandingData(),
  component: Landing,
})

const modes = [
  { title: '1 vs 1 Duel', body: 'Fast head-to-head matches. Average game: 8 minutes.', icon: Swords, color: 'bg-ludo-red' },
  { title: '2 vs 2 Teams', body: 'Partner up — captures and finishes count for the team.', icon: Users, color: 'bg-ludo-green' },
  { title: '4-Player Classic', body: 'The full board, four colours, one champion.', icon: Crown, color: 'bg-ludo-yellow' },
  { title: 'Private Rooms', body: 'Room ID + password. Invite friends with one link.', icon: Lock, color: 'bg-ludo-blue' },
]

const features = [
  { icon: Zap, title: 'Live multiplayer', body: 'Real-time moves synced across Android, iOS and web.' },
  { icon: Trophy, title: 'Daily & weekly tournaments', body: 'Climb brackets, earn rankings and coin prizes.' },
  { icon: Gift, title: 'Daily rewards & referrals', body: 'Streak bonuses and rewards for every friend who joins.' },
  { icon: ShieldCheck, title: 'Fair play first', body: 'Server-validated dice and moves, anti-cheat and verified payments.' },
]

function Landing() {
  const { online, tournaments } = Route.useLoaderData()
  return (
    <div className="relative overflow-hidden">
      {/* Splash screen */}
      <div className="splash-overlay fixed inset-0 z-50 grid place-items-center bg-background">
        <div className="splash-in flex flex-col items-center gap-6">
          <Logo size="lg" />
          <div className="h-1 w-48 overflow-hidden rounded-full bg-white/10">
            <div className="splash-bar h-full rounded-full bg-primary" />
          </div>
        </div>
      </div>

      <header className="relative z-10 mx-auto flex max-w-content items-center justify-between px-5 py-5">
        <Logo />
        <div className="flex items-center gap-2">
          <Button variant="ghost" asChild>
            <Link to="/login">Log in</Link>
          </Button>
          <Button asChild className="rounded-full font-bold">
            <Link to="/register">Sign up free</Link>
          </Button>
        </div>
      </header>

      <section className="relative">
        <img
          src={img('/img/hero.png', 1600)}
          alt=""
          className="absolute inset-0 -z-0 h-full w-full object-cover object-right opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/10" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />
        <div className="relative mx-auto max-w-content px-5 pt-16 pb-28 md:pt-24 md:pb-40">
          <div className="max-w-xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-bold tracking-wide text-primary ring-1 ring-primary/30">
              <span className="size-1.5 rounded-full bg-ludo-green" /> {online > 0 ? `${online.toLocaleString()} players online now` : 'Live multiplayer · free play'}
            </span>
            <h1 className="mt-5 text-5xl leading-[0.95] font-extrabold md:text-7xl">
              Roll. Race.
              <br />
              <span className="gold-text">Rule the board.</span>
            </h1>
            <p className="mt-5 text-lg text-muted-foreground">
              Ludo King Arena is live multiplayer Ludo for friends and rivals — duels, team battles, four-player classics and
              tournaments, all in one premium arena.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="h-12 rounded-full px-7 text-base font-bold shadow-lg shadow-primary/30">
                <Link to="/app/play">
                  <Dices /> Play now
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 rounded-full px-7 text-base font-bold">
                <Link to="/app">
                  Open the arena <ArrowRight />
                </Link>
              </Button>
            </div>
            <div className="mt-10 flex gap-8 text-sm">
              {[
                ['48K+', 'players'],
                ['18K', 'games today'],
                ['4.8★', 'rating'],
              ].map(([v, l]) => (
                <div key={l}>
                  <div className="font-display text-2xl font-extrabold">{v}</div>
                  <div className="text-muted-foreground">{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-content px-5 py-16">
        <h2 className="text-3xl font-extrabold md:text-4xl">Pick your way to play</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {modes.map((m) => (
            <Link
              key={m.title}
              to="/app/play"
              className="glass group rounded-2xl p-5 transition hover:-translate-y-1 hover:ring-1 hover:ring-primary/40"
            >
              <span className={`grid size-11 place-items-center rounded-xl ${m.color} text-white shadow-lg`}>
                <m.icon className="size-5" />
              </span>
              <h3 className="mt-4 text-lg font-bold">{m.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{m.body}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto grid max-w-content gap-10 px-5 py-16 lg:grid-cols-2">
        <div>
          <h2 className="text-3xl font-extrabold md:text-4xl">Tournaments every day</h2>
          <p className="mt-3 text-muted-foreground">
            Join daily dashes, weekly cups or set up a private league for your crew. Results and rankings update automatically.
          </p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {features.map((f) => (
              <div key={f.title} className="flex gap-3">
                <f.icon className="mt-0.5 size-5 shrink-0 text-primary" />
                <div>
                  <div className="font-bold">{f.title}</div>
                  <div className="text-sm text-muted-foreground">{f.body}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="space-y-3">
          {tournaments.length === 0 && <div className="glass rounded-2xl p-6 text-sm text-muted-foreground">Daily and weekly free tournaments open as soon as you sign in.</div>}
          {tournaments.map((t) => (
            <div key={t.id} className="glass flex items-center gap-4 rounded-2xl p-4">
              <Trophy className="size-8 text-primary" />
              <div className="flex-1">
                <div className="font-bold">{t.name}</div>
                <div className="text-xs text-muted-foreground">
                  {t.mode} · {t.players}/{t.capacity} players
                </div>
              </div>
              <div className="text-right">
                <div className="font-display font-extrabold text-primary">{t.prizeCoins.toLocaleString()} coins</div>
                <div className="text-xs text-muted-foreground">{t.status === 'live' ? 'Live now · free entry' : 'Free entry'}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-content px-5 pb-20">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent/60 to-primary/30 p-10 text-center ring-1 ring-white/10">
          <h2 className="text-3xl font-extrabold md:text-4xl">Your seat at the board is waiting</h2>
          <p className="mx-auto mt-3 max-w-lg text-muted-foreground">Sign up with Google or email and claim 500 welcome coins.</p>
          <Button asChild size="lg" className="mt-6 h-12 rounded-full px-8 text-base font-bold">
            <Link to="/register">Create free account</Link>
          </Button>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8 text-center text-xs text-muted-foreground">
        <p>© 2026 Ludo King Arena. Coins are in-game currency for entertainment. 18+ for paid features.</p>
        <p className="mt-2 flex justify-center gap-4">
          <Link to="/admin" className="hover:text-foreground">Admin console</Link>
        </p>
      </footer>
    </div>
  )
}
