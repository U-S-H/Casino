# Ludo King Arena — Product Roadmap

Ludo King Arena is a live multiplayer Ludo platform with coin wallets, manual mobile-wallet deposits, tournaments, referrals and an admin console. The work is split into small milestones. Each one ships something usable on its own.

## Backend approach

Persistence, auth and server logic run on Netlify's platform, so the whole product deploys from one repo:

| Need | Platform piece |
| --- | --- |
| Accounts (Google + email/password, email verification, password reset, roles) | Netlify Identity (`@netlify/identity`) |
| Users, wallets, ledger, games, tournaments, referrals, requests, audit log | Netlify Database (Postgres + Drizzle, schema in `db/schema.ts`) |
| Payment screenshots, profile pictures, KYC documents | Netlify Blobs (private stores) |
| Wallet operations, admin actions, matchmaking | TanStack Start server functions / Netlify Functions |
| Daily tournaments, reward resets, result settlement | Netlify Scheduled Functions |

The original brief named a Firebase project. Choosing one backend keeps balances, auth and the audit trail in a single source of truth. Live moves sync by polling the database-backed room (decided in milestone 4). See `docs/backend.md` for the data model, money rules and admin setup.

## Milestones

### 1. Product surface ✅ (done)
- Splash, landing, login, registration (with email verification and forgot-password flows), home dashboard.
- A playable Ludo board for 1v1, 2v2 and 4-player games against AI opponents. It has dice animation, automatic moves, captures, safe squares, extra turns and a win animation. The rules engine in `src/lib/ludo.ts` is pure, so the server can reuse it.
- Lobby with random matchmaking, private room (Room ID + password) creation and joining, and friend invites.
- Wallet, coin packages, deposit flow (package → method → account details → TID → screenshot → submit), withdrawal screen, transaction history, friends, tournaments, leaderboard and profile (avatar, referrals, responsible play, login history).
- Admin console: overview, deposit verification, withdrawals, users (block/unblock), tournaments, referrals and promos, game config, support, admin log.
- Originally driven by fixtures; all fixtures were replaced by server functions in milestones 2–6.

### 2. Accounts & profiles ✅ (done)
- Netlify Identity: Google OAuth, email/password, email verification, password recovery.
- A `profiles` table with a unique public player ID (`LKA-XXXXXX`), display name, avatar (stored in Blobs), referral code, age confirmation, and login history captured on sign-in.
- Protect `/app/*` and redirect guests to `/login`.

### 3. Wallet ledger (server-authoritative) ✅ (done)
- Double-entry style `wallet_ledger` table. Each row has a unique transaction ID, type, bucket (purchased/bonus/winnings), amount, idempotency key and status. Balances are derived only on the server.
- Unique constraints on the idempotency key and on (method, TID) block duplicate credits.
- Daily reward claims are rate-limited and happen once per day per user, inside a single DB transaction.
- Swap the wallet and transaction fixtures for server functions.

### 4. Live multiplayer ✅ (done)
- Game state lives on the server, and every roll and move is validated by the shared `ludo.ts` engine. Dice are rolled server-side, which makes them cheat-proof.
- Matchmaking queue by mode and rating, private rooms with hashed passwords, friend invites, turn timers and forfeits on disconnect.
- **Decision needed:** the real-time channel for move sync. Options are server-sent events or polling backed by the database (simplest, all on Netlify) or a dedicated realtime provider for lower latency.
- Game history and leaderboard ratings are written when a match ends. Entry fees and payouts post to the ledger.

### 5. Deposits & admin verification ✅ (done)
- Submitting a deposit request stores the package, method, TID, and the screenshot in a private Blob.
- Admin approve/reject runs server-side, credits the ledger idempotently, writes an admin audit log entry and notifies the user.
- Admin access is gated by a server-checked Identity role (`admin`). The first admin is promoted through a one-time CLI or setup script, with no hardcoded credentials.

### 6. Tournaments & referrals ✅ (done)
- Daily and weekly tournaments created by a scheduled function, plus private tournaments created by users. Brackets, automatic result settlement and prize posting.
- Referral attribution at signup. Rewards unlock after email verification plus 3 games, with device and IP heuristics for fraud. Admin can configure reward amounts.

### 6b. Coin-entry matches & more games ✅ (done)
- Shared virtual-coin entry (200–10,000, presets + custom) for Ludo, 8 Ball Pool, Carrom and Chess. Locked amounts, deducted once at start, server-verified payouts, refunds on cancel. Admin per-game settings, match monitoring, disputes and coin history.

### 6c. Dragon Tiger & Aviator ✅ (done)
- Live shared rounds with provably-fair seeds, main-wallet stakes (200–10,000), server-side settlement and cash-outs, admin sections (config, rounds, bets, ledger, liabilities, disputes, audit).

### 7. Notifications (in-app ✅, web push pending)
- In-app notification centre backed by the database: deposit approved/rejected, invites, rewards, promos.
- Web push for the web app, and push for mobile builds in milestone 9.

### 8. Trust, safety & compliance (partly done: rate limits, KYC queue, age, limits, self-exclusion, geo-block, anti-cheat report)
- KYC (CNIC + selfie) review queue, age gating, spend limits and self-exclusion enforced on the server.
- Rate limiting on auth, deposits and game actions. Anti-cheat signals (impossible timings, multi-accounting). Transaction monitoring alerts.
- Jurisdiction checks, plus backup and restore procedures for the database.
- Withdrawals of winnings are live (`CASHOUT_ENABLED = true`, manual admin payouts). Wagering stays disabled (`WAGERING_ENABLED = false`).

### 9. Mobile apps
- Wrap the responsive web app for Android and iOS (e.g. Capacitor), add native push, and publish to the stores.
