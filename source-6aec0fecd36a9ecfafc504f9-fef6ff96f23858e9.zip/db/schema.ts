import {
  bigint,
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from 'drizzle-orm/pg-core'
import { sql } from 'drizzle-orm'

/**
 * Ludo King Arena data model (Netlify Database / Postgres).
 *
 * Money rule: balances live in `wallets` and every change is mirrored by a
 * row in `transactions` written inside the same DB transaction. Nothing in
 * the browser can write to either table — only server functions in
 * `src/server/*`.
 */

const ts = (name: string) => timestamp(name, { withTimezone: true })

export const users = pgTable(
  'users',
  {
    id: text().primaryKey(), // Netlify Identity user id
    publicId: text('public_id').notNull().unique(), // LKA-XXXXXX
    email: text().notNull(),
    displayName: text('display_name').notNull(),
    avatarKey: text('avatar_key'),
    referralCode: text('referral_code').notNull().unique(),
    referredBy: text('referred_by'),
    status: text().notNull().default('active'), // active | blocked | suspended
    statusReason: text('status_reason'),
    suspendedUntil: ts('suspended_until'),
    ageConfirmed: boolean('age_confirmed').notNull().default(false),
    dateOfBirth: text('date_of_birth'),
    kycStatus: text('kyc_status').notNull().default('not_started'), // not_started | pending | verified | rejected
    kycName: text('kyc_name'),
    kycDocNumber: text('kyc_doc_number'),
    kycDocKey: text('kyc_doc_key'),
    selfExcludedUntil: ts('self_excluded_until'),
    dailyDepositLimitPkr: integer('daily_deposit_limit_pkr'),
    rating: integer().notNull().default(1200),
    gamesPlayed: integer('games_played').notNull().default(0),
    gamesWon: integer('games_won').notNull().default(0),
    captures: integer().notNull().default(0),
    dailyStreak: integer('daily_streak').notNull().default(0),
    lastDailyClaim: text('last_daily_claim'), // YYYY-MM-DD (UTC)
    passwordChangedAt: ts('password_changed_at'),
    notificationsSeenAt: ts('notifications_seen_at'),
    signupIpHash: text('signup_ip_hash'),
    country: text(),
    createdAt: ts('created_at').notNull().defaultNow(),
    lastSeenAt: ts('last_seen_at').notNull().defaultNow(),
  },
  (t) => [index('users_rating_idx').on(t.rating), index('users_created_idx').on(t.createdAt)],
)

export const admins = pgTable('admins', {
  userId: text('user_id').primaryKey(),
  email: text().notNull(),
  grantedBy: text('granted_by').notNull(),
  grantedAt: ts('granted_at').notNull().defaultNow(),
})

export const wallets = pgTable('wallets', {
  userId: text('user_id').primaryKey(),
  purchased: bigint({ mode: 'number' }).notNull().default(0),
  bonus: bigint({ mode: 'number' }).notNull().default(0),
  winnings: bigint({ mode: 'number' }).notNull().default(0),
  reserved: bigint({ mode: 'number' }).notNull().default(0),
  updatedAt: ts('updated_at').notNull().defaultNow(),
})

export const transactions = pgTable(
  'transactions',
  {
    id: text().primaryKey(), // TX-XXXXXXXX
    userId: text('user_id').notNull(),
    type: text().notNull(), // deposit | withdrawal | daily_reward | referral | promo | adjustment | tournament | welcome | game_win
    bucket: text().notNull(), // purchased | bonus | winnings | reserved
    amount: bigint({ mode: 'number' }).notNull(),
    balanceAfter: bigint('balance_after', { mode: 'number' }).notNull(),
    label: text().notNull(),
    status: text().notNull().default('completed'),
    refType: text('ref_type'),
    refId: text('ref_id'),
    idempotencyKey: text('idempotency_key').notNull().unique(),
    createdBy: text('created_by'),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [index('transactions_user_idx').on(t.userId, t.createdAt)],
)

export const deposits = pgTable(
  'deposits',
  {
    id: text().primaryKey(), // DR-XXXXXX
    userId: text('user_id').notNull(),
    packageId: text('package_id').notNull(),
    packageName: text('package_name').notNull(),
    coins: integer().notNull(),
    bonusCoins: integer('bonus_coins').notNull().default(0),
    amountPkr: integer('amount_pkr').notNull(),
    method: text().notNull(),
    payToAccount: text('pay_to_account').notNull(),
    senderAccount: text('sender_account'),
    tid: text().notNull(),
    tidNormalized: text('tid_normalized').notNull(),
    screenshotKey: text('screenshot_key'),
    status: text().notNull().default('pending'), // pending | under_review | approved | rejected
    flags: jsonb().$type<string[]>().notNull().default([]),
    adminNote: text('admin_note'),
    reviewedBy: text('reviewed_by'),
    reviewedAt: ts('reviewed_at'),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex('deposits_method_tid_uq').on(t.method, t.tidNormalized),
    index('deposits_status_idx').on(t.status, t.createdAt),
    index('deposits_user_idx').on(t.userId, t.createdAt),
  ],
)

export const withdrawals = pgTable(
  'withdrawals',
  {
    id: text().primaryKey(), // WR-XXXXXX
    userId: text('user_id').notNull(),
    method: text().notNull(),
    accountHolder: text('account_holder').notNull(),
    accountNumber: text('account_number').notNull(),
    coins: integer().notNull(),
    /** Rupees owed for `coins`, fixed at request time from the payout rate. */
    amountPkr: integer('amount_pkr'),
    status: text().notNull().default('pending'), // pending | approved | processing | paid | rejected
    paymentReference: text('payment_reference'),
    adminNote: text('admin_note'),
    idempotencyKey: text('idempotency_key').notNull().unique(),
    reviewedBy: text('reviewed_by'),
    createdAt: ts('created_at').notNull().defaultNow(),
    updatedAt: ts('updated_at').notNull().defaultNow(),
  },
  (t) => [
    index('withdrawals_status_idx').on(t.status, t.createdAt),
    index('withdrawals_user_idx').on(t.userId),
    // One payout transaction ID can settle only one request per method.
    uniqueIndex('withdrawals_method_ref_uq').on(t.method, t.paymentReference).where(sql`${t.paymentReference} is not null`),
  ],
)

export const referrals = pgTable(
  'referrals',
  {
    id: serial().primaryKey(),
    referrerId: text('referrer_id').notNull(),
    referredId: text('referred_id').notNull().unique(),
    code: text().notNull(),
    status: text().notNull().default('pending'), // pending | rewarded | flagged | rejected
    reward: integer().notNull().default(0),
    flags: jsonb().$type<string[]>().notNull().default([]),
    createdAt: ts('created_at').notNull().defaultNow(),
    resolvedAt: ts('resolved_at'),
  },
  (t) => [index('referrals_referrer_idx').on(t.referrerId)],
)

export interface SeatInfo {
  userId: string | null
  name: string
  isBot: boolean
  missed: number
  /** Coin-entry matches: the account that owns this seat (kept even if the seat is handed to a bot). */
  owner?: string
  /** Coin-entry matches: the player accepted the locked entry amount. */
  confirmed?: boolean
  /** The player left or forfeited — never eligible for a prize. */
  forfeited?: boolean
  /** Coin-entry matches: how the entry was taken from each wallet bucket (for exact refunds). */
  paid?: { bonus: number; purchased: number; winnings: number }
}

export const gameRooms = pgTable(
  'game_rooms',
  {
    id: text().primaryKey(),
    code: text().notNull().unique(), // 6-digit room code
    game: text().notNull().default('ludo'), // ludo | pool | carrom | chess
    mode: text().notNull(), // match type — ludo: 1v1 | 2v2 | 4p; others: classic | quick | rapid | blitz
    isPrivate: boolean('is_private').notNull().default(false),
    passwordHash: text('password_hash'),
    hostId: text('host_id').notNull(),
    status: text().notNull().default('waiting'), // waiting | playing | finished | abandoned
    seats: jsonb().$type<SeatInfo[]>().notNull(),
    state: jsonb().$type<Record<string, unknown> | null>(),
    version: integer().notNull().default(0),
    turnDeadline: ts('turn_deadline'),
    tournamentId: text('tournament_id'),
    /** Virtual-coin entry per player, locked when the room is created. 0 = free match. */
    entryFee: integer('entry_fee').notNull().default(0),
    /** Platform fee % snapshotted at room creation so later admin changes never affect it. */
    feePercent: integer('fee_percent').notNull().default(0),
    /** none (free) | pending (not charged yet) | charged | paid | refunded */
    stakeStatus: text('stake_status').notNull().default('none'),
    result: jsonb().$type<{ winners: string[]; reason: string; prizes: Record<string, number>; fee: number; pool: number; draw?: boolean } | null>(),
    cancelReason: text('cancel_reason'),
    disputed: boolean().notNull().default(false),
    startedAt: ts('started_at'),
    endedAt: ts('ended_at'),
    createdAt: ts('created_at').notNull().defaultNow(),
    updatedAt: ts('updated_at').notNull().defaultNow(),
  },
  (t) => [
    index('rooms_status_idx').on(t.status, t.mode, t.isPrivate),
    index('rooms_game_idx').on(t.game, t.status, t.entryFee),
    index('rooms_stake_idx').on(t.stakeStatus, t.updatedAt),
  ],
)

export const matchReports = pgTable(
  'match_reports',
  {
    id: serial().primaryKey(),
    roomId: text('room_id').notNull(),
    userId: text('user_id').notNull(),
    reason: text().notNull(),
    status: text().notNull().default('open'), // open | resolved | dismissed
    resolution: text(),
    resolvedBy: text('resolved_by'),
    createdAt: ts('created_at').notNull().defaultNow(),
    resolvedAt: ts('resolved_at'),
  },
  (t) => [index('match_reports_status_idx').on(t.status, t.createdAt), uniqueIndex('match_reports_room_user_uq').on(t.roomId, t.userId)],
)

export const roomMessages = pgTable(
  'room_messages',
  {
    id: serial().primaryKey(),
    roomId: text('room_id').notNull(),
    userId: text('user_id').notNull(),
    name: text().notNull(),
    text: text().notNull(),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [index('room_messages_room_idx').on(t.roomId, t.id)],
)

export const games = pgTable(
  'games',
  {
    id: text().primaryKey(),
    roomId: text('room_id').notNull(),
    game: text().notNull().default('ludo'),
    mode: text().notNull(),
    entryFee: integer('entry_fee').notNull().default(0),
    prizePool: integer('prize_pool').notNull().default(0),
    platformFee: integer('platform_fee').notNull().default(0),
    reason: text(),
    players: jsonb().$type<{ userId: string | null; name: string; color: string; team: number; won: boolean; finished: number }[]>().notNull(),
    winnerTeam: integer('winner_team'),
    tournamentId: text('tournament_id'),
    turns: integer().notNull().default(0),
    startedAt: ts('started_at').notNull(),
    endedAt: ts('ended_at').notNull().defaultNow(),
  },
  (t) => [index('games_ended_idx').on(t.endedAt)],
)

export const gamePlayers = pgTable(
  'game_players',
  {
    gameId: text('game_id').notNull(),
    userId: text('user_id').notNull(),
    won: boolean().notNull(),
    ratingDelta: integer('rating_delta').notNull().default(0),
    endedAt: ts('ended_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.gameId, t.userId] }), index('game_players_user_idx').on(t.userId, t.endedAt)],
)

export const tournaments = pgTable(
  'tournaments',
  {
    id: text().primaryKey(),
    name: text().notNull(),
    kind: text().notNull(), // daily | weekly | private
    mode: text().notNull(),
    entryFee: integer('entry_fee').notNull().default(0), // forced to 0 while wagering is disabled
    prizeCoins: integer('prize_coins').notNull().default(0), // promotional bonus coins
    capacity: integer().notNull().default(64),
    inviteCode: text('invite_code'),
    startsAt: ts('starts_at').notNull(),
    endsAt: ts('ends_at').notNull(),
    status: text().notNull().default('upcoming'), // upcoming | live | finished | cancelled
    createdBy: text('created_by').notNull(),
    settledAt: ts('settled_at'),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [index('tournaments_status_idx').on(t.status, t.startsAt)],
)

export const tournamentEntries = pgTable(
  'tournament_entries',
  {
    tournamentId: text('tournament_id').notNull(),
    userId: text('user_id').notNull(),
    points: integer().notNull().default(0),
    wins: integer().notNull().default(0),
    games: integer().notNull().default(0),
    rank: integer(),
    prize: integer().notNull().default(0),
    joinedAt: ts('joined_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.tournamentId, t.userId] }), index('entries_user_idx').on(t.userId)],
)

export const notifications = pgTable(
  'notifications',
  {
    id: serial().primaryKey(),
    userId: text('user_id'), // null + audience='admins' → visible to every admin; null + audience='all' → broadcast
    audience: text().notNull().default('user'), // user | admins | all
    kind: text().notNull(),
    title: text().notNull(),
    body: text().notNull(),
    link: text(),
    readAt: ts('read_at'),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [index('notifications_user_idx').on(t.userId, t.createdAt), index('notifications_aud_idx').on(t.audience, t.createdAt)],
)

export const settings = pgTable('settings', {
  key: text().primaryKey(),
  value: jsonb().notNull(),
  updatedBy: text('updated_by'),
  updatedAt: ts('updated_at').notNull().defaultNow(),
})

export const auditLogs = pgTable(
  'audit_logs',
  {
    id: serial().primaryKey(),
    actorId: text('actor_id').notNull(),
    actorEmail: text('actor_email').notNull(),
    action: text().notNull(),
    targetType: text('target_type'),
    targetId: text('target_id'),
    details: jsonb().$type<Record<string, unknown>>(),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [index('audit_created_idx').on(t.createdAt)],
)

export const supportTickets = pgTable(
  'support_tickets',
  {
    id: text().primaryKey(), // ST-XXXXXX
    userId: text('user_id').notNull(),
    subject: text().notNull(),
    message: text().notNull(),
    category: text().notNull().default('general'),
    priority: text().notNull().default('medium'),
    status: text().notNull().default('open'), // open | answered | closed
    adminReply: text('admin_reply'),
    createdAt: ts('created_at').notNull().defaultNow(),
    updatedAt: ts('updated_at').notNull().defaultNow(),
  },
  (t) => [index('tickets_status_idx').on(t.status, t.createdAt), index('tickets_user_idx').on(t.userId)],
)

export const loginHistory = pgTable(
  'login_history',
  {
    id: serial().primaryKey(),
    userId: text('user_id').notNull(),
    userAgent: text('user_agent'),
    ipHash: text('ip_hash'),
    country: text(),
    city: text(),
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [index('login_history_user_idx').on(t.userId, t.createdAt)],
)

export const friendships = pgTable(
  'friendships',
  {
    requesterId: text('requester_id').notNull(),
    addresseeId: text('addressee_id').notNull(),
    status: text().notNull().default('pending'), // pending | accepted
    createdAt: ts('created_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.requesterId, t.addresseeId] }), index('friend_addressee_idx').on(t.addresseeId)],
)

export const rateLimits = pgTable('rate_limits', {
  key: text().primaryKey(),
  windowStart: ts('window_start').notNull(),
  count: integer().notNull().default(0),
})

/**
 * Dragon Tiger and Aviator rounds. One shared round per game at a time; every
 * player bets on the same round. `server_seed` is drawn when the round is
 * created and only `seed_hash` is shown until the round settles. A database
 * trigger (see migration add_casino_games) makes the commitment columns
 * immutable and freezes a round once it is settled; rounds can't be deleted.
 */
export const casinoRounds = pgTable(
  'casino_rounds',
  {
    id: text().primaryKey(), // DT-0000001 / AV-0000001
    game: text().notNull(), // dragon_tiger | aviator
    roundNo: integer('round_no').notNull(),
    status: text().notNull().default('betting'), // betting | settled
    serverSeed: text('server_seed').notNull(),
    seedHash: text('seed_hash').notNull(),
    /** Round terms fixed at creation (aviator: edgeBps, maxX100). */
    params: jsonb().$type<Record<string, number>>().notNull(),
    opensAt: ts('opens_at').notNull(),
    /** Betting closes (Dragon Tiger: cards revealed; Aviator: take-off). */
    closesAt: ts('closes_at').notNull(),
    /** When the result happens (Aviator: crash time — secret until then). */
    resultAt: ts('result_at').notNull(),
    endsAt: ts('ends_at').notNull(),
    result: jsonb().$type<Record<string, unknown>>(),
    betCount: integer('bet_count').notNull().default(0),
    totalStake: bigint('total_stake', { mode: 'number' }).notNull().default(0),
    totalPayout: bigint('total_payout', { mode: 'number' }).notNull().default(0),
    createdAt: ts('created_at').notNull().defaultNow(),
    settledAt: ts('settled_at'),
  },
  (t) => [
    uniqueIndex('casino_rounds_game_no_uq').on(t.game, t.roundNo),
    index('casino_rounds_due_idx').on(t.game, t.status, t.resultAt),
    index('casino_rounds_created_idx').on(t.game, t.createdAt),
  ],
)

export const casinoBets = pgTable(
  'casino_bets',
  {
    id: text().primaryKey(), // BT-XXXXXXXXXX
    roundId: text('round_id').notNull(),
    game: text().notNull(),
    userId: text('user_id').notNull(),
    /** dragon | tiger | tie, or the Aviator bet slot ("1" | "2"). */
    choice: text().notNull(),
    stake: bigint({ mode: 'number' }).notNull(),
    /** Terms locked when the bet was placed. */
    terms: jsonb().$type<Record<string, number | null>>().notNull(),
    /** Aviator: effective automatic cash-out ×100 (player target, max multiplier or max payout). */
    autoX100: integer('auto_x100'),
    status: text().notNull().default('active'), // active | won | lost | push | cancelled
    cashoutX100: integer('cashout_x100'),
    payout: bigint({ mode: 'number' }).notNull().default(0),
    fee: bigint({ mode: 'number' }).notNull().default(0),
    /** Buckets the stake was taken from (exact refunds on cancel). */
    paid: jsonb().$type<{ bonus: number; purchased: number; winnings: number }>().notNull(),
    clientKey: text('client_key').notNull(),
    createdAt: ts('created_at').notNull().defaultNow(),
    settledAt: ts('settled_at'),
  },
  (t) => [
    uniqueIndex('casino_bets_round_user_choice_uq').on(t.roundId, t.userId, t.choice).where(sql`status <> 'cancelled'`),
    uniqueIndex('casino_bets_user_key_uq').on(t.userId, t.clientKey),
    index('casino_bets_round_idx').on(t.roundId, t.status),
    index('casino_bets_user_idx').on(t.userId, t.createdAt),
    index('casino_bets_game_idx').on(t.game, t.createdAt),
  ],
)

export const casinoDisputes = pgTable(
  'casino_disputes',
  {
    id: serial().primaryKey(),
    betId: text('bet_id').notNull(),
    roundId: text('round_id').notNull(),
    game: text().notNull(),
    userId: text('user_id').notNull(),
    reason: text().notNull(),
    status: text().notNull().default('open'), // open | resolved | dismissed
    resolution: text(),
    resolvedBy: text('resolved_by'),
    createdAt: ts('created_at').notNull().defaultNow(),
    resolvedAt: ts('resolved_at'),
  },
  (t) => [index('casino_disputes_status_idx').on(t.game, t.status, t.createdAt), uniqueIndex('casino_disputes_bet_user_uq').on(t.betId, t.userId)],
)
