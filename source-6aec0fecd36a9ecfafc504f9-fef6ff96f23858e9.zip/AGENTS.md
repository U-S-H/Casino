# AGENTS.md

Guide for AI agents and developers working on **Ludo King Arena**, a live multiplayer Ludo platform.

**Start with [PLAN.md](PLAN.md)** and **[docs/backend.md](docs/backend.md)**. Milestones 1–6 are done; 7 (web push) and 8 (remaining compliance) are partly done.

## Stack

TanStack Start (React 19, TanStack Router, Vite 8), Tailwind CSS 4, shadcn/ui (Radix), lucide-react, sonner toasts, TypeScript strict. Deployed on Netlify with `@netlify/vite-plugin-tanstack-start`. Persistence will use Netlify primitives: Identity, Database (Drizzle, `db/schema.ts`) and Blobs.

## Layout

```
src/
  lib/
    ludo.ts          Pure Ludo rules engine (track geometry, moves, captures, teams, bot AI). Reuse it server-side.
    ludo.test.ts     Engine unit tests.
    games/           Pure engines for pool/carrom/chess (deterministic physics/rules, shared by server + client) and catalog.ts (game config, prize maths).
    client.tsx       Client helpers: useServer (load/poll), useAction (mutation + toast), useApp (session from /app guard), errMsg.
  server/
    *.functions.ts   Server functions (account, wallet, game, social, tournament, admin, public). All auth checks live here.
    lib/             auth (viewer/admin bootstrap), ledger, rooms (multiplayer engine), tournaments, settings, files, ratelimit, audit.
    integration.test.ts  DB integration tests (run with LKA_IT_DB=…).
db/                  Drizzle schema + client. Migrations in netlify/database/migrations (generate with drizzle-kit).
  components/
    brand/           Logo, Coins, Avatar, Panel, PageHeader, img() helper, AuthShell, TxList.
    game/ludo-board.tsx  Board renderer + turn state machine (roll → choose → animate → next turn), dice, win overlay.
    ui/              shadcn/ui primitives.
  routes/
    index.tsx        Landing + CSS-only splash overlay.
    login.tsx, register.tsx
    app.tsx          Player shell: desktop sidebar, mobile bottom nav, header with coins + notifications.
    app/*.tsx        index (home), play, wallet, deposit, withdraw, transactions, friends, tournaments, leaderboard, profile.
    admin.tsx        Admin console shell (?section=…); sections in components/admin/*. Guarded + every admin fn re-checks.
public/img/hero.png  Generated hero art. Always serve it through img() → /.netlify/images.
```

## Conventions

- Dark premium theme only: `<html class="dark">`, and `:root`/`.dark` share the same palette in `src/styles.css`. Ludo colours are `bg-ludo-red|green|yellow|blue` (CSS vars `--ludo-*`). Gold `primary` is the accent. Reusable utilities: `.glass`, `.gold-text`, `.coin`.
- Fonts: Bricolage Grotesque for headings (`font-display`), Manrope for body text. Both load from Google Fonts in `__root.tsx`.
- Screens load data only through server functions in `src/server/`. Never compute balances in the browser.
- Every protected server function calls `requireViewer()` or `requireAdmin()`; route guards are UX only.
- Schema changes: edit `db/schema.ts`, then `npx drizzle-kit generate --name <verb_noun>`.
- Unused imports or locals fail the TypeScript build.

## Non-obvious decisions

- **Never trust client balances.** Wallet numbers in the UI are display-only. The server-side ledger (`postLedger`) uses idempotency keys; deposits have a unique (method, TID) index.
- **Deposits are never auto-credited.** An admin verifies the TID with the provider. The screenshot is only supporting evidence.
- **Withdrawals** (`CASHOUT_ENABLED = true`, enabled by the owner on 2026-11-05) go only through `src/server/lib/withdrawals.ts`. Only the winnings bucket is withdrawable. Request reserves winnings → reserved under a wallet row lock (one open request per user); admin flow pending → approved → processing → paid (needs a payment reference, unique per method) or rejected (needs a reason, returns coins). Payouts are sent manually by an admin; the rupee amount is fixed at request time from `limits.withdrawCoinsPerPkr`. `WAGERING_ENABLED` stays false.
- Admin access is enforced server-side (`admins` table + Identity `admin` role). The primary admin comes from `ADMIN_EMAILS` (default webhub262@gmail.com) on confirmed login. Never hardcode admin credentials.
- The board uses a 15×15 grid. Token progress is relative to each colour's start: -1 is the yard, 0–50 the track, 51–55 the home column, 56 finished. Tokens are absolutely positioned in % units so movement animates with CSS transitions.
- **Coin entry** (all games) goes only through `src/server/lib/stakes.ts`: amount locked at room creation, charged once at start, paid once after the server decides the result. Never pay or charge anywhere else. Pool/carrom physics must stay deterministic (no trig/random in `simulate`) because the client replays shots.
- **Dragon Tiger & Aviator** (`src/server/lib/casino.ts`) are shared house-banked rounds driven by a stored schedule + `tick()` on every poll (plus a per-minute scheduled settler). Results come only from the committed seed (HMAC-SHA256); DB triggers make rounds/bets immutable once settled. Never add an admin control that sets results. Stakes/wins go only through that file (ledger types `casino_*`).
- Game timers live in refs (`gameRef`, `timers`) so bot turns and step animations never read stale state.
