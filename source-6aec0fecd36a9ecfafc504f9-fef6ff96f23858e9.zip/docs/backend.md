# Backend, security & operations

Ludo King Arena runs entirely on Netlify: Identity for accounts, Netlify Database (Postgres) for data, Blobs for private files, TanStack Start server functions for all business logic, and a scheduled function for tournaments.

## Service mapping (requested Firebase service → what is used)

| Requested | Implemented with | Where |
| --- | --- | --- |
| Firebase Authentication (Google, email/password, verification, reset) | Netlify Identity (`@netlify/identity`) | `src/routes/login.tsx`, `register.tsx`, `src/components/auth/*` |
| Custom claims for admins | Identity `app_metadata.roles = ['admin']` **plus** the server-side `admins` table (authoritative) | `src/server/lib/auth.ts` |
| Firestore / Realtime Database | Netlify Database (Postgres + Drizzle) | `db/schema.ts`, `netlify/database/migrations/` |
| Storage | Netlify Blobs (private stores `avatars`, `deposit-screenshots`, `kyc-documents`) | `src/server/lib/files.ts` |
| Cloud Functions | TanStack Start server functions + Netlify scheduled function | `src/server/*.functions.ts`, `netlify/functions/tournament-scheduler.mts` |
| Security Rules | Server-side checks in every function (no client ever talks to the database) | `requireViewer()` / `requireAdmin()` |
| Cloud Messaging | In-app notification centre (polling). Web push is **not** implemented yet. | `notifications` table, bell in `src/routes/app.tsx` |

## Tables (`db/schema.ts`)

`users`, `admins`, `wallets`, `transactions`, `deposits`, `withdrawals`, `referrals`, `games`, `game_players`, `game_rooms`, `room_messages`, `match_reports`, `tournaments`, `tournament_entries`, `notifications`, `settings`, `audit_logs`, `support_tickets`, `login_history`, `friendships`, `rate_limits`.

Key constraints and indexes:

- `deposits (method, tid_normalized)` **unique** — the same TID can never be submitted twice per provider (spacing/case/dashes are normalised).
- `transactions.idempotency_key` **unique** — every balance change has exactly one ledger row; retries are no-ops.
- `withdrawals.idempotency_key` unique; `referrals.referred_id` unique (one referrer per user).
- Indexes on status/time for every admin queue, and on user/time for every history list.

## Money rules

- Balances live only in `wallets` (buckets: purchased, bonus, winnings, reserved). They change only through `postLedger()` (`src/server/lib/ledger.ts`) inside a DB transaction, which writes the ledger row with a `TX-…` id and the resulting balance. Debits are conditional updates and can never go below zero.
- Deposits are never auto-credited. The admin must tick “I verified this TID and amount in the provider’s statement” before approving; approval is a conditional status update (`pending|under_review → approved`) in the same transaction as the credit, so double approval is impossible.
- Withdrawals (`src/server/lib/withdrawals.ts`) reserve winnings atomically (winnings → reserved, ledger row `pending`) under a wallet row lock, one open request per user, idempotent per client key. Admin flow: pending → approved → processing → paid (reserved released, ledger row `completed`; payment reference unique per method) or rejected (reason required; reserved returned to winnings, ledger row `refunded` plus a credit). `amount_pkr` is fixed at request time from `limits.withdrawCoinsPerPkr`. `CASHOUT_ENABLED = true` and `WAGERING_ENABLED = false` are code constants in `src/server/lib/settings.ts`; no admin setting can change them.
- Every admin action writes `audit_logs`.

## Multiplayer

Game state is stored in `game_rooms.state` and only ever changed on the server. Dice use `crypto.randomInt`; moves are validated with the shared rules engine (`src/lib/ludo.ts`). Writes use optimistic locking (`version` column). Clients poll every ~0.9 s; each poll also advances bots and turn timeouts (3 missed turns → bot takes over). Finished games write `games`, `game_players`, ratings, tournament points and referral qualification.

## Coin-entry matches (all four games)

One shared system in `src/server/lib/stakes.ts` covers Ludo, 8 Ball Pool, Carrom and Chess. Prizes land in the winnings bucket, which players can withdraw through the withdrawal flow.

- **Config:** stored in `settings` under key `arena` (defaults in `src/lib/games/catalog.ts`). Per game: enabled, coin entry on/off, custom amounts, min/max (200–10,000), presets, platform fee %, prize split (Ludo matches with 3–4 sides), and match types. Edited in Admin → Matches & coin entry. Every save is audit-logged.
- **Locking:** a room's `entry_fee` and `fee_percent` are fixed when the room is created. Joiners preview the entry, prize pool, fee and their balance (`previewRoom`), then must send `acceptEntry` equal to the locked amount. Matchmaking pairs only players who picked the exact same entry. Coin rooms never use bots.
- **`stake_status` lifecycle:** `pending` → `charged` (when the room starts, every seat is debited bonus → purchased → winnings in one transaction with the status flip; idempotency key `entry:<room>:<user>:<bucket>`) → `paid` (server-verified result; key `prize:<room>:<user>`). Before the start, `cancelled` means nothing was deducted. After the start, `refunded` means an admin or system void returned the exact buckets. All transitions are conditional updates, so retries are no-ops.
- **Prize:** pool = entry × seats, fee = floor(pool × fee%), winner gets the rest (2v2 teams split it). A chess draw returns the entries with no fee. Seats that leave or forfeit (3 missed turns, or leaving mid-match) never receive a prize. When only one side is left, it wins immediately.
- **Repair:** finished matches stuck at `charged` are re-settled on the next poll, or with Admin → Retry payout. Players can report a match (`match_reports`); admins resolve, dismiss, or cancel and refund.

## Arena games (8 Ball Pool, Carrom, Chess)

Pure engines live in `src/lib/games/{pool,carrom,chess}.ts` (contract in `types.ts`). The server (`src/server/lib/arena.ts`) runs `apply`, which for pool and carrom includes the full deterministic physics simulation, and decides the winner. Clients send only intents (move, or direction + power) and replay `lastShot`/`lastStrike` locally with the same `simulate()`. Turn clocks are per match type. A timeout calls `engine.timeout`, and 3 missed turns in a row forfeit.

## Dragon Tiger & Aviator (live rounds)

Shared, house-banked rounds: every player bets on the same round. Engine/maths in `src/lib/games/casino.ts` (shared with the browser for display and verification), server logic in `src/server/lib/casino.ts`, player functions in `src/server/casino.functions.ts`, admin functions in `src/server/casino-admin.functions.ts`. Tables: `casino_rounds`, `casino_bets`, `casino_disputes`. Config lives in `settings` key `casino`.

- **Schedule, no game server:** each round row stores `opens_at`, `closes_at` (betting ends), `result_at` (DT reveal / Aviator crash time) and `ends_at`. Every player poll calls `tick()` (settle due rounds, open the next, pay due Aviator auto cash-outs); the scheduled function `netlify/functions/casino-settler.mts` runs `settleDue()` every minute so rounds settle even with nobody online.
- **Provably fair:** `server_seed` = 32 random bytes, `seed_hash` = SHA-256(seed) published before betting; result = f(HMAC-SHA256(seed, roundId)). Dragon Tiger: single 52-card deck, rejection-sampled, Ace low / King high, suits ignored. Aviator: crash = ⌊(100−edge)·2⁵²/(2⁵²−h)⌋/100 with h = first 52 bits, min 1.00x, capped at the round's max. Multiplier curve m(t) = e^(0.07·t). Seeds are revealed only when the round settles; the crash time is hidden from clients until it passes. Players verify in the browser (`fairDigests`).
- **Immutability:** DB triggers (migration `add_casino_games`) block changing a round's seed/hash/params/times, any change to a settled round or bet, and deletes. There is no admin function that sets or edits a result.
- **Money:** stake deducted on acceptance (bonus → purchased → winnings, wallet row `FOR UPDATE`) in the same transaction as the bet insert; `client_key` makes retries idempotent; one bet per side/slot per round. Wins credit the winnings bucket. Ledger keys `cas:bet:<bet>:<bucket>`, `cas:cancel:<bet>:<bucket>`, `cas:pay:<bet>`, `cas:loss:<bet>` (0-coin row so losses appear in history). Types `casino_bet|casino_win|casino_loss|casino_refund`, `ref_type` = game.
- **Odds:** Dragon Tiger odds are net profit (1:1 returns 2×, 8:1 returns 9×); a tie returns `tieRefundPercent` (default 50%) of Dragon/Tiger stakes; optional commission comes from profit only. Aviator pays ⌊stake × multiplier⌋.
- **Cash-out:** server receive time decides; must be before `result_at`; multiplier computed server-side. Settlement waits 600 ms after the crash for in-flight requests and runs under the round row lock, so a cash-out and the crash can't both win. Auto targets are capped by max multiplier and max payout per bet.
- **Limits:** min/max bet, max payout per bet, max worst-case exposure per round (new bets refused above it), pause/disable (open rounds still settle).
- Tests: `src/lib/games/casino.test.ts`; `LKA_IT_DB=… npx vitest run src/server/casino.integration.test.ts`. The local DB emulator shares one session across connections, so same-wallet race tests (and the two concurrency tests in `withdrawals.integration.test.ts`) only pass against a real Postgres (`LKA_IT_REAL_PG=1`).

## First administrator (secure setup)

No password is stored anywhere in this repository or database.

1. Netlify dashboard → **Project configuration → Identity**: confirm registration is open and **Autoconfirm is off** (email verification on). Enable **Google** under External providers.
2. Create the account `webhub262@gmail.com`: either sign up at `/register`, or in the Identity tab click **Invite users** (the invite email lets the owner choose the password).
3. Confirm the email, then log in. On login the server sees the email is in `ADMIN_EMAILS` (default `webhub262@gmail.com`, override with a server-side env var), so it records the user in `admins` and mirrors the `admin` role into Identity. This only works for a **confirmed** account. When the primary email changes, the previous primary admin (granted by bootstrap) loses admin access on its next request; admins promoted via **Make admin** keep their role.
4. The console shows a banner until the admin changes the password (Profile → Change password). Password reset is available on the login page.
5. More admins: Admin → Users → Details → **Make admin**.

If you do not control the `webhub262@gmail.com` inbox, set `ADMIN_EMAILS` to an address you do control before the first login.

## Rate limits, compliance

- Postgres-backed fixed-window rate limits on login records, deposits, withdrawals, chat, game actions, rooms, invites, tickets, KYC and uploads.
- Uploads: PNG/JPG/WEBP only, size-capped, magic-byte checked, stored in private Blobs; screenshots and KYC images are served only to admins (`/api/admin/*`).
- Age: 18+ checkbox at sign-up, date of birth required before deposits. Responsible play: personal daily deposit limit and self-exclusion (can only be extended). Jurisdiction: admin-configurable blocked countries (by Netlify geo header) for deposits. KYC: CNIC + photo review queue.

## Testing

- `pnpm test` — unit tests (rules engine, UI primitives).
- `LKA_IT_DB=postgres://… pnpm vitest run src/server/integration.test.ts` — integration tests against a real Postgres (ledger idempotency, duplicate-TID rejection, a full server-run 1v1 game, optimistic locking, referral payout once, tournament settlement once).
- `LKA_IT_DB=postgres://… pnpm vitest run src/server/stakes.integration.test.ts` — coin entry: single deduction, payout once, insufficient balance, cancel/void refunds, forfeits, draws, server-run pool/carrom shots, Ludo coin match. Run the two files one at a time (the local dev DB allows a single connection).
- Local DB: `netlify dev`, then `netlify db migrations apply` (with the remote `NETLIFY_DB_URL` unset) to migrate the local dev database.

## Deployment

Push to `main`. Netlify builds with `vite build`, applies pending migrations automatically, and enables Identity. No secrets or service-account keys are needed; the database and Blobs are wired by the platform.
