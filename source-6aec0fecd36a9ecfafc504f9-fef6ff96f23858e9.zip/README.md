# Ludo King Arena

Live multiplayer Ludo for friends and rivals: 1v1 duels, 2v2 team battles, four-player classics, private rooms, tournaments, leaderboards and a coin wallet. Deposits through EasyPaisa, JazzCash and SadaPay are verified by a person before coins are credited. Admins work from a separate console.

## What's in the app today

- **Landing page & splash** at `/`
- **Login / Register** at `/login` and `/register` (Google button, email verification, password reset)
- **Player app** under `/app`: home dashboard, Play (lobby + playable Ludo board), Tournaments, Wallet, Buy coins (deposit), Withdraw, Transactions, Friends, Leaderboard, Profile
- **Admin console** at `/admin`: overview, deposit verification, withdrawals, users, tournaments, referrals & promos, game config, support, admin log

Accounts (Netlify Identity), the server-side wallet ledger, live multiplayer with server-rolled dice, manual deposit verification, tournaments, referrals and the admin console are backed by Netlify Database and Blobs. See [docs/backend.md](docs/backend.md) for the data model, security model, first-admin setup and testing, and [PLAN.md](PLAN.md) for what is next.

## Tech

- TanStack Start (React 19, TanStack Router, Vite) deployed on Netlify
- Tailwind CSS 4 with theme variables in `src/styles.css`
- shadcn/ui components (Radix) and lucide icons
- Images served through Netlify Image CDN
- Planned: Netlify Identity, Netlify Database (Postgres + Drizzle), Netlify Blobs, Netlify Functions

## Run locally

```bash
pnpm install
netlify dev        # or: pnpm dev
pnpm test          # unit tests, including the Ludo rules engine
```

## Roadmap

1. ✅ Product surface and playable board
2. Accounts and profiles
3. Server-authoritative wallet ledger
4. Live multiplayer
5. Deposits and admin verification
6. Tournaments and referrals
7. Notifications
8. Trust, safety and compliance (KYC, limits, rate limiting; manual winnings withdrawals with admin review)
9. Android and iOS apps

Details are in [PLAN.md](PLAN.md).
